/* Registry and error-classification regression on a native NT5 guest.
   Creates a unique volatile test key in HKCU and writes P5CASES.TXT. */
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include "P5VIEW.H"
#include "P5STAGE.H"
void *memset(void *p,int value,size_t n){unsigned char *q=p;while(n--)*q++=(unsigned char)value;return p;}
static char report[3500];static unsigned count,failures;
static void check(const char *name,int passed)
{
    ++count;if(!passed)++failures;
    lstrcatA(report,passed?"PASS  ":"FAIL  ");lstrcatA(report,name);lstrcatA(report,"\r\n");
}
static HKEY create(HKEY parent,const char *leaf)
{
    HKEY key;DWORD disposition;
    if(RegCreateKeyExA(parent,leaf,0,NULL,REG_OPTION_VOLATILE,KEY_ALL_ACCESS,NULL,&key,&disposition))return NULL;
    if(disposition==REG_CREATED_NEW_KEY)return key;
    RegCloseKey(key);return NULL;
}
static BYTE data[276];
static void table(void)
{
    unsigned i,sum=0;
    data[0]='F';data[1]='A';data[2]='C';data[3]='P';
    data[4]=20;data[5]=1;data[8]=6;data[9]=0;
    for(i=0;i<sizeof(data);++i)sum+=data[i];
    data[9]=(BYTE)(0-sum);
}
static BOOL put(HKEY key,const char *name,DWORD type)
{
    return RegSetValueExA(key,name,0,type,data,sizeof(data))==ERROR_SUCCESS;
}
static void cache(void)
{
    char path[90];struct wp_fwtable info;HKEY root,fadt=NULL,oem=NULL,alias=NULL;
    wsprintfA(path,"Software\\WinpowerTest%08lX%08lX",GetCurrentProcessId(),GetTickCount());
    root=create(HKEY_CURRENT_USER,path);
    check("private volatile registry fixture created",root!=NULL);if(!root)return;
    check("no firmware table",wp5_cached_fadt(root,&info)==ERROR_NOT_FOUND && !info.revision);
    fadt=create(root,"FADT");if(fadt)oem=create(fadt,"OEM");alias=create(root,"FACP");
    check("both registry layouts created",oem && alias);
    if(oem && alias){
        data[131]=5;table();
        check("binary table in a nested OEM key",put(oem,"00000000",REG_BINARY) &&
              !wp5_cached_fadt(root,&info) && info.revision==6 && info.minor_valid && info.minor_revision==5);
        check("identical FACP alias",put(alias,"",REG_BINARY) && !wp5_cached_fadt(root,&info));
        data[131]=4;table();
        check("conflicting valid FADTs",put(alias,"",REG_BINARY) &&
              wp5_cached_fadt(root,&info)==ERROR_INVALID_DATA && !info.revision);
        RegDeleteValueA(oem,"00000000");
        check("default binary value under FACP",!wp5_cached_fadt(root,&info) && info.minor_revision==4);
        ++data[9];
        check("invalid table checksum",put(alias,"",REG_BINARY) &&
              wp5_cached_fadt(root,&info)==ERROR_NOT_FOUND && !info.revision);
        table();
        check("non-binary value ignored",put(alias,"",REG_SZ) && wp5_cached_fadt(root,&info)==ERROR_NOT_FOUND);
    }
    if(oem){RegCloseKey(oem);RegDeleteKeyA(fadt,"OEM");}
    if(fadt){RegCloseKey(fadt);RegDeleteKeyA(root,"FADT");}
    if(alias){RegCloseKey(alias);RegDeleteKeyA(root,"FACP");}
    RegCloseKey(root);RegDeleteKeyA(HKEY_CURRENT_USER,path);
}
static void problems(void)
{
    DWORD reply[8]={6,1,0,1,1,0,0,0},error;
    const char *reason;
    reason=wp5_problem(0,0,reply,60,&error);
    check("live driver lacking final registration has no fabricated Win32 error",
          reason && !error && !lstrcmpA(reason,"The driver found a power-off path, but the Windows final shutdown handoff is unavailable."));
    reply[5]=0x100;
    check("ready handoff",!wp5_problem(0,0,reply,60,&error) && !error);
    reply[4]=0;
    check("no firmware power-off path",wp5_problem(0,0,reply,30,&error)!=NULL && !error);
    reply[0]=5;
    check("old status format",wp5_problem(0,0,reply,60,&error)!=NULL && !error);
    check("missing service preserves 1060",wp5_problem(1060,2,reply,0,&error)!=NULL && error==1060);
    check("disabled service preserves 1058",wp5_problem(1058,2,reply,0,&error)!=NULL && error==1058);
    check("device access error preserved",wp5_problem(0,5,reply,0,&error)!=NULL && error==5);
    check("unrecognized device format preserved",wp5_problem(0,ERROR_REVISION_MISMATCH,reply,0,&error)!=NULL && error==ERROR_REVISION_MISMATCH);
    reason=wp5_problem(50,2,reply,WP5_PREP,&error);
    check("firmware refusal preserves actual SCM status 50",error==50 && reason &&
          !lstrcmpA(reason,"Driver startup stopped during firmware discovery. Windows retains power control."));
}
void WINAPI WinMainCRTStartup(void)
{
    char path[MAX_PATH],line[80];HANDLE h;DWORD n,bytes;char *leaf;
    cache();problems();
    wsprintfA(line,"%u checks, %u failures\r\n",count,failures);lstrcatA(report,line);
    n=GetModuleFileNameA(NULL,path,MAX_PATH);
    if(!n||n>=MAX_PATH)ExitProcess(2);
    leaf=path+n;while(leaf!=path && leaf[-1]!='\\')--leaf;
    if(leaf==path || leaf-path+(int)sizeof("P5CASES.TXT")>MAX_PATH)ExitProcess(2);
    lstrcpyA(leaf,"P5CASES.TXT");h=CreateFileA(path,GENERIC_WRITE,FILE_SHARE_READ,NULL,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,NULL);
    if(h==INVALID_HANDLE_VALUE)ExitProcess(2);
    n=(DWORD)lstrlenA(report);
    if(!WriteFile(h,report,n,&bytes,NULL)||n!=bytes||!FlushFileBuffers(h))++failures;
    CloseHandle(h);ExitProcess(failures?1:0);
}
