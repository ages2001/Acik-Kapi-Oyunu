/* Read-only firmware and NT5 handoff report. Writes beside the executable. */
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <setupapi.h>
#include "P5VIEW.H"
#include "P5SCM.H"
#include "FWVER.H"
#include "OSNAME.H"

void *memset(void *p,int value,size_t n){unsigned char *q=p;while(n--)*q++=(unsigned char)value;return p;}
static char report[8192],path[MAX_PATH];
static DWORD used;
static void field(const char *key,const char *value)
{
    DWORD n=(DWORD)lstrlenA(key), m=(DWORD)lstrlenA(value);
    if(used+n+m+5>sizeof(report))return;
    lstrcpyA(report+used,key);used+=n;
    lstrcpyA(report+used,": ");used+=2;
    lstrcpyA(report+used,value);used+=m;
    lstrcpyA(report+used,"\r\n");used+=2;
}
static void number(const char *key,DWORD value)
{
    char text[20];wsprintfA(text,"%lu",value);field(key,text);
}
static void outcome(const char *key,DWORD error)
{
    char text[64];
    if(error)wsprintfA(text,"Unavailable (status %lu)",error);
    else lstrcpyA(text,"OK");
    field(key,text);
}
/* Registry and SetupAPI strings have explicit byte counts. Bound all scans,
   join multi-strings, and keep firmware-supplied text on one report line. */
static void string_field(const char *label,const char *data,DWORD length)
{
    DWORD i,n=0;char text[256];int separator=0;
    for(i=0;i<length && n+1<sizeof(text);++i){
        unsigned c=(unsigned char)data[i];
        if(!c){if(i+1==length||!data[i+1])break;separator=1;continue;}
        if(separator){if(n+4>=sizeof(text))break;text[n++]=' ';text[n++]='/';text[n++]=' ';separator=0;}
        text[n++]=c<32||c==127?' ':(char)c;
    }
    text[n]=0;field(label,n?text:"N/A");
}
static void reg_text(const char *label,const char *subkey,const char *value)
{
    HKEY key;
    DWORD type,size=512;
    char data[512];
    LONG error=RegOpenKeyExA(HKEY_LOCAL_MACHINE,subkey,0,KEY_QUERY_VALUE,&key);
    if(!error){
        error=RegQueryValueExA(key,value,NULL,&type,(BYTE*)data,&size);
        RegCloseKey(key);
        if(!error && type!=REG_SZ && type!=REG_MULTI_SZ && type!=REG_EXPAND_SZ)error=ERROR_INVALID_DATA;
    }
    if(error)outcome(label,error);else string_field(label,data,size);
}
static void computer(void)
{
    static const GUID cls={0x4d36e966,0xe325,0x11ce,{0xbf,0xc1,0x08,0x00,0x2b,0xe1,0x03,0x18}};
    typedef HDEVINFO (WINAPI *GETDEVS)(const GUID *,PCSTR,HWND,DWORD);
    typedef BOOL (WINAPI *ENUMDEV)(HDEVINFO,DWORD,PSP_DEVINFO_DATA);
    typedef BOOL (WINAPI *GETPROP)(HDEVINFO,PSP_DEVINFO_DATA,DWORD,PDWORD,PBYTE,DWORD,PDWORD);
    typedef BOOL (WINAPI *ENDDEVS)(HDEVINFO);
    HMODULE mod;char library[MAX_PATH];UINT length=GetSystemDirectoryA(library,MAX_PATH);
    GETDEVS devices;ENUMDEV enumerate;GETPROP property;ENDDEVS done;
    HDEVINFO set;SP_DEVINFO_DATA dev;DWORD type,n,error=0;
    char text[512];
    if(!length||length>=MAX_PATH-sizeof("\\SETUPAPI.DLL")){outcome("Present computer device",ERROR_BAD_PATHNAME);return;}
    lstrcatA(library,"\\SETUPAPI.DLL");mod=LoadLibraryA(library);
    if(!mod){outcome("Present computer device",GetLastError());return;}
    devices=(GETDEVS)GetProcAddress(mod,"SetupDiGetClassDevsA");
    enumerate=(ENUMDEV)GetProcAddress(mod,"SetupDiEnumDeviceInfo");
    property=(GETPROP)GetProcAddress(mod,"SetupDiGetDeviceRegistryPropertyA");
    done=(ENDDEVS)GetProcAddress(mod,"SetupDiDestroyDeviceInfoList");
    if(!devices||!enumerate||!property||!done)error=ERROR_PROC_NOT_FOUND;
    else{
        set=devices(&cls,NULL,NULL,DIGCF_PRESENT);
        if(set==INVALID_HANDLE_VALUE)error=GetLastError();
        else{
            dev.cbSize=sizeof(dev);
            if(!enumerate(set,0,&dev))error=GetLastError();
            else{
                if(property(set,&dev,SPDRP_DEVICEDESC,&type,(BYTE*)text,sizeof(text),&n)
                        && type==REG_SZ && n<=sizeof(text))string_field("Present computer device",text,n);
                else field("Present computer device","N/A");
                if(property(set,&dev,SPDRP_HARDWAREID,&type,(BYTE*)text,sizeof(text),&n)
                        && type==REG_MULTI_SZ && n<=sizeof(text))string_field("Computer hardware IDs",text,n);
            }
            done(set);
        }
    }
    FreeLibrary(mod);
    if(error)outcome("Present computer device",error);
}
static void service(void)
{
    SC_HANDLE mgr,svc;SERVICE_STATUS ss;DWORD error;
    mgr=OpenSCManagerA(NULL,NULL,SC_MANAGER_CONNECT);
    if(!mgr){outcome("Service manager",GetLastError());return;}
    svc=OpenServiceA(mgr,WP5_NAME,SERVICE_QUERY_STATUS);
    error=svc?0:GetLastError();
    if(svc){
        if(!QueryServiceStatus(svc,&ss))error=GetLastError();
        else{
            const char *state=ss.dwCurrentState==SERVICE_RUNNING?"Running":
                ss.dwCurrentState==SERVICE_STOPPED?"Stopped":"Transition or paused";
            field("WINPWR5 state",state);number("Service Win32 exit code",ss.dwWin32ExitCode);
            number("Service-specific exit code",ss.dwServiceSpecificExitCode);
        }
        CloseServiceHandle(svc);
    }
    CloseServiceHandle(mgr);outcome("WINPWR5 status query",error);
}
static int nt5(const struct wp_fwtable *api_info)
{
    static const char cpu[]="HARDWARE\\DESCRIPTION\\System\\CentralProcessor\\0";
    static const char bios[]="HARDWARE\\DESCRIPTION\\System\\BIOS";
    SYSTEM_INFO sys;struct wp_fwtable cache;DWORD e,stage,s[8]={0};char line[120];
    GetSystemInfo(&sys);
    number("Windows-visible logical processors",sys.dwNumberOfProcessors);
    reg_text("Processor",cpu,"ProcessorNameString");reg_text("Processor identifier",cpu,"Identifier");
    reg_text("Board manufacturer",bios,"BaseBoardManufacturer");reg_text("Board model",bios,"BaseBoardProduct");
    reg_text("BIOS version","HARDWARE\\DESCRIPTION\\System","SystemBiosVersion");
    reg_text("BIOS date","HARDWARE\\DESCRIPTION\\System","SystemBiosDate");
    computer(); service();
    e=wp5_stage(&stage);outcome("Last recorded WINPWR5 stage query",e);
    if(!e){wsprintfA(line,"%lu (%s)",stage,wp5_stage_text(stage));field("Last recorded WINPWR5 stage",line);}
    e=wp5_reg_fadt(&cache);outcome("Windows ACPI registry FADT",e);
    if(!e){wp_fw_text(&cache,line);field("Registry ACPI revision",line);number("Registry FADT bytes",cache.table_length);}
    e=wp5_status(s);outcome("Live WINPOWER device query",e);
    if(!e){
        number("Driver status format",s[0]);
        if(s[0]==6){
            field("Driver ACPI S5 path",s[4]&1?"Available":"Unavailable");
            field("Driver APM power-off path",s[4]&16?"Available":"Unavailable");
            field("Windows final handoff",s[5]&0x100?"Available":"Unavailable");
            field("Live owner",s[5]&1?"WINPOWER driver":"Operating system");
            if(s[3]){pn_acpitext(s[2],s[3],wp_minor(s[4]),line);field("Driver ACPI revision",line);}
            if(s[7]){pn_apmtext(s[7],line);field("Driver APM revision",line);}
        }
    }
    /* Metadata from the last attempt may describe an earlier boot.
       Only Windows firmware data and a live reply identify this boot. */
    if(api_info->revision)wp_fw_text(api_info,line);
    else if(cache.revision)wp_fw_text(&cache,line);
    else if(!e && s[0]==6 && s[3])pn_acpitext(s[2],s[3],wp_minor(s[4]),line);
    else lstrcpyA(line,"N/A");
    field("ACPI revision available this boot",line);
    return lstrcmpA(line,"N/A")!=0;
}
static DWORD save(void)
{
    DWORD n=GetModuleFileNameA(NULL,path,MAX_PATH),written,error=0;int i;HANDLE file;
    if(!n||n>=MAX_PATH)return ERROR_INVALID_NAME;
    for(i=(int)n-1;i>=0&&path[i]!='\\';--i){}
    if(i<0||i+1+(int)sizeof("FWAUDIT.TXT")>MAX_PATH)return ERROR_FILENAME_EXCED_RANGE;
    lstrcpyA(path+i+1,"FWAUDIT.TXT");
    file=CreateFileA(path,GENERIC_WRITE,FILE_SHARE_READ,NULL,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,NULL);
    if(file==INVALID_HANDLE_VALUE)return GetLastError();
    if(!WriteFile(file,report,used,&written,NULL))error=GetLastError();
    else if(written!=used)error=ERROR_WRITE_FAULT;
    else if(!FlushFileBuffers(file))error=GetLastError();
    CloseHandle(file);return error;
}
void WINAPI WinMainCRTStartup(void)
{
    OSVERSIONINFOA os;struct wp_fwtable fw;char line[96],dialog[MAX_PATH+170];DWORD error;
    int revision_found;BOOL ok,api;HMODULE kernel=GetModuleHandleA("KERNEL32.DLL");
    ZeroMemory(&os,sizeof(os));os.dwOSVersionInfoSize=sizeof(os);ok=GetVersionExA(&os);
    api=kernel&&GetProcAddress(kernel,"GetSystemFirmwareTable")!=NULL;
    field("WINPOWER v1.0","Read-only firmware and power diagnostics");
    number("GetVersionEx success",ok!=0);number("OS platform",os.dwPlatformId);
    wsprintfA(line,"%lu.%lu build %lu",os.dwMajorVersion,os.dwMinorVersion,os.dwBuildNumber);
    field("OS reported version",line);field("Service pack",os.szCSDVersion[0]?os.szCSDVersion:"None reported");
    number("GetSystemFirmwareTable available",api);revision_found=wp_fw_query(&fw);number("Validated FADT query",revision_found);
    wp_fw_text(&fw,line);field("Firmware API revision",line);number("Table length",fw.table_length);
    number("FADT revision",fw.revision);number("Minor available",fw.minor_valid);
    number("Minor revision",fw.minor_revision);
    if(fw.flags_valid)wsprintfA(line,"0x%08lX (advertised)",fw.flags);else lstrcpyA(line,"N/A");
    field("Firmware API flags",line);number("Capability interpretation available",fw.capabilities_valid);
    if(fw.capabilities_valid){
        number("Reset register advertised",fw.reset_register);number("Hardware-reduced advertised",fw.hardware_reduced);
        number("Low-power S0 advertised",fw.low_power_s0);
    }
    if(ok && os.dwPlatformId==VER_PLATFORM_WIN32_NT && os.dwMajorVersion==5)revision_found=nt5(&fw);
    error=save();
    if(error)wsprintfA(dialog,"Could not save FWAUDIT.TXT beside this application (status %lu). Open FWAUDIT.EXE from a writable folder.",error);
    else wsprintfA(dialog,"Read-only diagnostics saved to:\r\n%s",path);
    MessageBoxA(NULL,dialog,"WINPOWER firmware audit",MB_OK|(error?MB_ICONEXCLAMATION:MB_ICONINFORMATION));
    ExitProcess(error?1:(revision_found?0:2));
}
