/* Single inert method added by QEMU to the refusal profile. */
DefinitionBlock ("", "SSDT", 2, "WPTEST", "PREPTEST", 1)
{
    Method (\_PTS, 1, NotSerialized)
    {
        Return (Zero)
    }
}
