/* Run only on a marked, writable QA volume with a private Windows guest.
   Exercise the distributed GUI and record its real owner selection/dialog. */
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
static DWORD pid;
static HWND mainwin,dialog;
static char report[4000],home[MAX_PATH],path[MAX_PATH];
static BOOL CALLBACK locate(HWND h,LPARAM unused)
{
    DWORD id;char cls[40];(void)unused;
    GetWindowThreadProcessId(h,&id);
    if(id!=pid)return TRUE;
    GetClassNameA(h,cls,sizeof(cls));
    if(!lstrcmpA(cls,"WINPOWER"))mainwin=h;
    else if(!lstrcmpA(cls,"#32770"))dialog=h;
    return TRUE;
}
static BOOL CALLBACK caption(HWND h,LPARAM unused)
{
    char cls[32],line[750];(void)unused;
    GetClassNameA(h,cls,sizeof(cls));
    if(!lstrcmpiA(cls,"Static") && GetWindowTextA(h,line,sizeof(line))>1){
        lstrcatA(report,"Dialog: ");lstrcatA(report,line);lstrcatA(report,"\r\n");
    }
    return TRUE;
}
static void name(const char *leaf){lstrcpyA(path,home);lstrcatA(path,leaf);}
static void state(const char *title)
{
    char line[700],owner[70];
    GetDlgItemTextA(mainwin,170,line,sizeof(line));
    wsprintfA(owner,"OS radio=%ld  Driver radio=%ld\r\n",
        (LONG)SendDlgItemMessageA(mainwin,104,BM_GETCHECK,0,0),
        (LONG)SendDlgItemMessageA(mainwin,105,BM_GETCHECK,0,0));
    lstrcatA(report,title);lstrcatA(report,"\r\n");lstrcatA(report,line);lstrcatA(report,"\r\n");lstrcatA(report,owner);
}
static void select_owner(int control)
{
    PostMessageA(mainwin,WM_COMMAND,MAKEWPARAM(control,BN_CLICKED),(LPARAM)GetDlgItem(mainwin,control));
}
void WINAPI WinMainCRTStartup(void)
{
    STARTUPINFOA si={sizeof(si)};PROCESS_INFORMATION pr;HANDLE file;
    DWORD n,i,bytes;BOOL denied;
    n=GetModuleFileNameA(NULL,home,sizeof(home));
    if(!n||n>=MAX_PATH-16)ExitProcess(1);
    while(n && home[n-1]!='\\')--n;
    if(!n)ExitProcess(1);
    home[n]=0;name("SLEEPQA.ID");if(GetFileAttributesA(path)==INVALID_FILE_ATTRIBUTES)ExitProcess(1);
    name("REFUSE.ID");denied=GetFileAttributesA(path)!=INVALID_FILE_ATTRIBUTES;
    name("WINPWRNT.EXE");
    if(!CreateProcessA(path,NULL,NULL,NULL,FALSE,0,NULL,home,&si,&pr))ExitProcess(2);
    pid=pr.dwProcessId;CloseHandle(pr.hThread);
    for(i=0;i<160&&!mainwin;++i){EnumWindows(locate,0);Sleep(100);}
    if(!mainwin)ExitProcess(3);
    Sleep(400);state("Before selection");
    if(!denied){select_owner(104);Sleep(500);state("After selecting Windows");}
    select_owner(105);
    for(i=0;i<200;++i){
        EnumWindows(locate,0);
        if(dialog || (!denied && SendDlgItemMessageA(mainwin,105,BM_GETCHECK,0,0)==BST_CHECKED))break;
        Sleep(100);
    }
    if(dialog){EnumChildWindows(dialog,caption,0);PostMessageA(dialog,WM_COMMAND,IDOK,0);Sleep(500);}
    state("After selecting WINPOWER");
    name("P5UI.TXT");file=CreateFileA(path,GENERIC_WRITE,FILE_SHARE_READ,NULL,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,NULL);
    if(file==INVALID_HANDLE_VALUE)ExitProcess(4);
    n=(DWORD)lstrlenA(report);
    if(!WriteFile(file,report,n,&bytes,NULL)||n!=bytes||!FlushFileBuffers(file))ExitProcess(5);
    CloseHandle(file);PostMessageA(mainwin,WM_CLOSE,0,0);CloseHandle(pr.hProcess);ExitProcess(0);
}
