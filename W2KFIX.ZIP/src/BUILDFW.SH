#!/bin/sh
# Read-only firmware audit utilities; no kernel driver is loaded.
set -eu
cd "$(dirname "$0")"
for arch in i686 x86_64; do
 if [ "$arch" = i686 ]; then cpu='-march=i386 -mno-sse -mno-mmx'; out=X86; entry=_WinMainCRTStartup@0; ver=3.10; else cpu=''; out=X64; entry=WinMainCRTStartup; ver=5.2; fi
 "$arch-w64-mingw32-gcc" $cpu -x c -Os -Wall -Wextra -Werror -Wno-cast-function-type -fno-builtin -fno-stack-protector -nostdlib -mwindows -I. ../TEST/FWAUDIT.C FWAPI.C FWTABLE.C OSNAME.C P5VIEW.C -Wl,--entry,"$entry",--subsystem,windows:$ver -o ../BIN/WINPWRNT/$out/FWAUDIT.EXE -luser32 -lkernel32 -ladvapi32
done
