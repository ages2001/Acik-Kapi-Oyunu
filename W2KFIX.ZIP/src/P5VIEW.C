#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include "P5SCM.H"
#include "P5VIEW.H"
#include "P5STAGE.H"

DWORD wp5_status(DWORD status[8])
{
    DWORD bytes = 0, error = ERROR_SUCCESS;
    HANDLE device = CreateFileA("\\\\.\\PN5LAB", GENERIC_READ,
        FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, OPEN_EXISTING, 0, NULL);
    if (device == INVALID_HANDLE_VALUE) return GetLastError();
    if (!DeviceIoControl(device, 0x226000, NULL, 0, status, 8 * sizeof(DWORD), &bytes, NULL))
        error = GetLastError();
    else if (bytes != 8 * sizeof(DWORD)) error = ERROR_INVALID_DATA;
    else if (status[0] != 5 && status[0] != 6) error = ERROR_REVISION_MISMATCH;
    else if (status[1] != 1) error = ERROR_INVALID_DATA;
    CloseHandle(device);
    return error;
}

DWORD wp5_stage(DWORD *stage)
{
    HKEY key;
    DWORD type, bytes = sizeof(*stage);
    LONG error;
    *stage = 0;
    error = RegOpenKeyExA(HKEY_LOCAL_MACHINE,
        "SYSTEM\\CurrentControlSet\\Services\\" WP5_NAME, 0, KEY_QUERY_VALUE, &key);
    if (error) return error;
    error = RegQueryValueExA(key, "Stage", NULL, &type, (BYTE *)stage, &bytes);
    RegCloseKey(key);
    if (!error && (type != REG_DWORD || bytes != sizeof(*stage))) error = ERROR_INVALID_DATA;
    if (error) *stage = 0;
    return error;
}

const char *wp5_stage_text(DWORD stage)
{
    switch (stage) {
    case 10: return "Windows version and processor check";
    case 30: return "ACPI and APM discovery";
    case 40: return "Driver device registration";
    case 60: return "Driver initialization completed";
    case WP5_BASIC: return "Windows memory information unavailable";
    case WP5_BDA: return "BIOS data area unavailable";
    case WP5_RSDP: return "No valid ACPI root pointer in the BIOS search areas";
    case WP5_ALLOC: return "Firmware table workspace unavailable";
    case WP5_FADT: return "ACPI root or fixed description table could not be validated";
    case WP5_LAYOUT: return "ACPI register layout or table configuration unsupported";
    case WP5_DSDT: return "ACPI definition table could not be validated";
    case WP5_SLEEP: return "Firmware S5 sleep data or preparation could not be used";
    case WP5_BIND: return "ACPI sleep registers could not be bound";
    case WP5_PREP: return "S5 requires firmware preparation unavailable at the final callback";
    case WP5_NOTIFY: return "Windows shutdown notification registration unavailable";
    case WP5_FINAL: return "Windows final shutdown handoff unavailable";
    default: return "No recognized stage";
    }
}

/* Return a numerical Windows error only for an operation that failed.
   Firmware checks from a successful device reply have no Win32 error. */
const char *wp5_problem(DWORD start_error, DWORD query_error, const DWORD s[8],
                        DWORD stage, DWORD *winerror)
{
    *winerror = 0;
    if (!query_error) {
        if (s[0] == 5) return "An older driver is loaded. Run HNDLOAD.EXE, then restart Windows.";
        if (!(s[4] & 0x11)) return "The driver reports no usable ACPI S5 or APM power-off path.";
        if (!(s[5] & 0x100)) return "The driver found a power-off path, but the Windows final shutdown handoff is unavailable.";
        return NULL;
    }
    if (query_error != ERROR_FILE_NOT_FOUND && query_error != ERROR_PATH_NOT_FOUND) {
        *winerror = query_error;
        if (query_error == ERROR_ACCESS_DENIED) return "Access to the WINPOWER status device was denied.";
        if (query_error == ERROR_INVALID_DATA || query_error == ERROR_REVISION_MISMATCH)
            return "The loaded driver's status reply does not match this WINPOWER package.";
        return "The WINPOWER status device could not be queried.";
    }
    *winerror = start_error ? start_error : query_error;
    switch (start_error) {
    case ERROR_SERVICE_DOES_NOT_EXIST: return "The WINPWR5 service is not installed. Run SETUP.EXE from the matching WINPOWER folder.";
    case ERROR_ACCESS_DENIED: return "Windows denied permission to start WINPWR5. Use an administrator account.";
    case ERROR_SERVICE_DISABLED: return "The WINPWR5 service is disabled.";
    case ERROR_FILE_NOT_FOUND: case ERROR_PATH_NOT_FOUND:
        return "Windows could not locate the installed driver image. Check the WINPOWER installation.";
    case ERROR_INVALID_DATA: return "The WINPWR5 service configuration does not match this package.";
    case ERROR_BAD_EXE_FORMAT: return "Windows could not load the driver image. Check the Windows version and architecture.";
    case ERROR_NOT_SUPPORTED:
        if (stage == 30 || (stage >= WP5_BASIC && stage <= WP5_PREP))
            return "Driver startup stopped during firmware discovery. Windows retains power control.";
        return "Windows reported that this driver start is unsupported.";
    case ERROR_SUCCESS: return "WINPWR5 accepted the start request, but its status device is unavailable.";
    default: return "Windows could not start the WINPWR5 driver.";
    }
}

struct cache_search {
    BYTE *first;
    DWORD length, visits;
};
static DWORD visit_table(HKEY key, unsigned depth, struct cache_search *search)
{
    DWORD index, nch, type, size, got, i, result;
    LONG error;
    char name[256];
    BYTE *data;
    HKEY child;
    struct wp_fwtable candidate;
    for (index = 0; ; ++index) {
        nch = sizeof(name);
        error = RegEnumValueA(key, index, name, &nch, NULL, &type, NULL, &size);
        if (error == ERROR_NO_MORE_ITEMS) break;
        if (error) return error;
        if (++search->visits > 256) return ERROR_MORE_DATA;
        if (type != REG_BINARY || size < 36 || size > WP_FADT_MAX) continue;
        data = (BYTE *)LocalAlloc(LMEM_FIXED, size);
        if (!data) return ERROR_NOT_ENOUGH_MEMORY;
        got = size;
        error = RegQueryValueExA(key, name, NULL, &type, data, &got);
        if (!error && type == REG_BINARY && got == size && wp_fadt(data, got, &candidate)) {
            if (!search->first) { search->first = data; search->length = got; continue; }
            if (search->length != got) error = ERROR_INVALID_DATA;
            else for (i = 0; i < got; ++i)
                if (search->first[i] != data[i]) { error = ERROR_INVALID_DATA; break; }
        }
        LocalFree(data);
        if (error) return error;
    }
    for (index = 0; ; ++index) {
        nch = sizeof(name);
        error = RegEnumKeyExA(key, index, name, &nch, NULL, NULL, NULL, NULL);
        if (error == ERROR_NO_MORE_ITEMS) return ERROR_SUCCESS;
        if (error) return error;
        if (depth >= 6 || ++search->visits > 256) return ERROR_MORE_DATA;
        error = RegOpenKeyExA(key, name, 0, KEY_READ, &child);
        if (error) return error;
        result = visit_table(child, depth + 1, search);
        RegCloseKey(child);
        if (result) return result;
    }
}

DWORD wp5_cached_fadt(HKEY acpi, struct wp_fwtable *info)
{
    static const char *const keys[] = {"FADT", "FACP"};
    struct cache_search search = {NULL, 0, 0};
    DWORD error = ERROR_SUCCESS;
    HKEY key;
    unsigned i;
    wp_fw_clear(info);
    for (i = 0; i < 2; ++i) {
        error = RegOpenKeyExA(acpi, keys[i], 0, KEY_READ, &key);
        if (error == ERROR_FILE_NOT_FOUND || error == ERROR_PATH_NOT_FOUND) { error = 0; continue; }
        if (error) break;
        error = visit_table(key, 0, &search);
        RegCloseKey(key);
        if (error) break;
    }
    if (!error && !search.first) error = ERROR_NOT_FOUND;
    if (!error && !wp_fadt(search.first, search.length, info)) error = ERROR_INVALID_DATA;
    if (search.first) LocalFree(search.first);
    return error;
}

DWORD wp5_reg_fadt(struct wp_fwtable *info)
{
    HKEY acpi;
    LONG error;
    wp_fw_clear(info);
    error = RegOpenKeyExA(HKEY_LOCAL_MACHINE, "HARDWARE\\ACPI", 0, KEY_READ, &acpi);
    if (!error) {
        error = wp5_cached_fadt(acpi, info);
        RegCloseKey(acpi);
    }
    return error;
}
