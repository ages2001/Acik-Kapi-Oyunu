#ifndef WINPOWER_P5STAGE_H
#define WINPOWER_P5STAGE_H
/* Last attempt, on this service only. The original driver uses 10,30,40,60. */
#define WP5_BASIC 70
#define WP5_BDA   71
#define WP5_RSDP  72
#define WP5_ALLOC 73
#define WP5_FADT  74
#define WP5_LAYOUT 75
#define WP5_DSDT  76
#define WP5_SLEEP 77
#define WP5_BIND  78
#define WP5_PREP  79
#define WP5_NOTIFY 80
#define WP5_FINAL 81
#endif
