#ifndef WINPOWER_P5VIEW_H
#define WINPOWER_P5VIEW_H
#include "FWAPI.H"

/* A read-only query of the existing NT5 device. An open error, an IOCTL
   error, an invalid reply and a valid reply with no handoff stay distinct. */
DWORD wp5_status(DWORD status[8]);
DWORD wp5_stage(DWORD *stage);
const char *wp5_stage_text(DWORD stage);
const char *wp5_problem(DWORD start_error, DWORD query_error, const DWORD status[8],
                        DWORD stage, DWORD *winerror);

/* Search only the firmware's FADT/FACP cache under the supplied ACPI key. */
DWORD wp5_cached_fadt(HKEY acpi, struct wp_fwtable *info);
DWORD wp5_reg_fadt(struct wp_fwtable *info);
#endif
