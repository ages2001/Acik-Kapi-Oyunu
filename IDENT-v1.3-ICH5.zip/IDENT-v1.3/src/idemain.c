#include "ident.h"

/* idemain.c - DriverEntry, controller and channel discovery (PCI native
   and compatibility mode, legacy ISA), initialization, ScsiPort entry
   points, interrupt watchdog, power */

BOOLEAN IdeHwInitialize(IN PVOID DeviceExtension);
BOOLEAN IdeStartIo(IN PVOID DeviceExtension, IN PSCSI_REQUEST_BLOCK Srb);
BOOLEAN IdeInterrupt(IN PVOID DeviceExtension);
BOOLEAN IdeResetBus(IN PVOID HwDeviceExtension, IN ULONG PathId);
ULONG   IdeFindAdapter(IN PVOID DeviceExtension, IN PVOID Context, IN PVOID BusInformation,
                       IN PCHAR ArgumentString, IN OUT PPORT_CONFIGURATION_INFORMATION ConfigInfo,
                       OUT PBOOLEAN Again);
VOID    IdeTimer(IN PVOID DeviceExtension);
static VOID IdeArmHotPlug(IN PHW_DEVICE_EXTENSION HwInit);
#ifdef IDE_W9X
BOOLEAN IdeAdapterState(IN PVOID DeviceExtension, IN PVOID Context, IN BOOLEAN SaveState);
#endif
#if !defined(IDE_NT4)
SCSI_ADAPTER_CONTROL_STATUS IdeAdapterControl(IN PVOID DeviceExtension,
                                              IN SCSI_ADAPTER_CONTROL_TYPE ControlType,
                                              IN PVOID Parameters);
#endif

/* Crash dump / hibernation copy of the driver (DriverEntry without a
   driver object): polled, no registry access. */
static BOOLEAN g_IdeDumpMode;
/* The disk class driver reads READ CAPACITY(16) when READ CAPACITY(10)
   reports FFFFFFFFh: Server 2003 SP1 and later, XP x64 */
static BOOLEAN g_IdeCapacity16;

/* ------------------------------------------------------------------ */
/* Windows 9x: VMM services                                            */
/* ------------------------------------------------------------------ */

#ifdef IDE_W9X

#define VMM_DEVICE_ID                   0x0001
#define Debug_Printf_Service_Ordinal    0x012D

/* _MapPhysToLinear(PhysAddr, nBytes, flags): a memory-mapped BAR. The 9x
   ScsiPortGetDeviceBase does not map one reliably (KB Q169584). VMM
   service 006Ch, called through int 20h; 0xFFFFFFFF on failure. */
#ifdef __GNUC__
static PVOID
IdeMapPhysToLinear(ULONG PhysAddr, ULONG Bytes)
{
    PVOID linear;

    __asm__ __volatile__(
        "pushl $0\n\t"
        "pushl %2\n\t"
        "pushl %1\n\t"
        "int $0x20\n\t"
        ".word 0x006C\n\t"
        ".word 0x0001\n\t"
        "addl $12, %%esp"
        : "=a" (linear)
        : "r" (PhysAddr), "r" (Bytes)
        : "ecx", "edx", "memory", "cc");
    return linear;
}
#else
static PVOID
IdeMapPhysToLinear(ULONG PhysAddr, ULONG Bytes)
{
    PVOID linear;

    __asm push 0
    __asm push Bytes
    __asm push PhysAddr
    __asm int  0x20
    __asm _emit 0x6C
    __asm _emit 0x00
    __asm _emit ((VMM_DEVICE_ID >> 0) & 0xFF)
    __asm _emit ((VMM_DEVICE_ID >> 8) & 0xFF)
    __asm add  esp, 3*4
    __asm mov  linear, eax
    return linear;
}
#endif

#ifdef IDE_DBG_ENABLED
/* _Debug_Printf_Service(format, argptr): WDEB386, SoftICE or DebugView */
VOID __cdecl
IdeDbgPrint(PCHAR Format, ...)
{
    __asm lea  eax, (Format + 4)
    __asm push eax
    __asm push Format
    __asm int  0x20
    __asm _emit ((Debug_Printf_Service_Ordinal >> 0) & 0xFF)
    __asm _emit ((Debug_Printf_Service_Ordinal >> 8) & 0xFF)
    __asm _emit ((VMM_DEVICE_ID >> 0) & 0xFF)
    __asm _emit ((VMM_DEVICE_ID >> 8) & 0xFF)
    __asm add  esp, 2*4
}
#endif

/* Required: SCSIPORT.PDR reports "Init Failure" if HwAdapterState is NULL.
   On "restore" the BIOS may have reset the drives (APM resume): the next
   request puts the transfer modes and settings back (see IdeCheckState). */
BOOLEAN
IdeAdapterState(IN PVOID DeviceExtension, IN PVOID Context, IN BOOLEAN SaveState)
{
    (VOID)Context;
    IDE_DBG((IDE_PFX "AdapterState: %s\n", SaveState ? "save" : "restore"));
    if (!SaveState) ((PHW_DEVICE_EXTENSION)DeviceExtension)->CheckState = TRUE;
    return TRUE;
}

#endif /* IDE_W9X */

/* ------------------------------------------------------------------ */
/* Claim table: channels by command port, functions by bus/slot        */
/* ------------------------------------------------------------------ */

#define IDE_MAX_CLAIMED                 (IDE_MAX_CONTROLLERS * 2 + IDE_LEGACY_CHANNELS)

static USHORT g_IdeClaimedPorts[IDE_MAX_CLAIMED];
static ULONG  g_IdeClaimedCount;

static BOOLEAN
IdeIsPortClaimed(IN USHORT CmdPort)
{
    ULONG i;
    for (i = 0; i < g_IdeClaimedCount; i++) {
        if (g_IdeClaimedPorts[i] == CmdPort) return TRUE;
    }
    return FALSE;
}

static VOID
IdeClaimPort(IN USHORT CmdPort)
{
    if (IdeIsPortClaimed(CmdPort)) return;
    if (g_IdeClaimedCount < IDE_MAX_CLAIMED) g_IdeClaimedPorts[g_IdeClaimedCount++] = CmdPort;
}

/* ------------------------------------------------------------------ */
/* PCI configuration access                                            */
/* ------------------------------------------------------------------ */

#define IDE_PCI_HEADER_LENGTH           64
#define IDE_PCI_EXTRA_LENGTH            0xA0        /* with 40h-9Fh: the channel enables */
#define IDE_PCI_MULTIFUNCTION           0x80

#if defined(IDE_NT31_COMPAT) || defined(IDE_W9X)
/* Configuration mechanism #1 through the I/O ports: for a HAL without PCI
   support (NT 3.1), and on 9x for functions other than the device node's
   own (SCSIPORT.PDR reads only that one) */
#define IDE_PCI_PORTS
#define IDE_PCI_CONFIG_ADDRESS          0xCF8
#define IDE_PCI_CONFIG_DATA             0xCFC
#define IDE_PCI_CONFIG_ENABLE           0x80000000UL

static VOID
IdePciSelect(IN ULONG Bus, IN ULONG Slot, IN ULONG Offset)
{
    PCI_SLOT_NUMBER slot;

    slot.u.AsULONG = Slot;
    ScsiPortWritePortUlong((PULONG)IDE_PCI_CONFIG_ADDRESS,
                           IDE_PCI_CONFIG_ENABLE | ((Bus & 0xFF) << 16) |
                           ((ULONG)slot.u.bits.DeviceNumber << 11) |
                           ((ULONG)slot.u.bits.FunctionNumber << 8) |
                           (Offset & 0xFC));
}

static ULONG
IdePciReadPortDword(IN ULONG Bus, IN ULONG Slot, IN ULONG Offset)
{
    IdePciSelect(Bus, Slot, Offset);
    return ScsiPortReadPortUlong((PULONG)IDE_PCI_CONFIG_DATA);
}

/* 40h-9Fh of a function (the channel enables) */
static VOID
IdePciReadPortExtra(IN ULONG Bus, IN ULONG Slot, OUT PPCI_COMMON_CONFIG PciConfig)
{
    PULONG dw = (PULONG)PciConfig;
    ULONG i;

    for (i = IDE_PCI_HEADER_LENGTH / sizeof(ULONG); i < IDE_PCI_EXTRA_LENGTH / sizeof(ULONG); i++) {
        dw[i] = IdePciReadPortDword(Bus, Slot, i * sizeof(ULONG));
    }
}

static BOOLEAN
IdePciReadPortHeader(IN ULONG Bus, IN ULONG Slot, OUT PPCI_COMMON_CONFIG PciConfig)
{
    PULONG dw = (PULONG)PciConfig;
    ULONG i;

    dw[0] = IdePciReadPortDword(Bus, Slot, 0);
    if ((dw[0] & 0xFFFF) == 0xFFFF || (dw[0] & 0xFFFF) == 0) return FALSE;
    for (i = 1; i < IDE_PCI_HEADER_LENGTH / sizeof(ULONG); i++) {
        dw[i] = IdePciReadPortDword(Bus, Slot, i * sizeof(ULONG));
    }
    if (PciConfig->BaseClass == PCI_CLASS_MASS_STORAGE) IdePciReadPortExtra(Bus, Slot, PciConfig);
    return TRUE;
}

#ifdef IDE_NT31_COMPAT
static VOID
IdePciWritePort(IN ULONG Bus, IN ULONG Slot, IN ULONG Offset, IN ULONG Width, IN ULONG Value)
{
    IdePciSelect(Bus, Slot, Offset & ~3UL);
    if (Width == 1) {
        IDE_OUTB(IDE_PCI_CONFIG_DATA + (Offset & 3), Value);
    } else if (Width == 2) {
        IDE_OUTW(IDE_PCI_CONFIG_DATA + (Offset & 2), Value);
    } else {
        IDE_OUTD(IDE_PCI_CONFIG_DATA, Value);
    }
}
#endif
#endif /* IDE_PCI_PORTS */

#ifdef IDE_NT31_COMPAT
static BOOLEAN g_IdePciProbed;
static BOOLEAN g_IdePciViaPorts;

static VOID
IdePciProbeAccess(IN PHW_DEVICE_EXTENSION HwInit)
{
    ULONG id, save;

    if (g_IdePciProbed) return;
    g_IdePciProbed = TRUE;

    if (ScsiPortGetBusData(HwInit, PCIConfiguration, 0, 0, &id, sizeof(ULONG)) != 0) return;

    save = ScsiPortReadPortUlong((PULONG)IDE_PCI_CONFIG_ADDRESS);
    ScsiPortWritePortUlong((PULONG)IDE_PCI_CONFIG_ADDRESS, IDE_PCI_CONFIG_ENABLE);
    if (ScsiPortReadPortUlong((PULONG)IDE_PCI_CONFIG_ADDRESS) == IDE_PCI_CONFIG_ENABLE) {
        g_IdePciViaPorts = TRUE;
    }
    ScsiPortWritePortUlong((PULONG)IDE_PCI_CONFIG_ADDRESS, save);
    IDE_DBG((IDE_PFX "PCI: no HAL config access, mechanism #1 %s\n",
             g_IdePciViaPorts ? "used" : "not found"));
}
#endif /* IDE_NT31_COMPAT */

/* Configuration space of the extension's own function (timing registers,
   command register) */
ULONG
IdePciReadConfig(IN PHW_DEVICE_EXTENSION HwInit, IN ULONG Offset, IN ULONG Width)
{
    UCHAR buffer[256];
    ULONG value = 0;

    if (!HwInit->HasPci || Offset + Width > sizeof(buffer)) return 0;
#ifdef IDE_NT31_COMPAT
    if (g_IdePciViaPorts) {
        ULONG dw = IdePciReadPortDword(HwInit->PciBus, HwInit->PciSlot, Offset & ~3UL);
        dw >>= 8 * (Offset & 3);
        return (Width == 1) ? (dw & 0xFF) : (Width == 2) ? (dw & 0xFFFF) : dw;
    }
#endif
    if (ScsiPortGetBusData(HwInit, PCIConfiguration, HwInit->PciBus, HwInit->PciSlot,
                           buffer, Offset + Width) < Offset + Width) {
        return 0;
    }
    CopyMemoryBytes(&value, &buffer[Offset], Width);
    return value;
}

static VOID
IdePciWriteConfigAt(IN PHW_DEVICE_EXTENSION HwInit, IN ULONG Bus, IN ULONG Slot,
                    IN ULONG Offset, IN ULONG Width, IN ULONG Value)
{
#ifdef IDE_NT31_COMPAT
    /* No ScsiPortSetBusDataByOffset to import on NT 3.1: configuration
       mechanism #1 through the ports, as the HAL does on x86 */
    (VOID)HwInit;
    IdePciWritePort(Bus, Slot, Offset, Width, Value);
#else
    ScsiPortSetBusDataByOffset(HwInit, PCIConfiguration, Bus, Slot, &Value, Offset, Width);
#endif
}

VOID
IdePciWriteConfig(IN PHW_DEVICE_EXTENSION HwInit, IN ULONG Offset, IN ULONG Width, IN ULONG Value)
{
    if (!HwInit->HasPci) return;
    IdePciWriteConfigAt(HwInit, HwInit->PciBus, HwInit->PciSlot, Offset, Width, Value);
}

static BOOLEAN
IdeReadPciHeader(
    IN PHW_DEVICE_EXTENSION HwInit,
    IN ULONG Bus,
    IN ULONG Slot,
    OUT PPCI_COMMON_CONFIG PciConfig,
    OUT PBOOLEAN BusMissing
)
{
    ULONG bytesRead;

#ifdef IDE_NT31_COMPAT
    if (g_IdePciViaPorts) {
        if (BusMissing != NULL) *BusMissing = FALSE;
        return IdePciReadPortHeader(Bus, Slot, PciConfig);
    }
#endif
    bytesRead = ScsiPortGetBusData(HwInit, PCIConfiguration, Bus, Slot, PciConfig, IDE_PCI_HEADER_LENGTH);
#ifdef IDE_W9X
    if (bytesRead < IDE_PCI_HEADER_LENGTH) {
        if (BusMissing != NULL) *BusMissing = FALSE;
        return IdePciReadPortHeader(Bus, Slot, PciConfig);
    }
#endif
    if (BusMissing != NULL) *BusMissing = (BOOLEAN)(bytesRead == 0);
    if (bytesRead < IDE_PCI_HEADER_LENGTH) return FALSE;
    if (PciConfig->VendorID == 0xFFFF || PciConfig->VendorID == 0x0000) return FALSE;
    /* A mass storage function: also 40h-9Fh, where the chip set keeps its
       channel enables (IdePciChannelEnabled) */
    if (PciConfig->BaseClass == PCI_CLASS_MASS_STORAGE &&
        ScsiPortGetBusData(HwInit, PCIConfiguration, Bus, Slot, PciConfig, IDE_PCI_EXTRA_LENGTH) < IDE_PCI_EXTRA_LENGTH) {
#ifdef IDE_PCI_PORTS
        IdePciReadPortExtra(Bus, Slot, PciConfig);
#else
        ZeroMemoryBytes(PciConfig->DeviceSpecific, IDE_PCI_EXTRA_LENGTH - IDE_PCI_HEADER_LENGTH);
#endif
    }
    return TRUE;
}

/* ------------------------------------------------------------------ */
/* Controller identification                                           */
/* ------------------------------------------------------------------ */

static UCHAR IdeChipKind(IN USHORT VendorId, IN USHORT DeviceId);

/* An IDE function: class 01:01, or a SATA/RAID-class controller that
   still presents IDE task files (its BARs say so: native mode set) */
static BOOLEAN
IdePciConfigIsIde(IN PPCI_COMMON_CONFIG PciConfig)
{
    if (PciConfig->BaseClass != PCI_CLASS_MASS_STORAGE) return FALSE;
    if ((PciConfig->HeaderType & 0x7F) != 0) return FALSE;
    if (PciConfig->SubClass == PCI_SUBCLASS_IDE) return TRUE;

    /* Silicon Image 3112/3512/3114 and the ATI IXP SATA functions built on
       them (SATA, class 0180 or 0104) */
    return (BOOLEAN)IDE_CHIP_IS_SII(IdeChipKind(PciConfig->VendorID, PciConfig->DeviceID));
}

/* Intel PATA controllers whose timing registers the driver programs */
static UCHAR
IdeIntelKind(IN USHORT VendorId, IN USHORT DeviceId)
{
    if (VendorId != 0x8086) return IDE_INTEL_NONE;
    switch (DeviceId) {
    case 0x7010:                                        /* PIIX3 */
    case 0x1230:                                        /* PIIX */
        return IDE_INTEL_PIIX3;
    case 0x7111:                                        /* PIIX4 */
    case 0x7199:                                        /* 82443MX */
    case 0x7601:                                        /* 82372FB */
    case 0x2421:                                        /* ICH0 */
        return IDE_INTEL_PIIX4;
    case 0x2411:                                        /* ICH */
        return IDE_INTEL_ICH66;
    case 0x244A: case 0x244B:                           /* ICH2 */
    case 0x248A: case 0x248B:                           /* ICH3 */
    case 0x24CA: case 0x24CB:                           /* ICH4 */
    case 0x24DB:                                        /* ICH5 */
    case 0x25A2:                                        /* 6300ESB */
    case 0x266F:                                        /* ICH6 */
    case 0x269E:                                        /* 631xESB/632xESB */
    case 0x27DF:                                        /* ICH7 */
    case 0x2850:                                        /* ICH8M */
        return IDE_INTEL_ICH100;
    default:
        return IDE_INTEL_NONE;
    }
}

/* Controller families the driver handles beyond SFF-8038i */
static UCHAR
IdeChipKind(IN USHORT VendorId, IN USHORT DeviceId)
{
    if (VendorId == 0x1095) {
        switch (DeviceId) {
        case 0x0643: return IDE_CHIP_CMD643;
        case 0x0646: return IDE_CHIP_CMD646;
        case 0x0648: return IDE_CHIP_CMD648;
        case 0x0649: return IDE_CHIP_CMD649;
        case 0x3112:
        case 0x0240: return IDE_CHIP_SII3112;
        case 0x3512: return IDE_CHIP_SII3512;
        case 0x3114: return IDE_CHIP_SII3114;
        case 0x0640: return IDE_CHIP_CMD640;
        default:     break;
        }
    } else if (VendorId == 0x1042 && (DeviceId == 0x1000 || DeviceId == 0x1001)) {
        return IDE_CHIP_RZ1000;
    } else if (VendorId == 0x1166) {
        if (DeviceId == 0x0211) return IDE_CHIP_OSB4;
        if (DeviceId == 0x0212 || DeviceId == 0x0213 || DeviceId == 0x0217) return IDE_CHIP_CSB;
    } else if (VendorId == 0x1002) {
        /* ATI IXP 300/400 SATA: Silicon Image 3112 cores */
        if (DeviceId == 0x436E || DeviceId == 0x4379 || DeviceId == 0x437A) return IDE_CHIP_SII3112;
    } else if (VendorId == 0x10B9 && DeviceId == 0x5229) {
        return IDE_CHIP_ALI;
    } else if (VendorId == 0x1106) {
        switch (DeviceId) {
        case 0x0415: case 0x0571: case 0x0581: case 0x1571:
        case 0x3164: case 0x5324: case 0xC409: case 0x9001:
            return IDE_CHIP_VIA;
        default:
            break;
        }
    } else if (VendorId == 0x1022) {
        switch (DeviceId) {
        case 0x7401: case 0x7409: case 0x7411: case 0x7441: case 0x7469:
        case 0x209A: case 0x2092:
            return IDE_CHIP_AMD;
        default:
            break;
        }
    } else if (VendorId == 0x10DE) {
        switch (DeviceId) {
        case 0x01BC: case 0x0065: case 0x0085: case 0x00D5: case 0x00E5:
        case 0x0053: case 0x0035: case 0x0265: case 0x036E: case 0x03EC:
        case 0x0448: case 0x0560: case 0x056C: case 0x0759:
            return IDE_CHIP_AMD;
        default:
            break;
        }
    }
    return IDE_CHIP_GENERIC;
}

/* A CMD64x interrupt latch: cleared when set. TRUE when it was set (the
   interrupt came from this channel). 643/646: CFR/ARTTIM23 in config
   space; 648/649: MRDMODE at bus master base + 1. */
BOOLEAN
IdeChipClearInterrupt(IN PHW_DEVICE_EXTENSION HwInit, IN ULONG Channel)
{
    ULONG port = HwInit->FirstChannel + Channel;
    ULONG reg, mask, value;

    switch (HwInit->Chip) {
    case IDE_CHIP_CMD643:
    case IDE_CHIP_CMD646:
        reg = port ? CMD_ARTTIM23 : CMD_CFR;
        mask = port ? CMD_ARTTIM23_INTR_CH1 : CMD_CFR_INTR_CH0;
        value = IdePciReadConfig(HwInit, reg, 1);
        if (!(value & mask)) return FALSE;
        /* the latch is write-1-to-clear, the other bits go back unchanged */
        IdePciWriteConfig(HwInit, reg, 1, value);
        return TRUE;
    case IDE_CHIP_CMD648:
    case IDE_CHIP_CMD649:
        if (HwInit->CmdMrdMode == NULL) return FALSE;
        mask = port ? CMD_MRDMODE_INTR_CH1 : CMD_MRDMODE_INTR_CH0;
        value = IDE_INB(HwInit->CmdMrdMode);
        if (!(value & mask)) return FALSE;
        /* only this channel's latch: the other one may be pending */
        IDE_OUTB(HwInit->CmdMrdMode, (value & ~(CMD_MRDMODE_INTR_CH0 | CMD_MRDMODE_INTR_CH1)) | mask);
        return TRUE;
    default:
        return FALSE;
    }
}

/* Controller set-up beyond SFF-8038i; again after a power transition */
VOID
IdeChipInit(IN PHW_DEVICE_EXTENSION HwInit)
{
    static const USHORT siiSien[SII_MAX_PORTS] = { 0x148, 0x1C8, 0x348, 0x3C8 };
    static const USHORT siiFifo[SII_MAX_PORTS] = { 0x40, 0x44, 0x240, 0x244 };
    static const USHORT siiSfis[SII_MAX_PORTS] = { 0x14C, 0x1CC, 0x34C, 0x3CC };
    ULONG c, value, ports, cls;

    if (IDE_CHIP_IS_CMD(HwInit->Chip) && HwInit->PciWritable) {
        /* Interrupts not blocked, memory read line on (as Linux
           pata_cmd64x sets them up); stale latches cleared */
        value = IdePciReadConfig(HwInit, CMD_MRDMODE, 1);
        IdePciWriteConfig(HwInit, CMD_MRDMODE, 1, (value & ~CMD_MRDMODE_BLOCK) | CMD_MRDMODE_READ_LINE);
        for (c = 0; c < HwInit->ChannelCount; c++) IdeChipClearInterrupt(HwInit, c);
    }

    if (IDE_CHIP_IS_SII(HwInit->Chip) && HwInit->SiiMmio != NULL) {
        ports = (HwInit->SiiMmioLength >= SII_MMIO_LENGTH_3114) ? 4 : 2;
        cls = IdePciReadConfig(HwInit, 0x0C, 1);            /* cache line size, dwords */
        for (c = 0; c < ports; c++) {
            /* SATA (PHY, hot-plug) interrupts off: nothing here would
               acknowledge them, and the PCI line would stay asserted */
            ScsiPortWriteRegisterUlong((PULONG)(HwInit->SiiMmio + siiSien[c]), 0);
            /* FIFO PCI bus arbitration thresholds from the cache line size */
            if (cls != 0) {
                value = (cls >> 3) + 1;
                ScsiPortWriteRegisterUshort((PUSHORT)(HwInit->SiiMmio + siiFifo[c]), (USHORT)((value << 8) | value));
            }
            /* 3512/3114: "R_ERR on DMA activate FIS" errata */
            if (HwInit->Chip != IDE_CHIP_SII3112) {
                value = ScsiPortReadRegisterUlong((PULONG)(HwInit->SiiMmio + siiSfis[c]));
                if ((value & 0x3) == 0x1) {
                    ScsiPortWriteRegisterUlong((PULONG)(HwInit->SiiMmio + siiSfis[c]), value & ~0x3UL);
                }
            }
        }
    }
}

/* VIA: the UDMA generation comes from the south bridge (device ID and
   revision), as Linux pata_via tells them apart; a 6410/6415 card is
   its own "bridge". Table order matters: the first match wins. */
typedef struct _IDE_VIA_BRIDGE {
    USHORT Vendor;
    USHORT Device;
    UCHAR  RevMin;
    UCHAR  RevMax;
    UCHAR  Udma;                                /* 0: MWDMA only */
    UCHAR  Flags;
} IDE_VIA_BRIDGE;

static const IDE_VIA_BRIDGE g_IdeViaBridges[] = {
    { 0x1106, 0x8409, 0x00, 0x2F, 6, IDE_VIA_BAD_AST | IDE_VIA_SATA_PATA },    /* VX855 */
    { 0x1106, 0x8353, 0x00, 0x2F, 6, IDE_VIA_BAD_AST | IDE_VIA_SATA_PATA },    /* VX800 */
    { 0x1106, 0x3402, 0x00, 0x2F, 6, IDE_VIA_BAD_AST },                        /* 8261 */
    { 0x1106, 0x3372, 0x00, 0x2F, 6, IDE_VIA_BAD_AST },                        /* 8237S */
    { 0x1106, 0x3287, 0x00, 0x2F, 6, IDE_VIA_BAD_AST },                        /* 8251 */
    { 0x1106, 0x8324, 0x00, 0x2F, 6, IDE_VIA_BAD_AST | IDE_VIA_SATA_PATA },    /* CX700 */
    { 0x1106, 0x3164, 0x00, 0x2F, 6, IDE_VIA_BAD_AST },                        /* 6410 */
    { 0x1106, 0x0415, 0x00, 0xFF, 6, IDE_VIA_BAD_AST },                        /* 6415 */
    { 0x1106, 0x3337, 0x00, 0x2F, 6, IDE_VIA_BAD_AST },                        /* 8237A */
    { 0x1106, 0x3227, 0x00, 0x2F, 6, IDE_VIA_BAD_AST },                        /* 8237 */
    { 0x1106, 0x3177, 0x00, 0x2F, 6, IDE_VIA_BAD_AST },                        /* 8235 */
    { 0x1106, 0x3147, 0x00, 0x2F, 6, IDE_VIA_BAD_AST },                        /* 8233A */
    { 0x1106, 0x3109, 0x00, 0x2F, 5, 0 },                                      /* 8233C */
    { 0x1106, 0x3074, 0x00, 0x2F, 5, 0 },                                      /* 8233 */
    { 0x1106, 0x8231, 0x00, 0x2F, 5, 0 },                                      /* 8231 */
    { 0x1106, 0x0686, 0x40, 0x4F, 5, 0 },                                      /* 82C686B */
    { 0x1106, 0x0686, 0x10, 0x2F, 4, 0 },                                      /* 82C686A */
    { 0x1106, 0x0686, 0x00, 0x0F, 2, IDE_VIA_BAD_CLK66 },                      /* 82C686 */
    { 0x1106, 0x0596, 0x10, 0x2F, 4, 0 },                                      /* 82C596B */
    { 0x1106, 0x0596, 0x00, 0x0F, 2, IDE_VIA_BAD_CLK66 },                      /* 82C596A */
    { 0x1106, 0x0586, 0x20, 0x4F, 2, 0 },                                      /* 82C586A/B */
    { 0x1106, 0x0586, 0x00, 0x0F, 0, 0 },                                      /* 82C586 */
    { 0x1106, 0x0576, 0x00, 0x2F, 0, 0 },                                      /* 82C576 */
    { 0x1107, 0x0576, 0x00, 0x2F, 0, 0 },                                      /* 82C576 (bad vendor ID) */
};
#define IDE_VIA_BRIDGES (sizeof(g_IdeViaBridges) / sizeof(g_IdeViaBridges[0]))

/* ALi M5229: the UDMA generation from the revision (and, for 20h-C1h,
   the M1533 south bridge), the chip set up as Linux pata_ali does it
   (init_chipset), its timing programmed by IdeAliSetHost */
static VOID
IdeAliSetup(IN PHW_DEVICE_EXTENSION HwInit, IN PPCI_COMMON_CONFIG PciConfig)
{
    ULONG saveBus = HwInit->PciBus, saveSlot = HwInit->PciSlot;
    ULONG dev, id, v, bridgeSlot = 0xFFFFFFFF, north;
    PCI_SLOT_NUMBER slot;
    UCHAR rev = HwInit->Revision;
    ULONG sub = ((ULONG)PciConfig->u.type0.SubVendorID << 16) | PciConfig->u.type0.SubSystemID;

    HwInit->AliTiming = FALSE;
    HwInit->AliUdmaMax = 0xFF;
    if (!HwInit->PciWritable) return;

    /* M1533 on bus 0, and the north bridge at 00:00.0 */
    HwInit->PciBus = 0;
    for (dev = 0; dev < 32; dev++) {
        slot.u.AsULONG = 0;
        slot.u.bits.DeviceNumber = dev;
        HwInit->PciSlot = slot.u.AsULONG;
        id = IdePciReadConfig(HwInit, 0x00, 4);
        if (id == ((0x1533UL << 16) | 0x10B9)) {
            bridgeSlot = slot.u.AsULONG;
            break;
        }
    }
    HwInit->PciSlot = 0;
    north = IdePciReadConfig(HwInit, 0x00, 4) & 0xFFFF;

    if (rev >= 0xC5) HwInit->AliUdmaMax = 6;
    else if (rev == 0xC4) HwInit->AliUdmaMax = 5;
    else if (rev >= 0xC2) HwInit->AliUdmaMax = 4;
    else if (rev >= 0x20 && bridgeSlot != 0xFFFFFFFF) {
        HwInit->PciSlot = bridgeSlot;
        if ((IdePciReadConfig(HwInit, 0x5E, 1) & 0x1E) == 0x12) HwInit->AliUdmaMax = 2;
    }
    /* North bridge of ALi with the M1533: its UDMA bits (Linux) */
    if (north == 0x10B9 && bridgeSlot != 0xFFFFFFFF && rev >= 0xC2 && rev < 0xC5) {
        HwInit->PciSlot = bridgeSlot;
        v = IdePciReadConfig(HwInit, 0x79, 1);
        IdePciWriteConfig(HwInit, 0x79, 1, v | ((rev == 0xC2) ? 0x04 : 0x02));
    }
    HwInit->PciBus = saveBus;
    HwInit->PciSlot = saveSlot;

    if (rev <= 0x20) {
        IdePciWriteConfig(HwInit, 0x53, 1, IdePciReadConfig(HwInit, 0x53, 1) | 0x03);
    } else {
        IdePciWriteConfig(HwInit, 0x4A, 1, IdePciReadConfig(HwInit, 0x4A, 1) | 0x20);
        v = IdePciReadConfig(HwInit, 0x4B, 1);
        v = (rev < 0xC2) ? (v & 0x7F) : (v | 0x01);
        IdePciWriteConfig(HwInit, 0x4B, 1, v | 0x08);
        IdePciWriteConfig(HwInit, 0x53, 1, IdePciReadConfig(HwInit, 0x53, 1) | ((rev >= 0xC7) ? 0x03 : 0x01));
    }
    /* Boards whose cable detection reads 80 wires on a short 40-wire cable */
    HwInit->AliCable40 = (BOOLEAN)(sub == ((0x10CFUL << 16) | 0x10AF) || sub == ((0x1071UL << 16) | 0x8317));
    HwInit->ClearSimplex = TRUE;
    HwInit->AliTiming = TRUE;
    if (HwInit->AliUdmaMax == 0xFF) {
        IDE_DBG((IDE_PFX "FindAdapter: ALi M5229 rev %02lX, no UDMA%s\n", (ULONG)rev,
                 bridgeSlot != 0xFFFFFFFF ? ", M1533 found" : ""));
    } else {
        IDE_DBG((IDE_PFX "FindAdapter: ALi M5229 rev %02lX, UDMA %lu%s\n", (ULONG)rev, (ULONG)HwInit->AliUdmaMax,
                 bridgeSlot != 0xFFFFFFFF ? ", M1533 found" : ""));
    }
}

/* VIA-style timing: which generation, and the chip fix-ups. FALSE when
   the generation is not known; the timing then stays as the BIOS set it. */
static BOOLEAN
IdeViaStyleSetup(IN PHW_DEVICE_EXTENSION HwInit, IN PPCI_COMMON_CONFIG PciConfig)
{
    ULONG saveBus = HwInit->PciBus, saveSlot = HwInit->PciSlot;
    ULONG found[40], count = 0, bus, dev, k, id, i;
    PCI_SLOT_NUMBER slot;
    USHORT vendor = PciConfig->VendorID, device = PciConfig->DeviceID;
    UCHAR rev = PciConfig->RevisionID;

    HwInit->ViaBase = 0;
    HwInit->ViaFlags = 0;
    if (!HwInit->PciWritable) return FALSE;

    if (vendor == 0x1022 || vendor == 0x10DE) {
        HwInit->ViaBase = (UCHAR)((vendor == 0x10DE) ? 0x50 : 0x40);
        HwInit->ViaFlags = IDE_VIA_AMD;
        switch (device) {
        case 0x7401: HwInit->ViaUdmaMax = 2; HwInit->ViaUdmaType = 1; break;           /* 756 */
        case 0x7409: HwInit->ViaUdmaMax = 4; HwInit->ViaUdmaType = 2; break;           /* 766 */
        case 0x7411: case 0x7441: case 0x209A: case 0x2092:
                     HwInit->ViaUdmaMax = 5; HwInit->ViaUdmaType = 3; break;           /* 768, 8111 rev. A, CS5536 */
        case 0x7469: HwInit->ViaUdmaMax = 6; HwInit->ViaUdmaType = 4;                  /* 8111 */
                     HwInit->ViaFlags |= IDE_VIA_AMD_CABLE;
                     /* Serenade boards: UDMA 5 at most */
                     if (IdePciReadConfig(HwInit, 0x2C, 4) == ((0x36C0UL << 16) | 0x1022)) HwInit->ViaUdmaMax = 5;
                     break;
        case 0x01BC: HwInit->ViaUdmaMax = 5; HwInit->ViaUdmaType = 3;                  /* nForce */
                     HwInit->ViaFlags |= IDE_VIA_NVIDIA; break;
        default:     HwInit->ViaUdmaMax = 6; HwInit->ViaUdmaType = 4;                  /* nForce2 and later */
                     HwInit->ViaFlags |= IDE_VIA_NVIDIA; break;
        }
        if (HwInit->ViaFlags & IDE_VIA_NVIDIA) HwInit->NvBiosUdma = IdePciReadConfig(HwInit, 0x60, 4);
        if (vendor == 0x1022) {
            /* Prefetch FIFO: off for now, per channel below (the 768's is broken) */
            ULONG fifo = IdePciReadConfig(HwInit, 0x41, 1) & 0x0F;
            if (device != 0x7411) fifo |= 0xF0;
            IdePciWriteConfig(HwInit, 0x41, 1, fifo);
        }
        /* 756/766: the simplex bit is wrong */
        if (device == 0x7401 || device == 0x7409) HwInit->ClearSimplex = TRUE;
        return TRUE;
    }

    /* VIA: the function itself, then function 0 of every device on its bus and bus 0 */
    found[count++] = ((ULONG)device << 16) | ((ULONG)vendor & 0xFFFF);
    found[count++] = rev;
    for (k = 0; k < 2; k++) {
        bus = k ? 0 : saveBus;
        if (k && saveBus == 0) break;
        for (dev = 0; dev < 32 && count + 2 <= sizeof(found) / sizeof(found[0]); dev++) {
            slot.u.AsULONG = 0;
            slot.u.bits.DeviceNumber = dev;
            HwInit->PciBus = bus;
            HwInit->PciSlot = slot.u.AsULONG;
            id = IdePciReadConfig(HwInit, 0x00, 4);
            if ((id & 0xFFFF) != 0x1106 && (id & 0xFFFF) != 0x1107) continue;
            found[count++] = id;
            found[count++] = IdePciReadConfig(HwInit, 0x08, 1);
        }
    }
    HwInit->PciBus = saveBus;
    HwInit->PciSlot = saveSlot;

    for (i = 0; i < IDE_VIA_BRIDGES; i++) {
        const IDE_VIA_BRIDGE *b = &g_IdeViaBridges[i];
        for (k = 0; k < count; k += 2) {
            if (found[k] != (((ULONG)b->Device << 16) | b->Vendor)) continue;
            if (found[k + 1] < b->RevMin || found[k + 1] > b->RevMax) continue;
            HwInit->ViaBase = 0x40;
            HwInit->ViaFlags = b->Flags;
            HwInit->ViaUdmaType = b->Udma;
            HwInit->ViaUdmaMax = (UCHAR)(b->Udma ? b->Udma : 0xFF);
            /* UDMA 66 parts need their 66 MHz clock, the early ones must not use it */
            if (b->Udma == 4) {
                IdePciWriteConfig(HwInit, 0x50, 4, IdePciReadConfig(HwInit, 0x50, 4) | 0x80008UL);
            } else if (b->Flags & IDE_VIA_BAD_CLK66) {
                IdePciWriteConfig(HwInit, 0x50, 4, IdePciReadConfig(HwInit, 0x50, 4) & ~0x80008UL);
            }
            IDE_DBG((IDE_PFX "FindAdapter: VIA south bridge %04lX rev %02lX, UDMA %lu\n",
                     (ULONG)b->Device, found[k + 1], (ULONG)b->Udma));
            return TRUE;
        }
    }
    IDE_DBG((IDE_PFX "FindAdapter: VIA south bridge not known, timing as the BIOS set it\n"));
    return FALSE;
}

/* Intel 450NX servers: PIIX4 DMA can hang with the original 82454NX PXB,
   and with revisions below 5 when PXB bus lock is on (Linux ata_piix) */
static BOOLEAN
IdeIntel450nxErrata(IN PHW_DEVICE_EXTENSION HwInit)
{
    ULONG saveBus = HwInit->PciBus, saveSlot = HwInit->PciSlot;
    ULONG bus, dev, id, rev, cfg;
    PCI_SLOT_NUMBER slot;
    BOOLEAN errata = FALSE;

    for (bus = 0; bus < 4 && !errata; bus++) {
        for (dev = 0; dev < 32 && !errata; dev++) {
            slot.u.AsULONG = 0;
            slot.u.bits.DeviceNumber = dev;
            HwInit->PciBus = bus;
            HwInit->PciSlot = slot.u.AsULONG;
            id = IdePciReadConfig(HwInit, 0x00, 4);
            if (id != 0x84CB8086) continue;
            rev = IdePciReadConfig(HwInit, 0x08, 1);
            cfg = IdePciReadConfig(HwInit, 0x41, 2);
            if (rev == 0x00 || ((cfg & (1UL << 14)) && rev < 5)) errata = TRUE;
        }
    }
    HwInit->PciBus = saveBus;
    HwInit->PciSlot = saveSlot;
    return errata;
}

/* Family of the PCI function and what it needs: called once the channels
   are attached */
static BOOLEAN
IdeChipSetup(IN PHW_DEVICE_EXTENSION HwInit, IN PPCI_COMMON_CONFIG PciConfig,
             IN INTERFACE_TYPE BusType, IN ULONG BusNumber)
{
    SCSI_PHYSICAL_ADDRESS pa;
    ULONG bar, length, value;

    HwInit->Chip = IdeChipKind(PciConfig->VendorID, PciConfig->DeviceID);
    HwInit->Revision = PciConfig->RevisionID;
    pa.HighPart = 0;

    switch (HwInit->Chip) {
    case IDE_CHIP_CMD648:
    case IDE_CHIP_CMD649:
        bar = PciConfig->u.type0.BaseAddresses[IDE_BAR_BUS_MASTER];
        if ((bar & 1) && (bar & 0xFFFC) != 0) {
            pa.LowPart = (bar & 0xFFFC) + 1;
            HwInit->CmdMrdMode = (PUCHAR)ScsiPortGetDeviceBase(HwInit, BusType, BusNumber, pa, 1, TRUE);
        }
        break;
    case IDE_CHIP_CMD640:
        /* Linux pata_cmd640: read-ahead off on all four drives (its data
           FIFO corrupts data), PIO 0 command timing, 512-byte bursts */
        IdePciWriteConfig(HwInit, 0x5B, 1, 0x00);
        IdePciWriteConfig(HwInit, 0x52, 1, 0x00);
        IdePciWriteConfig(HwInit, 0x59, 1, 0x40);
        value = IdePciReadConfig(HwInit, 0x51, 1);
        IdePciWriteConfig(HwInit, 0x51, 1, value | 0xC0);
        value = IdePciReadConfig(HwInit, 0x57, 1);
        IdePciWriteConfig(HwInit, 0x57, 1, value | 0x0C);
        IDE_DBG((IDE_PFX "FindAdapter: CMD640, read-ahead off, channels serialized\n"));
        break;
    case IDE_CHIP_RZ1000:
        /* Linux pata_rz1000: the read-ahead FIFO corrupts data; it must be
           off, or the controller is not driven at all */
        value = IdePciReadConfig(HwInit, 0x40, 2);
        IdePciWriteConfig(HwInit, 0x40, 2, value & 0xDFFF);
        value = IdePciReadConfig(HwInit, 0x40, 2);
        if (value & 0x2000) {
            IDE_DBG((IDE_PFX "FindAdapter: RZ1000 read-ahead still on, controller left alone\n"));
            return FALSE;
        }
        IDE_DBG((IDE_PFX "FindAdapter: RZ1000, read-ahead off, channels serialized\n"));
        break;
    case IDE_CHIP_ALI:
        /* Linux pata_ali: DMA from revision 20h, 48-bit DMA from C5h,
           ATAPI DMA not reliable */
        if (HwInit->Revision < 0x20) HwInit->DmaAllowed = FALSE;
        if (HwInit->Revision < 0xC5) HwInit->NoLba48Dma = TRUE;
        HwInit->NoAtapiDma = TRUE;
        IdeAliSetup(HwInit, PciConfig);
        break;
    case IDE_CHIP_SII3112:
    case IDE_CHIP_SII3512:
    case IDE_CHIP_SII3114:
        bar = PciConfig->u.type0.BaseAddresses[SII_MMIO_BAR];
        length = (HwInit->Chip == IDE_CHIP_SII3114) ? SII_MMIO_LENGTH_3114 : SII_MMIO_LENGTH;
        if (!(bar & 1) && (bar & 0xFFFFFFF0) != 0) {
            pa.LowPart = bar & 0xFFFFFFF0;
#ifdef IDE_W9X
            HwInit->SiiMmio = (PUCHAR)IdeMapPhysToLinear(pa.LowPart, length);
            if (HwInit->SiiMmio == (PUCHAR)0xFFFFFFFF) HwInit->SiiMmio = NULL;
#else
            HwInit->SiiMmio = (PUCHAR)ScsiPortGetDeviceBase(HwInit, BusType, BusNumber, pa, length, FALSE);
            if (HwInit->SiiMmio == NULL && BusType != PCIBus) {
                HwInit->SiiMmio = (PUCHAR)ScsiPortGetDeviceBase(HwInit, PCIBus, HwInit->PciBus, pa, length, FALSE);
            }
#endif
            if (HwInit->SiiMmio != NULL) HwInit->SiiMmioLength = length;
        }
        IDE_DBG((IDE_PFX "FindAdapter: Silicon Image registers at %08lX %s\n", pa.LowPart,
                 HwInit->SiiMmio != NULL ? "mapped" : "not mapped, timing as the BIOS set it"));
        break;
    case IDE_CHIP_VIA:
    case IDE_CHIP_AMD:
        IdeViaStyleSetup(HwInit, PciConfig);
        break;
    default:
        break;
    }
    if (HwInit->Intel == IDE_INTEL_PIIX4 && HwInit->DmaAllowed && IdeIntel450nxErrata(HwInit)) {
        IDE_DBG((IDE_PFX "FindAdapter: 450NX errata, DMA off\n"));
        HwInit->DmaAllowed = FALSE;
    }
    IdeChipInit(HwInit);
    return TRUE;
}

/* ------------------------------------------------------------------ */
/* Channel descriptions                                                */
/* ------------------------------------------------------------------ */

typedef struct _IDE_CHANNEL_DESC {
    USHORT  CmdPort;
    USHORT  CtlPort;
    USHORT  BmPort;         /* 0 without bus master */
    UCHAR   Irq;            /* 0 unknown */
    BOOLEAN Native;
    UCHAR   Index;          /* 0 primary, 1 secondary of its controller */
} IDE_CHANNEL_DESC, *PIDE_CHANNEL_DESC;

static const struct { USHORT Cmd; USHORT Ctl; UCHAR Irq; } g_IdeLegacy[IDE_LEGACY_CHANNELS] = {
    { IDE_LEGACY_PRIMARY_CMD,    IDE_LEGACY_PRIMARY_CTL,    IDE_LEGACY_PRIMARY_IRQ },
    { IDE_LEGACY_SECONDARY_CMD,  IDE_LEGACY_SECONDARY_CTL,  IDE_LEGACY_SECONDARY_IRQ },
    { IDE_LEGACY_TERTIARY_CMD,   IDE_LEGACY_TERTIARY_CTL,   IDE_LEGACY_TERTIARY_IRQ },
    { IDE_LEGACY_QUATERNARY_CMD, IDE_LEGACY_QUATERNARY_CTL, IDE_LEGACY_QUATERNARY_IRQ },
};

/* The two channels of a PCI IDE function, from its class code and BARs */
/* Intel SATA functions in IDE mode with a PATA function next to them: in
   combined mode (MAP, 90h) the PATA function has one of the two legacy
   channels. The values are those of Linux ata_piix (ich5_map_db, mask 7;
   ich6_map_db/ich6m_map_db, mask 3). */
static BOOLEAN
IdeIntelSataIde(IN USHORT DeviceId)
{
    switch (DeviceId) {
    case 0x24D1: case 0x25A3:                           /* ICH5, 6300ESB */
    case 0x2651: case 0x2652: case 0x2653:              /* ICH6, ICH6R, ICH6M */
    case 0x2680:                                        /* 631xESB/632xESB */
    case 0x27C0: case 0x27C4:                           /* ICH7, ICH7M */
        return TRUE;
    default:
        return FALSE;
    }
}

static BOOLEAN
IdeIntelSataChannelIsPata(IN PPCI_COMMON_CONFIG PciConfig, IN ULONG Channel)
{
    UCHAR map = PciConfig->DeviceSpecific[0x90 - 0x40];

    if (PciConfig->VendorID != 0x8086 || PciConfig->SubClass != PCI_SUBCLASS_IDE) return FALSE;
    switch (PciConfig->DeviceID) {
    case 0x24D1:                                        /* ICH5 */
    case 0x25A3:                                        /* 6300ESB */
        map &= 7;
        if (map == 4 || map == 5) return (BOOLEAN)(Channel == 1);   /* SATA primary, PATA secondary */
        if (map == 6 || map == 7) return (BOOLEAN)(Channel == 0);   /* PATA primary, SATA secondary */
        return FALSE;
    case 0x2651: case 0x2652: case 0x2653:              /* ICH6, ICH6R, ICH6M */
    case 0x2680:                                        /* 631xESB/632xESB */
    case 0x27C0: case 0x27C4:                           /* ICH7, ICH7M */
        map &= 3;
        if (map == 1) return (BOOLEAN)(Channel == 0);               /* PATA primary */
        if (map == 2) return (BOOLEAN)(Channel == 1);               /* PATA secondary */
        return FALSE;
    default:
        return FALSE;
    }
}

/* A channel the chip set has turned off (the BIOS setup's "Disabled", or a
   legacy channel an Intel ICH gives to its other function in combined mode):
   it decodes nothing or another function answers on its ports, so it is not
   used and its ports are not claimed. The enable bits are those Linux checks
   before it resets a channel (ata_piix, pata_via, pata_amd); a chip that is
   not listed counts as enabled. */
static BOOLEAN
IdePciChannelEnabled(IN PPCI_COMMON_CONFIG PciConfig, IN ULONG Channel)
{
    const UCHAR *cfg = PciConfig->DeviceSpecific;       /* offset 40h */
    UCHAR bit = (UCHAR)(Channel ? 0x01 : 0x02);

    if (PciConfig->VendorID == 0x8086) {
        /* IDETIM (40h primary, 42h secondary) bit 15: IDE decode enable, on
           the PIIX/ICH PATA functions and the ICH SATA functions alike */
        if (IdeIntelKind(PciConfig->VendorID, PciConfig->DeviceID) != IDE_INTEL_NONE ||
            IdeIntelSataIde(PciConfig->DeviceID)) {
            if (!(cfg[(Channel ? 0x43 : 0x41) - 0x40] & 0x80)) return FALSE;
        }
        return (BOOLEAN)!IdeIntelSataChannelIsPata(PciConfig, Channel);
    }
    if (PciConfig->VendorID == 0x1106) {
        /* VIA south bridges (40h bit 1 primary, bit 0 secondary); the VT6410 and
           VT6415 cards have no enables */
        switch (PciConfig->DeviceID) {
        case 0x0571: case 0x1571: case 0x5324: case 0xC409:
            return (BOOLEAN)((cfg[0] & bit) != 0);
        default:
            return TRUE;
        }
    }
    if (PciConfig->VendorID == 0x1022) {
        switch (PciConfig->DeviceID) {
        case 0x7401: case 0x7409: case 0x7411: case 0x7441: case 0x7469:
            return (BOOLEAN)((cfg[0] & bit) != 0);       /* AMD: 40h */
        default:
            return TRUE;
        }
    }
    if (PciConfig->VendorID == 0x10DE && IdeChipKind(PciConfig->VendorID, PciConfig->DeviceID) == IDE_CHIP_AMD) {
        return (BOOLEAN)((cfg[0x50 - 0x40] & bit) != 0); /* nVidia nForce: 50h */
    }
    return TRUE;
}

static ULONG
IdeDescribePciChannels(IN PPCI_COMMON_CONFIG PciConfig, OUT PIDE_CHANNEL_DESC Desc)
{
    ULONG bar4 = PciConfig->u.type0.BaseAddresses[IDE_BAR_BUS_MASTER];
    BOOLEAN sataClass = (BOOLEAN)(PciConfig->SubClass != PCI_SUBCLASS_IDE);
    /* The programming interface tells of a bus master only in class 0101;
       the SATA/RAID-class functions taken here have theirs at BAR 4 */
    USHORT bm = (USHORT)(((bar4 & 1) && (bar4 & 0xFFFC) != 0 &&
                          ((PciConfig->ProgIf & IDE_PROGIF_BUS_MASTER) || sataClass)) ? (bar4 & 0xFFFC) : 0);
    ULONG n = 0, c;

    for (c = 0; c < 2; c++) {
        UCHAR nativeBit = (UCHAR)(c ? IDE_PROGIF_SECONDARY_NATIVE : IDE_PROGIF_PRIMARY_NATIVE);
        ULONG barCmd = PciConfig->u.type0.BaseAddresses[c ? IDE_BAR_SECONDARY_CMD : IDE_BAR_PRIMARY_CMD];
        ULONG barCtl = PciConfig->u.type0.BaseAddresses[c ? IDE_BAR_SECONDARY_CTL : IDE_BAR_PRIMARY_CTL];
        PIDE_CHANNEL_DESC d = &Desc[n];

        ZeroMemoryBytes(d, sizeof(*d));
        d->Index = (UCHAR)c;
        if (!IdePciChannelEnabled(PciConfig, c)) continue;
        if ((PciConfig->ProgIf & nativeBit) || sataClass) {
            if (!(barCmd & 1) || !(barCtl & 1) || (barCmd & 0xFFF8) == 0 || (barCtl & 0xFFFC) == 0) continue;
            d->CmdPort = (USHORT)(barCmd & 0xFFF8);
            d->CtlPort = (USHORT)((barCtl & 0xFFFC) + 2);
            d->Irq = (UCHAR)((PciConfig->u.type0.InterruptLine == 0xFF) ? 0 : PciConfig->u.type0.InterruptLine);
            d->Native = TRUE;
        } else {
            d->CmdPort = g_IdeLegacy[c].Cmd;
            d->CtlPort = g_IdeLegacy[c].Ctl;
            d->Irq = g_IdeLegacy[c].Irq;
            d->Native = FALSE;
        }
        d->BmPort = (USHORT)(bm ? bm + 8 * c : 0);
        n++;
    }
    return n;
}

#if !defined(IDE_NT4)
/* PnP start of a compatibility-mode function (idepnp.c): the ISA IRQ of
   its first channel in use, 0 when it has none. In an Intel ICH's
   combined mode the PATA and the SATA function have one legacy channel
   each, so one of them raises IRQ 15 only. */
ULONG
IdePciCompatIrq(IN PVOID PciConfig)
{
    IDE_CHANNEL_DESC desc[2];
    ULONG n, i;

    n = IdeDescribePciChannels((PPCI_COMMON_CONFIG)PciConfig, desc);
    for (i = 0; i < n; i++) {
        if (!desc[i].Native) return desc[i].Irq;
    }
    return 0;
}
#endif

/* Walk the PCI buses for the next IDE function with an unclaimed channel
   (with NativeOnly: an unclaimed channel in native mode) */
static BOOLEAN
IdeScanPci(
    IN PHW_DEVICE_EXTENSION HwInit,
    IN BOOLEAN NativeOnly,
    OUT PULONG FoundBus,
    OUT PULONG FoundSlot,
    OUT PPCI_COMMON_CONFIG PciConfig
)
{
    PCI_SLOT_NUMBER slot;
    ULONG bus, device, function, n, i;
    BOOLEAN busMissing, multiFunction;
    IDE_CHANNEL_DESC desc[2];

    for (bus = 0; bus < 256; bus++) {
        for (device = 0; device < 32; device++) {
            multiFunction = FALSE;
            for (function = 0; function < 8; function++) {
                if (function > 0 && !multiFunction) break;
                slot.u.AsULONG = 0;
                slot.u.bits.DeviceNumber = device;
                slot.u.bits.FunctionNumber = function;

                if (!IdeReadPciHeader(HwInit, bus, slot.u.AsULONG, PciConfig, &busMissing)) {
                    if (busMissing && device == 0 && function == 0) return FALSE;
                    if (function == 0) break;
                    continue;
                }
                if (function == 0) {
                    multiFunction = (BOOLEAN)((PciConfig->HeaderType & IDE_PCI_MULTIFUNCTION) != 0);
                }
                if (!IdePciConfigIsIde(PciConfig)) continue;

                n = IdeDescribePciChannels(PciConfig, desc);
                for (i = 0; i < n; i++) {
                    if (!IdeIsPortClaimed(desc[i].CmdPort) && (!NativeOnly || desc[i].Native)) {
                        *FoundBus = bus;
                        *FoundSlot = slot.u.AsULONG;
                        return TRUE;
                    }
                }
            }
        }
    }
    return FALSE;
}

#if !defined(IDE_NT4)
/* The PCI IDE function whose compatibility-mode channel sits at CmdPort */
static BOOLEAN
IdeFindCompatFunction(
    IN PHW_DEVICE_EXTENSION HwInit,
    IN USHORT CmdPort,
    IN BOOLEAN AlsoDisabled,
    OUT PULONG FoundBus,
    OUT PULONG FoundSlot,
    OUT PPCI_COMMON_CONFIG PciConfig
)
{
    PCI_SLOT_NUMBER slot;
    ULONG bus, device, function, i;
    BOOLEAN busMissing, multiFunction;

    for (bus = 0; bus < 256; bus++) {
        for (device = 0; device < 32; device++) {
            multiFunction = FALSE;
            for (function = 0; function < 8; function++) {
                if (function > 0 && !multiFunction) break;
                slot.u.AsULONG = 0;
                slot.u.bits.DeviceNumber = device;
                slot.u.bits.FunctionNumber = function;
                if (!IdeReadPciHeader(HwInit, bus, slot.u.AsULONG, PciConfig, &busMissing)) {
                    if (busMissing && device == 0 && function == 0) return FALSE;
                    if (function == 0) break;
                    continue;
                }
                if (function == 0) multiFunction = (BOOLEAN)((PciConfig->HeaderType & IDE_PCI_MULTIFUNCTION) != 0);
                if (!IdePciConfigIsIde(PciConfig)) continue;
                /* Also a channel the chip set has turned off: the legacy ports of
                   a compatibility-mode channel are the chip set's, not an ISA
                   card's, whether it decodes them (or its other function does,
                   an ICH in combined mode) or nobody does (AlsoDisabled: the
                   ISA pass; the dump instance wants the function in charge) */
                if (PciConfig->SubClass == PCI_SUBCLASS_IDE) {
                    for (i = 0; i < 2; i++) {
                        if (!(PciConfig->ProgIf & (i ? IDE_PROGIF_SECONDARY_NATIVE : IDE_PROGIF_PRIMARY_NATIVE)) &&
                            g_IdeLegacy[i].Cmd == CmdPort &&
                            (AlsoDisabled || IdePciChannelEnabled(PciConfig, i))) {
                            *FoundBus = bus;
                            *FoundSlot = slot.u.AsULONG;
                            return TRUE;
                        }
                    }
                }
            }
        }
    }
    return FALSE;
}
#endif

/* Anything answering on a legacy channel? A floating bus reads 0xFF on
   both ports; a device drives the status and the count register. */
static BOOLEAN
IdeLegacyChannelPresent(IN USHORT CmdPort, IN USHORT CtlPort)
{
    UCHAR s1, s2, c;

    s1 = IDE_INB(CtlPort);
    s2 = IDE_INB(CmdPort + IDE_REG_STATUS);
    if (s1 == 0xFF && s2 == 0xFF) return FALSE;
    if (s1 & IDE_STS_BSY) return TRUE;              /* busy device, decided later */
    IDE_OUTB(CmdPort + IDE_REG_DEVICE, IDE_DEV_DEFAULT);
    ScsiPortStallExecution(2);
    IDE_OUTB(CmdPort + IDE_REG_COUNT, 0x55);
    IDE_OUTB(CmdPort + IDE_REG_LBA0, 0xAA);
    IDE_OUTB(CmdPort + IDE_REG_COUNT, 0xAA);
    IDE_OUTB(CmdPort + IDE_REG_LBA0, 0x55);
    IDE_OUTB(CmdPort + IDE_REG_COUNT, 0x55);
    IDE_OUTB(CmdPort + IDE_REG_LBA0, 0xAA);
    c = IDE_INB(CmdPort + IDE_REG_COUNT);
    if (c != 0x55) return FALSE;
    c = IDE_INB(CmdPort + IDE_REG_LBA0);
    return (BOOLEAN)(c == 0xAA);
}

#if defined(IDE_NT4) && !defined(IDE_W9X)
/* ------------------------------------------------------------------ */
/* Native-mode channels on another controller's ports                  */
/* ------------------------------------------------------------------ */

/* A BIOS may leave the BARs 0-3 of a native-mode function at the legacy
   addresses (SeaBIOS writes 1F0h/3F4h/170h/374h into every native IDE
   function other than the PIIX), where a compatibility-mode function
   decodes as well: both answer, and the devices of one controller hide
   those of the other. Before any channel is taken, such a function is
   moved to free I/O space next to its bus master block, inside the
   window of its bridge. 2000/XP get the same through the PnP resource
   requirements (idepnp.c). Not on 9x: drives without a protected-mode
   driver stay on INT 13h, and the BIOS reaches them at the addresses
   it set. */

#define IDE_IO_USED_MAX                 160
#define IDE_IO_BRIDGES_MAX              16
#define IDE_IO_FUNCTIONS_MAX            IDE_MAX_CONTROLLERS
#define IDE_IO_BLOCK                    32      /* cmd 8 + ctl 4 per channel, two channels */
#define IDE_IO_FLOOR                    0x1000
#define IDE_IO_SEARCH_STEPS             2048

typedef struct _IDE_IO_RANGE {
    ULONG Start;
    ULONG End;                                  /* inclusive */
} IDE_IO_RANGE;

typedef struct _IDE_IO_BRIDGE {
    UCHAR   Primary;
    UCHAR   Secondary;
    BOOLEAN WindowOn;
    ULONG   Base;
    ULONG   Limit;
} IDE_IO_BRIDGE;

typedef struct _IDE_IO_FUNCTION {
    ULONG Bus;
    ULONG Slot;
    ULONG Bar[5];
    UCHAR ProgIf;
    UCHAR SubClass;
} IDE_IO_FUNCTION;

typedef struct _IDE_IO_MAP {
    IDE_IO_RANGE    Used[IDE_IO_USED_MAX];      /* taken, for the search of a free block */
    ULONG           UsedCount;
    IDE_IO_RANGE    Ide[IDE_IO_USED_MAX];       /* IDE ports decoded for certain */
    ULONG           IdeRangeCount;
    IDE_IO_BRIDGE   Bridge[IDE_IO_BRIDGES_MAX];
    ULONG           BridgeCount;
    IDE_IO_FUNCTION Fn[IDE_IO_FUNCTIONS_MAX];
    ULONG           IdeCount;
    BOOLEAN         Overflow;                   /* a table ran full: move nothing */
} IDE_IO_MAP;

static IDE_IO_MAP g_IdeIoMap;
static BOOLEAN g_IdeIoChecked;

static VOID
IdeIoAddUsed(IN ULONG Start, IN ULONG End)
{
    IDE_IO_MAP *m = &g_IdeIoMap;
    if (Start == 0 || End < Start) return;
    if (m->UsedCount >= IDE_IO_USED_MAX) {
        m->Overflow = TRUE;
        return;
    }
    m->Used[m->UsedCount].Start = Start;
    m->Used[m->UsedCount].End = End;
    m->UsedCount++;
}

/* Ports an IDE channel decodes for certain: the legacy ports of a
   compatibility-mode channel, the exact command and control blocks of a
   native one */
static VOID
IdeIoAddIde(IN ULONG Start, IN ULONG End)
{
    IDE_IO_MAP *m = &g_IdeIoMap;
    IdeIoAddUsed(Start, End);
    if (Start == 0 || End < Start) return;
    if (m->IdeRangeCount >= IDE_IO_USED_MAX) {
        m->Overflow = TRUE;
        return;
    }
    m->Ide[m->IdeRangeCount].Start = Start;
    m->Ide[m->IdeRangeCount].End = End;
    m->IdeRangeCount++;
}

static BOOLEAN
IdeIoOverlapsIde(IN ULONG Start, IN ULONG End)
{
    ULONG i;
    for (i = 0; i < g_IdeIoMap.IdeRangeCount; i++) {
        if (Start <= g_IdeIoMap.Ide[i].End && End >= g_IdeIoMap.Ide[i].Start) return TRUE;
    }
    return FALSE;
}

static BOOLEAN
IdeIoOverlapsUsed(IN ULONG Start, IN ULONG End)
{
    ULONG i;
    for (i = 0; i < g_IdeIoMap.UsedCount; i++) {
        if (Start <= g_IdeIoMap.Used[i].End && End >= g_IdeIoMap.Used[i].Start) return TRUE;
    }
    return FALSE;
}

/* An I/O BAR whose size is not known: a BAR is aligned to its size and
   an I/O BAR is at most 256 bytes, so the alignment of its base bounds it */
static VOID
IdeIoAddBar(IN ULONG Bar)
{
    ULONG base, size;

    if (!(Bar & 1)) return;
    base = Bar & 0xFFFC;
    if (base == 0 || (Bar & 0xFFFF0000UL) != 0) return;
    size = base & (0 - base);
    if (size > 0x100) size = 0x100;
    IdeIoAddUsed(base, base + size - 1);
}

/* The native channels of a recorded IDE function: BAR 0/1 and 2/3 */
static BOOLEAN
IdeIoChannelNative(IN IDE_IO_FUNCTION *F, IN ULONG Channel)
{
    if (F->SubClass != PCI_SUBCLASS_IDE) return TRUE;
    return (BOOLEAN)((F->ProgIf & (Channel ? IDE_PROGIF_SECONDARY_NATIVE : IDE_PROGIF_PRIMARY_NATIVE)) != 0);
}

static BOOLEAN
IdeIoChannelRanges(IN IDE_IO_FUNCTION *F, IN ULONG Channel, OUT IDE_IO_RANGE *Cmd, OUT IDE_IO_RANGE *Ctl)
{
    ULONG cmd = F->Bar[2 * Channel], ctl = F->Bar[2 * Channel + 1];

    if (!(cmd & 1) || !(ctl & 1) || (cmd & 0xFFF8) == 0 || (ctl & 0xFFFC) == 0) return FALSE;
    Cmd->Start = cmd & 0xFFF8;
    Cmd->End = Cmd->Start + 7;
    Ctl->Start = ctl & 0xFFFC;
    Ctl->End = Ctl->Start + 3;
    return TRUE;
}

/* Every function on every bus: I/O BARs, bridge windows, IDE functions */
static VOID
IdeIoScan(IN PHW_DEVICE_EXTENSION HwInit)
{
    IDE_IO_MAP *m = &g_IdeIoMap;
    PCI_COMMON_CONFIG cfg;
    PCI_SLOT_NUMBER slot;
    PUCHAR raw = (PUCHAR)&cfg;
    ULONG bus, device, function, i, c;
    BOOLEAN busMissing, multiFunction;

    for (bus = 0; bus < 256; bus++) {
        for (device = 0; device < 32; device++) {
            multiFunction = FALSE;
            for (function = 0; function < 8; function++) {
                if (function > 0 && !multiFunction) break;
                slot.u.AsULONG = 0;
                slot.u.bits.DeviceNumber = device;
                slot.u.bits.FunctionNumber = function;
                if (!IdeReadPciHeader(HwInit, bus, slot.u.AsULONG, &cfg, &busMissing)) {
                    if (busMissing && device == 0 && function == 0) return;
                    if (function == 0) break;
                    continue;
                }
                if (function == 0) multiFunction = (BOOLEAN)((cfg.HeaderType & IDE_PCI_MULTIFUNCTION) != 0);

                if ((cfg.HeaderType & 0x7F) == 1) {
                    /* PCI-PCI bridge: its own BARs and the window it forwards */
                    IdeIoAddBar(*(PULONG)&raw[0x10]);
                    IdeIoAddBar(*(PULONG)&raw[0x14]);
                    if (m->BridgeCount >= IDE_IO_BRIDGES_MAX) {
                        m->Overflow = TRUE;
                    } else {
                        IDE_IO_BRIDGE *b = &m->Bridge[m->BridgeCount++];
                        b->Primary = raw[0x18];
                        b->Secondary = raw[0x19];
                        b->Base = (ULONG)(raw[0x1C] & 0xF0) << 8;
                        b->Limit = ((ULONG)(raw[0x1D] & 0xF0) << 8) | 0xFFF;
                        b->WindowOn = (BOOLEAN)(b->Limit > b->Base);
                    }
                    continue;
                }
                if ((cfg.HeaderType & 0x7F) != 0) continue;

                if (IdePciConfigIsIde(&cfg) && m->IdeCount >= IDE_IO_FUNCTIONS_MAX) m->Overflow = TRUE;
                if (IdePciConfigIsIde(&cfg) && m->IdeCount < IDE_IO_FUNCTIONS_MAX) {
                    IDE_IO_FUNCTION *f = &m->Fn[m->IdeCount++];
                    f->Bus = bus;
                    f->Slot = slot.u.AsULONG;
                    f->ProgIf = cfg.ProgIf;
                    f->SubClass = cfg.SubClass;
                    for (i = 0; i < 5; i++) f->Bar[i] = cfg.u.type0.BaseAddresses[i];
                    /* Compatibility-mode channels decode the legacy ports */
                    for (c = 0; c < 2; c++) {
                        if (IdeIoChannelNative(f, c)) continue;
                        IdeIoAddIde(g_IdeLegacy[c].Cmd, g_IdeLegacy[c].Cmd + 7);
                        IdeIoAddIde(g_IdeLegacy[c].Ctl, g_IdeLegacy[c].Ctl);
                    }
                    IdeIoAddBar(cfg.u.type0.BaseAddresses[4]);
                    IdeIoAddBar(cfg.u.type0.BaseAddresses[5]);
                    continue;
                }
                for (i = 0; i < 6; i++) {
                    ULONG bar = cfg.u.type0.BaseAddresses[i];
                    if (bar & 1) {
                        IdeIoAddBar(bar);
                    } else if ((bar & 0x6) == 0x4) {
                        i++;                    /* upper half of a 64-bit memory BAR */
                    }
                }
            }
        }
    }
}

/* A free, aligned block for the native channels of F: upward from its
   bus master block (in the BIOS's pool of PCI I/O space), then downward */
static ULONG
IdeIoFindBlock(IN IDE_IO_FUNCTION *F)
{
    IDE_IO_MAP *m = &g_IdeIoMap;
    ULONG low = IDE_IO_FLOOR, high = 0xFFFF, anchor, k, i, cand;
    LONG dir;

    if (m->Overflow) return 0;
    for (i = 0; i < m->BridgeCount; i++) {
        if (m->Bridge[i].Secondary == F->Bus && F->Bus != 0) {
            if (!m->Bridge[i].WindowOn) return 0;
            if (m->Bridge[i].Base > low) low = m->Bridge[i].Base;
            if (m->Bridge[i].Limit < high) high = m->Bridge[i].Limit;
        }
    }
    anchor = ((F->Bar[4] & 1) && (F->Bar[4] & 0xFFFC) != 0) ? (F->Bar[4] & 0xFFE0) : (high & ~(IDE_IO_BLOCK - 1));

    for (dir = 1; dir >= -1; dir -= 2) {
        for (k = (dir > 0) ? 0 : 1; k < IDE_IO_SEARCH_STEPS; k++) {
            cand = (dir > 0) ? anchor + k * IDE_IO_BLOCK : anchor - k * IDE_IO_BLOCK;
            if (cand < low || cand + IDE_IO_BLOCK - 1 > high || cand > 0xFFFF) continue;
            /* Clear of the ISA 10-bit aliases, and forwarded by a bridge
               with ISA enable set */
            if ((cand & 0x300) != 0) continue;
            if (IdeIoOverlapsUsed(cand, cand + IDE_IO_BLOCK - 1)) continue;
            for (i = 0; i < m->BridgeCount; i++) {
                IDE_IO_BRIDGE *b = &m->Bridge[i];
                if (b->Primary == F->Bus && b->WindowOn && cand <= b->Limit && cand + IDE_IO_BLOCK - 1 >= b->Base) break;
            }
            if (i < m->BridgeCount) continue;
            return cand;
        }
    }
    return 0;
}

/* Move the native channels of F to Block; FALSE (and the BARs as they
   were) when the function does not take the addresses */
static BOOLEAN
IdeIoMoveFunction(IN PHW_DEVICE_EXTENSION HwInit, IN IDE_IO_FUNCTION *F, IN ULONG Block)
{
    PCI_COMMON_CONFIG cfg;
    ULONG command, c, want[4];
    BOOLEAN ok = TRUE;

    if (!IdeReadPciHeader(HwInit, F->Bus, F->Slot, &cfg, NULL)) return FALSE;
    command = cfg.Command;
    IdePciWriteConfigAt(HwInit, F->Bus, F->Slot, 0x04, 2, command & ~1UL);   /* I/O decode off */
    for (c = 0; c < 2; c++) {
        want[2 * c] = F->Bar[2 * c];
        want[2 * c + 1] = F->Bar[2 * c + 1];
        if (!IdeIoChannelNative(F, c)) continue;
        want[2 * c] = (Block + 16 * c) | 1;
        want[2 * c + 1] = (Block + 16 * c + 8) | 1;
        IdePciWriteConfigAt(HwInit, F->Bus, F->Slot, 0x10 + 8 * c, 4, want[2 * c]);
        IdePciWriteConfigAt(HwInit, F->Bus, F->Slot, 0x14 + 8 * c, 4, want[2 * c + 1]);
    }
    if (IdeReadPciHeader(HwInit, F->Bus, F->Slot, &cfg, NULL)) {
        for (c = 0; c < 4; c++) {
            if ((cfg.u.type0.BaseAddresses[c] & 0xFFFC) != (want[c] & 0xFFFC)) ok = FALSE;
        }
    } else {
        ok = FALSE;
    }
    if (!ok) {
        for (c = 0; c < 4; c++) IdePciWriteConfigAt(HwInit, F->Bus, F->Slot, 0x10 + 4 * c, 4, F->Bar[c]);
    }
    IdePciWriteConfigAt(HwInit, F->Bus, F->Slot, 0x04, 2, command);
    return ok;
}

static VOID
IdeResolvePortConflicts(IN PHW_DEVICE_EXTENSION HwInit)
{
    IDE_IO_MAP *m = &g_IdeIoMap;
    IDE_IO_RANGE cmd, ctl;
    ULONG f, c, block;
    BOOLEAN conflict;

    if (g_IdeIoChecked) return;
    g_IdeIoChecked = TRUE;
    ZeroMemoryBytes(m, sizeof(*m));
    IdeIoScan(HwInit);

    for (f = 0; f < m->IdeCount; f++) {
        IDE_IO_FUNCTION *fn = &m->Fn[f];

        /* Only another IDE channel on the same ports is a conflict: the
           size of any other BAR is only bounded by its alignment here, and
           a board's BIOS does not overlap BARs (GitHub issue #4: on real
           boards a display controller's I/O BAR at F000h made every SATA
           IDE BAR above it look taken, and the functions were moved) */
        conflict = FALSE;
        for (c = 0; c < 2; c++) {
            if (!IdeIoChannelNative(fn, c) || !IdeIoChannelRanges(fn, c, &cmd, &ctl)) continue;
            if (IdeIoOverlapsIde(cmd.Start, cmd.End) || IdeIoOverlapsIde(ctl.Start, ctl.End)) conflict = TRUE;
        }
        if (conflict) {
            block = IdeIoFindBlock(fn);
            if (block != 0 && IdeIoMoveFunction(HwInit, fn, block)) {
                IDE_DBG((IDE_PFX "Ports: bus %lu slot %08lX native channels moved from %lX to %lX "
                         "(another controller decodes the same ports)\n",
                         fn->Bus, fn->Slot, fn->Bar[0] & 0xFFFC, block));
                for (c = 0; c < 2; c++) {
                    if (!IdeIoChannelNative(fn, c)) continue;
                    fn->Bar[2 * c] = (block + 16 * c) | 1;
                    fn->Bar[2 * c + 1] = (block + 16 * c + 8) | 1;
                }
            } else {
                IDE_DBG((IDE_PFX "Ports: bus %lu slot %08lX shares ports with another controller, "
                         "no free I/O space found to move it\n", fn->Bus, fn->Slot));
            }
        }
        for (c = 0; c < 2; c++) {
            if (!IdeIoChannelNative(fn, c) || !IdeIoChannelRanges(fn, c, &cmd, &ctl)) continue;
            IdeIoAddIde(cmd.Start, cmd.End);
            IdeIoAddIde(ctl.Start, ctl.End);
        }
    }
}
#endif

/* ------------------------------------------------------------------ */
/* DMA arena: PRD table and bounce buffer per channel                  */
/* ------------------------------------------------------------------ */

#define IDE_CHANNEL_DMA_BYTES           (IDE_PRD_TABLE_SIZE + IDE_BOUNCE_SIZE)

static BOOLEAN
IdeAllocateDma(IN PHW_DEVICE_EXTENSION HwInit, IN PPORT_CONFIGURATION_INFORMATION ConfigInfo)
{
    ULONG length, phys, misalign, c;
    PUCHAR virt;

    if (HwInit->DmaArea != NULL) return TRUE;

    HwInit->DmaLength = IDE_MAX_CHANNELS * IDE_CHANNEL_DMA_BYTES + IDE_PRD_TABLE_SIZE;
    HwInit->DmaArea = (PUCHAR)ScsiPortGetUncachedExtension(HwInit, ConfigInfo, HwInit->DmaLength);
    if (HwInit->DmaArea == NULL) {
        IDE_DBG((IDE_PFX "AllocateDma: ScsiPortGetUncachedExtension(%lu) failed\n", HwInit->DmaLength));
        return FALSE;
    }
    length = HwInit->DmaLength;
    HwInit->DmaAreaPhysical = ScsiPortGetPhysicalAddress(HwInit, NULL, HwInit->DmaArea, &length);
    if (HwInit->DmaAreaPhysical.LowPart == 0 && HwInit->DmaAreaPhysical.HighPart == 0) {
        IDE_DBG((IDE_PFX "AllocateDma: no physical address\n"));
        return FALSE;
    }
    if (HwInit->DmaAreaPhysical.HighPart != 0) {
        IDE_DBG((IDE_PFX "AllocateDma: area above 4 GB\n"));
        return FALSE;
    }
    ZeroMemoryBytes(HwInit->DmaArea, HwInit->DmaLength);

    virt = HwInit->DmaArea;
    phys = HwInit->DmaAreaPhysical.LowPart;
    misalign = phys % IDE_PRD_TABLE_SIZE;
    if (misalign != 0) {
        virt += IDE_PRD_TABLE_SIZE - misalign;
        phys += IDE_PRD_TABLE_SIZE - misalign;
    }
    for (c = 0; c < IDE_MAX_CHANNELS; c++) {
        PIDE_CHANNEL ch = &HwInit->Channels[c];
        ch->Prd = (PIDE_PRD_ENTRY)virt;
        ch->PrdPhysical = phys;
        virt += IDE_PRD_TABLE_SIZE; phys += IDE_PRD_TABLE_SIZE;
        ch->BounceBuffer = virt;
        ch->BouncePhysical = phys;
        virt += IDE_BOUNCE_SIZE; phys += IDE_BOUNCE_SIZE;
    }
    return TRUE;
}

/* ------------------------------------------------------------------ */
/* Channel bring-up                                                    */
/* ------------------------------------------------------------------ */

/* IDENTIFY, parse, transfer mode and settings for one unit */
static VOID
IdeSetupUnit(IN PHW_DEVICE_EXTENSION HwInit, IN ULONG Channel, IN ULONG Unit)
{
    PIDE_DEVICE dev = &HwInit->Channels[Channel].Devices[Unit];

    if (!dev->Present) return;
    if (IdeIdentifyDevice(HwInit, Channel, Unit)) {
        IdeParseIdentify(HwInit, Channel, Unit);
        IdeSelectTransferMode(HwInit, Channel, Unit);
    } else {
        IdeParseIdentify(HwInit, Channel, Unit);
    }
    IdeApplyDeviceSettings(HwInit, Channel, Unit);
}

/* After a reset: modes and settings of every device on the channel */
VOID
IdeSetupChannel(IN PHW_DEVICE_EXTENSION HwInit, IN ULONG Channel)
{
    PIDE_CHANNEL ch = &HwInit->Channels[Channel];
    ULONG unit;

    ch->NeedsSetup = FALSE;
    for (unit = 0; unit < IDE_DEVICES_PER_CHANNEL; unit++) {
        if (ch->Devices[unit].Present) IdeSetupUnit(HwInit, Channel, unit);
    }
    IdeSetControl(ch, IDE_CTL_NIEN);
}

#define IDE_SLAVE_SIGNATURE_MS          3000

#if defined(IDE_NT4) && !defined(IDE_W9X)
static BOOLEAN g_IdeAtapiFound;
#endif

/* A slave that IDENTIFY shows as the master again: a master that does not
   decode the device bit answers for an absent slave */
static BOOLEAN
IdeGhostSlave(IN PIDE_CHANNEL Ch)
{
    PIDE_DEVICE m = &Ch->Devices[0], s = &Ch->Devices[1];
    ULONG i;
    BOOLEAN serial = FALSE;

    if (!m->Present || !m->IdentifyValid || !s->IdentifyValid || m->IsAtapi != s->IsAtapi) return FALSE;
    for (i = IDE_ID_SERIAL; i < IDE_ID_SERIAL + 10; i++) {
        if (s->Id[i] != 0 && s->Id[i] != 0x2020) serial = TRUE;
    }
    if (!serial) return FALSE;
    for (i = IDE_ID_SERIAL; i < IDE_ID_WORDS; i++) {
        if (m->Id[i] != s->Id[i]) return FALSE;
    }
    return TRUE;
}

/* Reset the channel and find its devices */
static VOID
IdeInitializeChannel(IN PHW_DEVICE_EXTENSION HwInit, IN ULONG Channel)
{
    PIDE_CHANNEL ch = &HwInit->Channels[Channel];
    ULONG unit;
    UCHAR status, c, n;
    UCHAR sigStatus[IDE_DEVICES_PER_CHANNEL], sigLba1[IDE_DEVICES_PER_CHANNEL], sigLba2[IDE_DEVICES_PER_CHANNEL];
    BOOLEAN noSignature;

    ch->Outstanding = NULL;
    ch->QueueHead = 0;
    ch->QueueCount = 0;
    ch->LuBlocked = 0;
    ch->SelectedUnit = 0xFF;
    ch->DeviceCount = 0;
    for (unit = 0; unit < IDE_DEVICES_PER_CHANNEL; unit++) {
        ch->HpPolls[unit] = 0;
        ch->HpEmpty[unit] = FALSE;
    }

    if (ch->Off) {
        /* OFF=: no reset, no commands, no devices */
        ZeroMemoryBytes(ch->Devices, sizeof(ch->Devices));
        ch->NeedsSetup = FALSE;
        IDE_DBG((IDE_PFX "Channel %lu: turned off (OFF=)\n", Channel));
        return;
    }

    IdeResetChannel(HwInit, Channel);

    /* Both signatures first: a register write reaches both devices, so
       probing the master would overwrite the signature of a packet
       device behind it */
    for (unit = 0; unit < IDE_DEVICES_PER_CHANNEL; unit++) {
        ULONG ms;
        IdeSelectUnit(ch, unit);
        /* the reset waited for the master; a slave may still be busy */
        for (ms = 0; ms < IDE_SLAVE_SIGNATURE_MS; ms++) {
            sigStatus[unit] = IdeAltStatus(ch);
            if (sigStatus[unit] == 0xFF || !(sigStatus[unit] & IDE_STS_BSY)) break;
            ScsiPortStallExecution(1000);
        }
        sigLba1[unit] = IDE_INB(ch->Cmd + IDE_REG_LBA1);
        sigLba2[unit] = IDE_INB(ch->Cmd + IDE_REG_LBA2);
    }

    for (unit = 0; unit < IDE_DEVICES_PER_CHANNEL; unit++) {
        PIDE_DEVICE dev = &ch->Devices[unit];
        UCHAR wantWc = dev->WantWriteCache, wantLa = dev->WantLookAhead, dmaErrors = dev->DmaErrors;

        ZeroMemoryBytes(dev, sizeof(IDE_DEVICE));
        dev->Unit = (UCHAR)unit;
        dev->WantWriteCache = wantWc;
        dev->WantLookAhead = wantLa;
        dev->DmaErrors = dmaErrors;

        if (ch->UnitsOff & (1U << unit)) {
            IDE_DBG((IDE_PFX "Channel %lu.%lu: turned off (OFF=)\n", Channel, unit));
            continue;
        }
        IdeSelectUnit(ch, unit);
        status = sigStatus[unit];
        dev->IsAtapi = (BOOLEAN)(sigLba1[unit] == IDE_SIG_ATAPI_LBA1 && sigLba2[unit] == IDE_SIG_ATAPI_LBA2);
        /* Floating bus */
        if (status == 0xFF) continue;
        /* Status 0 and no signature: nothing, or a packet device (DRDY
           clear after a reset) that left no signature */
        noSignature = (BOOLEAN)(status == 0x00 && !dev->IsAtapi);

        /* A device: it answers in its registers (a master shadows an
           absent slave only until the status is read) */
        IDE_OUTB(ch->Cmd + IDE_REG_COUNT, 0x55);
        IDE_OUTB(ch->Cmd + IDE_REG_LBA0, 0xAA);
        c = IDE_INB(ch->Cmd + IDE_REG_COUNT);
        n = IDE_INB(ch->Cmd + IDE_REG_LBA0);
        if (c != 0x55 || n != 0xAA) {
            if (noSignature || !IdeWaitStatus(ch, IDE_STS_BSY, 0, 1000)) continue;
        }
        if (noSignature) dev->IsAtapi = TRUE;
        dev->Present = TRUE;

        if (!IdeIdentifyDevice(HwInit, Channel, unit)) {
            /* No or a stale signature: the other IDENTIFY once */
            dev->IsAtapi = (BOOLEAN)!dev->IsAtapi;
            if (!IdeIdentifyDevice(HwInit, Channel, unit)) {
                dev->Present = FALSE;
                IDE_DBG((IDE_PFX "Channel %lu.%lu: no answer (status %02lX)\n", Channel, unit, (ULONG)status));
                continue;
            }
        }
        IdeParseIdentify(HwInit, Channel, unit);
        if (unit == 1 && IdeGhostSlave(ch)) {
            IDE_DBG((IDE_PFX "Channel %lu.1: the master answers for an absent slave, ignored\n", Channel));
            dev->Present = FALSE;
            continue;
        }
#if defined(IDE_NT4) && !defined(IDE_W9X)
        if (dev->IsAtapi) g_IdeAtapiFound = TRUE;
#endif
        IdeSelectTransferMode(HwInit, Channel, unit);
        IdeApplyDeviceSettings(HwInit, Channel, unit);
        ch->DeviceCount++;
    }
    ch->NeedsSetup = FALSE;
    IdeSetControl(ch, IDE_CTL_NIEN);
    IDE_DBG((IDE_PFX "Channel %lu: %lu device(s), %s\n", Channel, (ULONG)ch->DeviceCount,
             ch->Async ? "interrupt" : "Fast Polling"));
}

static VOID
IdeInitializeAll(IN PHW_DEVICE_EXTENSION HwInit)
{
    ULONG c;

    for (c = 0; c < HwInit->ChannelCount; c++) {
        if (HwInit->Channels[c].Present) IdeInitializeChannel(HwInit, c);
    }
    HwInit->Stopped = FALSE;
    HwInit->CheckState = FALSE;    IdeArmHotPlug(HwInit);
}

/* After a power transition or a BIOS that used the controller: set
   everything up again. MODE SELECT settings are kept per device. */
BOOLEAN
IdeReinitialize(IN PHW_DEVICE_EXTENSION HwInit)
{
    ULONG c;

    IDE_DBG((IDE_PFX "Reinitialize\n"));
    for (c = 0; c < HwInit->ChannelCount; c++) {
        if (HwInit->Channels[c].Outstanding != NULL || HwInit->Channels[c].QueueCount != 0) {
            IdeFailOutstanding(HwInit, c, SRB_STATUS_BUS_RESET);
        }
    }
    IdeChipInit(HwInit);
    IdeInitializeAll(HwInit);
    return TRUE;
}

/* The devices may have been reset behind the driver's back (APM resume,
   a BIOS call): put the transfer modes and settings back. */
VOID
IdeCheckState(IN PHW_DEVICE_EXTENSION HwInit)
{
    ULONG c, unit;

    if (HwInit->Stopped) {
        IdeReinitialize(HwInit);
        return;
    }
    if (!HwInit->CheckState) return;
    HwInit->CheckState = FALSE;
    for (c = 0; c < HwInit->ChannelCount; c++) {
        PIDE_CHANNEL ch = &HwInit->Channels[c];
        if (!ch->Present) continue;
        IdeDrainChannel(HwInit, c);
        for (unit = 0; unit < IDE_DEVICES_PER_CHANNEL; unit++) {
            if (ch->Devices[unit].Present) IdeSetupUnit(HwInit, c, unit);
        }
        IdeSetControl(ch, IDE_CTL_NIEN);
    }
}

/* Flush every disk, put it in standby, stop the channels. The next
   request or POWER_UP brings everything back. */
BOOLEAN
IdePowerDown(IN PHW_DEVICE_EXTENSION HwInit)
{
    ULONG c, unit;

    IDE_DBG((IDE_PFX "PowerDown\n"));
    for (c = 0; c < HwInit->ChannelCount; c++) {
        PIDE_CHANNEL ch = &HwInit->Channels[c];
        if (!ch->Present) continue;
        IdeDrainChannel(HwInit, c);
        for (unit = 0; unit < IDE_DEVICES_PER_CHANNEL; unit++) {
            PIDE_DEVICE dev = &ch->Devices[unit];
            if (!dev->Present || dev->IsAtapi) continue;
            IdeFlushDevice(HwInit, c, unit);
            IdeRunSimple(HwInit, c, unit, IDE_COMMAND_STANDBY_IMMEDIATE, 0, 0, IDE_POLL_TIMEOUT_POWER_SEC);
        }
        IdeStopChannel(HwInit, c);
    }
    HwInit->Stopped = TRUE;
    return TRUE;
}

/* ------------------------------------------------------------------ */
/* Interrupt watchdog                                                  */
/* ------------------------------------------------------------------ */

/* One timer per adapter: the interrupt watchdog (short) and the hot-plug
   check (long). A request while one is pending is not passed on: the
   pending one runs first and asks again, so that ScsiPort never gets a
   second request for a timer it still holds. */
static VOID
IdeRequestTimer(IN PHW_DEVICE_EXTENSION HwInit, IN ULONG Usec)
{
    if (HwInit->TimerArmed) return;
    HwInit->TimerArmed = TRUE;
    HwInit->TimerUsec = Usec;
    ScsiPortNotification(RequestTimerCall, HwInit, IdeTimer, Usec);
}

VOID
IdeArmTimer(IN PHW_DEVICE_EXTENSION HwInit)
{
    if (!HwInit->AsyncMode) return;
    IdeRequestTimer(HwInit, IDE_TIMER_USEC);
}

static VOID
IdeArmHotPlug(IN PHW_DEVICE_EXTENSION HwInit)
{
    if (!HwInit->HotPlug || HwInit->Stopped) return;
    IdeRequestTimer(HwInit, IDE_HOTPLUG_USEC);
}

#if !defined(IDE_NT4)
/* The secondary channel of a compatibility-mode function on its own
   IRQ 15 (connected by the PnP front end) or back to Fast Polling; called
   synchronized with the interrupt. FALSE: nothing to switch. */
BOOLEAN
IdeSecondaryInterrupt(IN PVOID HwInitContext, IN BOOLEAN On)
{
    PHW_DEVICE_EXTENSION HwInit = (PHW_DEVICE_EXTENSION)HwInitContext;
    BOOLEAN found = FALSE;
    ULONG c;

    if (On && !HwInit->AsyncMode) return FALSE;
    for (c = 0; c < HwInit->ChannelCount; c++) {
        PIDE_CHANNEL ch = &HwInit->Channels[c];
        if (ch->Native || ch->Irq != IDE_LEGACY_SECONDARY_IRQ) continue;
        if (On) {
            if (ch->Present && ch->Outstanding != NULL) IdeDrainChannel(HwInit, c);
            ch->Async = TRUE;
        } else {
            ch->Async = FALSE;
            if (ch->Present && ch->Outstanding != NULL) IdeDrainChannel(HwInit, c);
        }
        found = TRUE;
        IDE_DBG((IDE_PFX "Channel %lu: %s\n", c, On ? "interrupt (IRQ 15)" : "Fast Polling"));
    }
    return found;
}
#endif

/* Back to Fast Polling for good */
static VOID
IdeDisableAsync(IN PHW_DEVICE_EXTENSION HwInit)
{
    ULONG c;

    IDE_DBG((IDE_PFX "Interrupts not delivered, back to Fast Polling\n"));
    /* Off first: the requests that waited are then run polled while the
       channels drain */
    for (c = 0; c < HwInit->ChannelCount; c++) HwInit->Channels[c].Async = FALSE;
    for (c = 0; c < HwInit->ChannelCount; c++) {
        if (HwInit->Channels[c].Present) IdeDrainChannel(HwInit, c);
    }
    HwInit->AsyncMode = FALSE;
}

/* ------------------------------------------------------------------ */
/* Hot plug (HOTPLUG=1)                                                */
/* ------------------------------------------------------------------ */

/* Status of a position as the check sees it: FFh (floating bus) and 7Fh
   (what SATA controllers in IDE mode return for an empty port) are no
   device; 00h is nothing there either for a position without one */
static BOOLEAN
IdeStatusGone(IN UCHAR Status)
{
    return (BOOLEAN)(Status == 0xFF || Status == 0x7F);
}

/* Every idle channel, both positions (also one waiting for its setup
   after a reset, which a device that went away during a command leaves
   behind): a device that reads as gone
   twice in a row, or a device where the position read as empty before
   and now reads as a device twice in a row, has the channel reset and
   its devices found again. A channel busy with a DMA command only has
   its active device checked: when that one is gone, what the channel
   has in flight and in its queue fails. 2000/XP/x64: ScsiPort is told,
   and the disks come and go in the system; NT 3.1-4.0 and 9x: a device
   that comes back is usable again at the same address. */
static VOID
IdeHotPlugCheck(IN PHW_DEVICE_EXTENSION HwInit)
{
    ULONG c, unit;
    BOOLEAN busChange = FALSE;

    for (c = 0; c < HwInit->ChannelCount; c++) {
        PIDE_CHANNEL ch = &HwInit->Channels[c];
        BOOLEAN change = FALSE, before[IDE_DEVICES_PER_CHANNEL];
        UCHAR status;

        if (!ch->Present || ch->Off) continue;

        if (ch->Outstanding != NULL) {
            unit = ch->ActiveUnit;
            if (!IdeStatusGone(IdeAltStatus(ch))) {
                ch->HpPolls[unit] = 0;
                continue;
            }
            if (++ch->HpPolls[unit] < IDE_HOTPLUG_CONFIRM) continue;
            IDE_DBG((IDE_PFX "Channel %lu.%lu: device gone with a command in flight\n", c, unit));
            IdeFailOutstanding(HwInit, c, SRB_STATUS_SELECTION_TIMEOUT);
            ch->HpPolls[unit] = IDE_HOTPLUG_CONFIRM;
        }

        for (unit = 0; unit < IDE_DEVICES_PER_CHANNEL; unit++) {
            PIDE_DEVICE dev = &ch->Devices[unit];
            if (ch->UnitsOff & (1U << unit)) continue;
            if (ch->SelectedUnit != unit) IdeSelectUnit(ch, unit);
            status = IdeAltStatus(ch);
            if (dev->Present) {
                if (!IdeStatusGone(status)) {
                    ch->HpPolls[unit] = 0;
                } else if (++ch->HpPolls[unit] >= IDE_HOTPLUG_CONFIRM) {
                    IDE_DBG((IDE_PFX "Channel %lu.%lu: device gone (status %02lX)\n", c, unit, (ULONG)status));
                    change = TRUE;
                }
            } else if (IdeStatusGone(status) || status == 0x00) {
                ch->HpEmpty[unit] = TRUE;
                ch->HpPolls[unit] = 0;
            } else if (ch->HpEmpty[unit] && ++ch->HpPolls[unit] >= IDE_HOTPLUG_CONFIRM) {
                IDE_DBG((IDE_PFX "Channel %lu.%lu: device arrived (status %02lX)\n", c, unit, (ULONG)status));
                change = TRUE;
            }
        }
        if (!change) continue;

        /* The device that stays keeps what it has cached; then the reset
           and the search of the channel */
        for (unit = 0; unit < IDE_DEVICES_PER_CHANNEL; unit++) {
            before[unit] = ch->Devices[unit].Present;
            if (ch->Devices[unit].Present && ch->HpPolls[unit] == 0 && !ch->Devices[unit].IsAtapi) {
                IdeFlushDevice(HwInit, c, unit);
            }
        }
        IdeInitializeChannel(HwInit, c);
        for (unit = 0; unit < IDE_DEVICES_PER_CHANNEL; unit++) {
            if (ch->Devices[unit].Present != before[unit]) busChange = TRUE;
        }
    }
#if !defined(IDE_NT4)
    if (busChange) ScsiPortNotification(BusChangeDetected, HwInit, 0);
#else
    (VOID)busChange;
#endif
}

/* Interrupt watchdog: the timer completes what the interrupt missed.
   Hot plug: the channels are checked. */
static VOID IdeEnter(IN PHW_DEVICE_EXTENSION HwInit);
static VOID IdeLeave(IN PHW_DEVICE_EXTENSION HwInit);
static VOID IdeTimerBody(IN PHW_DEVICE_EXTENSION hwInit);

VOID
IdeTimer(IN PVOID DeviceExtension)
{
    PHW_DEVICE_EXTENSION hwInit = (PHW_DEVICE_EXTENSION)DeviceExtension;

    IdeEnter(hwInit);
    IdeTimerBody(hwInit);
    IdeLeave(hwInit);
}

static VOID
IdeTimerBody(IN PHW_DEVICE_EXTENSION hwInit)
{
    ULONG c, missed = 0, elapsed = hwInit->TimerUsec;
    BOOLEAN pending = FALSE;

    hwInit->TimerArmed = FALSE;
    if (hwInit->Stopped) return;

    if (hwInit->AsyncMode) {
        for (c = 0; c < hwInit->ChannelCount; c++) {
            if (hwInit->Channels[c].Outstanding == NULL) continue;
            missed += IdeServiceChannel(hwInit, c, FALSE);
            if (hwInit->Channels[c].Outstanding != NULL) pending = TRUE;
        }
        if (missed != 0 && ++hwInit->MissedInterrupts >= IDE_MISSED_IRQ_LIMIT) {
            IdeDisableAsync(hwInit);
            pending = FALSE;
        }
    }
    if (hwInit->HotPlug) {
        hwInit->HpElapsed += elapsed;
        if (hwInit->HpElapsed >= IDE_HOTPLUG_USEC) {
            hwInit->HpElapsed = 0;
            IdeHotPlugCheck(hwInit);
        }
    }
    if (pending) IdeArmTimer(hwInit);
    IdeArmHotPlug(hwInit);
}

/* ------------------------------------------------------------------ */
/* DriverEntry                                                         */
/* ------------------------------------------------------------------ */

#ifdef IDE_NT31_COMPAT
static BOOLEAN g_IdeFindAdapterCalled;
#endif

#if !defined(IDE_W9X)
/* Registry access for the NT family. Declared here: miniport.h has no
   registry API. */
typedef struct _IDE_UNICODE_STRING {
    USHORT Length;
    USHORT MaximumLength;
    USHORT *Buffer;
} IDE_UNICODE_STRING, *PIDE_UNICODE_STRING;

typedef struct _IDE_OBJECT_ATTRIBUTES {
    ULONG Length;
    PVOID RootDirectory;
    PIDE_UNICODE_STRING ObjectName;
    ULONG Attributes;
    PVOID SecurityDescriptor;
    PVOID SecurityQualityOfService;
} IDE_OBJECT_ATTRIBUTES;

LONG __stdcall ZwOpenKey(PVOID *KeyHandle, ULONG DesiredAccess, PVOID ObjectAttributes);
LONG __stdcall ZwCreateKey(PVOID *KeyHandle, ULONG DesiredAccess, PVOID ObjectAttributes,
                           ULONG TitleIndex, PVOID Class, ULONG CreateOptions, PULONG Disposition);
LONG __stdcall ZwSetValueKey(PVOID KeyHandle, PVOID ValueName, ULONG TitleIndex, ULONG Type,
                             PVOID Data, ULONG DataSize);
LONG __stdcall ZwQueryValueKey(PVOID KeyHandle, PVOID ValueName, ULONG KeyValueInformationClass,
                               PVOID KeyValueInformation, ULONG Length, PULONG ResultLength);
LONG __stdcall ZwClose(PVOID Handle);
#if !defined(IDE_NT4)
BOOLEAN __stdcall PsGetVersion(PULONG MajorVersion, PULONG MinorVersion, PULONG BuildNumber,
                               PIDE_UNICODE_STRING CsdVersion);
#else
/* hal.dll, every NT version; KIRQL and KAFFINITY as UCHAR and ULONG */
ULONG __stdcall HalGetInterruptVector(INTERFACE_TYPE InterfaceType, ULONG BusNumber, ULONG BusInterruptLevel,
                                      ULONG BusInterruptVector, PUCHAR Irql, PULONG Affinity);
#endif

#define IDE_OBJ_CASE_INSENSITIVE        0x00000040
#define IDE_OBJ_KERNEL_HANDLE           0x00000200
#define IDE_KEY_READ_WRITE              0x0002001F
#define IDE_REG_CREATED_NEW_KEY         1
#define IDE_REG_DWORD                   4

static VOID
IdeInitString(OUT PIDE_UNICODE_STRING String, IN USHORT *Text, IN ULONG Bytes)
{
    String->Buffer = Text;
    String->Length = (USHORT)(Bytes - sizeof(USHORT));
    String->MaximumLength = (USHORT)Bytes;
}

static VOID
IdeInitAttributes(OUT IDE_OBJECT_ATTRIBUTES *Oa, IN PIDE_UNICODE_STRING Name, IN PVOID Root)
{
    Oa->Length = sizeof(IDE_OBJECT_ATTRIBUTES);
    Oa->RootDirectory = Root;
    Oa->ObjectName = Name;
#ifdef IDE_NT4
    /* OBJ_KERNEL_HANDLE is 2000 and later; NT 4.0 rejects it */
    Oa->Attributes = IDE_OBJ_CASE_INSENSITIVE;
#else
    Oa->Attributes = IDE_OBJ_CASE_INSENSITIVE | IDE_OBJ_KERNEL_HANDLE;
#endif
    Oa->SecurityDescriptor = NULL;
    Oa->SecurityQualityOfService = NULL;
}
#endif

#if !defined(IDE_NT4)
/* Text-mode setup boots with a bare service key: the [Config] values of
   txtsetup.oem reach only the installed system. Without
   Parameters\PnpInterface the x64 ScsiPort fails IRP_MN_START_DEVICE
   before HwFindAdapter (STOP 0x7B), so the driver adds the entry the INF
   would have made. */
static USHORT g_IdeParametersName[] = L"Parameters";
static USHORT g_IdePnpInterfaceName[] = L"PnpInterface";
static USHORT g_IdePciBusValueName[] = L"5";

static VOID
IdeEnsurePnpInterface(IN PVOID RegistryPath)
{
    IDE_OBJECT_ATTRIBUTES oa;
    IDE_UNICODE_STRING name;
    PVOID service, params, pnp;
    ULONG disposition = 0;
    ULONG one = 1;
    LONG status;

    if (RegistryPath == NULL) return;

    IdeInitAttributes(&oa, (PIDE_UNICODE_STRING)RegistryPath, NULL);
    if (ZwOpenKey(&service, IDE_KEY_READ_WRITE, &oa) < 0) return;

    IdeInitString(&name, g_IdeParametersName, sizeof(g_IdeParametersName));
    IdeInitAttributes(&oa, &name, service);
    status = ZwCreateKey(&params, IDE_KEY_READ_WRITE, &oa, 0, NULL, 0, &disposition);
    if (status >= 0) {
        IdeInitString(&name, g_IdePnpInterfaceName, sizeof(g_IdePnpInterfaceName));
        IdeInitAttributes(&oa, &name, params);
        status = ZwCreateKey(&pnp, IDE_KEY_READ_WRITE, &oa, 0, NULL, 0, &disposition);
        if (status >= 0) {
            if (disposition == IDE_REG_CREATED_NEW_KEY) {
                IdeInitString(&name, g_IdePciBusValueName, sizeof(g_IdePciBusValueName));
                status = ZwSetValueKey(pnp, &name, 0, IDE_REG_DWORD, &one, sizeof(one));
                IDE_DBG((IDE_PFX "DriverEntry: Parameters\\PnpInterface\\5 added (%08lX)\n", (ULONG)status));
            }
            ZwClose(pnp);
        }
        ZwClose(params);
    }
    ZwClose(service);
}
#endif

#if defined(IDE_NT4) && !defined(IDE_W9X)
/* atdisk (Primary disk group) and atapi (an earlier tag) load before IDENT
   and take the channels. oemsetup.inf turns them off; a text-mode setup
   cannot, as txtsetup.oem reaches only IDENT's own key. So once IDENT has
   found a controller, the driver does what oemsetup.inf does: the old
   Start is kept as InboxStart_<name> under the IDENT key (oemsetup.inf
   puts it back when IDENT is removed) and Start set to 4. A driver with a
   saved value is left alone, so one turned on again by hand stays on.
   When a driver is turned off, the disk class driver is made a boot
   driver, as IDENT's disks need it at boot. */
#define IDE_KEY_VALUE_PARTIAL_INFORMATION   2

static USHORT g_IdeStartName[] = L"Start";
static USHORT g_IdeNotInboxName[] = L"NotInboxDriver";
static USHORT g_IdeAtdiskName[] = L"atdisk";
static USHORT g_IdeAtapiName[] = L"atapi";
static USHORT g_IdeAtdiskSaved[] = L"InboxStart_atdisk";
static USHORT g_IdeAtapiSaved[] = L"InboxStart_atapi";
static USHORT g_IdeScsidiskName[] = L"scsidisk";
static USHORT g_IdeDiskName[] = L"disk";
static USHORT g_IdeScsicdrmName[] = L"scsicdrm";
static USHORT g_IdeCdromName[] = L"cdrom";
static USHORT g_IdeCdfsName[] = L"cdfs";
static USHORT g_IdeCdfsRecName[] = L"cdfs_rec";
static USHORT g_IdeFsRecName[] = L"fs_rec";

static BOOLEAN g_IdeAdapterFound;

static PVOID
IdeRegOpen(IN PVOID Root, IN USHORT *Name, IN ULONG Bytes)
{
    IDE_OBJECT_ATTRIBUTES oa;
    IDE_UNICODE_STRING name;
    PVOID key;

    IdeInitString(&name, Name, Bytes);
    IdeInitAttributes(&oa, &name, Root);
    if (ZwOpenKey(&key, IDE_KEY_READ_WRITE, &oa) < 0) return NULL;
    return key;
}

static BOOLEAN
IdeRegReadDword(IN PVOID Key, IN USHORT *Name, IN ULONG Bytes, OUT PULONG Value)
{
    IDE_UNICODE_STRING name;
    ULONG info[4], length = 0;

    IdeInitString(&name, Name, Bytes);
    /* TitleIndex, Type, DataLength, Data */
    if (ZwQueryValueKey(Key, &name, IDE_KEY_VALUE_PARTIAL_INFORMATION, info, sizeof(info), &length) < 0 ||
        info[1] != IDE_REG_DWORD || info[2] != sizeof(ULONG)) {
        return FALSE;
    }
    *Value = info[3];
    return TRUE;
}

static VOID
IdeRegWriteDword(IN PVOID Key, IN USHORT *Name, IN ULONG Bytes, IN ULONG Value)
{
    IDE_UNICODE_STRING name;

    IdeInitString(&name, Name, Bytes);
    ZwSetValueKey(Key, &name, 0, IDE_REG_DWORD, &Value, sizeof(Value));
}

/* Start of a service, 0xFFFFFFFF without key or value */
static ULONG
IdeServiceStart(IN PVOID Services, IN USHORT *Name, IN ULONG Bytes)
{
    PVOID key = IdeRegOpen(Services, Name, Bytes);
    ULONG start = 0xFFFFFFFF;

    if (key == NULL) return start;
    if (!IdeRegReadDword(key, g_IdeStartName, sizeof(g_IdeStartName), &start)) start = 0xFFFFFFFF;
    ZwClose(key);
    return start;
}

/* A service at Start 4 to 1 (system); TRUE when its key exists */
static BOOLEAN
IdeServiceEnable(IN PVOID Services, IN USHORT *Name, IN ULONG Bytes, IN PCHAR Text)
{
    PVOID key = IdeRegOpen(Services, Name, Bytes);
    ULONG start;

    if (key == NULL) return FALSE;
    if (IdeRegReadDword(key, g_IdeStartName, sizeof(g_IdeStartName), &start) && start == 4) {
        IdeRegWriteDword(key, g_IdeStartName, sizeof(g_IdeStartName), 1);
        IDE_DBG((IDE_PFX "DriverEntry: %s, Start 4 -> 1\n", Text));
    }
    ZwClose(key);
    return TRUE;
}

/* A CD-ROM drive was found: its class driver (scsicdrm on NT 3.x, cdrom
   on NT 4.0) and CDFS have to start. NT 3.1 has no IDE CD-ROM support, so
   an installation on IDE leaves them at Start 4. CDFS is left alone when
   a file system recognizer loads it (cdfs_rec on NT 3.x, fs_rec on 4.0). */
static VOID
IdeEnableCdromDrivers(IN PVOID Services)
{
    ULONG rec;

    if (!IdeServiceEnable(Services, g_IdeScsicdrmName, sizeof(g_IdeScsicdrmName), "scsicdrm")) {
        IdeServiceEnable(Services, g_IdeCdromName, sizeof(g_IdeCdromName), "cdrom");
    }
    rec = IdeServiceStart(Services, g_IdeCdfsRecName, sizeof(g_IdeCdfsRecName));
    if (rec >= 4) rec = IdeServiceStart(Services, g_IdeFsRecName, sizeof(g_IdeFsRecName));
    if (rec >= 4) IdeServiceEnable(Services, g_IdeCdfsName, sizeof(g_IdeCdfsName), "cdfs");
}

/* Name (Count characters) equal to the zero-terminated Ref, case ignored */
static BOOLEAN
IdeSameName(IN USHORT *Name, IN ULONG Count, IN USHORT *Ref)
{
    ULONG i;
    USHORT a, b;

    for (i = 0; i < Count; i++) {
        a = Name[i]; b = Ref[i];
        if (b == 0) return FALSE;
        if (a >= 'A' && a <= 'Z') a = (USHORT)(a + 'a' - 'A');
        if (b >= 'A' && b <= 'Z') b = (USHORT)(b + 'a' - 'A');
        if (a != b) return FALSE;
    }
    return (BOOLEAN)(Ref[Count] == 0);
}

static VOID
IdeDisableInboxDrivers(IN PVOID RegistryPath)
{
    static USHORT *const inbox[2] = { g_IdeAtdiskName, g_IdeAtapiName };
    static const ULONG inboxBytes[2] = { sizeof(g_IdeAtdiskName), sizeof(g_IdeAtapiName) };
    static USHORT *const saved[2] = { g_IdeAtdiskSaved, g_IdeAtapiSaved };
    static const ULONG savedBytes[2] = { sizeof(g_IdeAtdiskSaved), sizeof(g_IdeAtapiSaved) };
    static USHORT *const cls[2] = { g_IdeScsidiskName, g_IdeDiskName };
    static const ULONG clsBytes[2] = { sizeof(g_IdeScsidiskName), sizeof(g_IdeDiskName) };
    static const PCHAR inboxText[2] = { "atdisk", "atapi" };
    static const PCHAR clsText[2] = { "scsidisk", "disk" };
    PIDE_UNICODE_STRING path = (PIDE_UNICODE_STRING)RegistryPath;
    IDE_OBJECT_ATTRIBUTES oa;
    IDE_UNICODE_STRING parent;
    PVOID ident, services, key;
    ULONG i, n, start, old;
    LONG status;
    BOOLEAN changed = FALSE;

    if (path == NULL || path->Buffer == NULL) return;
    /* The Services key: the registry path without its last component */
    n = path->Length / sizeof(USHORT);
    while (n > 0 && path->Buffer[n - 1] != '\\') n--;
    if (n < 2) return;
    parent.Buffer = path->Buffer;
    parent.Length = (USHORT)((n - 1) * sizeof(USHORT));
    parent.MaximumLength = parent.Length;

    IdeInitAttributes(&oa, path, NULL);
    status = ZwOpenKey(&ident, IDE_KEY_READ_WRITE, &oa);
    if (status < 0) {
        IDE_DBG((IDE_PFX "DriverEntry: service key not opened (%08lX)\n", (ULONG)status));
        return;
    }
    IdeInitAttributes(&oa, &parent, NULL);
    status = ZwOpenKey(&services, IDE_KEY_READ_WRITE, &oa);
    if (status < 0) {
        IDE_DBG((IDE_PFX "DriverEntry: Services key not opened (%08lX)\n", (ULONG)status));
        ZwClose(ident);
        return;
    }

    for (i = 0; i < 2; i++) {
        /* IDENT installed under that name: its own key */
        if (IdeSameName(&path->Buffer[n], path->Length / sizeof(USHORT) - n, inbox[i])) continue;
        key = IdeRegOpen(services, inbox[i], inboxBytes[i]);
        if (key == NULL) continue;
        /* AHCINT, MMCSDNT or NVMENT copied over atapi.sys (they mark their
           service key): not an in-box IDE driver, possibly the system disk */
        if (IdeRegReadDword(key, g_IdeNotInboxName, sizeof(g_IdeNotInboxName), &old) && old != 0) {
            IDE_DBG((IDE_PFX "DriverEntry: %s is not the in-box driver, left alone\n", inboxText[i]));
            ZwClose(key);
            continue;
        }
        if (!IdeRegReadDword(ident, saved[i], savedBytes[i], &old) &&
            IdeRegReadDword(key, g_IdeStartName, sizeof(g_IdeStartName), &start)) {
            IdeRegWriteDword(ident, saved[i], savedBytes[i], start);
            if (start != 4) {
                IdeRegWriteDword(key, g_IdeStartName, sizeof(g_IdeStartName), 4);
                changed = TRUE;
            }
            IDE_DBG((IDE_PFX "DriverEntry: in-box driver %s, Start %lu -> 4\n", inboxText[i], start));
        }
        ZwClose(key);
    }

    /* scsidisk (NT 3.x) or else disk (NT 4.0): a disk key on NT 3.x has no
       driver behind it */
    for (i = 0; changed && i < 2; i++) {
        key = IdeRegOpen(services, cls[i], clsBytes[i]);
        if (key == NULL) continue;
        if (IdeRegReadDword(key, g_IdeStartName, sizeof(g_IdeStartName), &start) && start != 0) {
            IdeRegWriteDword(key, g_IdeStartName, sizeof(g_IdeStartName), 0);
            IDE_DBG((IDE_PFX "DriverEntry: class driver %s, Start %lu -> 0\n", clsText[i], start));
        }
        ZwClose(key);
        break;
    }
    if (g_IdeAtapiFound) IdeEnableCdromDrivers(services);
    ZwClose(services);
    ZwClose(ident);
}
#endif

#ifdef IDE_W9X
/* The Windows 9x loader does not clear the uninitialized data of a .MPD
   (its RAM holds whatever was there): every global that has to start at
   zero is cleared before anything reads it */
static VOID
IdeClearGlobals9x(VOID)
{
    ZeroMemoryBytes(&g_IdeCapacity16, sizeof(g_IdeCapacity16));
    ZeroMemoryBytes(&g_IdeClaimedPorts, sizeof(g_IdeClaimedPorts));
    ZeroMemoryBytes(&g_IdeClaimedCount, sizeof(g_IdeClaimedCount));
}
#endif

ULONG
DriverEntry(IN PVOID DriverObject, IN PVOID Argument2)
{
    HW_INITIALIZATION_DATA initData;
    ULONG status, status2;

#ifdef IDE_W9X
    IdeClearGlobals9x();
#endif
    g_IdeDumpMode = (BOOLEAN)(DriverObject == NULL);

    IDE_DBG((IDE_PFX "DriverEntry%s\n", g_IdeDumpMode ? " (dump)" : ""));

#if !defined(IDE_NT4)
#if defined(_AMD64_)
    g_IdeCapacity16 = TRUE;
#else
    {
        ULONG major = 0, minor = 0, build = 0;
        IDE_UNICODE_STRING csd;
        csd.Length = 0;
        csd.MaximumLength = 0;
        csd.Buffer = NULL;
        PsGetVersion(&major, &minor, &build, &csd);
        g_IdeCapacity16 = (BOOLEAN)(major > 5 || (major == 5 && minor >= 2 && (build > 3790 || csd.Length != 0)));
        IDE_DBG((IDE_PFX "DriverEntry: Windows %lu.%lu.%lu%s\n", major, minor, build,
                 g_IdeCapacity16 ? ", READ CAPACITY(16) used" : ""));
    }
#endif
#endif

    ZeroMemoryBytes(&initData, sizeof(HW_INITIALIZATION_DATA));

#ifdef IDE_NT31_COMPAT
    initData.HwInitializationDataSize = IDE_HWINIT_SIZE_NT35;
#elif defined(IDE_W9X)
    /* SCSIPORT.PDR fails any structure larger than 4Ch bytes (up to
       DeviceId) with "Init Failure", before HwFindAdapter is called */
    initData.HwInitializationDataSize = (ULONG)FIELD_OFFSET(HW_INITIALIZATION_DATA, DeviceId) + sizeof(PVOID);
#else
    initData.HwInitializationDataSize = sizeof(HW_INITIALIZATION_DATA);
#endif
    initData.HwInitialize = IdeHwInitialize;
    initData.HwStartIo = IdeStartIo;
    initData.HwInterrupt = IdeInterrupt;
    initData.HwResetBus = IdeResetBus;
    initData.HwFindAdapter = IdeFindAdapter;
#ifdef IDE_W9X
    initData.HwAdapterState = IdeAdapterState;
#endif
#if !defined(IDE_NT4)
    initData.HwAdapterControl = IdeAdapterControl;
#endif
    initData.DeviceExtensionSize = sizeof(HW_DEVICE_EXTENSION);
    initData.AdapterInterfaceType = PCIBus;
    /* Two channels: command block, control register each, and the bus
       master block */
    initData.NumberOfAccessRanges = 8;
    initData.MapBuffers = TRUE;
    initData.NeedPhysicalAddresses = TRUE;
    initData.AutoRequestSense = FALSE;
#if defined(IDE_W9X)
    initData.TaggedQueuing = FALSE;
    initData.MultipleRequestPerLu = FALSE;
#else
    /* NT 3.1-4.0, 2000/XP/x64: queued requests per disk in interrupt mode;
       INQUIRY reports CmdQue only for disks that get them (IdeDiskQueued).
       Not in the dump stack. */
    initData.TaggedQueuing = (BOOLEAN)!g_IdeDumpMode;
    initData.MultipleRequestPerLu = (BOOLEAN)!g_IdeDumpMode;
#endif

#if !defined(IDE_NT4)
    if (!g_IdeDumpMode) IdeEnsurePnpInterface(Argument2);
#endif

    status = ScsiPortInitialize(DriverObject, Argument2, &initData, NULL);

#ifdef IDE_NT31_COMPAT
    /* NT 3.1 refuses any other structure size before HwFindAdapter is ever
       called, and has no PCI bus to scan: retry with its 40h-byte layout on
       the ISA bus. PCI functions are then found through the ports, legacy
       channels by probing. */
    if (status != 0 && !g_IdeFindAdapterCalled) {
        IDE_DBG((IDE_PFX "DriverEntry: %08lX, retrying with the NT 3.1 layout\n", status));
        initData.HwInitializationDataSize = IDE_HWINIT_SIZE_NT31;
        initData.AdapterInterfaceType = Isa;
        status = ScsiPortInitialize(DriverObject, Argument2, &initData, NULL);
        IDE_DBG((IDE_PFX "DriverEntry: ScsiPortInitialize returned %08lX\n", status));
        if (g_IdeAdapterFound) IdeDisableInboxDrivers(Argument2);
        return status;
    }
#endif

#if defined(IDE_NT4)
    /* The ISA pass: legacy channels not behind a PCI function (ISA/VLB
       controllers), each channel an adapter of its own with its IRQ */
    if (!g_IdeDumpMode) {
        initData.AdapterInterfaceType = Isa;
        status2 = ScsiPortInitialize(DriverObject, Argument2, &initData, NULL);
        IDE_DBG((IDE_PFX "DriverEntry: ScsiPortInitialize returned %08lX (PCI), %08lX (ISA)\n", status, status2));
        if (status != 0 && status2 == 0) status = status2;
#ifndef IDE_W9X
        if (g_IdeAdapterFound) IdeDisableInboxDrivers(Argument2);
#endif
    } else {
        IDE_DBG((IDE_PFX "DriverEntry: ScsiPortInitialize returned %08lX\n", status));
    }
#else
    /* 2000/XP: everything comes through PnP, ISA controllers as *PNP0600.
       An adapter detected by ScsiPort itself (NT 4.0 style) would make
       this a legacy driver and take the system's sleep states away. The
       start IRP of a compatibility-mode PCI function gets its legacy IRQ
       added before ScsiPort sees it (idepnp.c). */
    (VOID)status2;
    if (!g_IdeDumpMode && status == 0) IdeHookPnp(DriverObject);
    IDE_DBG((IDE_PFX "DriverEntry: ScsiPortInitialize returned %08lX\n", status));
#endif
    return status;
}

/* ------------------------------------------------------------------ */
/* HwFindAdapter                                                       */
/* ------------------------------------------------------------------ */

static BOOLEAN
IdeArgPresent(IN PCHAR Args, IN PCHAR Key)
{
    ULONG i, j;
    CHAR a, b;

    if (Args == NULL) return FALSE;
    for (i = 0; Args[i] != 0; i++) {
        for (j = 0; Key[j] != 0; j++) {
            a = Args[i + j];
            b = Key[j];
            if (a >= 'a' && a <= 'z') a = (CHAR)(a - 'a' + 'A');
            if (a != b) break;
        }
        if (Key[j] == 0) return TRUE;
    }
    return FALSE;
}

/* Map one channel's ports and record it in the extension */
static BOOLEAN
IdeAttachChannel(
    IN PHW_DEVICE_EXTENSION HwInit,
    IN PPORT_CONFIGURATION_INFORMATION ConfigInfo,
    IN INTERFACE_TYPE BusType,
    IN ULONG BusNumber,
    IN ULONG Index,
    IN PIDE_CHANNEL_DESC Desc
)
{
    PIDE_CHANNEL ch = &HwInit->Channels[Index];
    SCSI_PHYSICAL_ADDRESS pa;

    ZeroMemoryBytes(ch, FIELD_OFFSET(IDE_CHANNEL, Prd));
    ch->CmdPort = Desc->CmdPort;
    ch->BmPort = Desc->BmPort;
    ch->Irq = Desc->Irq;
    ch->Native = Desc->Native;

    pa.HighPart = 0;
    pa.LowPart = Desc->CmdPort;
    ch->Cmd = (PUCHAR)ScsiPortGetDeviceBase(HwInit, BusType, BusNumber, pa, 8, TRUE);
    pa.LowPart = Desc->CtlPort;
    ch->Ctl = (PUCHAR)ScsiPortGetDeviceBase(HwInit, BusType, BusNumber, pa, 1, TRUE);
    if (ch->Cmd == NULL || ch->Ctl == NULL) {
        IDE_DBG((IDE_PFX "FindAdapter: mapping ports %lX/%lX failed\n",
                 (ULONG)Desc->CmdPort, (ULONG)Desc->CtlPort));
        return FALSE;
    }
    if (Desc->BmPort != 0) {
        pa.LowPart = Desc->BmPort;
        ch->Bm = (PUCHAR)ScsiPortGetDeviceBase(HwInit, BusType, BusNumber, pa, 8, TRUE);
        if (ch->Bm == NULL) {
            IDE_DBG((IDE_PFX "FindAdapter: mapping bus master block %lX failed, PIO only\n", (ULONG)Desc->BmPort));
        }
    }
    ch->Present = TRUE;
    IdeClaimPort(Desc->CmdPort);
    (VOID)ConfigInfo;
    return TRUE;
}

static VOID
IdeSetAccessRange(IN PPORT_CONFIGURATION_INFORMATION ConfigInfo, IN ULONG Index, IN ULONG Port, IN ULONG Length)
{
    PACCESS_RANGE ranges = *ConfigInfo->AccessRanges;

    if (ranges == NULL || Index >= ConfigInfo->NumberOfAccessRanges) return;
    ranges[Index].RangeStart.HighPart = 0;
    ranges[Index].RangeStart.LowPart = Port;
    ranges[Index].RangeLength = Length;
    ranges[Index].RangeInMemory = FALSE;
}

static PCHAR
IdeParseDecimal(IN PCHAR P, OUT PULONG Value)
{
    ULONG v = 0;
    PCHAR start = P;

    while (*P >= '0' && *P <= '9') v = v * 10 + (ULONG)(*P++ - '0');
    *Value = v;
    return (P == start) ? NULL : P;
}

/* SPINDOWN=n (minutes, 1-330): the ATA standby timer count. 1-240 count
   in units of 5 s (up to 20 minutes), 241-251 in units of 30 minutes. */
static UCHAR
IdeSpinDownCount(IN PCHAR Args)
{
    ULONG i, n;
    static const CHAR key[] = "SPINDOWN=";

    if (Args == NULL) return 0;
    for (i = 0; Args[i] != 0; i++) {
        ULONG j;
        for (j = 0; key[j] != 0; j++) {
            CHAR c = Args[i + j];
            if (c >= 'a' && c <= 'z') c = (CHAR)(c - 'a' + 'A');
            if (c != key[j]) break;
        }
        if (key[j] != 0) continue;
        if (IdeParseDecimal(&Args[i + j], &n) == NULL || n == 0) return 0;
        if (n <= 20) return (UCHAR)(n * 12);
        n = (n + 29) / 30;
        return (UCHAR)(240 + ((n > 11) ? 11 : n));
    }
    return 0;
}

/* OFF=item[,item...]: channels and devices the driver leaves alone;
   PIO=item[,item...]: channels and devices that run with PIO only.
   item = [bus.device.function:]channel[.unit], all decimal: channel 0 is
   the primary, 1 the secondary; unit 0 the master, 1 the slave. With the
   PCI location (as Device Manager shows it) the item applies to that
   controller only, without it to every controller. TRUE when the whole
   channel is listed; Units gets the units listed one by one. */
static BOOLEAN
IdeListLookup(IN PCHAR Args, IN PCHAR Key, IN BOOLEAN Pci, IN ULONG Bus, IN ULONG Slot, IN ULONG Channel,
              OUT PUCHAR Units)
{
    ULONG i, j, n, v[5], count, colon;
    PCHAR p;
    CHAR a;
    BOOLEAN off = FALSE;
    UCHAR units = 0;
    PCI_SLOT_NUMBER slot;

    slot.u.AsULONG = Slot;
    for (i = 0; Args != NULL && Args[i] != 0; i++) {
        for (j = 0; Key[j] != 0; j++) {
            a = Args[i + j];
            if (a >= 'a' && a <= 'z') a = (CHAR)(a - 'a' + 'A');
            if (a != Key[j]) break;
        }
        if (Key[j] != 0) continue;
        p = &Args[i + j];
        for (;;) {
            count = 0;
            colon = 0;
            while (count < 5) {
                p = IdeParseDecimal(p, &n);
                if (p == NULL) break;
                v[count++] = n;
                if (*p == ':' && count == 3 && colon == 0) { colon = 3; p++; continue; }
                if (*p == '.') { p++; continue; }
                break;
            }
            if (p == NULL) break;
            if (colon != 0 && (!Pci || v[0] != Bus || v[1] != slot.u.bits.DeviceNumber ||
                               v[2] != slot.u.bits.FunctionNumber)) {
                count = 0;          /* another controller */
            }
            n = count - colon;
            if (count > colon && v[colon] == Channel) {
                if (n == 1) off = TRUE;
                else if (n == 2 && v[colon + 1] < IDE_DEVICES_PER_CHANNEL) units |= (UCHAR)(1U << v[colon + 1]);
            }
            if (*p != ',') break;
            p++;
        }
    }
    if (Units != NULL) *Units = units;
    return off;
}

static BOOLEAN
IdeOffLookup(IN PCHAR Args, IN BOOLEAN Pci, IN ULONG Bus, IN ULONG Slot, IN ULONG Channel, OUT PUCHAR UnitsOff)
{
    return IdeListLookup(Args, "OFF=", Pci, Bus, Slot, Channel, UnitsOff);
}

ULONG
IdeFindAdapter(
    IN PVOID DeviceExtension,
    IN PVOID Context,
    IN PVOID BusInformation,
    IN PCHAR ArgumentString,
    IN OUT PPORT_CONFIGURATION_INFORMATION ConfigInfo,
    OUT PBOOLEAN Again
)
{
    PHW_DEVICE_EXTENSION hwInit = (PHW_DEVICE_EXTENSION)DeviceExtension;
    PCI_COMMON_CONFIG pciConfig;
    IDE_CHANNEL_DESC desc[2];
    ULONG descCount = 0, first = 0, count = 0;
    ULONG targetBus = 0, targetSlot = 0;
    ULONG i, c;
    BOOLEAN hasSlot, pci = FALSE, legacyPass, nativeOnly = FALSE;
    BOOLEAN interrupts, level2;
    INTERFACE_TYPE busType;
    ULONG busNumber;

    (VOID)Context;
    (VOID)BusInformation;
    *Again = FALSE;

#ifdef IDE_NT31_COMPAT
    g_IdeFindAdapterCalled = TRUE;
    IdePciProbeAccess(hwInit);
    hasSlot = (BOOLEAN)IDE_CONFIG_HAS(ConfigInfo, SlotNumber);
#else
    hasSlot = TRUE;
#endif
    if (hwInit->ChannelCount != 0) return SP_RETURN_FOUND;

    hwInit->DumpMode = (BOOLEAN)(g_IdeDumpMode || IdeArgPresent(ArgumentString, "DUMP="));
    /* ScsiPort's own enumeration (NT 4.0 everywhere, the ISA pass on
       2000/XP) as opposed to a PnP start or the dump stack's call */
#if defined(IDE_NT4)
    legacyPass = (BOOLEAN)!hwInit->DumpMode;
#else
    legacyPass = (BOOLEAN)(!hwInit->DumpMode && ConfigInfo->AdapterInterfaceType == Isa && hasSlot &&
                           ConfigInfo->SlotNumber == 0 && ConfigInfo->NumberOfAccessRanges != 0 &&
                           (*ConfigInfo->AccessRanges)[0].RangeLength == 0);
#endif
#if defined(IDE_NT4) && !defined(IDE_W9X)
    /* Before the first channel is taken */
    if (legacyPass) IdeResolvePortConflicts(hwInit);
#endif
#if defined(IDE_NT4) && !defined(IDE_W9X)
    /* NATIVEFIRST=1: channels in native mode get the first adapters (and
       disk numbers), for NT 3.1 booting from a native-mode controller */
    if (legacyPass && IdeArgPresent(ArgumentString, "NATIVEFIRST=1")) {
        ULONG b, s;
        nativeOnly = IdeScanPci(hwInit, TRUE, &b, &s, &pciConfig);
    }
#endif
    hwInit->DmaAllowed = (BOOLEAN)!IdeArgPresent(ArgumentString, "DMA=0");
    hwInit->TrimAllowed = (BOOLEAN)!IdeArgPresent(ArgumentString, "TRIM=0");
#if defined(IDE_W9X)
    hwInit->QueueAllowed = FALSE;
#else
    hwInit->QueueAllowed = (BOOLEAN)!IdeArgPresent(ArgumentString, "QUEUE=0");
#endif
    hwInit->StandbyAtShutdown = IdeArgPresent(ArgumentString, "STANDBY=1");
    hwInit->SpinDown = IdeSpinDownCount(ArgumentString);
    hwInit->Capacity16 = g_IdeCapacity16;
    if (IdeArgPresent(ArgumentString, "RC16=1")) hwInit->Capacity16 = TRUE;
    if (IdeArgPresent(ArgumentString, "RC16=0")) hwInit->Capacity16 = FALSE;
    hwInit->Sector4K = IdeArgPresent(ArgumentString, "4K=1");
    hwInit->HotPlug = (BOOLEAN)(IdeArgPresent(ArgumentString, "HOTPLUG=1") && !hwInit->DumpMode);
    hwInit->DmaForced = IdeArgPresent(ArgumentString, "DMA=1");
    hwInit->PciWritable = TRUE;

    IDE_DBG((IDE_PFX "FindAdapter: bus type %lu, bus %lu slot %08lX, %lu range(s), IRQ %lu%s\n",
             (ULONG)ConfigInfo->AdapterInterfaceType, ConfigInfo->SystemIoBusNumber,
             hasSlot ? ConfigInfo->SlotNumber : 0xFFFFFFFF, ConfigInfo->NumberOfAccessRanges,
             ConfigInfo->BusInterruptLevel, hwInit->DumpMode ? ", dump" : ""));

#if defined(IDE_NT4) && !defined(IDE_W9X)
selectChannel:
#endif
    pci = FALSE;
    descCount = 0;
    first = 0;
    count = 0;
    /* Step 1: the PCI function ScsiPort / PnP / SCSIPORT.PDR called us for */
    if (hasSlot && ConfigInfo->AdapterInterfaceType == PCIBus) {
        targetBus = ConfigInfo->SystemIoBusNumber;
        targetSlot = ConfigInfo->SlotNumber;
        if (IdeReadPciHeader(hwInit, targetBus, targetSlot, &pciConfig, NULL) &&
            IdePciConfigIsIde(&pciConfig)) {
            descCount = IdeDescribePciChannels(&pciConfig, desc);
#if !defined(IDE_NT4)
            /* A PnP start: the function is this device node's, also when an
               earlier instance (before a stop, removal or driver update)
               left its channels in the claim table */
            if (!legacyPass && descCount != 0) pci = TRUE;
#endif
            for (i = 0; i < descCount && !pci; i++) {
                if (!IdeIsPortClaimed(desc[i].CmdPort) && (!nativeOnly || desc[i].Native)) pci = TRUE;
            }
#if !defined(IDE_NT4)
            if (!pci && !legacyPass) return SP_RETURN_NOT_FOUND;
#endif
        }
    }

    /* Step 2: the next PCI IDE function with a free channel (NT 4.0 and
       NT 3.1 scan the bus themselves) */
#if defined(IDE_NT4)
    if (!pci && ConfigInfo->AdapterInterfaceType != Isa) {
        if (IdeScanPci(hwInit, nativeOnly, &targetBus, &targetSlot, &pciConfig)) {
            descCount = IdeDescribePciChannels(&pciConfig, desc);
            pci = TRUE;
        }
    }
#ifdef IDE_NT31_COMPAT
    /* NT 3.1: one ISA pass does the PCI functions too */
    if (!pci && !hasSlot && IdeScanPci(hwInit, nativeOnly, &targetBus, &targetSlot, &pciConfig)) {
        descCount = IdeDescribePciChannels(&pciConfig, desc);
        pci = TRUE;
    }
#endif
#else
#endif

    if (pci) {
        /* Which of the function's channels, and how many, this instance takes */
        for (first = 0; first < descCount &&
                        (IdeIsPortClaimed(desc[first].CmdPort) || (nativeOnly && !desc[first].Native)); first++) ;
#if !defined(IDE_NT4)
        if (!legacyPass) first = 0;             /* PnP start: the whole function */
#endif
#if !defined(IDE_NT4)
        if (legacyPass) {
            while (first < descCount && desc[first].Native) first++;
        }
#endif
        if (first >= descCount) return SP_RETURN_NOT_FOUND;
#ifdef IDE_W9X
        count = descCount - first;              /* the whole function: one call per device node */
#else
        if (legacyPass && !IDE_CHIP_SERIALIZED(IdeChipKind(pciConfig.VendorID, pciConfig.DeviceID))) {
            count = 1;                          /* one channel per instance: its own IRQ */
        } else {
            count = descCount - first;          /* the whole function */
        }
#endif
        hwInit->HasPci = TRUE;
        hwInit->PciBus = targetBus;
        hwInit->PciSlot = targetSlot;
        hwInit->VendorId = pciConfig.VendorID;
        hwInit->DeviceId = pciConfig.DeviceID;
        hwInit->Intel = IdeIntelKind(pciConfig.VendorID, pciConfig.DeviceID);
        hwInit->FirstChannel = desc[first].Index;

        /* I/O space and bus master on */
        if ((pciConfig.Command & 0x0005) != 0x0005 || (pciConfig.Command & (1 << 10))) {
            IdePciWriteConfig(hwInit, 0x04, 2, (pciConfig.Command | 0x0005) & ~(1UL << 10));
        }
        IDE_DBG((IDE_PFX "FindAdapter: %04lX:%04lX at bus %lu slot %08lX, progif %02lX, channel %lu%s\n",
                 (ULONG)pciConfig.VendorID, (ULONG)pciConfig.DeviceID, targetBus, targetSlot,
                 (ULONG)pciConfig.ProgIf, (ULONG)desc[first].Index, (count > 1) ? " and next" : ""));
    } else if (legacyPass && (ConfigInfo->AdapterInterfaceType == Isa || !hasSlot)) {
        /* Step 3: a legacy channel nobody claimed (ISA pass, NT 3.1) */
        for (i = 0; i < IDE_LEGACY_CHANNELS; i++) {
            if (IdeIsPortClaimed(g_IdeLegacy[i].Cmd)) continue;
#if !defined(IDE_NT4)
            /* A PCI function's channel: PnP starts the function (idepnp.c) */
            if (IdeFindCompatFunction(hwInit, g_IdeLegacy[i].Cmd, TRUE, &targetBus, &targetSlot, &pciConfig)) continue;
#endif
            if (!IdeLegacyChannelPresent(g_IdeLegacy[i].Cmd, g_IdeLegacy[i].Ctl)) {
                IdeClaimPort(g_IdeLegacy[i].Cmd);   /* not probed again */
                continue;
            }
            break;
        }
        if (i >= IDE_LEGACY_CHANNELS) return SP_RETURN_NOT_FOUND;
        ZeroMemoryBytes(&desc[0], sizeof(desc[0]));
        desc[0].CmdPort = g_IdeLegacy[i].Cmd;
        desc[0].CtlPort = g_IdeLegacy[i].Ctl;
        desc[0].Irq = g_IdeLegacy[i].Irq;
        desc[0].Index = (UCHAR)(i & 1);
        descCount = 1;
        first = 0;
        count = 1;
        hwInit->FirstChannel = desc[0].Index;
        IDE_DBG((IDE_PFX "FindAdapter: legacy channel at %lX, IRQ %lu\n", (ULONG)desc[0].CmdPort, (ULONG)desc[0].Irq));
    } else {
#if defined(IDE_NT4)
        return SP_RETURN_NOT_FOUND;
#else
        /* PnP ISA (*PNP0600) or a dump instance: ports from the resources */
        {
            PACCESS_RANGE ranges = *ConfigInfo->AccessRanges;
            ZeroMemoryBytes(&desc[0], sizeof(desc[0]));
            if (ranges != NULL && ConfigInfo->NumberOfAccessRanges >= 2 && ranges[0].RangeLength >= 8) {
                desc[0].CmdPort = (USHORT)ranges[0].RangeStart.LowPart;
                desc[0].CtlPort = (USHORT)(ranges[1].RangeStart.LowPart + ((ranges[1].RangeLength >= 4) ? 2 : 0));
                desc[0].Irq = (UCHAR)ConfigInfo->BusInterruptLevel;
                if (ConfigInfo->NumberOfAccessRanges >= 3 && ranges[2].RangeLength >= 8) {
                    desc[0].BmPort = (USHORT)ranges[2].RangeStart.LowPart;
                }
            } else if (hwInit->DumpMode) {
                /* The dump stack's copy of a legacy adapter's configuration:
                   the ISA pass reports no ranges for a PCI function's
                   channel (see there), its IRQ names the channel */
                for (i = 0; i < IDE_LEGACY_CHANNELS; i++) {
                    if (g_IdeLegacy[i].Irq == ConfigInfo->BusInterruptLevel) break;
                }
                if (i >= IDE_LEGACY_CHANNELS) return SP_RETURN_NOT_FOUND;
                desc[0].CmdPort = g_IdeLegacy[i].Cmd;
                desc[0].CtlPort = g_IdeLegacy[i].Ctl;
                desc[0].Irq = g_IdeLegacy[i].Irq;
                if (IdeFindCompatFunction(hwInit, desc[0].CmdPort, FALSE, &targetBus, &targetSlot, &pciConfig)) {
                    IDE_CHANNEL_DESC all[2];
                    ULONG n = IdeDescribePciChannels(&pciConfig, all);
                    for (i = 0; i < n; i++) {
                        if (all[i].CmdPort == desc[0].CmdPort) desc[0].BmPort = all[i].BmPort;
                    }
                    hwInit->HasPci = TRUE;
                    hwInit->PciBus = targetBus;
                    hwInit->PciSlot = targetSlot;
                    hwInit->VendorId = pciConfig.VendorID;
                    hwInit->DeviceId = pciConfig.DeviceID;
                    hwInit->Intel = IdeIntelKind(pciConfig.VendorID, pciConfig.DeviceID);
                }
            } else {
                return SP_RETURN_NOT_FOUND;
            }
            desc[0].Index = (UCHAR)((desc[0].CmdPort == IDE_LEGACY_SECONDARY_CMD) ? 1 : 0);
            descCount = 1;
            first = 0;
            count = 1;
            hwInit->FirstChannel = desc[0].Index;
            IDE_DBG((IDE_PFX "FindAdapter: channel from %s at %lX\n", (ranges != NULL && ranges[0].RangeLength >= 8) ? "resources" : "its IRQ", (ULONG)desc[0].CmdPort));
        }
#endif
    }

#if defined(IDE_NT4) && !defined(IDE_W9X)
    /* A channel turned off as a whole (OFF=) gets no adapter: its ports
       stay free. The next channel is taken instead. */
    if (legacyPass && count == 1 &&
        IdeOffLookup(ArgumentString, pci, targetBus, targetSlot, desc[first].Index, NULL)) {
        IDE_DBG((IDE_PFX "FindAdapter: channel at %lX turned off (OFF=)\n", (ULONG)desc[first].CmdPort));
        IdeClaimPort(desc[first].CmdPort);
        goto selectChannel;
    }
#endif

    /* Bus type and number for mapping and the interrupt */
    busType = ConfigInfo->AdapterInterfaceType;
    busNumber = ConfigInfo->SystemIoBusNumber;
    /* Our own enumeration and the dump stack: the interrupt and bus type
       are ours to set. A PnP start brought them in the resources. */
    if (legacyPass || hasSlot == FALSE || ConfigInfo->AdapterInterfaceType != PCIBus) {
        if (pci && desc[first].Native) {
            /* PCI interrupt (level, shared): the function's own slot */
            busType = PCIBus;
            busNumber = targetBus;
            if (hasSlot) {
                ConfigInfo->SystemIoBusNumber = targetBus;
                ConfigInfo->SlotNumber = targetSlot;
            }
            ConfigInfo->InterruptMode = LevelSensitive;
            ConfigInfo->BusInterruptLevel = desc[first].Irq;
            ConfigInfo->BusInterruptVector = desc[first].Irq;
#ifdef IDE_NT31_COMPAT
            if (!hasSlot) {
                /* NT 3.1 has no PCI bus handler: INTx only on request, on the
                   EISA bus; Fast Polling otherwise */
                busType = Eisa;
                busNumber = 0;
                ConfigInfo->AdapterInterfaceType = Eisa;
                if (!IdeArgPresent(ArgumentString, "IRQ=1")) {
                    ConfigInfo->BusInterruptLevel = 0;
                    ConfigInfo->BusInterruptVector = 0;
                }
            }
#endif
        } else {
            /* Legacy IRQ 14/15 (edge). The EISA bus handler gives a 32-bit DMA
               adapter for the bus master; a plain ISA channel needs none. */
            busType = (desc[first].BmPort != 0) ? Eisa : Isa;
            busNumber = 0;
            ConfigInfo->AdapterInterfaceType = busType;
            ConfigInfo->SystemIoBusNumber = 0;
            ConfigInfo->InterruptMode = Latched;
            ConfigInfo->BusInterruptLevel = desc[first].Irq;
            ConfigInfo->BusInterruptVector = desc[first].Irq;
        }
        if (IdeArgPresent(ArgumentString, "IRQ=0") ||
            (pci && IDE_CHIP_SERIALIZED(IdeChipKind(pciConfig.VendorID, pciConfig.DeviceID)))) {
            ConfigInfo->BusInterruptLevel = 0;
            ConfigInfo->BusInterruptVector = 0;
        }
#if defined(IDE_NT4) && !defined(IDE_W9X)
        /* The HAL must have a vector for the line: an MPS HAL whose MP
           table has no entry for it gives none, and ScsiPort would then
           fail the adapter (0x7B with the system disk on it). Fast Polling
           needs no interrupt. */
        if (ConfigInfo->BusInterruptLevel != 0 || ConfigInfo->BusInterruptVector != 0) {
            UCHAR irql = 0;
            ULONG affinity = 0;
            ULONG vector = HalGetInterruptVector(ConfigInfo->AdapterInterfaceType, ConfigInfo->SystemIoBusNumber,
                                                 ConfigInfo->BusInterruptLevel, ConfigInfo->BusInterruptVector,
                                                 &irql, &affinity);
            if (vector == 0 || affinity == 0) {
                IDE_DBG((IDE_PFX "FindAdapter: no vector for IRQ %lu (vector %lu, affinity %lX), Fast Polling\n",
                         ConfigInfo->BusInterruptLevel, vector, affinity));
                ConfigInfo->BusInterruptLevel = 0;
                ConfigInfo->BusInterruptVector = 0;
            }
        }
#endif
        /* Report the ranges this instance uses. On 2000/XP a PCI function's
           ports are on record with its device node; reported again here they
           would conflict with it. */
        for (i = 0; i < ConfigInfo->NumberOfAccessRanges; i++) IdeSetAccessRange(ConfigInfo, i, 0, 0);
#if !defined(IDE_NT4)
        if (!pci)
#endif
        {
            for (c = 0; c < count && 3 * c + 2 < ConfigInfo->NumberOfAccessRanges; c++) {
                IdeSetAccessRange(ConfigInfo, 3 * c, desc[first + c].CmdPort, 8);
                IdeSetAccessRange(ConfigInfo, 3 * c + 1, desc[first + c].CtlPort, 1);
                IdeSetAccessRange(ConfigInfo, 3 * c + 2, desc[first + c].BmPort, desc[first + c].BmPort ? 8 : 0);
            }
        }
        *Again = TRUE;
    } else if (pci) {
        busType = PCIBus;
        busNumber = targetBus;
    }

    for (c = 0; c < count; c++) {
        if (!IdeAttachChannel(hwInit, ConfigInfo, busType, busNumber, c, &desc[first + c])) {
            return SP_RETURN_ERROR;
        }
        hwInit->Channels[c].Off = IdeOffLookup(ArgumentString, pci, targetBus, targetSlot, desc[first + c].Index,
                                               &hwInit->Channels[c].UnitsOff);
        if (IdeListLookup(ArgumentString, "PIO=", pci, targetBus, targetSlot, desc[first + c].Index,
                          &hwInit->Channels[c].UnitsPio)) {
            hwInit->Channels[c].UnitsPio = (1U << IDE_DEVICES_PER_CHANNEL) - 1;
        }
    }
    hwInit->ChannelCount = (UCHAR)count;
    if (hwInit->HasPci && !IdeChipSetup(hwInit, &pciConfig, busType, busNumber)) {
        hwInit->ChannelCount = 0;
        return SP_RETURN_NOT_FOUND;
    }

    /* Legacy channels: atdisk must leave them alone */
    for (c = 0; c < count; c++) {
        if (desc[first + c].CmdPort == IDE_LEGACY_PRIMARY_CMD) ConfigInfo->AtdiskPrimaryClaimed = TRUE;
        if (desc[first + c].CmdPort == IDE_LEGACY_SECONDARY_CMD) ConfigInfo->AtdiskSecondaryClaimed = TRUE;
    }

    if (IDE_CONFIG_HAS(ConfigInfo, MaximumNumberOfTargets)) {
        ConfigInfo->MaximumNumberOfTargets = (UCHAR)(count * IDE_DEVICES_PER_CHANNEL);
    }
    ConfigInfo->NumberOfBuses = 1;
    ConfigInfo->InitiatorBusId[0] = 7;
    ConfigInfo->MaximumTransferLength = IDE_MAX_TRANSFER;
    ConfigInfo->NumberOfPhysicalBreaks = IDE_MAX_PHYS_BREAKS;
    ConfigInfo->AlignmentMask = 0x1;
    ConfigInfo->CachesData = TRUE;             /* ScsiPort passes SRB_FUNCTION_SHUTDOWN and FLUSH only then */

    /* A 32-bit scatter/gather master. Also for a PCI channel without a
       bus master: ScsiPort allocates the uncached extension (PRD tables,
       IDENTIFY buffer) through the adapter's DMA object, and a PCI or
       EISA slave gets none. A plain ISA channel: no DMA adapter (an ISA
       master would get map registers below 16 MB, and their copy-back
       would overwrite what PIO put into the buffer). */
    ConfigInfo->Master = FALSE;
    ConfigInfo->ScatterGather = FALSE;
    ConfigInfo->Dma32BitAddresses = FALSE;
    for (c = 0; c < count; c++) {
        if (hwInit->Channels[c].Bm != NULL || busType != Isa) {
            ConfigInfo->Master = TRUE;
            ConfigInfo->ScatterGather = TRUE;
            ConfigInfo->Dma32BitAddresses = TRUE;
        }
    }

    /* Commands complete in the interrupt where one is connected: the first
       channel's, the second one's own (BusInterruptLevel2) or the shared
       PCI line of a native-mode controller. Off in the dump stack and with
       IRQ=0. */
    interrupts = (BOOLEAN)(ConfigInfo->BusInterruptLevel != 0 || ConfigInfo->BusInterruptVector != 0);
#ifdef IDE_W9X
    level2 = FALSE;                             /* SCSIPORT.PDR has no second interrupt */
#else
    level2 = (BOOLEAN)(IDE_CONFIG_HAS(ConfigInfo, BusInterruptLevel2) &&
                       (ConfigInfo->BusInterruptLevel2 != 0 || ConfigInfo->BusInterruptVector2 != 0));
#endif
    if (hwInit->DumpMode || IdeArgPresent(ArgumentString, "IRQ=0")) interrupts = FALSE;
    if (IDE_CHIP_SERIALIZED(hwInit->Chip)) interrupts = FALSE;
#ifdef IDE_W9X
    /* Their latch is cleared in config space, which is not touched from
       an interrupt on 9x */
    if (hwInit->Chip == IDE_CHIP_CMD643 || hwInit->Chip == IDE_CHIP_CMD646) interrupts = FALSE;
#endif
    hwInit->AsyncMode = interrupts;
    for (c = 0; c < count; c++) {
        PIDE_CHANNEL ch = &hwInit->Channels[c];
        /* The second channel of a PnP-started compatibility-mode function:
           ScsiPort connects only the first interrupt of a PnP adapter */
        BOOLEAN line = (BOOLEAN)(c == 0 || ch->Native || (level2 && legacyPass));
#if !defined(IDE_NT4)
        if (!legacyPass) {
            /* PnP start: the one interrupt in the resources. A channel in
               compatibility mode raises its ISA IRQ, a native one the PCI
               line (one of each in a function with mixed modes). */
            ULONG irq = ConfigInfo->BusInterruptLevel, k;
            BOOLEAN mixed = FALSE;
            for (k = 0; k < count; k++) {
                if (!hwInit->Channels[k].Native) mixed = TRUE;
            }
            line = (BOOLEAN)(ch->Native ? !(mixed && (irq == IDE_LEGACY_PRIMARY_IRQ || irq == IDE_LEGACY_SECONDARY_IRQ))
                                        : (irq == ch->Irq));
        }
#endif
        ch->Async = (BOOLEAN)(interrupts && line);
    }
#if !defined(IDE_NT4)
    /* PnP start of a compatibility-mode function: the PnP front end
       connects IRQ 15 for the secondary channel once ScsiPort started the
       adapter (x86) */
    if (!legacyPass && interrupts) {
        for (c = 0; c < count; c++) {
            PIDE_CHANNEL ch = &hwInit->Channels[c];
            if (!ch->Native && !ch->Async && ch->Irq == IDE_LEGACY_SECONDARY_IRQ) {
                IdePnpNoteAdapter(hwInit);
                break;
            }
        }
    }
#endif

    IDE_DBG((IDE_PFX "FindAdapter: %lu channel(s) at %lX%s, IRQ %lu/%lu, %s%s\n",
             count, (ULONG)desc[first].CmdPort, hwInit->Channels[0].Bm ? " (bus master)" : "",
             ConfigInfo->BusInterruptLevel,
             level2 ? ConfigInfo->BusInterruptLevel2 : 0,
             interrupts ? "interrupt" : "Fast Polling",
             hwInit->DmaAllowed ? "" : ", DMA off"));

    if (!IdeAllocateDma(hwInit, ConfigInfo)) return SP_RETURN_ERROR;
#if defined(IDE_NT4) && !defined(IDE_W9X)
    g_IdeAdapterFound = TRUE;
#endif
    return SP_RETURN_FOUND;
}

/* ------------------------------------------------------------------ */
/* HwInitialize                                                        */
/* ------------------------------------------------------------------ */

BOOLEAN
IdeHwInitialize(IN PVOID DeviceExtension)
{
    IdeInitializeAll((PHW_DEVICE_EXTENSION)DeviceExtension);
    IDE_DBG((IDE_PFX "HwInitialize: done\n"));
    return TRUE;
}

/* ------------------------------------------------------------------ */
/* HwStartIo                                                           */
/* ------------------------------------------------------------------ */

static VOID
IdeResetTarget(IN PHW_DEVICE_EXTENSION HwInit, IN ULONG Target)
{
    ULONG c = Target / IDE_DEVICES_PER_CHANNEL;

    if (c >= HwInit->ChannelCount || !HwInit->Channels[c].Present) return;
    IdeFailOutstanding(HwInit, c, SRB_STATUS_BUS_RESET);
    IdeResetChannel(HwInit, c);
}

/* A disk that takes queued requests: interrupt mode with DMA */
BOOLEAN
IdeDiskQueued(IN PHW_DEVICE_EXTENSION HwInit, IN PIDE_CHANNEL Ch, IN PIDE_DEVICE Dev)
{
    return (BOOLEAN)(HwInit->QueueAllowed && !HwInit->DumpMode && Ch->Async && HwInit->AsyncMode &&
                     Dev->Present && !Dev->IsAtapi && Dev->UseDma);
}

/* A DMA read/write for a channel that is busy with one already: it can
   wait and be started from the completion of the one before */
static BOOLEAN
IdeCanQueue(IN PHW_DEVICE_EXTENSION HwInit, IN PSCSI_REQUEST_BLOCK Srb)
{
    PIDE_CHANNEL ch;
    PIDE_DEVICE dev;

    if (Srb->Function != SRB_FUNCTION_EXECUTE_SCSI || HwInit->DumpMode) return FALSE;
    if (Srb->TargetId >= HwInit->ChannelCount * IDE_DEVICES_PER_CHANNEL) return FALSE;
    ch = IDE_CHANNEL_OF_TARGET(HwInit, Srb->TargetId);
    dev = IDE_DEVICE_OF_TARGET(HwInit, Srb->TargetId);
    if (!ch->Async || !dev->Present || !dev->UseDma || ch->NeedsSetup || HwInit->CheckState) return FALSE;

    switch (Srb->Cdb[0]) {
    case SCSIOP_READ6:
    case SCSIOP_WRITE6:
    case SCSIOP_READ:
    case SCSIOP_WRITE:
    case IDE_SCSIOP_READ12:
    case IDE_SCSIOP_WRITE12:
        return TRUE;
    case IDE_SCSIOP_READ16:
    case IDE_SCSIOP_WRITE16:
        return (BOOLEAN)!dev->IsAtapi;
    default:
        return FALSE;
    }
}

/* After a request went to the channel or its queue: a queued request
   (tagged) lets ScsiPort send the next one for the same disk while there
   is room, otherwise only requests for other targets */
static VOID
IdeRequestNext(IN PHW_DEVICE_EXTENSION HwInit, IN PIDE_CHANNEL Ch, IN PSCSI_REQUEST_BLOCK Srb)
{
    if (Ch != NULL && (Srb->SrbFlags & SRB_FLAGS_QUEUE_ACTION_ENABLE) && Srb->Function == SRB_FUNCTION_EXECUTE_SCSI) {
        if (Ch->QueueCount < IDE_QUEUE_DEPTH) {
            ScsiPortNotification(NextLuRequest, HwInit, Srb->PathId, Srb->TargetId, Srb->Lun);
            return;
        }
        Ch->LuBlocked |= (UCHAR)(1 << IDE_UNIT_OF_TARGET(Srb->TargetId));
    }
    ScsiPortNotification(NextRequest, HwInit, NULL);
}

static BOOLEAN IdeStartIoBody(IN PHW_DEVICE_EXTENSION hwInit, IN PSCSI_REQUEST_BLOCK Srb);

BOOLEAN
IdeStartIo(IN PVOID DeviceExtension, IN PSCSI_REQUEST_BLOCK Srb)
{
    PHW_DEVICE_EXTENSION hwInit = (PHW_DEVICE_EXTENSION)DeviceExtension;
    BOOLEAN result;

    IdeEnter(hwInit);
    result = IdeStartIoBody(hwInit, Srb);
    IdeLeave(hwInit);
    return result;
}

static BOOLEAN
IdeStartIoBody(IN PHW_DEVICE_EXTENSION hwInit, IN PSCSI_REQUEST_BLOCK Srb)
{
    PIDE_CHANNEL ch = NULL;
    ULONG c, unit;

    Srb->SrbStatus = SRB_STATUS_PENDING;

    if (Srb->TargetId < hwInit->ChannelCount * IDE_DEVICES_PER_CHANNEL) {
        ch = IDE_CHANNEL_OF_TARGET(hwInit, Srb->TargetId);
    }

    /* The channel is busy with an interrupt-completed command */
    if (ch != NULL && ch->Outstanding != NULL) {
        if (ch->QueueCount < IDE_QUEUE_DEPTH && IdeCanQueue(hwInit, Srb)) {
            ch->Queue[(ch->QueueHead + ch->QueueCount) % IDE_QUEUE_DEPTH] = Srb;
            ch->QueueCount++;
            IdeRequestNext(hwInit, ch, Srb);
            return TRUE;
        }
        IdeDrainChannel(hwInit, Srb->TargetId / IDE_DEVICES_PER_CHANNEL);
    }

    switch (Srb->Function) {
    case SRB_FUNCTION_EXECUTE_SCSI:
        IdeCheckState(hwInit);
        IdeSatlProcessSrb(hwInit, Srb);
        break;

    case SRB_FUNCTION_IO_CONTROL:
        IdeProcessIoControl(hwInit, Srb);
        break;

    case SRB_FUNCTION_RESET_BUS:
        IdeResetBus(hwInit, Srb->PathId);
        Srb->SrbStatus = SRB_STATUS_SUCCESS;
        break;

    case SRB_FUNCTION_RESET_DEVICE:
        IdeResetTarget(hwInit, Srb->TargetId);
        Srb->SrbStatus = SRB_STATUS_SUCCESS;
        break;

    case SRB_FUNCTION_ABORT_COMMAND:
        Srb->SrbStatus = SRB_STATUS_ABORT_FAILED;
        break;

    case SRB_FUNCTION_SHUTDOWN:
    case SRB_FUNCTION_FLUSH:
        IdeCheckState(hwInit);
        if (ch != NULL) {
            c = Srb->TargetId / IDE_DEVICES_PER_CHANNEL;
            unit = IDE_UNIT_OF_TARGET(Srb->TargetId);
            if (Srb->Function == SRB_FUNCTION_SHUTDOWN) {
                for (unit = 0; unit < IDE_DEVICES_PER_CHANNEL; unit++) IdeShutdownDevice(hwInit, c, unit);
            } else {
                IdeFlushDevice(hwInit, c, unit);
            }
        }
        Srb->SrbStatus = SRB_STATUS_SUCCESS;
        break;

    default:
        Srb->SrbStatus = SRB_STATUS_INVALID_REQUEST;
        break;
    }

    if (Srb->SrbStatus != SRB_STATUS_PENDING) {
        ScsiPortNotification(RequestComplete, hwInit, Srb);
        ScsiPortNotification(NextRequest, hwInit, NULL);
    } else {
        IdeArmTimer(hwInit);
        IdeRequestNext(hwInit, ch, Srb);
    }
    return TRUE;
}

/* ------------------------------------------------------------------ */
/* HwInterrupt                                                         */
/* ------------------------------------------------------------------ */

/* Every channel: commands in flight, stray interrupts */
static BOOLEAN
IdeServiceAll(IN PHW_DEVICE_EXTENSION hwInit)
{
    BOOLEAN claimed = FALSE;
    ULONG c;
    UCHAR bmsts;

    for (c = 0; c < hwInit->ChannelCount; c++) {
        PIDE_CHANNEL ch = &hwInit->Channels[c];
        if (!ch->Present) continue;

        if (ch->Outstanding != NULL) {
            if (IdeServiceChannel(hwInit, c, TRUE) != 0) {
                hwInit->MissedInterrupts = 0;
                claimed = TRUE;
            }
            continue;
        }
        /* Nothing in flight: a stray interrupt (reset, polled command on
           a device with nIEN clear). Acknowledge it on our own channels. */
        if (ch->Bm != NULL) {
            bmsts = IDE_INB(ch->Bm + BM_REG_STATUS);
            if (bmsts & BM_STS_INTERRUPT) {
                IDE_OUTB(ch->Bm + BM_REG_STATUS, bmsts | BM_STS_INTERRUPT);
                IDE_INB(ch->Cmd + IDE_REG_STATUS);
                claimed = TRUE;
            }
        } else if (!ch->Native && hwInit->AsyncMode) {
            /* Legacy line of our own: reading the status drops INTRQ */
            IDE_INB(ch->Cmd + IDE_REG_STATUS);
            claimed = TRUE;
        }
    }
    /* CMD64x: the controller holds its PCI interrupt while a latch is set */
    if (IDE_CHIP_IS_CMD(hwInit->Chip)) {
        for (c = 0; c < hwInit->ChannelCount; c++) {
            PIDE_CHANNEL ch = &hwInit->Channels[c];
            if (ch->Present && IdeChipClearInterrupt(hwInit, c)) {
                if (ch->Outstanding == NULL) IDE_INB(ch->Cmd + IDE_REG_STATUS);
                claimed = TRUE;
            }
        }
    }
    if (claimed) hwInit->InterruptCount++;
    return claimed;
}

/* Re-entry. On an APIC HAL the IRQ 15 the driver connects itself (2000/XP
   x64, a compatibility-mode controller) can have a higher level than
   ScsiPort's interrupt, and on a uniprocessor kernel ScsiPort's lock then
   does not keep it out of a routine of the driver that is running: it
   would complete, on the same processor, a command that routine is in
   the middle of. Such an interrupt only notes that the channels must be
   looked at, and the routine it came into does that before it returns. */
static VOID
IdeEnter(IN PHW_DEVICE_EXTENSION HwInit)
{
    HwInit->InMiniport++;
}

static VOID
IdeLeave(IN PHW_DEVICE_EXTENSION HwInit)
{
    while (HwInit->Recheck) {
        HwInit->Recheck = FALSE;
        IdeServiceAll(HwInit);
    }
    HwInit->InMiniport--;
}

BOOLEAN
IdeInterrupt(IN PVOID DeviceExtension)
{
    PHW_DEVICE_EXTENSION hwInit = (PHW_DEVICE_EXTENSION)DeviceExtension;
    BOOLEAN claimed;

    if (hwInit->InMiniport != 0) {
        hwInit->Recheck = TRUE;
        hwInit->NestedInterrupts++;
        return TRUE;
    }
    IdeEnter(hwInit);
    claimed = IdeServiceAll(hwInit);
    if (hwInit->Recheck) claimed = TRUE;
    IdeLeave(hwInit);
    return claimed;
}

/* ------------------------------------------------------------------ */
/* HwResetBus                                                          */
/* ------------------------------------------------------------------ */

BOOLEAN
IdeResetBus(IN PVOID HwDeviceExtension, IN ULONG PathId)
{
    PHW_DEVICE_EXTENSION hwInit = (PHW_DEVICE_EXTENSION)HwDeviceExtension;
    ULONG c, unit;

    (VOID)PathId;
    IDE_DBG((IDE_PFX "ResetBus\n"));

    IdeEnter(hwInit);
    for (c = 0; c < hwInit->ChannelCount; c++) {
        PIDE_CHANNEL ch = &hwInit->Channels[c];
        if (!ch->Present) continue;
        if (ch->Outstanding != NULL) {
            /* A DMA command that never finished: counts against DMA */
            PIDE_DEVICE dev = &ch->Devices[ch->ActiveUnit];
            if (++dev->DmaErrors >= IDE_DMA_ERROR_LIMIT) {
                dev->UseDma = FALSE;
                dev->ModeType = IDE_MODE_PIO;
                dev->Mode = 0;
            }
        }
        IdeFailOutstanding(hwInit, c, SRB_STATUS_BUS_RESET);
        IdeResetChannel(hwInit, c);
        for (unit = 0; unit < IDE_DEVICES_PER_CHANNEL; unit++) ch->Devices[unit].SensePending = FALSE;
    }
    IdeLeave(hwInit);
    return TRUE;
}

/* ------------------------------------------------------------------ */
/* HwAdapterControl (2000/XP/x64): stop and restart for power changes  */
/* ------------------------------------------------------------------ */

#if !defined(IDE_NT4)
SCSI_ADAPTER_CONTROL_STATUS
IdeAdapterControl(
    IN PVOID DeviceExtension,
    IN SCSI_ADAPTER_CONTROL_TYPE ControlType,
    IN PVOID Parameters
)
{
    PHW_DEVICE_EXTENSION hwInit = (PHW_DEVICE_EXTENSION)DeviceExtension;
    PSCSI_SUPPORTED_CONTROL_TYPE_LIST list;
    ULONG i, c;

    switch (ControlType) {
    case ScsiQuerySupportedControlTypes:
        list = (PSCSI_SUPPORTED_CONTROL_TYPE_LIST)Parameters;
        for (i = 0; i < list->MaxControlType; i++) {
            list->SupportedTypeList[i] = (BOOLEAN)(i == ScsiQuerySupportedControlTypes ||
                                                  i == ScsiStopAdapter ||
                                                  i == ScsiRestartAdapter);
        }
        return ScsiAdapterControlSuccess;

    case ScsiStopAdapter:
        IDE_DBG((IDE_PFX "AdapterControl: stop\n"));
        for (c = 0; c < hwInit->ChannelCount; c++) {
            if (!hwInit->Channels[c].Present) continue;
            IdeDrainChannel(hwInit, c);
            IdeStopChannel(hwInit, c);
        }
        hwInit->Stopped = TRUE;
        return ScsiAdapterControlSuccess;

    case ScsiRestartAdapter:
        IDE_DBG((IDE_PFX "AdapterControl: restart\n"));
        IdeReinitialize(hwInit);
        return ScsiAdapterControlSuccess;

    default:
        return ScsiAdapterControlUnsuccessful;
    }
}
#endif
