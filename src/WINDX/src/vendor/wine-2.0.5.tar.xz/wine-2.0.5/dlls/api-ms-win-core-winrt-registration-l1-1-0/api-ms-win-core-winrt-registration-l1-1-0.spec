@ stub RoGetActivatableClassRegistration
@ stub RoGetServerActivatableClasses
