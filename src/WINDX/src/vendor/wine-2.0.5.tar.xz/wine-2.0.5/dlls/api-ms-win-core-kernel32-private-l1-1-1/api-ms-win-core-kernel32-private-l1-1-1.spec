@ stub PrivCopyFileExW
