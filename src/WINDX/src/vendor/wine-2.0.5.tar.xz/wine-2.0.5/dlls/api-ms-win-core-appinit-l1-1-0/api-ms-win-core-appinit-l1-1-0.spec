@ stub LoadAppInitDlls
