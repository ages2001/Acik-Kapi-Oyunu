@ stub GetFileVersionInfoByHandle
