@ stub ApiSetQueryApiSetPresence
