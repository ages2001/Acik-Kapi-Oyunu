..
    **************************************************
    *                                                *
    *   Automatically generated file, do not edit!   *
    *                                                *
    **************************************************

.. _amdgpu_synid8_dst_buf_d16_128:

vdst
===========================

Instruction output: data read from a memory buffer and converted to a 16-bit format.

*Size:* depends on GFX8 GPU revision and :ref:`tfe<amdgpu_synid_tfe>`:

* 4 dwords for GFX8.0. This H/W supports no packing.
* 2 dwords for GFX8.1+. This H/W supports data packing.
* :ref:`tfe<amdgpu_synid_tfe>` adds one dword if specified.

*Operands:* :ref:`v<amdgpu_synid_v>`
