..
    **************************************************
    *                                                *
    *   Automatically generated file, do not edit!   *
    *                                                *
    **************************************************

.. _amdgpu_synid10_saddr_flat_global:

saddr
===========================

An optional 64-bit flat global address. Must be specified as :ref:`off<amdgpu_synid_off>` if not used.

See :ref:`vaddr<amdgpu_synid10_vaddr_flat_global>` for description of available addressing modes.

*Size:* 2 dwords.

*Operands:* :ref:`s<amdgpu_synid_s>`, :ref:`vcc<amdgpu_synid_vcc>`, :ref:`ttmp<amdgpu_synid_ttmp>`, :ref:`null<amdgpu_synid_null>`, :ref:`off<amdgpu_synid_off>`
