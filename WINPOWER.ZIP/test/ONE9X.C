/* Native shutdown after a verified GUI owner change on a marked Win95/98/Me test volume. */
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
static DWORD product;
static HWND mainwin,confirmation;
static BOOL CALLBACK locate(HWND w,LPARAM unused)
{
    DWORD id;char cls[26];(void)unused;
    GetWindowThreadProcessId(w,&id);
    if(id==product&&IsWindowVisible(w)&&GetDlgItem(w,105)&&GetClassNameA(w,cls,sizeof(cls))&&!lstrcmpA(cls,"WINPOWER"))mainwin=w;
    return !mainwin;
}
static BOOL CALLBACK find_confirm(HWND w,LPARAM unused)
{
    DWORD id;char cls[32];(void)unused;
    GetWindowThreadProcessId(w,&id);
    if(id==product&&GetClassNameA(w,cls,sizeof(cls))&&!lstrcmpA(cls,"#32770")&&
       GetDlgItem(w,IDYES)&&GetDlgItem(w,IDNO))confirmation=w;
    return !confirmation;
}
void WINAPI WinMainCRTStartup(void)
{
    char base[MAX_PATH],path[MAX_PATH],*leaf,text[400];
    DWORD info[16],size,owner=2,n;unsigned i;
    HANDLE drv,log;BOOL restart,back,gui;STARTUPINFOA si={0};PROCESS_INFORMATION pi;
    if(!(GetVersion()&0x80000000UL)||!GetModuleFileNameA(NULL,base,sizeof(base))||lstrlenA(base)>=MAX_PATH-14)ExitProcess(1);
    leaf=base+lstrlenA(base);while(leaf>base&&leaf[-1]!='\\')--leaf;*leaf=0;
    wsprintfA(path,"%sSLEEPQA.ID",base);if(GetFileAttributesA(path)==INVALID_FILE_ATTRIBUTES)ExitProcess(2);
    wsprintfA(path,"%sRESTART.ID",base);restart=GetFileAttributesA(path)!=INVALID_FILE_ATTRIBUTES;
    wsprintfA(path,"%sHANDBACK.ID",base);back=GetFileAttributesA(path)!=INVALID_FILE_ATTRIBUTES;
    wsprintfA(path,"%sGUI.ID",base);gui=GetFileAttributesA(path)!=INVALID_FILE_ATTRIBUTES;
    wsprintfA(path,"%sNATIVE.TXT",base);
    log=CreateFileA(path,GENERIC_WRITE,FILE_SHARE_READ,NULL,CREATE_NEW,0,NULL);if(log==INVALID_HANDLE_VALUE)ExitProcess(3);
    drv=CreateFileA("\\\\.\\PN9HOOK",0,0,NULL,OPEN_EXISTING,0,NULL);
    if(drv==INVALID_HANDLE_VALUE||!DeviceIoControl(drv,1,NULL,0,info,sizeof(info),&size,NULL)||size!=sizeof(info))ExitProcess(4);
    wsprintfA(text,"VMM %04lX. APM %04lX. RSDP %04lX. FADT %lu. OS ACPI %lu. Capabilities %08lX. Ready %lu. Stage %lu.\r\n",info[2],info[3],info[4],info[5],info[9],info[6],info[1],info[8]);
    WriteFile(log,text,lstrlenA(text),&n,NULL);FlushFileBuffers(log);CloseHandle(drv);
    if(!info[1])ExitProcess(5);
    si.cb=sizeof(si);
    if(!CreateProcessA("C:\\WINPWR9X\\WINPWR9X.EXE",NULL,NULL,NULL,FALSE,0,NULL,NULL,&si,&pi))ExitProcess(6);
    product=pi.dwProcessId;CloseHandle(pi.hThread);CloseHandle(pi.hProcess);
    for(i=0;i<180&&!mainwin;i++){EnumWindows(locate,0);Sleep(100);}
    if(!mainwin)ExitProcess(7);
    for(i=0;i<(back?3u:2u);++i){
        unsigned choice=i&1,attempt;
        PostMessageA(mainwin,WM_COMMAND,104+choice,(LPARAM)GetDlgItem(mainwin,104+choice));
        for(attempt=0;attempt<60;++attempt){
            BOOL matched=FALSE;Sleep(200);
            drv=CreateFileA("\\\\.\\PN9HOOK",0,0,NULL,OPEN_EXISTING,0,NULL);
            if(drv!=INVALID_HANDLE_VALUE){
                matched=DeviceIoControl(drv,5,NULL,0,&owner,sizeof(owner),&size,NULL)&&size==sizeof(owner)&&owner==choice;
                CloseHandle(drv);
            }
            if(matched)break;
        }
        if(attempt==60)ExitProcess(8);
        wsprintfA(text,"Read back %s owner from the resident driver.\r\n",choice?"Driver":"Windows");
        WriteFile(log,text,lstrlenA(text),&n,NULL);FlushFileBuffers(log);
    }
    wsprintfA(text,"Requesting %s %s.\r\n",gui?"WINPOWER GUI":"native Windows",restart?"restart":"power off");
    WriteFile(log,text,lstrlenA(text),&n,NULL);FlushFileBuffers(log);CloseHandle(log);
    if(gui){
        PostMessageA(mainwin,WM_COMMAND,restart?102:101,(LPARAM)GetDlgItem(mainwin,restart?102:101));
        for(i=0;i<100&&!confirmation;++i){EnumWindows(find_confirm,0);Sleep(100);}
        if(!confirmation)ExitProcess(10);
        PostMessageA(confirmation,WM_COMMAND,IDYES,(LPARAM)GetDlgItem(confirmation,IDYES));ExitProcess(0);
    }
    ExitProcess(ExitWindowsEx(restart?EWX_REBOOT:(EWX_SHUTDOWN|EWX_POWEROFF),0)?0:9);
}
