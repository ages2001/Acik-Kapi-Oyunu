"""Read real QEMU x86 firmware state descriptors across i440FX and Q35 profiles."""
import argparse
import json
import struct
import subprocess
from pathlib import Path

def sample(args, machine, device, s3, s4):
    command = [args.qemu,"-machine",machine,"-accel","tcg","-m","32","-S","-nodefaults",
               "-display","none","-L",args.bios,"-qtest","stdio","-qtest-log","/dev/null",
               "-global",device+".disable_s3="+str(int(not s3)),
               "-global",device+".disable_s4="+str(int(not s4))]
    proc = subprocess.Popen(command,stdin=subprocess.PIPE,stdout=subprocess.PIPE,
                            stderr=subprocess.DEVNULL,text=True,bufsize=1)
    def call(line):
        proc.stdin.write(line+"\n");proc.stdin.flush()
        while True:
            reply=proc.stdout.readline().strip()
            if reply=="OK":return 0
            if reply.startswith("OK "):return int(reply[3:],0)
            if not reply or not reply.startswith("IRQ "):raise RuntimeError((machine,line,reply))
    def read(count):
        return bytes(call("inb 0x511") for _ in range(count))
    try:
        call("outw 0x510 0x19")
        entries,=struct.unpack(">I",read(4))
        assert 0<entries<1024
        files={}
        for _ in range(entries):
            size,selector,_,label=struct.unpack(">IHH56s",read(64))
            files[label.split(bytes(1),1)[0].decode("ascii")]=(size,selector)
        assert "etc/acpi/tables" in files
        size,selector=files["etc/system-states"]
        assert size==6
        call("outw 0x510 "+hex(selector))
        states=read(size)
        supported=[i for i,b in enumerate(states) if b&128]
        expected=[0]+([3] if s3 else [])+([4] if s4 else [])+[5]
        assert supported==expected,(machine,states,expected)
        return dict(machine=machine,controller=device,s3_enabled=s3,s4_enabled=s4,
                    firmware_bytes=states.hex(),advertised=["S"+str(n) for n in supported])
    finally:
        proc.terminate()
        proc.wait(timeout=5)

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--qemu",required=True);ap.add_argument("--bios",required=True)
    ap.add_argument("--report",type=Path,required=True);args=ap.parse_args()
    rows=[]
    for board,device in (("pc-i440fx-5.2","PIIX4_PM"),("pc","PIIX4_PM"),("q35","ICH9-LPC")):
        for s3 in (False,True):
            for s4 in (False,True):
                rows.append(sample(args,board,device,s3,s4))
    result={"qemu":subprocess.check_output([args.qemu,"--version"],text=True).splitlines()[0],
            "measurement":"QEMU fw_cfg etc/system-states on initialized machine models. This probe does not request an OS transition.",
            "source":"https://github.com/qemu/qemu/blob/v10.0.13/hw/acpi/core.c","profiles":rows}
    args.report.write_text(json.dumps(result,indent=2)+"\n")
    print(len(rows),"QEMU machine and firmware combinations passed.")

if __name__=="__main__":
    main()
