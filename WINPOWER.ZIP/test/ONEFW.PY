"""Exercise DOS power actions on disposable IDE copies, with one firmware interface per run."""
import argparse
import hashlib
import json
from pathlib import Path
import socket
import subprocess
import tempfile
import time

def measure(args, mode, action):
    utility = Path(__file__).resolve().parents[1] / "bin/DOS/WPWRDOS.EXE"
    with tempfile.TemporaryDirectory() as scratch:
        work = Path(scratch)
        disk = work / "DOS.IMG"
        subprocess.run(["cp", "--sparse=always", args.disk, disk], check=True)
        fat = str(disk) + "@@" + str(args.offset)
        def copy(name, data):
            subprocess.run(["mcopy", "-o", "-i", fat, "-", "::" + name], input=data, check=True)
        copy("WPWRDOS.EXE", utility.read_bytes())
        copy("AUTOEXEC.BAT", ("@ECHO OFF\r\nC:\\WPWRDOS /STATUS > C:\\ONEFW.TXT\r\n"
                              "C:\\WPWRDOS /" + action + " /Y\r\n").encode("ascii"))
        qmp = work / "qmp"
        command = [args.qemu, "-L", args.romdir, "-machine", "pc" if mode != "stock-apm" else "pc,acpi=off",
                   "-cpu", "486", "-m", "32", "-drive", "file=" + str(disk) + ",format=raw,if=ide",
                   "-display", "none", "-nic", "none", "-S", "-no-reboot", "-no-shutdown",
                   "-qmp", "unix:" + str(qmp) + ",server=on,wait=off"]
        if mode == "acpi":
            command += ["-bios", args.noapm]
        elif mode == "apm":
            command += ["-bios", args.noacpi]
        proc = subprocess.Popen(command, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
        events = []
        try:
            for _ in range(100):
                if qmp.exists(): break
                if proc.poll() is not None: raise RuntimeError(proc.stderr.read().decode())
                time.sleep(.05)
            with socket.socket(socket.AF_UNIX) as monitor:
                monitor.settimeout(args.timeout)
                monitor.connect(str(qmp))
                with monitor.makefile("rwb", buffering=0) as stream:
                    stream.readline()
                    for request in ("qmp_capabilities", "cont"):
                        stream.write((json.dumps({"execute":request}) + "\n").encode())
                        while True:
                            response = json.loads(stream.readline())
                            if "return" in response: break
                            if "error" in response: raise RuntimeError(response)
                    try:
                        while True:
                            message = json.loads(stream.readline())
                            if "event" in message:
                                events.append(message)
                                if message["event"] in ("RESET","SHUTDOWN"): break
                    except TimeoutError:
                        pass
        finally:
            proc.terminate()
            proc.wait(timeout=10)
        status = subprocess.check_output(["mtype", "-i", fat, "::ONEFW.TXT"]).decode("ascii")
    positive = any((e["event"]=="SHUTDOWN" and e.get("data",{}).get("reason")==(
        "guest-reset" if action=="RESTART" else "guest-shutdown")) or (action=="RESTART" and
        e["event"]=="RESET") for e in events)
    assert ("APM BIOS version: N/A" in status) == (mode=="acpi"),status
    assert ("ACPI power off: unavailable" in status) == (mode!="acpi"),status
    print(mode,action,positive,status.replace("\n"," ").strip(),flush=True)
    return dict(guest="MS-DOS", controller="IDE", firmware=mode, action=action,
                hardware_transition=positive, firmware_report=status.splitlines(), events=events,
                utility_sha256=hashlib.sha256(utility.read_bytes()).hexdigest())

if __name__ == "__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--disk",required=True,help="Installed DOS raw disk. Each run uses an independent copy.")
    parser.add_argument("--offset",type=int,default=32256)
    parser.add_argument("--qemu",default="qemu-system-i386")
    parser.add_argument("--romdir",required=True)
    parser.add_argument("--noapm",required=True,help="SeaBIOS built with CONFIG_APMBIOS disabled.")
    parser.add_argument("--noacpi",required=True,help="SeaBIOS with APM enabled and ACPI / FW_ROMFILE_LOAD disabled.")
    parser.add_argument("--timeout",type=int,default=25)
    parser.add_argument("--report",type=Path,required=True)
    args=parser.parse_args()
    results=[measure(args,mode,action) for mode in ("acpi","apm") for action in ("OFF","RESTART")]
    report=dict(apm_only_bios_sha256=hashlib.sha256(Path(args.noacpi).read_bytes()).hexdigest(),
                qemu=subprocess.check_output([args.qemu,"--version"],text=True).splitlines()[0],
                acpi_only_bios_sha256=hashlib.sha256(Path(args.noapm).read_bytes()).hexdigest(),cases=results)
    args.report.write_text(json.dumps(report,indent=2)+"\n")
    raise SystemExit(0 if all(c["hardware_transition"] for c in results) else 1)
