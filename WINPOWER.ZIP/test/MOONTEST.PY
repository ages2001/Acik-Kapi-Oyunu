"""Compare every title-icon pixel on real guest captures against the drawing."""
from pathlib import Path
import argparse
import json
import re
from PIL import Image

root=Path(__file__).resolve().parent.parent
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument("--report",type=Path,required=True)
args=parser.parse_args()
src=(root/"src/ICONUI.C").read_text()
start=src.index('{"           c    "')
rows=re.findall(r'"([^"]*)"',src[start:src.index('}',start)])
assert len(rows)==16 and all(len(row)==16 for row in rows)
result={}
for file in sorted([*(root/"test/UI").glob("*SLEEP.PNG"), *(root/"test/UI").glob("*SLP.PNG")]):
    with Image.open(file) as original:
        im=original.convert("RGB")
    background=im.getpixel((0,0))
    accent=next(y for y in range(im.height) if im.getpixel((0,y))!=background)
    height=accent+3
    size=24 if height<45 else 32
    left,top=10,(height-size)//2-1
    if file.name.endswith("SLP.PNG"):
        assert accent==42 and size==32
        left,top=11,5
    paints={};opaque=0;clear=0
    # Rectangles use integer boundaries at logical_cell * size / 16.
    for row,chars in enumerate(rows):
        for col,char in enumerate(chars):
            for y in range(top+row*size//16,top+(row+1)*size//16):
                for x in range(left+col*size//16,left+(col+1)*size//16):
                    actual=im.getpixel((x,y))
                    if char==" ":
                        assert actual==background,(file.name,"background",x,y,actual)
                        clear+=1
                    else:
                        assert actual!=background,(file.name,"missing pixel",x,y)
                        if char in paints:assert paints[char]==actual
                        paints[char]=actual;opaque+=1
    assert set(paints)=={"y","c","a"} and len(set(paints.values()))==3
    assert left>0 and top>0 and top+size<accent
    r,g,b=paints["y"];assert min(r,g)>b
    r,g,b=paints["c"];assert min(g,b)>r
    assert min(paints["a"])>=192
    result[file.name]={"title_height":height,"glyph_size":size,"left_margin":left,"top_margin":top,
                      "outlined_pixels":opaque,"transparent_pixels":clear,"transparent_background_rgb":background,
                      "yellow":paints["y"],"cyan":paints["c"],"white":paints["a"],
                      "missing_or_unexpected_pixels":0}
assert result
args.report.write_text(json.dumps(result,indent=2)+"\n")
print(len(result),"native sleep-title screenshots matched every moon and star pixel.")
