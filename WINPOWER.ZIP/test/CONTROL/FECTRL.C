/* Windows-only control on a marked private Windows 98 FE clone. */
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
static int bytes_equal(const char *a,const char *b,unsigned count){while(count--){if(*a++!=*b++)return 0;}return 1;}
static HANDLE output;static HWND marker;static char info[512],path[MAX_PATH],cmd[MAX_PATH];
static void logline(LPCSTR msg){DWORD n;WriteFile(output,msg,lstrlenA(msg),&n,NULL);WriteFile(output,"\r\n",2,&n,NULL);FlushFileBuffers(output);}
static LRESULT CALLBACK window(HWND w,UINT m,WPARAM wp,LPARAM lp){
 if(m==WM_TIMER){typedef BOOL(WINAPI *state_fn)(BOOL,BOOL);state_fn fn;KillTimer(w,1);
  fn=(state_fn)GetProcAddress(GetModuleHandleA("KERNEL32"),"SetSystemPowerState");if(!fn){logline("Windows suspend API absent.");return 0;}
  logline("Calling Windows KERNEL32 SetSystemPowerState(TRUE,FALSE) directly.");if(!fn(TRUE,FALSE)){wsprintfA(info,"Windows error %lu",GetLastError());logline(info);}else logline("Windows API returned after the request.");return 0;}
 if(m==WM_POWERBROADCAST){if(wp==PBT_APMSUSPEND)logline("Windows broadcast suspend.");else if(wp==PBT_APMRESUMESUSPEND||wp==0x12)logline("Windows broadcast resume to the original window.");return TRUE;}
 if(m==WM_DESTROY){PostQuitMessage(0);return 0;}return DefWindowProcA(w,m,wp,lp);
}
static int ini_mentions_driver(void){char ini[MAX_PATH];HANDLE f;DWORD len,n,i;char *buf;
 if(!GetWindowsDirectoryA(ini,MAX_PATH-12))return -1;lstrcatA(ini,"\\SYSTEM.INI");f=CreateFileA(ini,GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,NULL,OPEN_EXISTING,0,NULL);if(f==INVALID_HANDLE_VALUE)return -1;
 len=GetFileSize(f,NULL);if(!len||len>500000){CloseHandle(f);return -1;}buf=(char*)LocalAlloc(LPTR,len+1);if(!buf||!ReadFile(f,buf,len,&n,NULL)||n!=len){CloseHandle(f);if(buf)LocalFree(buf);return -1;}
 CloseHandle(f);CharUpperBuffA(buf,len);for(i=0;i+11<=len;++i)if(bytes_equal(buf+i,"PN9HOOK.VXD",11))break;LocalFree(buf);return i+11<=len;
}
void WINAPI WinMainCRTStartup(void){HANDLE d;DWORD live,present,ini,i;OSVERSIONINFOA os={sizeof(os)};WNDCLASSA c={0};STARTUPINFOA si={sizeof(si)};PROCESS_INFORMATION pi;MSG msg;HKEY k;DWORD size=sizeof(cmd),type;
 if(GetFileAttributesA("A:\\SLEEPQA.ID")==INVALID_FILE_ATTRIBUTES||!FindWindowA("Shell_TrayWnd",NULL))ExitProcess(2);
 if(!GetVersionExA(&os)||os.dwPlatformId!=1||os.dwMajorVersion!=4||os.dwMinorVersion!=10||(os.dwBuildNumber&65535)!=1998)ExitProcess(3);
 GetModuleFileNameA(NULL,path,sizeof(path));for(i=lstrlenA(path);i&&path[i-1]!='\\';--i){};
 output=CreateFileA(!lstrcmpiA(path+i,"U.EXE")?"A:\\UNLOG.TXT":!lstrcmpiA(path+i,"R.EXE")?"A:\\REBOOT.TXT":"A:\\NATIVE.TXT",GENERIC_WRITE,FILE_SHARE_READ,NULL,CREATE_ALWAYS,0,NULL);if(output==INVALID_HANDLE_VALUE)ExitProcess(4);
 d=CreateFileA("\\\\.\\PN9HOOK",0,0,NULL,OPEN_EXISTING,0,NULL);live=d!=INVALID_HANDLE_VALUE;if(live)CloseHandle(d);present=GetFileAttributesA("C:\\WINPWR9X\\PN9HOOK.VXD")!=INVALID_FILE_ATTRIBUTES;ini=ini_mentions_driver();
 wsprintfA(info,"Windows 98 FE build %lu. WINPOWER device open=%lu, driver file present=%lu, SYSTEM.INI references driver=%lu.",os.dwBuildNumber&65535,live,present,ini);logline(info);
 if(!lstrcmpiA(path+i,"U.EXE")){
  if(RegOpenKeyExA(HKEY_LOCAL_MACHINE,"Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\WINPWR9X",0,KEY_READ,&k)==ERROR_SUCCESS){if(RegQueryValueExA(k,"UninstallString",NULL,&type,(BYTE*)cmd,&size)!=ERROR_SUCCESS)cmd[0]=0;RegCloseKey(k);}
  if(!*cmd)lstrcpyA(cmd,"C:\\WINPWR9X\\UNINST.EXE");logline(cmd);if(!CreateProcessA(NULL,cmd,NULL,NULL,FALSE,0,NULL,NULL,&si,&pi)){wsprintfA(info,"Failed to start uninstaller. Error %lu.",GetLastError());logline(info);}ExitProcess(0);}
 if(!lstrcmpiA(path+i,"R.EXE")){if(present||ini){logline("Removal is incomplete.");ExitProcess(5);}logline("Restarting to unload the removed product.");CloseHandle(output);ExitProcess(ExitWindowsEx(EWX_REBOOT,0)?0:6);}
 if(live||present||ini){logline("Control stopped because the product may still be active.");ExitProcess(7);}logline("Confirmed Windows-only control without the WINPOWER device, driver file or SYSTEM.INI registration.");
 c.lpfnWndProc=window;c.hInstance=GetModuleHandleA(NULL);c.lpszClassName="Win98NativeSleep";c.hbrBackground=(HBRUSH)(COLOR_WINDOW+1);RegisterClassA(&c);marker=CreateWindowA(c.lpszClassName,"Windows 98 native sleep control",WS_OVERLAPPEDWINDOW|WS_VISIBLE,10,10,350,90,NULL,NULL,c.hInstance,NULL);
 if(!marker)ExitProcess(9);SetTimer(marker,1,2000,NULL);while(GetMessageA(&msg,NULL,0,0)>0){TranslateMessage(&msg);DispatchMessageA(&msg);}ExitProcess(0);}
