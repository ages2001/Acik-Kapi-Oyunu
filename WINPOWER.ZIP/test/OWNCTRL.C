/* Exercise the visible, independent session-owner controls on marked QA media.
   Close the complete application between stages to verify saved choices. */
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
static char base[MAX_PATH],gui[MAX_PATH],file[MAX_PATH],line[180];
static HANDLE report,process;
static DWORD pid;
static HWND mainwin,dialog;
static int seen[2];
static BOOL CALLBACK find_window(HWND w,LPARAM unused)
{
    char cls[32],title[80];DWORD id;(void)unused;
    GetWindowThreadProcessId(w,&id);
    if(id!=pid||!IsWindowVisible(w)||!GetClassNameA(w,cls,sizeof(cls)))return TRUE;
    if(!lstrcmpA(cls,"WINPOWER"))mainwin=w;
    if(!lstrcmpA(cls,"#32770")&&GetWindowTextA(w,title,sizeof(title))&&
       !lstrcmpA(title,"WINPOWER - Sleep states"))dialog=w;
    return TRUE;
}
static void record(const char *text)
{
    DWORD bytes;if(!WriteFile(report,text,lstrlenA(text),&bytes,NULL)||!FlushFileBuffers(report))ExitProcess(6);
}
static BOOL start_gui(void)
{
    STARTUPINFOA si={0};PROCESS_INFORMATION pi;unsigned i;BOOL sent=FALSE;
    si.cb=sizeof(si);mainwin=dialog=NULL;
    if(!CreateProcessA(gui,NULL,NULL,NULL,FALSE,0,NULL,base,&si,&pi))return FALSE;
    process=pi.hProcess;pid=pi.dwProcessId;CloseHandle(pi.hThread);
    for(i=0;i<240;++i){
        EnumWindows(find_window,0);
        if(dialog&&GetDlgItem(dialog,163))return TRUE;
        if(mainwin&&!sent)sent=PostMessageA(mainwin,WM_COMMAND,106,0);
        Sleep(100);
    }
    return FALSE;
}
static BOOL stop_gui(void)
{
    unsigned i;BOOL ok;
    if(dialog)PostMessageA(dialog,WM_CLOSE,0,0);
    for(i=0;i<50&&IsWindow(dialog);++i)Sleep(50);
    PostMessageA(mainwin,WM_CLOSE,0,0);
    ok=WaitForSingleObject(process,10000)==WAIT_OBJECT_0;CloseHandle(process);return ok;
}
static int active(int id){return SendDlgItemMessageA(dialog,id,BM_GETCHECK,0,0)==BST_CHECKED;}
static BOOL select_owner(int os,int driver)
{
    SendDlgItemMessageA(dialog,os+driver,BM_CLICK,0,0);
    return active(os+driver)&&!active(os+!driver);
}
static BOOL check_routes(unsigned stage)
{
    unsigned i;int tested=0;
    for(i=0;i<2;++i){
        int os=160+2*i,os_ok=IsWindowEnabled(GetDlgItem(dialog,os));
        int driver_ok=IsWindowEnabled(GetDlgItem(dialog,os+1));
        wsprintfA(line,"Process %lu. %s OS enabled=%d, Driver enabled=%d.\r\n",
                  pid,i?"Hibernate":"Suspend",os_ok,driver_ok);record(line);
        if(!os_ok||!driver_ok){if(seen[i])return FALSE;continue;}
        if(stage && (!seen[i]||!active(os+1)||active(os)))return FALSE;
        seen[i]=1;tested++;
        if(!select_owner(os,0))return FALSE;
        if(!stage && !select_owner(os,1))return FALSE;
        if(!stage && i==1 && seen[0] && !active(161))return FALSE;
    }
    return tested!=0;
}
void WINAPI WinMainCRTStartup(void)
{
    char *leaf;unsigned stage;BOOL passed=TRUE;
    if(!GetModuleFileNameA(NULL,base,MAX_PATH)||lstrlenA(base)>=MAX_PATH-16)ExitProcess(1);
    leaf=base+lstrlenA(base);while(leaf>base&&leaf[-1]!='\\')--leaf;*leaf=0;
    wsprintfA(file,"%sSLEEPQA.ID",base);if(GetFileAttributesA(file)==INVALID_FILE_ATTRIBUTES)ExitProcess(2);
    wsprintfA(gui,"%sWINPWR9X.EXE",base);
    if(GetFileAttributesA(gui)==INVALID_FILE_ATTRIBUTES)wsprintfA(gui,"%sWINPWRNT.EXE",base);
    wsprintfA(file,"%sOWNTEST.TXT",base);
    report=CreateFileA(file,GENERIC_WRITE,FILE_SHARE_READ,NULL,CREATE_NEW,0,NULL);
    if(report==INVALID_HANDLE_VALUE)ExitProcess(3);
    for(stage=0;stage<2;++stage){
        if(!start_gui()){passed=FALSE;break;}
        if(!check_routes(stage))passed=FALSE;
        if(!stop_gui()||!passed){passed=FALSE;break;}
    }
    record(passed?"PASS: Windows to Driver, Driver after relaunch, and explicit handback to Windows.\r\n":
                  "The ownership sequence could not be established.\r\n");
    CloseHandle(report);ExitProcess(passed?0:4);
}
