/* Run the ordinary Win9x installer or uninstaller on a marked private disk. */
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
static DWORD pid;static HANDLE logfd;static HWND seen;static BOOL removing;
static void note(const char *s){DWORD n;WriteFile(logfd,s,lstrlenA(s),&n,0);WriteFile(logfd,"\r\n",2,&n,0);FlushFileBuffers(logfd);}
static BOOL CALLBACK message(HWND win,LPARAM unused)
{
 char cls[32],body[600];HWND child;DWORD other;int button=0;(void)unused;
 GetWindowThreadProcessId(win,&other);
 if(other!=pid||!GetClassNameA(win,cls,sizeof(cls))||lstrcmpA(cls,"#32770"))return TRUE;
 child=GetWindow(win,GW_CHILD);
 while(child){if(GetClassNameA(child,cls,sizeof(cls))&&!lstrcmpA(cls,"Static")&&GetWindowTextA(child,body,sizeof(body))>4)note(body);child=GetWindow(child,GW_HWNDNEXT);}
 if(GetDlgItem(win,IDYES))button=IDYES;else if(GetDlgItem(win,IDOK))button=IDOK;
 if(button){seen=win;PostMessageA(GetDlgItem(win,button),BM_CLICK,0,0);}
 return TRUE;
}
void WINAPI WinMainCRTStartup(void)
{
 char old[512],current[512],line[]="@C:\\WINPWR9X\\WPAPM9.COM\r\n";
 char cmd[180];STARTUPINFOA si={0};PROCESS_INFORMATION pi;HANDLE f;DWORD n=0,m=0,rc,i;
 if(!(GetVersion()&0x80000000UL)||GetFileAttributesA("D:\\SLEEPQA.ID")==INVALID_FILE_ATTRIBUTES)ExitProcess(3);
 removing=GetFileAttributesA("D:\\REMOVE.ID")!=INVALID_FILE_ATTRIBUTES;
 logfd=CreateFileA(removing?"D:\\REMTEST.TXT":"D:\\SETTEST.TXT",GENERIC_WRITE,FILE_SHARE_READ,0,CREATE_NEW,0,0);if(logfd==INVALID_HANDLE_VALUE)ExitProcess(4);
 if(!removing){
  f=CreateFileA("C:\\AUTOEXEC.BAT",GENERIC_READ,FILE_SHARE_READ,0,OPEN_EXISTING,0,0);
  if(f!=INVALID_HANDLE_VALUE){if(GetFileSize(f,0)>=sizeof(old)||!ReadFile(f,old,sizeof(old)-1,&n,0))ExitProcess(5);CloseHandle(f);}
  else if(GetLastError()!=ERROR_FILE_NOT_FOUND)ExitProcess(6);
  f=CreateFileA("D:\\PRIOR.BAT",GENERIC_WRITE,FILE_SHARE_READ,0,CREATE_NEW,0,0);
  if(f==INVALID_HANDLE_VALUE||!WriteFile(f,old,n,&m,0)||m!=n)ExitProcess(7);CloseHandle(f);
 }else{
  f=CreateFileA("D:\\PRIOR.BAT",GENERIC_READ,FILE_SHARE_READ,0,OPEN_EXISTING,0,0);
  if(f==INVALID_HANDLE_VALUE||!ReadFile(f,old,sizeof(old)-1,&n,0))ExitProcess(8);CloseHandle(f);
 }
 lstrcpyA(cmd,removing?"C:\\WINPWR9X\\UNINST.EXE":"D:\\SETUP.EXE");si.cb=sizeof(si);
 if(!CreateProcessA(0,cmd,0,0,FALSE,0,0,0,&si,&pi))ExitProcess(9);
 CloseHandle(pi.hThread);pid=pi.dwProcessId;
 for(i=0;i<1500;i++){if(WaitForSingleObject(pi.hProcess,100)==WAIT_OBJECT_0)break;EnumWindows(message,0);}
 if(!GetExitCodeProcess(pi.hProcess,&rc)||rc!=0||!seen)ExitProcess(10);CloseHandle(pi.hProcess);
 old[n]=0;f=CreateFileA("C:\\AUTOEXEC.BAT",GENERIC_READ,FILE_SHARE_READ,0,OPEN_EXISTING,0,0);
 if(f!=INVALID_HANDLE_VALUE){if(!ReadFile(f,current,sizeof(current)-1,&m,0))ExitProcess(11);CloseHandle(f);}
 else {if(!removing||GetLastError()!=ERROR_FILE_NOT_FOUND)ExitProcess(12);m=0;}
 current[m]=0;if(removing){if(m!=n||lstrcmpA(current,old))ExitProcess(13);}
 else {if(m!=n+sizeof(line)-1||lstrcmpA(current+sizeof(line)-1,old))ExitProcess(14);current[sizeof(line)-1]=0;if(lstrcmpA(current,line))ExitProcess(15);}
 if((GetFileAttributesA("C:\\WINPWR9X\\WPAPM9.COM")!=INVALID_FILE_ATTRIBUTES)==removing)ExitProcess(16);
 note(removing?"PASS. Removed the helper and restored the original batch contents.":"PASS. Installed the helper and preserved the original batch contents.");
 CloseHandle(logfd);ExitProcess(0);
}
