"""Verify every hourglass pixel against real Windows client captures."""
import argparse
import json
from pathlib import Path
import re
from PIL import Image

root = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--report", type=Path, required=True)
args = parser.parse_args()
source = (root / "src/ICONUI.C").read_text()
art = re.findall(r'\{((?:"[nstcagpy ]{16}",?\s*){16})\}', source)
assert len(art) == 5
rows = re.findall(r'"([^"]*)"', art[4])
report = {}
files = sorted((root/"test/UI").glob("*MAIN.PNG"))
files += [root/"test/UI"/(n+".PNG") for n in ("W101","W203","W310","W211")]
for path in files:
    with Image.open(path) as frame:
        im = frame.convert("RGB")
    classic = not path.name.endswith("MAIN.PNG")
    x = 19 if classic else 257
    hits = []
    for y in range(70, im.height-16):
        colors = {}
        for dy, row in enumerate(rows):
            for dx, key in enumerate(row):
                value = im.getpixel((x+dx, y+dy))
                if key in colors and colors[key] != value: break
                colors[key] = value
            else: continue
            break
        else:
            if len(set(colors.values())) < 4 or colors["n"]==colors[" "] or colors["n"]==colors["y"]:
                continue
            if colors[" "] != im.getpixel((x-1,y+8)): continue
            hits.append(y)
    assert len(hits)==1, (path.name, hits)
    y=hits[0];clear=sum(row.count(" ") for row in rows)
    report[path.name]=dict(left=x,top=y,size=16,drawn_pixels=256-clear,
                           transparent_pixels=clear,unmatched_pixels=0)
args.report.write_text(json.dumps(report,indent=2)+"\n",encoding="ascii")
print(len(report),"native main screens matched all 256 hourglass pixels.")
