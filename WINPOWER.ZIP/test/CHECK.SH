#!/bin/sh
# Host tests only; no change to shipped Windows/DOS binaries.
set -eu
cd "$(dirname "$0")/../src"
run() {
 name=$1;shift
 cc -x c -std=c89 -Wall -Wextra -Werror -pedantic -fsanitize=address,undefined -I. "$@" -o ../test/CHECK
 ../test/CHECK
 rm ../test/CHECK
}
run CORE ACPI.C POLICY.C ../test/CORE.C
run SLEEP ../test/SLPCHECK.C
run SLPSTATE ../test/SLPROUT.C
python3 ../test/UILOOK.PY
run APMSLEEP ../test/APMSLP.C
run OSNAME OSNAME.C ../test/OSNAME.C
run SESSION ../test/SESSION.C
run LEGOWNER ../test/LEGOWNER.C
run S5 S5.C ACPI.C ../test/S5TEST.C
run TIMER -DPN_TIMER_INFO S5.C ACPI.C ../test/S5TEST.C
run POWER PWRSEQ.C ../test/PWRTEST.C
run W2KRESET -DWP_2000 PWRSEQ.C ../test/PWRTEST.C
run REDUCED S5.C ACPI.C PWRSEQ.C ../test/REDTEST.C
run TABLE64 -DPN_WIDE_TABLES S5.C ACPI.C ../test/TABLE64.C
run MEMORY MEMMAP.C ../test/MEMTEST.C
run INTENT INTENT.C ../test/INTTEST.C
run INI PN9INI.C ../test/INITEST.C
run SHUTFIND SHUTFIND.C ../test/SHUTTEST.C
run SHA256 SHA256.C ../test/SHATEST.C
run NTREG NTREG.C ../test/REGTEST.C
run FIRMWARE FWTABLE.C ../test/FWTEST.C
run FWREV FWTABLE.C OSNAME.C ../test/FWREV.C
python3 APMGEN.PY --check
run APM APMDATA.C ../test/APMTEST.C
run NTITEM -Wno-misleading-indentation ../test/NTITEM.C
run AML -Wno-misleading-indentation AML.C ../test/AMLTEST.C
run AMLTAB -Wno-misleading-indentation -DPN_AML S5.C ACPI.C AML.C ../test/AMLTAB.C
run S5AML -Wno-misleading-indentation -DPN_AML S5.C ACPI.C AML.C ../test/S5TEST.C
sh ../test/LINKTEST.SH
