Earlier color UI and guest qualification

These screen captures and logs identify their original binaries. SE and
X32 cover Windows 98 SE and XP x86, N35 is NT 3.50 and W7 is Windows 7.
See test/UI for the current artwork and test/SLEEP for the independent
owner and wake tests. W7S4 documents a Standard VGA return from disk.
