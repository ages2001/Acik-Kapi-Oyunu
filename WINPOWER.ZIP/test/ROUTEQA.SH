#!/bin/sh
set -eu
cd "$(dirname "$0")"
: "${1:?Specify an output directory outside the product.}"
mkdir -p "$1"
export SOURCE_DATE_EPOCH=1795046400
for spec in nt32 nt64 win9x; do
    arch=i686; entry='_WinMainCRTStartup@0'; version=4.0; cpu='-march=i386 -mno-sse -mno-mmx'; args=; api=-lsetupapi
    case "$spec" in
      nt64) arch=x86_64; entry=WinMainCRTStartup; version=5.2; cpu= ;;
      win9x) args=-DWP_9XQA; api= ;;
    esac
    base="-x c -Os -fno-builtin -fno-stack-protector -nostdlib -mwindows"
    "$arch-w64-mingw32-gcc" $base $cpu $args -DWP_TEST_ROUTE VGASLEEP.C "-Wl,--entry,$entry,--subsystem,windows:$version" -o "$1/$spec.EXE" $api -luser32 -lkernel32 -lgdi32 -ladvapi32
    if [ "$spec" != win9x ]; then
        "$arch-w64-mingw32-windres" ../src/ADMIN.RC -I ../src -O coff -o "$1/$spec.O"
        "$arch-w64-mingw32-gcc" $base $cpu SLPLOAD.C ../src/SHA256.C -x none "$1/$spec.O" "-Wl,--entry,$entry,--subsystem,windows:$version" -o "$1/I$spec.EXE" -luser32 -lkernel32 -ladvapi32
    fi
done
