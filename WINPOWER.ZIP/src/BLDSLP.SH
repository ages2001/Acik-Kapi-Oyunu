#!/bin/sh
set -eu
cd "$(dirname "$0")"
: "${1:?Usage: sh BLDSLP.SH OUTPUT_DIRECTORY}"
for arch in i686 x86_64; do
    case "$arch" in
      i686) entry=_DriverEntry@8; version=5.0; cpu=-march=i486; groups='2KXP NT6X86' ;;
      x86_64) entry=DriverEntry; version=5.2; cpu=-mno-red-zone; groups='XPAMD64 NT6AMD64' ;;
    esac
    set -- "$1" $groups
    mkdir -p "$1/$2" "$1/$3"
    "$arch-w64-mingw32-gcc" -x c $cpu -Os -Wall -Wextra -Werror -ffreestanding \
        -nostdlib -fno-stack-protector -D_WIN32_WINNT=0x0502 -DNTDDI_VERSION=0x05020000 -DNTDDI_WINVISTA=0x06000000 \
        -I"${DDK_ROOT:-/usr}/$arch-w64-mingw32/include/ddk" -shared SLPDRV.C \
        "-Wl,--entry,$entry,--subsystem,native:$version,--image-base,0x10000" \
        -o "$1/$2/WPSLPDRV.SYS" -lntoskrnl -lhal
    cp "$1/$2/WPSLPDRV.SYS" "$1/$3/WPSLPDRV.SYS"
done
