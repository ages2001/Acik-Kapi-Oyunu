/* Owner-drawn native static controls keep their text for keyboard tools and
   accessibility. Drawing is opaque as a whole; icon masks use the same face. */
static BOOL ui_high_contrast;
static char ui_values[7][160];
enum {UI_ACPI,UI_APM,UI_LINE,UI_BATTERY,UI_TIME,UI_OWNER,UI_FIRMWARE};

static void ui_colors(void)
{
 HIGHCONTRASTA mode;ZeroMemory(&mode,sizeof(mode));mode.cbSize=sizeof(mode);
 ui_high_contrast=SystemParametersInfoA(SPI_GETHIGHCONTRAST,sizeof(mode),&mode,0) &&
                  (mode.dwFlags&HCF_HIGHCONTRASTON);
}
static COLORREF ui_band(COLORREF color)
{
 return ui_high_contrast?GetSysColor(COLOR_HIGHLIGHT):color;
}
static COLORREF ui_light(void)
{
 return ui_high_contrast?GetSysColor(COLOR_HIGHLIGHTTEXT):WP_PAPER;
}
static COLORREF ui_band_ink(HDC dc,COLORREF band)
{
 if(!ui_high_contrast&&band==WP_TEAL&&GetDeviceCaps(dc,BITSPIXEL)*GetDeviceCaps(dc,PLANES)<=4)
  return RGB(0,0,0);
 return ui_light();
}
static void ui_text(HDC dc,HFONT font,COLORREF color,int x,int y,int right,int bottom,
                    const char *text,UINT align)
{
 RECT r;HFONT old=(HFONT)SelectObject(dc,font);
 r.left=x;r.top=y;r.right=right;r.bottom=bottom;
 SetBkMode(dc,TRANSPARENT);SetTextColor(dc,color);
 DrawTextA(dc,text,-1,&r,align|DT_NOPREFIX);SelectObject(dc,old);
}
#define UI_LEFT (DT_LEFT|DT_SINGLELINE|DT_VCENTER)
static void ui_icon(HDC dc,int id,int x,int y,int size,HBRUSH background)
{
 pn_icon(dc,LoadIconA(inst,MAKEINTRESOURCEA(id>=3&&id<=13?id+20:id)),x,y,size,background);
}
static void ui_heading(HDC dc,int x,int y,int right,int height,const char *name,COLORREF tone)
{
 pn_area(dc,x,y,right,y+height,ui_band(tone));
 ui_text(dc,sectionfont,ui_band_ink(dc,tone),x+8,y,right-4,y+height,name,UI_LEFT);
}
static void ui_main_status(LPDRAWITEMSTRUCT d)
{
 HDC dc=d->hDC;RECT r=d->rcItem;
 int w=r.right-r.left,h=r.bottom-r.top,col=w*46/100,second=col+6;
 int identity=compact?30:39,footer=compact?35:43,cap=compact?17:21;
 int end=h-footer-3,first=identity+cap,row=(end-first)/3,i;
 COLORREF paper=GetSysColor(COLOR_WINDOW),ink=GetSysColor(COLOR_WINDOWTEXT);
 COLORREF rule=GetSysColor(COLOR_BTNSHADOW);
 HBRUSH paperbrush=CreateSolidBrush(paper);
 const char *lefts[2]={"ACPI","APM"},*rights[3]={"AC line","Battery","Time left"};
 FillRect(dc,&r,bodybrush);
 pn_mark(dc,PN_SCREEN,1,(identity-28)/2,28);
 ui_text(dc,sectionfont,ui_high_contrast?ink:WP_NAVY,37,0,w,identity/2,osname,UI_LEFT);
 ui_text(dc,bodyfont,GetSysColor(COLOR_BTNTEXT),37,identity/2,w,identity,architecture,UI_LEFT);
 pn_area(dc,0,identity,col,end+1,rule);pn_area(dc,second,identity,w,end+1,rule);
 pn_area(dc,1,first,col-1,end,paper);pn_area(dc,second+1,first,w-1,end,paper);
 ui_heading(dc,0,identity,col,cap,"Firmware",WP_NAVY);
 ui_heading(dc,second,identity,w,cap,"Power supply",WP_TEAL);
 for(i=0;i<2;++i){
  int y=first+i*row;
  ui_text(dc,sectionfont,ink,9,y,58,y+row,lefts[i],UI_LEFT);
  ui_text(dc,bodyfont,ink,62,y,col-4,y+row,ui_values[UI_ACPI+i],UI_LEFT);
 }
 for(i=0;i<3;++i){
  int y=first+i*row;
  if(i<2&&paperbrush)ui_icon(dc,i?batteryicon:acicon,second+5,y+(row-16)/2,16,paperbrush);
  if(i==2)pn_mark(dc,PN_HOURGLASS,second+5,y+(row-16)/2,16);
  ui_text(dc,sectionfont,ink,second+25,y,second+91,y+row,rights[i],UI_LEFT);
  ui_text(dc,bodyfont,ink,second+94,y,w-4,y+row,ui_values[UI_LINE+i],UI_LEFT);
 }
 if(paperbrush)DeleteObject(paperbrush);
 pn_mark(dc,PN_CHIP,4,end+4+(footer-22)/2,22);
 ui_text(dc,sectionfont,GetSysColor(COLOR_BTNTEXT),34,end+3,163,end+3+footer/2,"Shutdown owner",UI_LEFT);
 ui_text(dc,bodyfont,GetSysColor(COLOR_BTNTEXT),168,end+3,w,end+3+footer/2,ui_values[UI_OWNER],UI_LEFT);
 ui_text(dc,sectionfont,GetSysColor(COLOR_BTNTEXT),34,end+3+footer/2,163,h,"Firmware control",UI_LEFT);
 ui_text(dc,bodyfont,GetSysColor(COLOR_BTNTEXT),168,end+3+footer/2,w,h,ui_values[UI_FIRMWARE],UI_LEFT);
}
static void ui_ownership(LPDRAWITEMSTRUCT d)
{
 HDC dc=d->hDC;int w=d->rcItem.right,h=d->rcItem.bottom;
 FillRect(dc,&d->rcItem,bodybrush);pn_mark(dc,PN_SWITCH,1,(h-19)/2,19);
 ui_text(dc,sectionfont,ui_high_contrast?GetSysColor(COLOR_BTNTEXT):WP_NAVY,
         26,0,w,h,"Shutdown and restart control",UI_LEFT);
 {SIZE size;HFONT old=(HFONT)SelectObject(dc,sectionfont);
  GetTextExtentPointA(dc,"Shutdown and restart control",lstrlenA("Shutdown and restart control"),&size);SelectObject(dc,old);
  pn_area(dc,35+size.cx,h/2,w,h/2+1,GetSysColor(COLOR_BTNSHADOW));}
}
static void ui_header(HDC dc,RECT r,int icon,const char *name,const char *subtitle)
{
 int height=r.bottom-r.top,symbol=height<45?24:32,x=r.left+symbol+24;
 pn_area(dc,r.left,r.top,r.right,r.bottom,ui_band(WP_NAVY));
 pn_area(dc,r.left,r.bottom-3,r.right,r.bottom,ui_high_contrast?ui_light():WP_TEAL);
 if(icon==12)pn_mark(dc,PN_MOON,r.left+10,r.top+(height-symbol)/2-1,symbol);
 else ui_icon(dc,icon,r.left+10,r.top+(height-symbol)/2-1,symbol,headerbrush);
 pn_area(dc,x-6,r.top+7,x-5,r.bottom-9,ui_high_contrast?ui_light():WP_TEAL);
 if(subtitle){
  int split=r.top+(height*56)/100;
  ui_text(dc,titlefont,ui_light(),x+3,r.top+2,r.right-12,split,name,UI_LEFT);
  ui_text(dc,bodyfont,ui_light(),x+4,split,r.right-12,r.bottom-4,subtitle,UI_LEFT);
 }else ui_text(dc,titlefont,ui_light(),x+3,r.top+1,r.right-12,r.bottom-4,name,UI_LEFT);
}
/* NT 3.x predates owner-drawn STATIC. Subclass an ordinary text control so
   the original window procedure continues to serve WM_GETTEXT and WM_GETFONT. */
static void ui_paint_view(HWND window,HDC dc)
{
 DRAWITEMSTRUCT item;ZeroMemory(&item,sizeof(item));
 item.hwndItem=window;item.hDC=dc;item.CtlID=(UINT)GetDlgCtrlID(window);
 GetClientRect(window,&item.rcItem);
 if(item.CtlID==ID_STATUS)ui_main_status(&item);
 else if(item.CtlID==ID_CONTROL)ui_ownership(&item);
 else wp_draw_sleep(&item);
}
static BOOL wp_row_input(HWND,UINT,WPARAM,LPARAM,LRESULT *);
static LRESULT CALLBACK ui_view_proc(HWND window,UINT msg,WPARAM w,LPARAM l)
{
 WNDPROC prior=(WNDPROC)(LONG_PTR)GetPropA(window,"WINPOWER.PaintProc");LRESULT result;
 if(!prior)return DefWindowProcA(window,msg,w,l);
 if(GetDlgCtrlID(window)==151 && wp_row_input(window,msg,w,l,&result))return result;
 switch(msg){
 case WM_PAINT:{
  PAINTSTRUCT ps;HDC dc=BeginPaint(window,&ps);
  ui_paint_view(window,dc);EndPaint(window,&ps);return 0;
 }
 case WM_PRINTCLIENT:ui_paint_view(window,(HDC)w);return 0;
 case WM_ERASEBKGND:return TRUE;
 case WM_SETTEXT:
  result=CallWindowProcA(prior,window,msg,w,l);
  InvalidateRect(window,NULL,FALSE);return result;
 case WM_NCDESTROY:
  RemovePropA(window,"WINPOWER.PaintProc");break;
 }
 return CallWindowProcA(prior,window,msg,w,l);
}
static void ui_attach(HWND window)
{
 WNDPROC prior;
 if(!window)return;
 prior=(WNDPROC)GetWindowLongPtrA(window,GWLP_WNDPROC);
 if(prior&&SetPropA(window,"WINPOWER.PaintProc",(HANDLE)(LONG_PTR)prior)){
  if(SetWindowLongPtrA(window,GWLP_WNDPROC,(LONG_PTR)ui_view_proc))InvalidateRect(window,NULL,FALSE);
  else RemovePropA(window,"WINPOWER.PaintProc");
 }
}
