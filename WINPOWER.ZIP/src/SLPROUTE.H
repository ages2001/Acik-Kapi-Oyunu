#include "SLPDEV.H"
#include "SLPPOL.H"
static struct wp_sleep_caps wp_drv_caps;
static int wp_preference[2]={WP_NONE,WP_NONE};
static enum wp_hybrid wp_hybrid;
static const char *const wp_hy_reason[]={"Use Hybrid sleep","Needs Vista or later","Needs standby","Needs S4","Needs a full S4 file","Windows policy blocks","Power plan: off","Power plan unknown","No hybrid support"};
static const char *const wp_hy_detail[]={
    "Hybrid sleep writes this session to disk before standby. Windows uses its active power plan.",
    "Hybrid sleep requires Windows Vista or later, standby and a complete hibernation image.",
    "Hybrid sleep needs S1, S2 or S3. Firmware, Windows and installed device drivers must allow standby.",
    "Hybrid sleep needs S4 hardware and an OS that can restore a hibernation image.",
    "Hybrid sleep needs a full hibernation file. Check hibernation in Windows Power Options.",
    "Windows currently restricts suspend or hibernation for this session.",
    "Allow hybrid sleep is off for the current power source. It can be enabled in Power Options.",
    "Windows did not report its hybrid sleep policy for the current power source.",
    "Windows reports that this platform cannot save a hibernation image while entering standby (FastSystemS4)."};
static void wp_sleep_preferences(void)
{
    HKEY key;DWORD type,size,v;unsigned i;
    wp_preference[0]=wp_preference[1]=WP_NONE;
    if(RegOpenKeyA(HKEY_CURRENT_USER,"Software\\WINPOWER\\Sleep",&key)!=ERROR_SUCCESS)return;
    for(i=0;i<2;i++){
        size=sizeof(v);
        if(RegQueryValueExA(key,i?"Hibernate":"Suspend",NULL,&type,(BYTE *)&v,&size)==ERROR_SUCCESS &&
           type==REG_DWORD && size==sizeof(v) && v<=1)wp_preference[i]=(int)v;
    }
    RegCloseKey(key);
}
static DWORD wp_write_preference(int hibernate,int driver)
{
    HKEY key;DWORD value=(DWORD)driver,actual,type,bytes=sizeof(actual);
    const char *name=hibernate?"Hibernate":"Suspend";
    DWORD err=RegCreateKeyA(HKEY_CURRENT_USER,"Software\\WINPOWER\\Sleep",&key);
    if(err)return err;
    err=RegSetValueExA(key,name,0,REG_DWORD,(BYTE *)&value,sizeof(value));
    if(!err)err=RegQueryValueExA(key,name,NULL,&type,(BYTE *)&actual,&bytes);
    if(!err&&(type!=REG_DWORD||bytes!=sizeof(actual)||value!=actual))err=ERROR_INVALID_DATA;
    RegCloseKey(key);return err;
}
static int wp_session_route(int hibernate)
{
    return wp_route(wp_preference[hibernate],hibernate?wp_sleep.hibernate:wp_sleep.suspend,
                    hibernate?wp_drv_caps.hibernate:wp_drv_caps.suspend);
}
static DWORD wp_sleep_device(BOOL query,BOOL hibernate,unsigned minimum)
{
    BOOL nt=os.dwPlatformId==VER_PLATFORM_WIN32_NT;
    HANDLE dev;DWORD reply=0,bytes=0,error=0;
    struct wp_sleep_packet packet;
    if(nt && os.dwMajorVersion<5)return ERROR_NOT_SUPPORTED;
    if(!nt && os.dwPlatformId!=VER_PLATFORM_WIN32_WINDOWS)return ERROR_NOT_SUPPORTED;
    dev=CreateFileA(nt?"\\\\.\\WpSleep":"\\\\.\\PN9HOOK",nt?(query?GENERIC_READ:GENERIC_WRITE):0,
        nt?(FILE_SHARE_READ|FILE_SHARE_WRITE):0,NULL,OPEN_EXISTING,0,NULL);
    if(dev==INVALID_HANDLE_VALUE)return GetLastError();
    packet.version=WP_SLEEP_ABI;packet.action=hibernate?WP_DO_HIBER:WP_DO_SUSPEND;packet.minimum=minimum;
    if(query){
        if(!DeviceIoControl(dev,nt?WP_SLP_QUERY:6,NULL,0,&reply,sizeof(reply),&bytes,NULL))error=GetLastError();
        else if(bytes!=sizeof(reply)||reply!=WP_SLEEP_ABI)error=ERROR_NOT_SUPPORTED;
    }else if(!DeviceIoControl(dev,nt?WP_SLP_APPLY:7,&packet,sizeof(packet),NULL,0,&bytes,NULL))error=GetLastError();
    CloseHandle(dev);return error;
}
static int wp_hybrid_plan(void)
{
#ifdef WP_MODERN
    typedef DWORD (WINAPI *get_scheme)(HKEY,GUID **);
    typedef DWORD (WINAPI *read_value)(HKEY,const GUID *,const GUID *,const GUID *,DWORD *);
    static const GUID sub={0x238c9fa8,0x0aad,0x41ed,{0x83,0xf4,0x97,0xbe,0x24,0x2c,0x8f,0x20}};
    static const GUID setting={0x94ac6d29,0x73ce,0x41a6,{0x80,0x9f,0x63,0x63,0xba,0x21,0xb4,0x7e}};
    GUID *scheme=NULL;DWORD ac=2,dc=2;SYSTEM_POWER_STATUS supply;
    get_scheme get;read_value read_ac,read_dc;int result=-1;
    if(!wp_prof || os.dwMajorVersion<6)return -1;
    get=(get_scheme)GetProcAddress(wp_prof,"PowerGetActiveScheme");
    read_ac=(read_value)GetProcAddress(wp_prof,"PowerReadACValueIndex");
    read_dc=(read_value)GetProcAddress(wp_prof,"PowerReadDCValueIndex");
    if(!get||!read_ac||!read_dc||get(NULL,&scheme)!=ERROR_SUCCESS||!scheme)return -1;
    if(read_ac(NULL,scheme,&sub,&setting,&ac))ac=2;
    if(read_dc(NULL,scheme,&sub,&setting,&dc))dc=2;
    if(GetSystemPowerStatus(&supply) && supply.ACLineStatus<=1){
        DWORD active=supply.ACLineStatus?ac:dc;if(active<=1)result=(int)active;
    }else if(ac<=1 && ac==dc)result=(int)ac;
    LocalFree(scheme);return result;
#else
    return -1;
#endif
}
