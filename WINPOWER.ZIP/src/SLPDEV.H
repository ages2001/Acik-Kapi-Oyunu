#ifndef WP_SLPDEV_H
#define WP_SLPDEV_H
/* One versioned, bounded request. Buffered IOCTLs require explicit file access. */
#define WP_SLEEP_ABI 0x57505331UL
#define WP_SLP_QUERY 0x226400UL
#define WP_SLP_APPLY 0x22a404UL
#define WP_DO_SUSPEND 1u
#define WP_DO_HIBER 2u
struct wp_sleep_packet {
    unsigned long version, action, minimum;
};
#endif
