/* Native NT 3.x/4 display mapping. The later USER32 display enumeration
   interface cannot be called reliably on these versions. */
static BOOL wp_nt_video_value(HKEY key,const char *name,char *buffer,DWORD capacity)
{
 DWORD type,size=capacity-1;
 buffer[0]=0;
 if(RegQueryValueExA(key,name,NULL,&type,(BYTE *)buffer,&size)!=ERROR_SUCCESS ||
    (type!=REG_SZ && type!=REG_MULTI_SZ) || !size || size>=capacity)return FALSE;
 buffer[size]=0;return buffer[0]!=0;
}
static void wp_nt_video(char *label,unsigned capacity)
{
 static const char machine[]="\\Registry\\Machine\\";
 char path[420],description[180],module[120];
 HKEY map,adapter;unsigned i;BOOL ok;
 if(capacity<4)return;
 lstrcpyA(label,"N/A");
 if(RegOpenKeyExA(HKEY_LOCAL_MACHINE,"HARDWARE\\DEVICEMAP\\VIDEO",0,KEY_QUERY_VALUE,&map)!=ERROR_SUCCESS)return;
 ok=wp_nt_video_value(map,"\\Device\\Video0",path,sizeof(path));RegCloseKey(map);
 if(!ok || lstrlenA(path)<(int)sizeof(machine))return;
 for(i=0;i<sizeof(machine)-1;i++)if((path[i]|32)!=(machine[i]|32))return;
 if(RegOpenKeyExA(HKEY_LOCAL_MACHINE,path+sizeof(machine)-1,0,KEY_QUERY_VALUE,&adapter)!=ERROR_SUCCESS)return;
 if(!wp_nt_video_value(adapter,"Device Description",description,sizeof(description)))
     wp_nt_video_value(adapter,"DriverDesc",description,sizeof(description));
 wp_nt_video_value(adapter,"InstalledDisplayDrivers",module,sizeof(module));RegCloseKey(adapter);
 if(description[0]){
   lstrcpynA(label,description,(int)capacity);
   if(module[0] && (unsigned)(lstrlenA(label)+lstrlenA(module)+4)<=capacity){
     lstrcatA(label," (");lstrcatA(label,module);lstrcatA(label,")");
   }
 }else if(module[0])lstrcpynA(label,module,(int)capacity);
}
