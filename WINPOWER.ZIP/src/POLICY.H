#ifndef PN_POLICY_H
#define PN_POLICY_H
/* Hardware and OS families report their live provider separately. */
int pn_eligible(int nt, unsigned major, unsigned minor, int provider_available);
int pn_owner(int requested, int eligible, int backend_ready);
#endif
