#ifndef WP_SLPMIN_H
#define WP_SLPMIN_H

/* Bits 1..3 correspond to the named minimum accepted by Windows. */
static unsigned wp_minimum_mask(const struct wp_sleep_caps *caps, int native_api)
{
    unsigned mask = 0, level;
    if (native_api && caps->suspend)
        for (level = 1; level <= 3; ++level)
            if (caps->state[level] == WP_YES) mask |= 1u << level;
    return mask;
}

static int wp_minimum_valid(unsigned mask, unsigned level)
{
    return level >= 1 && level <= 3 && (mask & (1u << level)) != 0;
}
#endif
