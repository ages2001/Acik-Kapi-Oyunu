#ifndef WP_SLPPOL_H
#define WP_SLPPOL_H
#define WP_OS 0
#define WP_DRIVER 1
#define WP_NONE 2
enum wp_hybrid { WP_HY_OK,WP_HY_OS,WP_HY_SLEEP,WP_HY_S4,WP_HY_FILE,WP_HY_VETO,WP_HY_PLAN,WP_HY_UNKNOWN,WP_HY_PLATFORM };
static int wp_route(int preferred,int system,int driver)
{
    if(preferred==WP_DRIVER)return driver?WP_DRIVER:WP_NONE;
    if(preferred==WP_OS)return system?WP_OS:WP_NONE;
    return system?WP_OS:(driver?WP_DRIVER:WP_NONE);
}
static enum wp_hybrid wp_hybrid_status(const struct wp_sleep_caps *c,int supported_os,int plan)
{
    if(!supported_os)return WP_HY_OS;
    if(c->state[1]!=WP_YES && c->state[2]!=WP_YES && c->state[3]!=WP_YES)return WP_HY_SLEEP;
    if(c->state[4]!=WP_YES)return WP_HY_S4;
    if(c->file_present!=WP_YES||c->reduced_file)return WP_HY_FILE;
    if(c->hybrid_capable!=WP_YES)return WP_HY_PLATFORM;
    if(!c->suspend||!c->hibernate)return WP_HY_VETO;
    if(plan<0)return WP_HY_UNKNOWN;
    return plan?WP_HY_OK:WP_HY_PLAN;
}
#endif
