#!/bin/sh
# Build the firmware update in an isolated tree, preserving ready packages
# not affected by it. The previous owner-switch setup binaries remain usable.
set -eu
src=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
root=$(dirname "$src")
case $# in
 0) full=0 ;;
 2) [ "$1" = --all ] || { echo 'Usage: BLDFIRM.SH [--all OUTPUT_DIR]' >&2; exit 2; }
    full=1
    output=$(python3 -c 'import os,sys; print(os.path.abspath(sys.argv[1]))' "$2")
    [ ! -e "$output" ] || { echo 'The full build needs a new output directory.' >&2; exit 2; } ;;
 *) echo 'Usage: BLDFIRM.SH [--all OUTPUT_DIR]' >&2; exit 2 ;;
esac
stage=$(mktemp -d)
trap 'rm -rf "$stage"' EXIT HUP INT TERM
dest="$root/bin"
if [ "$full" = 1 ]; then
 dest="$stage/out"
 for d in DOS NT3 NT4 WIN9X 2KXP XPAMD64 NT6X86 NT6AMD64 WIN1 WIN2 WIN3 WIN386; do mkdir -p "$dest/$d"; done
fi
cp -R "$src" "$stage/src"
mkdir -p "$stage/test" "$stage/TEST" "$stage/bin"
cp "$root"/test/*.C "$stage/test/"
cp "$root/test/FIXVXD.PY" "$stage/test/"
cp "$stage/test/FWAUDIT.C" "$stage/TEST/"
for d in DOS NT3 NT4 WIN9X 2KXP XPAMD64 NT6X86 NT6AMD64; do mkdir -p "$stage/bin/$d"; done
cd "$stage/src"
export SOURCE_DATE_EPOCH=1795046400
python3 GLYPHS.PY
python3 APMGEN.PY --check
sh BLDFIX.SH
sh BUILDSSD.SH
sh BUILDAPM.SH
sh BUILDFW.SH
sh BLDSLP.SH "$dest"
as --32 APMEXIT.S -o "$stage/APMEXIT.O"
ld -m elf_i386 -Ttext 0x100 --oformat binary "$stage/APMEXIT.O" -o "$dest/WIN9X/WPAPM9.COM"
as --32 APM.S -o "$stage/APM.O"
ld -m elf_i386 -Ttext 0x100 --oformat binary "$stage/APM.O" -o "$stage/bin/APM.COM"
for d in WIN1 WIN2 WIN3 WIN386; do
 for f in WINPWR16.EXE UNINST.EXE WPWRDOS.EXE; do cp "$stage/BIN/WINPWR16/$d/$f" "$dest/$d/"; done
done
cp "$stage/bin/APM.COM" "$dest/DOS/"
for f in WPWRDOS.EXE WPAPM.EXE PNACPI.EXE WPS5DOS.EXE WPSLEEP.EXE; do cp "$stage/BIN/WPWRDOS/$f" "$dest/DOS/"; done
for d in NT3 NT4; do cp "$stage/bin/$d/PN4HOOK.SYS" "$stage/bin/$d/WINPWRNT.EXE" "$dest/$d/"; done
cp "$stage/bin/NT3/PN3HOOK.SYS" "$dest/NT3/"
for d in 2KXP XPAMD64; do cp "$stage/bin/$d/PN5HOOK.SYS" "$stage/bin/$d/WINPWRNT.EXE" "$dest/$d/"; done
cp "$stage/bin/2KXP/W2KHOOK.SYS" "$dest/2KXP/"
for d in NT6X86 NT6AMD64; do cp "$stage/bin/$d/WINPWRNT.EXE" "$dest/$d/"; done
cp "$stage/bin/WIN9X/PN9HOOK.VXD" "$stage/bin/WIN9X/WINPWR9X.EXE" "$dest/WIN9X/"
for d in 2KXP NT4; do cp "$stage/BIN/WINPWRNT/X86/FWAUDIT.EXE" "$dest/$d/"; done
cp "$stage/BIN/WINPWRNT/X64/FWAUDIT.EXE" "$dest/XPAMD64/"
if [ "$full" = 1 ]; then
 python3 "$src/AUXBUILD.PY" "$stage" "$root" "$output"
fi
