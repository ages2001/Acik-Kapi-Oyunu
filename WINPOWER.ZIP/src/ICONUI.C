#include "ICONUI.H"
#include "PALUI.H"
#include "UIMASK.H"
static void pn_dim(HDC dc,unsigned icon,int x,int y,int size){
 int pass,row,col,start;RECT r;HBRUSH b;COLORREF highlight,shadow;
 if(icon<1||icon>13||size<=0)return;
#ifdef _WIN32
 highlight=GetSysColor(COLOR_BTNHIGHLIGHT);shadow=GetSysColor(COLOR_BTNSHADOW);
#else
 highlight=WP_PAPER;shadow=LOBYTE(LOWORD(GetVersion()))<3?RGB(0,0,0):WP_SLATE;
#endif
 for(pass=1;pass>=0;--pass){
  b=CreateSolidBrush(pass?highlight:shadow);if(!b)continue;
  for(row=0;row<size;++row){
   unsigned long mask=pn_opaque[icon-1][row*32/size];
   r.top=y+row+pass;r.bottom=r.top+1;start=-1;
   for(col=0;col<=size;++col){
    int visible=col<size && (mask&(1UL<<(31-col*32/size)));
    if(visible&&start<0)start=col;
    if(!visible&&start>=0){r.left=x+start+pass;r.right=x+col+pass;FillRect(dc,&r,b);start=-1;}
   }
  }
  DeleteObject(b);
 }
}
void pn_area(HDC dc,int left,int top,int right,int bottom,COLORREF color){
 RECT r;HBRUSH brush;
 if(left>=right||top>=bottom)return;
 r.left=left;r.top=top;r.right=right;r.bottom=bottom;
 brush=CreateSolidBrush(GetNearestColor(dc,color));
 if(brush){FillRect(dc,&r,brush);DeleteObject(brush);}
}
void pn_mark(HDC dc,unsigned glyph,int x,int y,int size){
 static const char art[][16][17]={
  {"                ","  nnnnnnnnnnnn  "," nssssssssssssn "," nnttttttttttnn ",
   " nnacccccccctnn "," nnacccccccctnn "," nnacccccccctnn "," nnacccccccctnn ",
   " nnttttttttttnn "," nsssssssssagsn ","  nnnnnnnnnnnn  ","      nssn      ",
   "     nnssnn     ","   nnnnnnnnnn   ","                ","                "},
  {"                ","    s s s s     ","    n n n n     ","   nnnnnnnnnn   ",
   " snnttttttttnns ","   ntaccacctn   "," snntcttttctnns ","   ntctggtctn   ",
   " snntctggtctnns ","   ntacctactn   "," snnttttttttnns ","   nnnnnnnnnn   ",
   "    n n n n     ","    s s s s     ","                ","                "},
  {"                ","      nnn       ","     npppn      ","     npspn      ",
   "      npn       ","     nppn       ","    nppn        ","   nppn         ",
   "  nnnnnnnnnnnn  "," nssssssssssssn "," nssnnnssgnnssn "," nssnnnssgnnssn ",
   " nssssssssssssn ","  nnnnnnnnnnnn  ","                ","                "},
  {"           c    ","     yyyy ccc   ","   yyyya   c    ","  yyyy          ",
   " yyyy       a   "," yyyy      aaa  "," yyyy       a   "," yyyy           ",
   " yyyyy          ","  yyyyy       y ","  yyyyyya   ayy ","   yyyyyyyyyyy  ",
   "    ayyyyyyyy   ","      ayyyy     ","                ","                "},
  {"                ","  nnnnnnnnnnnn  ","  ntyyyyyyyysn  ","   naccssccn    ",
   "   ncyyyyyyn    ","    ncyyyyn     ","     ncyyn      ","      nt n      ",
   "      n yn      ","     nc y n     ","    nc  y  n    ","   nc  yyy  n   ",
   "   nsyyyyyysn   ","  ntyyyyyyyysn  ","  nnnnnnnnnnnn  ","                "}
 };
 static const COLORREF colors[]={WP_NAVY,RGB(192,192,192),WP_TEAL,WP_AQUA,
                                 RGB(255,255,255),WP_GREEN,WP_PLUM,RGB(255,255,0)};
 static const char keys[]="nstcagpy";
 HBRUSH brushes[8];int i,row,at,end;RECT box;
 if(glyph>=sizeof(art)/sizeof(art[0])||size<8)return;
 for(i=0;i<8;++i)brushes[i]=CreateSolidBrush(GetNearestColor(dc,colors[i]));
 for(row=0;row<16;++row){
  box.top=y+row*size/16;box.bottom=y+(row+1)*size/16;
  if(box.bottom<=box.top)continue;
  for(at=0;at<16;at=end){
   char c=art[glyph][row][at];for(end=at+1;end<16&&art[glyph][row][end]==c;++end){}
   if(c==' ')continue;
   for(i=0;i<8&&keys[i]!=c;++i){}
   if(i==8||!brushes[i])continue;
   box.left=x+at*size/16;box.right=x+end*size/16;
   if(box.left<box.right)FillRect(dc,&box,brushes[i]);
  }
 }
 for(i=0;i<8;++i)if(brushes[i])DeleteObject(brushes[i]);
}
#ifndef _WIN32
#include "INK16.H"
void pn_pixel(HDC dc,unsigned icon,int x,int y,int size){
 int a,b;unsigned c;unsigned oldpalette=LOBYTE(LOWORD(GetVersion()))<3;
 if(icon<1||icon>11)return;
 for(b=0;b<size;b++)for(a=0;a<size;a++){
  c=pn_pixels[icon-1][(b*32/size)*32+(a*32/size)];
  if(c!=255)SetPixel(dc,x+a,y+b,(oldpalette&&c==8)?RGB(0,0,0):pn_colors[c]);
 }
}
#endif
void pn_icon(HDC dc,HICON icon,int x,int y,int size,HBRUSH background){
 HDC mem;HBITMAP bmp,old;RECT r;int previous;
 if(!icon)return;
 mem=CreateCompatibleDC(dc);if(!mem)return;
 bmp=CreateCompatibleBitmap(dc,32,32);if(!bmp){DeleteDC(mem);return;}
 old=(HBITMAP)SelectObject(mem,bmp);r.left=r.top=0;r.right=r.bottom=32;
 FillRect(mem,&r,background);DrawIcon(mem,0,0,icon);
 previous=SetStretchBltMode(dc,COLORONCOLOR);
 StretchBlt(dc,x,y,size,size,mem,0,0,32,32,SRCCOPY);SetStretchBltMode(dc,previous);
 SelectObject(mem,old);DeleteObject(bmp);DeleteDC(mem);
}
void pn_button(LPDRAWITEMSTRUCT d,HINSTANCE instance,unsigned icon,HFONT font,HBRUSH background){
 RECT r=d->rcItem,edge,text;HBRUSH light,dark;HFONT old;int shift=(d->itemState&ODS_SELECTED)?1:0;char caption[64];
#ifdef _WIN32
 light=CreateSolidBrush(GetSysColor(shift?COLOR_BTNSHADOW:COLOR_BTNHIGHLIGHT));
 dark=CreateSolidBrush(GetSysColor(shift?COLOR_BTNHIGHLIGHT:COLOR_BTNSHADOW));
#else
 /* The button color indexes were added after Windows 2.x. */
 {COLORREF shadow=LOBYTE(LOWORD(GetVersion()))<3?RGB(0,0,0):RGB(128,128,128);
 light=CreateSolidBrush(shift?shadow:RGB(255,255,255));
 dark=CreateSolidBrush(shift?RGB(255,255,255):shadow);}
#endif
 FillRect(d->hDC,&r,background);
 edge=r;edge.bottom=edge.top+2;FillRect(d->hDC,&edge,light);
 edge=r;edge.right=edge.left+2;FillRect(d->hDC,&edge,light);
 edge=r;edge.top=edge.bottom-2;FillRect(d->hDC,&edge,dark);
 edge=r;edge.left=edge.right-2;FillRect(d->hDC,&edge,dark);
 DeleteObject(light);DeleteObject(dark);
 if(!(d->itemState&ODS_DISABLED)){
  COLORREF accent=(icon==3||icon==2)?RGB(128,0,0):icon==4?WP_GREEN:
                  (icon==12||icon==13)?WP_PLUM:WP_TEAL;
  pn_area(d->hDC,r.left+3+shift,r.top+4+shift,r.left+6+shift,r.bottom-4,accent);
 }
 if(d->itemState&ODS_DISABLED)pn_dim(d->hDC,icon,r.left+9,r.top+(r.bottom-r.top-20)/2,20);
 else{
#ifdef _WIN32
 pn_icon(d->hDC,LoadIcon(instance,MAKEINTRESOURCE(icon>=3&&icon<=13?icon+20:icon)),r.left+9+shift,r.top+(r.bottom-r.top-20)/2+shift,20,background);
#else
 (void)instance;
 pn_pixel(d->hDC,icon,r.left+9+shift,r.top+(r.bottom-r.top-20)/2+shift,20);
#endif
 }
 text=r;text.left+=34+shift;text.right-=4;text.top+=shift;
 GetWindowText(d->hwndItem,caption,sizeof(caption));old=(HFONT)SelectObject(d->hDC,font);
 SetBkMode(d->hDC,TRANSPARENT);
#ifdef _WIN32
 SetTextColor(d->hDC,GetSysColor((d->itemState&ODS_DISABLED)?COLOR_GRAYTEXT:COLOR_BTNTEXT));
#else
 SetTextColor(d->hDC,((d->itemState&ODS_DISABLED)&&LOBYTE(LOWORD(GetVersion()))>=3)?RGB(128,128,128):RGB(0,0,0));
#endif
 DrawText(d->hDC,caption,-1,&text,DT_CENTER|DT_VCENTER|DT_SINGLELINE);
 SelectObject(d->hDC,old);
 if(d->itemState&ODS_FOCUS){
  r.left+=4;r.top+=4;r.right-=4;r.bottom-=4;
#ifdef _WIN32
  DrawFocusRect(d->hDC,&r);
#else
  /* USER.466 (DrawFocusRect) is absent from Windows 1.x. */
  {int p;for(p=r.left;p<r.right;p+=2){SetPixel(d->hDC,p,r.top,RGB(0,0,0));SetPixel(d->hDC,p,r.bottom-1,RGB(0,0,0));}
   for(p=r.top;p<r.bottom;p+=2){SetPixel(d->hDC,r.left,p,RGB(0,0,0));SetPixel(d->hDC,r.right-1,p,RGB(0,0,0));}}
#endif
 }
}
