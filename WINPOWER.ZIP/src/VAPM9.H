/* Some Windows 95 installations report zero through the VPOWERD BIOS
   version service even though Windows started an APM Plug and Play node.
   Read the detected revision from the active node. A battery status
   service is optional on AC-powered PCs and is unrelated to power off. */
#define WP_CM_SERVICE(name,ordinal,params) \
 static U32 __declspec(naked) __cdecl name params { \
  _asm int 20h \
  _asm dw ordinal \
  _asm dw 33h \
 }
/* DDK VxDJmp keeps the caller's cdecl return address and arguments. */
WP_CM_SERVICE(cm_locate,8002h,(U32 *node,const char *id,U32 flags))
WP_CM_SERVICE(cm_child,8004h,(U32 *out,U32 node,U32 flags))
WP_CM_SERVICE(cm_sibling,8005h,(U32 *out,U32 node,U32 flags))
WP_CM_SERVICE(cm_id,8007h,(U32 node,char *id,U32 size,U32 flags))
WP_CM_SERVICE(cm_status,8036h,(U32 *status,U32 *problem,U32 node,U32 flags))
WP_CM_SERVICE(cm_value,803eh,(U32 node,const char *key,const char *name,U32 type,
                              void *buffer,U32 *size,U32 flags))
#undef WP_CM_SERVICE

static int is_apm_node(const char *id)
{
 static const char name[]="PNP0C05";unsigned i;char c;
 while(*id && *id!='\\')++id;
 if(!*id++)return 0;
 if(*id=='*')++id;
 for(i=0;i<sizeof(name)-1;++i){
  c=*id++;if(c>='a'&&c<='z')c-=32;
  if(c!=name[i])return 0;
 }
 return *id=='\\';
}
static unsigned pnp_apm_version(void)
{
 U32 pending[32],count=1,visited=0,node,other,flags,problem,bytes;
 U16 version;char id[200];
 if(!getddb(0x33)||cm_locate(pending,0,0))return 0;
 while(count && ++visited<=512){
  node=pending[--count];id[sizeof(id)-1]=0;
  if(!cm_id(node,id,sizeof(id)-1,0) && is_apm_node(id) &&
     !cm_status(&flags,&problem,node,0) && (flags&8) && !(flags&0x400)){
   bytes=sizeof(version);version=0;
   if(!cm_value(node,0,"APMBiosVer",3,&version,&bytes,0) && bytes==sizeof(version) &&
      version>=0x100 && version<=0x102)return version;
  }
  if(count+2>sizeof(pending)/sizeof(pending[0]))return 0;
  if(!cm_sibling(&other,node,0))pending[count++]=other;
  if(!cm_child(&other,node,0))pending[count++]=other;
 }
 return 0;
}
