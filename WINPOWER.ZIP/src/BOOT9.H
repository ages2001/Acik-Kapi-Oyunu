/* Register the real-mode APM helper on the DOS boot volume. Only the line
   installed here is eligible for removal. Other batch contents are opaque. */
static BOOL wb_fail(const char *s){fail(s);return FALSE;}
static void wb_copy(char *out,const char *in,DWORD n){while(n--)*out++=*in++;}
static BOOL wb_write(const char *path,const char *data,DWORD size)
{
 DWORD got;HANDLE h=CreateFileA(path,GENERIC_WRITE,0,0,CREATE_NEW,FILE_ATTRIBUTE_NORMAL,0);
 BOOL ok;if(h==INVALID_HANDLE_VALUE)return FALSE;
 ok=WriteFile(h,data,size,&got,0)&&got==size&&FlushFileBuffers(h);CloseHandle(h);
 if(!ok)DeleteFileA(path);
 return ok;
}
static char wb_drive(void)
{
 char win[MAX_PATH],shortwin[MAX_PATH],path[]="C:\\MSDOS.SYS",value[MAX_PATH],shortval[MAX_PATH],found=0;
 DWORD mask=GetLogicalDrives();unsigned i;
 if(!GetWindowsDirectoryA(win,sizeof(win))||!GetShortPathNameA(win,shortwin,sizeof(shortwin)))return 0;
 for(i=2;i<26;++i){
  char root[]="C:\\";
  if(!(mask&(1UL<<i)))continue;
  root[0]=path[0]=(char)('A'+i);
  if(GetDriveTypeA(root)!=DRIVE_FIXED)continue;
  if(!GetPrivateProfileStringA("Paths","WinDir","",value,sizeof(value),path) ||
     !GetShortPathNameA(value,shortval,sizeof(shortval)) || lstrcmpiA(shortval,shortwin))continue;
  if(found)return 0;
  found=root[0];
 }
 return found;
}
static BOOL wb_contents(const char *data,DWORD n,const char *line,BOOL remove,DWORD *out)
{
 DWORD i=0,end,content,k=0,match=0,len=(DWORD)lstrlenA(line);
 if(!remove&&n+len+2>=sizeof(after))return FALSE;
 if(!remove){
  wb_copy(after,line,len);after[len]='\r';after[len+1]='\n';k=len+2;
 }
 while(i<n){
  end=i;while(end<n&&data[end]!='\n'&&data[end]!='\r')++end;content=end;
  if(end<n&&data[end]=='\r')++end;
  if(end<n&&data[end]=='\n')++end;
  if(content-i==len&&same(data+i,line,len))++match;
  else {wb_copy(after+k,data+i,end-i);k+=end-i;}
  i=end;
 }
 if(match>1||(!remove&&match))return FALSE;
 *out=k;return TRUE;
}
BOOL pn9_boot(const char *folder,BOOL remove)
{
 char record[MAX_PATH],dir[MAX_PATH],line[MAX_PATH+16],info[2];
 char batch[]="C:\\AUTOEXEC.BAT",temp[]="C:\\WP9NEW.BAT",save[]="C:\\WP9SAVE.BAT";
 DWORD n=0,check=0,k=0,attrs,err;BOOL existed,drop;
 join(record,folder,"APMBOOT.ID");
 if(remove){
  if(GetFileAttributesA(record)==INVALID_FILE_ATTRIBUTES&&GetLastError()==ERROR_FILE_NOT_FOUND)return TRUE;
  if(!readfile(record,before,&n)||n!=2||before[0]<'C'||before[0]>'Z'||(before[1]!='0'&&before[1]!='1'))
   return wb_fail("The saved APM startup record could not be read.");
  info[0]=before[0];info[1]=before[1];n=0;
 }else{
  /* The standard Windows Me boot process does not run DOS startup programs. */
  if(HIBYTE(LOWORD(GetVersion()))==90)return TRUE;
  info[0]=wb_drive();if(!info[0])return wb_fail("The DOS boot volume could not be identified. See INSTALL.TXT for APM startup.");
 }
 batch[0]=temp[0]=save[0]=info[0];
 if(!GetShortPathNameA(folder,dir,sizeof(dir)))return wb_fail("Cannot resolve the DOS path to the APM helper.");
 wsprintfA(line,"@%s\\WPAPM9.COM",dir);
 attrs=GetFileAttributesA(batch);err=GetLastError();existed=attrs!=INVALID_FILE_ATTRIBUTES;
 if(!existed&&err!=ERROR_FILE_NOT_FOUND)return wb_fail("Cannot read AUTOEXEC.BAT on the DOS boot volume.");
 if(existed&&((attrs&FILE_ATTRIBUTE_READONLY)||!readfile(batch,before,&n)))
  return wb_fail("AUTOEXEC.BAT could not be edited. See INSTALL.TXT for APM startup.");
 if(!remove)info[1]=existed?'1':'0';
 if(!wb_contents(before,n,line,remove,&k))return wb_fail("AUTOEXEC.BAT has a duplicate APM entry or exceeds the supported size.");
 if(remove&&k==n)return TRUE;
 if(GetFileAttributesA(save)!=INVALID_FILE_ATTRIBUTES||GetFileAttributesA(temp)!=INVALID_FILE_ATTRIBUTES)
  return wb_fail("The DOS boot volume already has WP9NEW.BAT or WP9SAVE.BAT. Preserve that recovery file before retrying.");
 drop=remove&&!k&&info[1]=='0';
 if(!drop){
  if(!wb_write(temp,after,k))return wb_fail("The new APM startup file could not be written.");
  if(existed&&!SetFileAttributesA(temp,attrs)){DeleteFileA(temp);return wb_fail("Cannot preserve AUTOEXEC.BAT attributes.");}
 }
 if(!remove&&!wb_write(record,info,2)){if(!drop)DeleteFileA(temp);return wb_fail("Cannot record the DOS startup change.");}
 if(existed&&(!readfile(batch,verify,&check)||check!=n||!same(before,verify,n)||GetFileAttributesA(batch)!=attrs||!MoveFileA(batch,save))){
  if(!drop)DeleteFileA(temp);
  if(!remove)DeleteFileA(record);
  return wb_fail("AUTOEXEC.BAT changed or could not be reserved. Its contents were preserved.");
 }
 if(!drop&&!MoveFileA(temp,batch)){
  if(existed&&!MoveFileA(save,batch)){recovery=TRUE;wsprintfA(reason,"Restore %s to %s before restarting Windows.",save,batch);return FALSE;}
  DeleteFileA(temp);if(!remove)DeleteFileA(record);
  return wb_fail("The APM startup change could not be committed.");
 }
 if(existed&&!DeleteFileA(save)){wsprintfA(reason,"The edited AUTOEXEC.BAT is active. Its previous copy remains in %s.",save);return FALSE;}
 return TRUE;
}
