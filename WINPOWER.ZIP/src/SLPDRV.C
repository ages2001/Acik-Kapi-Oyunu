/* An NT5+ caller can request an orderly system-wide power action.
   The Windows power manager prepares devices, writes S4 and restores the session. */
#include <ntddk.h>
#include "SLPDEV.H"

NTSYSAPI NTSTATUS NTAPI ZwInitiatePowerAction(POWER_ACTION,SYSTEM_POWER_STATE,ULONG,BOOLEAN);
#define WP_QUERY_ALLOWED 0x01UL
#define WP_UI_ALLOWED 0x02UL
static UNICODE_STRING link_name;
static volatile LONG in_flight;

static NTSTATUS NTAPI dispatch(PDEVICE_OBJECT device,PIRP irp)
{
    PIO_STACK_LOCATION stack=IoGetCurrentIrpStackLocation(irp);
    PVOID buffer=irp->AssociatedIrp.SystemBuffer;
    NTSTATUS status=STATUS_INVALID_DEVICE_REQUEST;
    ULONG_PTR count=0;
    (void)device;
    switch(stack->MajorFunction){
    case IRP_MJ_CREATE:
        status=stack->FileObject->FileName.Length?STATUS_OBJECT_NAME_INVALID:STATUS_SUCCESS;
        break;
    case IRP_MJ_CLEANUP:case IRP_MJ_CLOSE:status=STATUS_SUCCESS;break;
    case IRP_MJ_DEVICE_CONTROL:
        if(stack->Parameters.DeviceIoControl.IoControlCode==WP_SLP_QUERY){
            if(!buffer||stack->Parameters.DeviceIoControl.OutputBufferLength<sizeof(ULONG))
                status=STATUS_BUFFER_TOO_SMALL;
            else{*(ULONG *)buffer=WP_SLEEP_ABI;count=sizeof(ULONG);status=STATUS_SUCCESS;}
        }else if(stack->Parameters.DeviceIoControl.IoControlCode==WP_SLP_APPLY){
            struct wp_sleep_packet request;
            POWER_ACTION action;
            SYSTEM_POWER_STATE level;
            LUID privilege;
            if(!buffer||stack->Parameters.DeviceIoControl.InputBufferLength!=sizeof(request)){
                status=STATUS_INVALID_PARAMETER;break;
            }
            request=*(struct wp_sleep_packet *)buffer;
            if(request.version!=WP_SLEEP_ABI){status=STATUS_REVISION_MISMATCH;break;}
            if(request.action==WP_DO_SUSPEND && request.minimum<=3){
                action=PowerActionSleep;
                level=(SYSTEM_POWER_STATE)(PowerSystemSleeping1+(request.minimum?request.minimum-1:0));
            }else if(request.action==WP_DO_HIBER && !request.minimum){
                action=PowerActionHibernate;level=PowerSystemHibernate;
            }else{status=STATUS_INVALID_PARAMETER;break;}
            privilege.HighPart=0;privilege.LowPart=SE_SHUTDOWN_PRIVILEGE;
            if(!SeSinglePrivilegeCheck(privilege,irp->RequestorMode)){
                status=STATUS_PRIVILEGE_NOT_HELD;break;
            }
            if(KeGetCurrentIrql()!=PASSIVE_LEVEL){status=STATUS_INVALID_DEVICE_STATE;break;}
            if(InterlockedCompareExchange(&in_flight,1,0)){status=STATUS_DEVICE_BUSY;break;}
            status=ZwInitiatePowerAction(action,level,WP_QUERY_ALLOWED|WP_UI_ALLOWED,FALSE);
            InterlockedExchange(&in_flight,0);
        }
        break;
    }
    irp->IoStatus.Status=status;irp->IoStatus.Information=count;
    IoCompleteRequest(irp,IO_NO_INCREMENT);return status;
}
static VOID NTAPI unload(PDRIVER_OBJECT driver)
{
    IoDeleteSymbolicLink(&link_name);IoDeleteDevice(driver->DeviceObject);
}
NTSTATUS NTAPI DriverEntry(PDRIVER_OBJECT driver,PUNICODE_STRING registry)
{
    UNICODE_STRING name;
    PDEVICE_OBJECT device;
    unsigned i;
    NTSTATUS status;
    (void)registry;
    RtlInitUnicodeString(&name,L"\\Device\\WpSleep");
    RtlInitUnicodeString(&link_name,L"\\DosDevices\\WpSleep");
    status=IoCreateDevice(driver,0,&name,FILE_DEVICE_UNKNOWN,FILE_DEVICE_SECURE_OPEN,FALSE,&device);
    if(!NT_SUCCESS(status))return status;
    for(i=0;i<=IRP_MJ_MAXIMUM_FUNCTION;++i)driver->MajorFunction[i]=dispatch;
    driver->DriverUnload=unload;
    status=IoCreateSymbolicLink(&link_name,&name);
    if(!NT_SUCCESS(status)){IoDeleteDevice(device);return status;}
    device->Flags&=~DO_DEVICE_INITIALIZING;return STATUS_SUCCESS;
}
