/* Classic VGA colors. All pictograms leave unmarked pixels transparent. */
#ifndef WP_PALUI_H
#define WP_PALUI_H
#include <windows.h>
#define WP_NAVY RGB(0,0,128)
#define WP_TEAL RGB(0,128,128)
#define WP_PLUM RGB(128,0,128)
#define WP_GREEN RGB(0,128,0)
#define WP_AQUA RGB(0,255,255)
#define WP_PAPER RGB(255,255,255)
#define WP_SLATE RGB(128,128,128)

void pn_area(HDC dc,int left,int top,int right,int bottom,COLORREF color);
void pn_mark(HDC dc,unsigned glyph,int x,int y,int size);
/* Source, firmware and control selector icons, numbered independently of ICO resources. */
#define PN_SCREEN 0
#define PN_CHIP 1
#define PN_SWITCH 2
#define PN_MOON 3
#define PN_HOURGLASS 4
#endif
