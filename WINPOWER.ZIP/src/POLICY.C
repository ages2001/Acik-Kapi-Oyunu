#include "POLICY.H"
int pn_eligible(int nt, unsigned major, unsigned minor, int provider_available) {
    if (nt) {
        if ((major == 3 && (minor == 10 || minor == 50 || minor == 51)) ||
            (major == 4 && minor == 0) || (major == 5 && minor <= 2)) return 1;
        return provider_available && ((major == 6 && minor <= 3) ||
                           (major == 10 && minor == 0));
    }
    return (major >= 1 && major <= 3) ||
           (major == 4 && (minor == 0 || minor == 10 || minor == 90));
}
int pn_owner(int requested, int eligible, int backend_ready) {
    return requested && eligible && backend_ready;
}
