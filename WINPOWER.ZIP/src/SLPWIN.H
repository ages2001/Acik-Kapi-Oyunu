/* Windows coordinates device state, application notifications and the resume image. */
#include "SLPCAPS.H"
#include <powrprof.h>
#if defined(WP_NT5CFG) || defined(WP_MODERN)
#include "SLPMIN.H"
#define WP_MINIMUM_LIST 1
#endif
#include "SLPVIDEO.H"
#ifdef WP_NT34CFG
#include "NTVIDEO.H"
#endif
typedef BOOLEAN (WINAPI *wp_caps_fn)(SYSTEM_POWER_CAPABILITIES *);
typedef BOOLEAN (WINAPI *wp_allowed_fn)(void);
typedef BOOLEAN (WINAPI *wp_suspend_fn)(BOOLEAN,BOOLEAN,BOOLEAN);
typedef BOOL (WINAPI *wp_old_suspend_fn)(BOOL,BOOL);
typedef LONG (WINAPI *wp_min_sleep_fn)(ULONG,ULONG,ULONG,BOOLEAN);
static struct wp_sleep_caps wp_sleep;
static HMODULE wp_prof;
static wp_caps_fn wp_caps_query;
static wp_allowed_fn wp_can_suspend,wp_can_hibernate;
static wp_suspend_fn wp_set_sleep;
static wp_old_suspend_fn wp_set_old;
static wp_min_sleep_fn wp_set_min;
static BOOL wp_sleep_busy;
#include "SLPROUTE.H"
static int wp_focus_row=-1;
static BOOL wp_minimum_api(int route)
{
    return route==WP_DRIVER ? (os.dwPlatformId==VER_PLATFORM_WIN32_NT && os.dwMajorVersion>=5) :
                               (route==WP_OS && wp_set_min!=NULL);
}
static BOOL wp_level_open(int route, unsigned level)
{
    const struct wp_sleep_caps *caps=route==WP_DRIVER?&wp_drv_caps:&wp_sleep;
    return level<=3 && (!level || (wp_minimum_api(route) && caps->state[level]==WP_YES));
}

static void wp_sleep_open(void)
{
    char path[MAX_PATH];
    UINT length=GetSystemDirectoryA(path,sizeof(path));
    if(length && length+sizeof("\\POWRPROF.DLL")<=sizeof(path)){
        lstrcatA(path,"\\POWRPROF.DLL");
        wp_prof=LoadLibraryA(path);
    }
    if(wp_prof){
        wp_caps_query=(wp_caps_fn)GetProcAddress(wp_prof,"GetPwrCapabilities");
        wp_can_suspend=(wp_allowed_fn)GetProcAddress(wp_prof,"IsPwrSuspendAllowed");
        wp_can_hibernate=(wp_allowed_fn)GetProcAddress(wp_prof,"IsPwrHibernateAllowed");
        wp_set_sleep=(wp_suspend_fn)GetProcAddress(wp_prof,"SetSuspendState");
    }
    wp_set_old=(wp_old_suspend_fn)GetProcAddress(GetModuleHandleA("KERNEL32.DLL"),"SetSystemPowerState");
    if(os.dwPlatformId==VER_PLATFORM_WIN32_NT && os.dwMajorVersion>=5)
        wp_set_min=(wp_min_sleep_fn)GetProcAddress(GetModuleHandleA("NTDLL.DLL"),"NtInitiatePowerAction");
}
static void wp_sleep_refresh(void)
{
    SYSTEM_POWER_CAPABILITIES caps;
    BOOL known,device,pe=FALSE;
    int suspend_policy=WP_UNKNOWN,hibernate_policy=WP_UNKNOWN;
    ZeroMemory(&caps,sizeof(caps));
    known=wp_caps_query && wp_caps_query(&caps);
    if(wp_can_suspend)suspend_policy=wp_can_suspend()?WP_YES:WP_NO;
    else if(!known && os.dwPlatformId==VER_PLATFORM_WIN32_WINDOWS && wp_set_old)
        suspend_policy=WP_YES; /* Original Windows 95 can ask its APM driver. */
    if(wp_can_hibernate)hibernate_policy=wp_can_hibernate()?WP_YES:WP_NO;
#ifdef WP_MODERN
    pe=pe_mode;
#endif
    wp_sleep_decode(&wp_sleep,known?(const unsigned char *)&caps:NULL,
        os.dwMajorVersion,os.dwMinorVersion,wp_set_sleep||wp_set_old,suspend_policy,
        wp_set_sleep||wp_set_old,hibernate_policy,pe);
    device=(wp_sleep_device(TRUE,FALSE,0)==0);
    wp_sleep_decode(&wp_drv_caps,known?(const unsigned char *)&caps:NULL,
        os.dwMajorVersion,os.dwMinorVersion,device,suspend_policy,device,hibernate_policy,pe);
    wp_hybrid=wp_hybrid_status(wp_session_route(0)==WP_DRIVER?&wp_drv_caps:&wp_sleep,os.dwPlatformId==VER_PLATFORM_WIN32_NT && os.dwMajorVersion>=6,wp_hybrid_plan());
}
static const char *wp_state_word(unsigned v)
{
    if(v==WP_UNKNOWN)return "N/A";
    return v==WP_YES?"Available":"Unavailable";
}
static const char *wp_selection_reason(int row)
{
    unsigned value;
    if(row==0)return "Already running";
    if(row==1)return wp_sleep.low_idle==WP_YES?"Windows chooses":(os.dwMajorVersion<6 ||
        (os.dwMajorVersion==6 && os.dwMinorVersion<2)?"Needs Windows 8+":"OS unavailable");
    if(row==7)return wp_hy_reason[wp_hybrid];
    value=wp_sleep.state[row-1];
    if(row==6)return "Use Power off";
    if(value==WP_UNKNOWN)return "OS did not report";
    if(value==WP_NO)return "OS unavailable";
    if(row==5){
        if(wp_sleep.file_present==WP_NO||wp_sleep.reduced_file)return "Full file needed";
        return wp_session_route(1)!=WP_NONE?"Use Hibernate":"Policy / route";
    }
    if(wp_session_route(0)==WP_NONE)return "Policy / route";
    return wp_minimum_api(wp_session_route(0))?"Minimum only":"Windows chooses";
}
static const char *wp_selection_detail(int row)
{
    if(row==7)return wp_hy_detail[wp_hybrid];
    if(row==0)return "S0 is the current running session.";
    if(row==1)return wp_sleep.low_idle==WP_YES?"Windows controls entry to Low Power Idle.":
        "Low Power Idle needs a compatible Windows 8 or later installation and platform.";
    if(row==6)return "S5 ends the session. Use Power off in the main window.";
    if(row>=2 && row<=5){
        if(wp_sleep.state[row-1]==WP_UNKNOWN)return "Windows did not report this state on this installation.";
        if(wp_sleep.state[row-1]==WP_NO)return "Windows reports this state unavailable. Firmware or an installed device driver may limit it.";
        if(row==5 && (wp_sleep.file_present==WP_NO||wp_sleep.reduced_file))return "Windows needs a full hibernation file to restore the session.";
        if(row==5)return "Use Hibernate to save the session to disk. Windows must permit hibernation.";
        if(!wp_minimum_api(wp_session_route(0)))return "This Windows version selects the standby level. Its suspend API takes no S-number.";
        if(wp_session_route(0)==WP_NONE)return "A usable suspend route and permission from Windows are required.";
        return "This row selects the minimum suspend level. Press Suspend to request it. Windows can enter a deeper level.";
    }
    return "Select a table row for details. Suspend and hibernate have separate owners.";
}
static const char *const wp_levels[]={"S0","S0","S1","S2","S3","S4","S5","S1-3+4"};
static const char *const wp_names[]={"Working","Low Power Idle","Standby","Standby","Suspend to RAM","Hibernate to disk","Soft off","Hybrid sleep"};
static unsigned wp_row_state(int row)
{
    if(row==0)return WP_YES;
    if(row==1)return wp_sleep.low_idle;
    if(row==7)return wp_hybrid==WP_HY_OK?WP_YES:WP_NO;
    return wp_sleep.state[row-1];
}
static void wp_draw_states(LPDRAWITEMSTRUCT d)
{
    HDC dc=d->hDC;int w=d->rcItem.right,h=d->rcItem.bottom;
    int c1=w*12/100,c2=w*43/100,c3=w*66/100,i,top,bottom,cx,mark;
    HFONT font=(HFONT)SendMessageA(d->hwndItem,WM_GETFONT,0,0);
    COLORREF ink=GetSysColor(COLOR_WINDOWTEXT),paper=GetSysColor(COLOR_WINDOW),rule=GetSysColor(COLOR_BTNSHADOW);
    if(!font)font=bodyfont;
    pn_area(dc,0,0,w,h,rule);pn_area(dc,1,1,w-1,h-1,paper);
    pn_area(dc,0,0,w,h/9,ui_band(WP_TEAL));
    {COLORREF col=ui_band_ink(dc,WP_TEAL);
    ui_text(dc,font,col,5,0,c1,h/9,"State",UI_LEFT);ui_text(dc,font,col,c1,0,c2,h/9,"Power state",UI_LEFT);
    ui_text(dc,font,col,c2,0,c3,h/9,"Status",UI_LEFT);ui_text(dc,font,col,c3,0,w-2,h/9,"Selection / reason",UI_LEFT);}
    for(i=0;i<8;++i){
        unsigned v=wp_row_state(i);COLORREF color=ink;
        const char *status=i==0?"In use":wp_state_word(v);
        top=(i+1)*h/9;bottom=(i+2)*h/9;
        if(i==wp_focus_row){pn_area(dc,1,top,w-1,bottom,GetSysColor(COLOR_HIGHLIGHT));color=GetSysColor(COLOR_HIGHLIGHTTEXT);}
        else if(i==1||i==5||i==7)pn_area(dc,1,top,w-1,top+1,rule);
        ui_text(dc,font,color,5,top,c1-1,bottom,wp_levels[i],UI_LEFT);
        ui_text(dc,font,color,c1,top,c2-2,bottom,wp_names[i],UI_LEFT);
        cx=c2;mark=(top+bottom)/2;
        if(v==WP_YES){COLORREF live=(ui_high_contrast||i==wp_focus_row)?color:WP_GREEN;
            pn_area(dc,cx,mark,cx+3,mark+3,live);pn_area(dc,cx+2,mark+2,cx+5,mark+4,live);
            pn_area(dc,cx+4,mark,cx+7,mark+2,live);pn_area(dc,cx+6,mark-2,cx+8,mark+1,live);}
        else pn_area(dc,cx,mark,cx+7,mark+1,i==wp_focus_row?color:rule);
        ui_text(dc,font,color,c2+11,top,c3-1,bottom,status,UI_LEFT);
        ui_text(dc,font,color,c3,top,w-2,bottom,wp_selection_reason(i),UI_LEFT);
    }
}
static BOOL wp_draw_sleep(LPDRAWITEMSTRUCT d)
{
    HDC dc=d->hDC;int w=d->rcItem.right,h=d->rcItem.bottom;char text[320];
    HFONT font=(HFONT)SendMessageA(d->hwndItem,WM_GETFONT,0,0);
    COLORREF ink=GetSysColor(COLOR_BTNTEXT);
    if(!font)font=bodyfont;
    switch(d->CtlID){
    case 157:ui_header(dc,d->rcItem,12,"Sleep states",NULL);return TRUE;
    case 151:wp_draw_states(d);return TRUE;
    case 153:
        FillRect(dc,&d->rcItem,bodybrush);pn_area(dc,0,2,3,h-2,ui_band(WP_PLUM));
        GetWindowTextA(d->hwndItem,text,sizeof(text));
        ui_text(dc,font,ink,9,2,w-2,h,text,DT_LEFT|DT_WORDBREAK);return TRUE;
    case 156:
        FillRect(dc,&d->rcItem,bodybrush);pn_mark(dc,PN_SCREEN,0,(h-24)/2,24);
        ui_text(dc,sectionfont,ui_high_contrast?ink:WP_NAVY,31,0,w,h/2,"Display driver",UI_LEFT);
        GetWindowTextA(d->hwndItem,text,sizeof(text));
        ui_text(dc,font,ink,31,h/2,w,h,text,UI_LEFT);return TRUE;
    case 158:pn_area(dc,0,0,w,h,GetSysColor(COLOR_BTNSHADOW));return TRUE;
    case 154:case 155:case 159:pn_button(d,inst,d->CtlID==155?13:12,font,bodybrush);return TRUE;
    }
    return FALSE;
}
static void wp_sleep_display(HWND dialog, BOOL init)
{
    HWND combo=GetDlgItem(dialog,152);
    const char *text;
    char states[960],item[48],video[240];
    unsigned i;LRESULT index;
#ifdef WP_MINIMUM_LIST
    static unsigned listed;
    unsigned offered, old_level=0;
    LRESULT selected=0;
#endif
    wp_sleep_refresh();
    states[0]=0;
    for(i=0;i<8;++i){
        char row[120];
        wsprintfA(row,"%s   %s  /  %s  /  %s",wp_levels[i],wp_names[i],i?wp_state_word(wp_row_state(i)):"In use",wp_selection_reason(i));
        if(i)lstrcatA(states,"\r\n");lstrcatA(states,row);
    }
    SetDlgItemTextA(dialog,151,states);
#ifdef WP_NT34CFG
    if(os.dwPlatformId==VER_PLATFORM_WIN32_NT && os.dwMajorVersion<=4)wp_nt_video(video,sizeof(video));
    else
#endif
    wp_sleep_video(video,sizeof(video));
    SetDlgItemTextA(dialog,156,video);
#ifdef WP_MINIMUM_LIST
    offered=wp_minimum_mask(wp_session_route(0)==WP_DRIVER?&wp_drv_caps:&wp_sleep,wp_minimum_api(wp_session_route(0)));
    if(!init && offered!=listed){
        index=SendMessageA(combo,CB_GETCURSEL,0,0);
        if(index!=CB_ERR)old_level=(unsigned)SendMessageA(combo,CB_GETITEMDATA,index,0);
        init=TRUE;
    }
#endif
    if(init){
        SendMessageA(combo,CB_RESETCONTENT,0,0);
        index=SendMessageA(combo,CB_ADDSTRING,0,(LPARAM)"Windows policy");
        SendMessageA(combo,CB_SETITEMDATA,index,0);
#ifdef WP_MINIMUM_LIST
        listed=offered;
        for(i=1;i<=3;i++)if(wp_minimum_valid(offered,i)){
#else
        if(wp_set_min)for(i=1;i<=3;i++)if(wp_sleep.state[i]==WP_YES){
#endif
            wsprintfA(item,"S%u or deeper",i);
            index=SendMessageA(combo,CB_ADDSTRING,0,(LPARAM)item);
            SendMessageA(combo,CB_SETITEMDATA,index,i);
#ifdef WP_MINIMUM_LIST
            if(i==old_level && index>=0)selected=index;
#endif
        }
#ifdef WP_MINIMUM_LIST
        SendMessageA(combo,CB_SETCURSEL,selected,0);
#else
        SendMessageA(combo,CB_SETCURSEL,0,0);
#endif
    }
    {
        int j;
        for(j=0;j<=1;++j){
            int route=wp_session_route(j);int base=j?162:160;
            EnableWindow(GetDlgItem(dialog,base),!wp_sleep_busy && (j?wp_sleep.hibernate:wp_sleep.suspend));
            EnableWindow(GetDlgItem(dialog,base+1),!wp_sleep_busy && (j?wp_drv_caps.hibernate:wp_drv_caps.suspend));
            SendDlgItemMessageA(dialog,base,BM_SETCHECK,route==WP_OS?BST_CHECKED:BST_UNCHECKED,0);
            SendDlgItemMessageA(dialog,base+1,BM_SETCHECK,route==WP_DRIVER?BST_CHECKED:BST_UNCHECKED,0);
        }
    }
    EnableWindow(combo,wp_session_route(0)!=WP_NONE && SendMessageA(combo,CB_GETCOUNT,0,0)>1 && !wp_sleep_busy);
    EnableWindow(GetDlgItem(dialog,154),wp_session_route(0)!=WP_NONE && !wp_sleep_busy);
    EnableWindow(GetDlgItem(dialog,155),wp_session_route(1)!=WP_NONE && !wp_sleep_busy);
    EnableWindow(GetDlgItem(dialog,159),wp_hybrid==WP_HY_OK && wp_session_route(0)!=WP_NONE && !wp_sleep_busy);
    text=wp_selection_detail(wp_focus_row);
    SetDlgItemTextA(dialog,153,text);
}
static void wp_choose_row(HWND table,int row)
{
    HWND parent=GetParent(table),combo=GetDlgItem(parent,152);
    int i,count;
    if(row<0||row>7)return;
    wp_focus_row=row;
    if(row>=2 && row<=4 && IsWindowEnabled(combo)){
        count=(int)SendMessageA(combo,CB_GETCOUNT,0,0);
        for(i=1;i<count;++i)if((int)SendMessageA(combo,CB_GETITEMDATA,i,0)==row-1){
            SendMessageA(combo,CB_SETCURSEL,i,0);break;
        }
    }
    SetDlgItemTextA(parent,153,wp_selection_detail(row));InvalidateRect(table,NULL,FALSE);
}
static BOOL wp_row_input(HWND table,UINT m,WPARAM w,LPARAM l,LRESULT *reply)
{
    RECT r;int row=wp_focus_row;
    *reply=0;
    if(m==WM_GETDLGCODE){*reply=DLGC_WANTARROWS;return TRUE;}
    if(m==WM_LBUTTONDOWN){
        SetFocus(table);GetClientRect(table,&r);
        if(r.bottom>0){int y=(short)HIWORD(l);int k;for(k=0;k<8;++k)if(y>=(k+1)*r.bottom/9 && y<(k+2)*r.bottom/9){wp_choose_row(table,k);break;}}
        return TRUE;
    }
    if(m==WM_SETFOCUS && row<0){wp_choose_row(table,0);return FALSE;}
    if(m!=WM_KEYDOWN)return FALSE;
    if(w==VK_DOWN)row=row<7?row+1:7;
    else if(w==VK_UP)row=row>0?row-1:0;
    else if(w==VK_HOME)row=0;
    else if(w==VK_END)row=7;
    else return FALSE;
    wp_choose_row(table,row);return TRUE;
}
static void wp_sleep_request(HWND dialog,int action)
{
    DWORD bytes=0,err=0;HANDLE token=NULL;
    TOKEN_PRIVILEGES want,original;BOOL adjusted=FALSE,ok=FALSE;
    HWND combo=GetDlgItem(dialog,152);
    LRESULT index=SendMessageA(combo,CB_GETCURSEL,0,0);
    ULONG minimum=index==CB_ERR?0:(ULONG)SendMessageA(combo,CB_GETITEMDATA,index,0);
    LONG native_status=0;
    BOOL hibernate=action==WP_DO_HIBER,hybrid=action==3;int route;
    if(wp_sleep_busy)return;
    wp_sleep_refresh();
    route=wp_session_route(hibernate);
    if(route==WP_NONE || (hybrid && wp_hybrid!=WP_HY_OK)){wp_sleep_display(dialog,FALSE);return;}
    /* Hybrid uses the active plan. Keep the user-selected standby minimum. */
    if(!hibernate && !wp_level_open(route,minimum)){
        wp_sleep_display(dialog,TRUE);return;
    }
    if(MessageBoxA(dialog,hybrid?"Save the session to disk and enter hybrid sleep?":hibernate?"Hibernate this session to disk?":"Suspend this session?",
                   "WINPOWER",MB_YESNO|MB_ICONQUESTION|MB_DEFBUTTON2)!=IDYES)return;
    /* A dock or power-policy change can occur while confirmation is open. */
    wp_sleep_refresh();
    if(route!=wp_session_route(hibernate) || (hybrid && wp_hybrid!=WP_HY_OK) ||
       (!hibernate && !wp_level_open(route,minimum))){
        wp_sleep_display(dialog,FALSE);
        MessageBoxA(dialog,"The selected operation is no longer available.","WINPOWER",MB_OK|MB_ICONINFORMATION);
        return;
    }
    if(os.dwPlatformId==VER_PLATFORM_WIN32_NT){
        if(!OpenProcessToken(GetCurrentProcess(),TOKEN_ADJUST_PRIVILEGES|TOKEN_QUERY,&token)){
            error(dialog,"Cannot open the process token.");return;
        }
        want.PrivilegeCount=1;want.Privileges[0].Attributes=SE_PRIVILEGE_ENABLED;
        if(!LookupPrivilegeValueA(NULL,"SeShutdownPrivilege",&want.Privileges[0].Luid)){err=GetLastError();goto done;}
        bytes=sizeof(original);SetLastError(ERROR_SUCCESS);
        if(!AdjustTokenPrivileges(token,FALSE,&want,sizeof(original),&original,&bytes)){err=GetLastError();goto done;}
        err=GetLastError();if(err)goto done;
        adjusted=TRUE;
    }
    wp_sleep_busy=TRUE;
    EnableWindow(GetDlgItem(dialog,154),FALSE);EnableWindow(GetDlgItem(dialog,155),FALSE);
    if(route==WP_DRIVER){
        err=wp_sleep_device(FALSE,hibernate,minimum);ok=err==ERROR_SUCCESS;
    }else if(hybrid && !minimum && wp_set_sleep){
        ok=wp_set_sleep(FALSE,FALSE,FALSE);
    }else if(!hibernate && minimum){
        /* PowerActionSleep=2. PowerSystemSleeping1..3=2..4. These are minima.
           QUERY_ALLOWED and UI_ALLOWED preserve application and driver consent. */
        native_status=wp_set_min(PowerActionSleep,PowerSystemSleeping1+minimum-1,
                                 POWER_ACTION_QUERY_ALLOWED|POWER_ACTION_UI_ALLOWED,FALSE);
        ok=native_status>=0;
    }
#ifdef WP_WIN9X_STATUS
    else if(os.dwPlatformId==VER_PLATFORM_WIN32_WINDOWS && wp_set_old)
        ok=wp_set_old(!hibernate,FALSE);
#endif
    else if(wp_set_sleep)ok=wp_set_sleep((BOOLEAN)hibernate,FALSE,FALSE);
    else if(wp_set_old)ok=wp_set_old(!hibernate,FALSE);
    if(!ok && !err && native_status>=0){err=GetLastError();if(!err)err=ERROR_NOT_SUPPORTED;}
done:
    if(adjusted)AdjustTokenPrivileges(token,FALSE,&original,0,NULL,NULL);
    if(token)CloseHandle(token);
    wp_sleep_busy=FALSE;
    wp_sleep_display(dialog,FALSE);
    if(native_status<0){
        char msg[100];wsprintfA(msg,"Windows declined this minimum sleep level (NTSTATUS 0x%08lX).",native_status);
        MessageBoxA(dialog,msg,"WINPOWER",MB_OK|MB_ICONEXCLAMATION);
    }else if(err){SetLastError(err);error(dialog,"Windows could not complete the sleep request.");}
    else if(ok)SetDlgItemTextA(dialog,153,"Windows accepted the requested power transition.");
}
/* Preserve the native font and the drop-down list when the desktop is
   only 400 pixels high. Positions and heights use the dialog's font units. */
static int wp_short_dialog(HWND dialog,int height)
{
    static const struct {unsigned id,top,height;} rows[]={
        {157,0,20},{151,22,85},{164,110,10},{152,108,65},
        {165,123,10},{160,121,12},{161,121,12},
        {166,136,10},{162,134,12},{163,134,12},
        {153,149,18},{156,168,23},{158,192,1},
        {154,196,18},{155,196,18},{159,196,18},{IDOK,196,18}
    };
    RECT client,units;unsigned i;
    GetClientRect(dialog,&client);
    for(i=0;i<sizeof(rows)/sizeof(rows[0]);++i){
        HWND item=GetDlgItem(dialog,rows[i].id);RECT old;POINT origin;
        if(!item||!GetWindowRect(item,&old))continue;
        origin.x=old.left;origin.y=old.top;ScreenToClient(dialog,&origin);
        units.left=units.right=0;units.top=rows[i].top;
        units.bottom=rows[i].top+rows[i].height;MapDialogRect(dialog,&units);
        SetWindowPos(item,NULL,origin.x,units.top,old.right-old.left,units.bottom-units.top,
                     SWP_NOZORDER|SWP_NOACTIVATE);
    }
    units.left=units.top=units.right=0;units.bottom=219;MapDialogRect(dialog,&units);
    return height-client.bottom+units.bottom;
}
static INT_PTR CALLBACK wp_sleep_dialog(HWND h,UINT m,WPARAM w,LPARAM l)
{
    switch(m){
    case WM_INITDIALOG:{
        RECT owner,work,window;int x,y,width,height;HWND parent=GetParent(h);
        GetWindowRect(h,&window);width=window.right-window.left;height=window.bottom-window.top;
        work.left=work.top=0;work.right=GetSystemMetrics(SM_CXSCREEN);work.bottom=GetSystemMetrics(SM_CYSCREEN);
        if(os.dwMajorVersion>=4){
            RECT area;if(SystemParametersInfoA(SPI_GETWORKAREA,0,&area,0))work=area;
        }
        if(height>work.bottom-work.top)height=wp_short_dialog(h,height);
        if(!parent||!GetWindowRect(parent,&owner))owner=work;
        x=(owner.left+owner.right-width)/2;y=(owner.top+owner.bottom-height)/2;
        if(x+width>work.right)x=work.right-width;
        if(y+height>work.bottom)y=work.bottom-height;
        if(x<work.left)x=work.left;
        if(y<work.top)y=work.top;
        SetWindowPos(h,NULL,x,y,width,height,SWP_NOZORDER|SWP_NOACTIVATE);
        ui_attach(GetDlgItem(h,157));ui_attach(GetDlgItem(h,151));ui_attach(GetDlgItem(h,153));
        ui_attach(GetDlgItem(h,156));ui_attach(GetDlgItem(h,158));
        wp_focus_row=-1;wp_sleep_preferences();wp_sleep_open();wp_sleep_display(h,TRUE);return TRUE;
    }
    case WM_CTLCOLORDLG:case WM_CTLCOLORSTATIC:case WM_CTLCOLORBTN:
        SetBkColor((HDC)w,GetSysColor(COLOR_BTNFACE));SetTextColor((HDC)w,GetSysColor(COLOR_BTNTEXT));
        return (INT_PTR)bodybrush;
    case WM_DRAWITEM:{
        LPDRAWITEMSTRUCT d=(LPDRAWITEMSTRUCT)l;
        if(wp_draw_sleep(d))return TRUE;
        break;
    }
    case WM_POWERBROADCAST:
        if(!wp_sleep_busy)wp_sleep_display(h,FALSE);
        return TRUE;
    case WM_COMMAND:
        if(LOWORD(w)==152 && HIWORD(w)==CBN_SELCHANGE){
            HWND combo=GetDlgItem(h,152);LRESULT ix=SendMessageA(combo,CB_GETCURSEL,0,0);
            int level=ix<0?0:(int)SendMessageA(combo,CB_GETITEMDATA,ix,0);
            wp_focus_row=level>=1&&level<=3?level+1:-1;
            SetDlgItemTextA(h,153,wp_selection_detail(wp_focus_row));InvalidateRect(GetDlgItem(h,151),NULL,FALSE);return TRUE;
        }
        if(LOWORD(w)>=160 && LOWORD(w)<=163 && HIWORD(w)==BN_CLICKED){
            int id=LOWORD(w),which=id>=162,driver=(id&1);DWORD err;
            wp_sleep_refresh();
            if(!(driver?(which?wp_drv_caps.hibernate:wp_drv_caps.suspend):(which?wp_sleep.hibernate:wp_sleep.suspend))){
                wp_sleep_display(h,FALSE);return TRUE;
            }
            err=wp_write_preference(which,driver);
            if(err){SetLastError(err);error(h,"Could not save the session power preference.");}
            wp_sleep_preferences();wp_sleep_display(h,FALSE);return TRUE;
        }
        if(LOWORD(w)==154||LOWORD(w)==155||LOWORD(w)==159){
            wp_sleep_request(h,LOWORD(w)==159?3:(LOWORD(w)==155?WP_DO_HIBER:WP_DO_SUSPEND));return TRUE;
        }
        if(LOWORD(w)!=IDOK && LOWORD(w)!=IDCANCEL)break;
        /* fall through */
    case WM_CLOSE:
        if(!wp_sleep_busy)EndDialog(h,0);
        return TRUE;
    case WM_DESTROY:
        if(wp_prof)FreeLibrary(wp_prof);
        wp_prof=NULL;wp_caps_query=NULL;wp_can_suspend=NULL;wp_can_hibernate=NULL;wp_set_sleep=NULL;wp_set_old=NULL;wp_set_min=NULL;
        return TRUE;
    }
    return FALSE;
}
