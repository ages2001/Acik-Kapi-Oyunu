#ifndef WP_SLPCAPS_H
#define WP_SLPCAPS_H

/* The byte offsets are the stable part of SYSTEM_POWER_CAPABILITIES.
   Windows 8 and Windows 10 gave previously reserved bytes a meaning. */
#define WP_NO 0
#define WP_YES 1
#define WP_UNKNOWN 2
struct wp_sleep_caps {
    unsigned char state[6];
    unsigned char low_idle, file_present, reduced_file, hybrid_capable;
    unsigned char suspend, hibernate;
};
static void wp_sleep_decode(struct wp_sleep_caps *c, const unsigned char *raw,
    unsigned major, unsigned minor, int suspend_api, int suspend_policy,
    int hibernate_api, int hibernate_policy, int recovery)
{
    unsigned s;
    for(s=1;s<=5;s++)c->state[s]=raw?(raw[2+s]?WP_YES:WP_NO):WP_UNKNOWN;
    c->state[0]=WP_YES;
    c->low_idle=raw && (major>6 || (major==6 && minor>=2)) ?
        (raw[20]?WP_YES:WP_NO):WP_UNKNOWN;
    /* FastSystemS4 is the distinct Windows hybrid-sleep capability. */
    c->hybrid_capable=raw && major>=6 ? (raw[17]?WP_YES:WP_NO):WP_UNKNOWN;
    c->file_present=raw?(raw[8]?WP_YES:WP_NO):WP_UNKNOWN;
    c->reduced_file=raw && major>=10 && raw[22]==1;
    c->suspend=!recovery && suspend_api && suspend_policy!=WP_NO &&
        (raw?(c->state[1]||c->state[2]||c->state[3]||c->low_idle==WP_YES):
             suspend_policy==WP_YES);
    c->hibernate=!recovery && hibernate_api && hibernate_policy!=WP_NO &&
        (raw?(c->state[4] && c->file_present==WP_YES && !c->reduced_file):
             hibernate_policy==WP_YES);
}
#endif
