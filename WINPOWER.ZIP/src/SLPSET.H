#ifndef WP_SLPSET_H
#define WP_SLPSET_H
#include "SHA256.H"
#define WP_SERVICE "WPSLPDRV"
#define WP_TITLE "WINPOWER session sleep driver"
#define WP_IMAGE "System32\\drivers\\WPSLPDRV.SYS"

static DWORD wp_slp_filehash(const char *path,char *hex)
{
    static const char digits[]="0123456789abcdef";
    struct wp_sha256 state;
    BYTE page[1024],hash[32];
    DWORD count,error=0,i;
    HANDLE f=CreateFileA(path,GENERIC_READ,FILE_SHARE_READ,NULL,OPEN_EXISTING,0,NULL);
    if(f==INVALID_HANDLE_VALUE)return GetLastError();
    wp_sha_init(&state);
    for(;;){
        if(!ReadFile(f,page,sizeof(page),&count,NULL)){error=GetLastError();break;}
        if(!count)break;
        wp_sha_add(&state,page,count);
    }
    CloseHandle(f);if(error)return error;
    wp_sha_end(&state,hash);
    for(i=0;i<32;i++){hex[2*i]=digits[hash[i]>>4];hex[2*i+1]=digits[hash[i]&15];}
    hex[64]=0;return 0;
}
static DWORD wp_slp_path(char *path)
{
    UINT n=GetSystemDirectoryA(path,MAX_PATH);
    if(!n||n>=MAX_PATH-sizeof("\\drivers\\WPSLPDRV.SYS"))return ERROR_BAD_PATHNAME;
    lstrcatA(path,"\\drivers\\WPSLPDRV.SYS");return 0;
}
static DWORD wp_slp_install(const char *setup,const char *ini)
{
    SC_HANDLE manager,service=NULL;
    char from[MAX_PATH],path[MAX_PATH],digest[65],*tail;
    DWORD error=wp_slp_path(path);BOOL copied=FALSE,created=FALSE;
    if(error)return error;
    if(lstrlenA(setup)>=MAX_PATH-14)return ERROR_BAD_PATHNAME;
    lstrcpyA(from,setup);tail=from+lstrlenA(from);
    while(tail>from && tail[-1]!='\\')--tail;
    if(tail==from)return ERROR_BAD_PATHNAME;
    lstrcpyA(tail,"WPSLPDRV.SYS");
    manager=OpenSCManagerA(NULL,NULL,SC_MANAGER_CREATE_SERVICE);
    if(!manager)return GetLastError();
    if(!CopyFileA(from,path,TRUE)){error=GetLastError();goto finish;}
    copied=TRUE;
    if(!SetFileAttributesA(path,FILE_ATTRIBUTE_NORMAL)){error=GetLastError();goto finish;}
    error=wp_slp_filehash(path,digest);if(error)goto finish;
    service=CreateServiceA(manager,WP_SERVICE,WP_TITLE,SERVICE_START|DELETE,SERVICE_KERNEL_DRIVER,
                           SERVICE_AUTO_START,SERVICE_ERROR_NORMAL,WP_IMAGE,NULL,NULL,NULL,NULL,NULL);
    if(!service){error=GetLastError();goto finish;}
    created=TRUE;
    if(!WritePrivateProfileStringA("Sleep","DriverHash",digest,ini)){error=GetLastError();if(!error)error=ERROR_WRITE_FAULT;goto finish;}
    copied=created=FALSE; /* Removal can now verify the registered service and file. */
    if(!StartServiceA(service,0,NULL)){error=GetLastError();if(error==ERROR_SERVICE_ALREADY_RUNNING)error=0;}
finish:
    if(created)DeleteService(service);
    if(service)CloseServiceHandle(service);
    if(copied)DeleteFileA(path);
    CloseServiceHandle(manager);return error;
}
static DWORD wp_slp_remove(const char *ini)
{
    SC_HANDLE manager,service=NULL;
    char path[MAX_PATH],expected[68],actual[65];
    union { QUERY_SERVICE_CONFIGA config; BYTE bytes[1536]; } info;
    DWORD needed,error,i;SERVICE_STATUS status;
    if(GetPrivateProfileStringA("Sleep","DriverHash","",expected,sizeof(expected),ini)==0)return 0;
    if(lstrlenA(expected)!=64)return ERROR_INVALID_DATA;
    error=wp_slp_path(path);if(error)return error;
    error=wp_slp_filehash(path,actual);
    if(error!=ERROR_FILE_NOT_FOUND && (error||lstrcmpA(expected,actual)))return error?error:ERROR_INVALID_DATA;
    manager=OpenSCManagerA(NULL,NULL,SC_MANAGER_CONNECT);
    if(!manager)return GetLastError();
    service=OpenServiceA(manager,WP_SERVICE,SERVICE_QUERY_CONFIG|SERVICE_QUERY_STATUS|SERVICE_STOP|DELETE);
    if(!service){error=GetLastError();if(error==ERROR_SERVICE_DOES_NOT_EXIST)error=0;}
    else if(!QueryServiceConfigA(service,&info.config,sizeof(info),&needed))error=GetLastError();
    else if(info.config.dwServiceType!=SERVICE_KERNEL_DRIVER || lstrcmpiA(info.config.lpBinaryPathName,WP_IMAGE) ||
            lstrcmpA(info.config.lpDisplayName,WP_TITLE))error=ERROR_INVALID_DATA;
    else{
        error=0;
        if(!ControlService(service,SERVICE_CONTROL_STOP,&status)){
            error=GetLastError();if(error==ERROR_SERVICE_NOT_ACTIVE)error=0;
        }else{
            for(i=0;i<40 && status.dwCurrentState==SERVICE_STOP_PENDING;++i){
                Sleep(100);if(!QueryServiceStatus(service,&status)){error=GetLastError();break;}
            }
            if(!error && status.dwCurrentState!=SERVICE_STOPPED)error=ERROR_SERVICE_REQUEST_TIMEOUT;
        }
        if(!error && !DeleteService(service))error=GetLastError();
    }
    if(service)CloseServiceHandle(service);
    CloseServiceHandle(manager);if(error)return error;
    if(!DeleteFileA(path)){error=GetLastError();if(error!=ERROR_FILE_NOT_FOUND)return error;}
    if(!WritePrivateProfileStringA("Sleep","DriverHash",NULL,ini))return ERROR_WRITE_FAULT;
    return 0;
}
static void wp_slp_finish(const char *setup,const char *ini)
{
    char text[240];DWORD error=wp_slp_install(setup,ini);
    if(error){wsprintfA(text,"Windows power management is available where supported. The optional WINPOWER sleep driver could not start or install (Windows error %lu).",error);
        MessageBoxA(NULL,text,"WINPOWER Setup",MB_OK|MB_ICONINFORMATION);}
}
#endif
