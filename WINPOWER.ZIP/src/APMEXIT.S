/* DOS resident for the Win9x real-mode exit broadcast. The protected-mode
   driver arms this one-shot request only after final storage cleanup. */
.code16
.global _start
_start:
    jmp install
    .balign 16,0x90
signature:
    .ascii "WINPOWER.APM9.1!"
request: .word 0,0
firmwarever: .word 0
old: .word 0,0
handler:
    pushf
    cmpw $0xd7eb,%ax
    jne event
    cmpw $0x5057,%bx
    jne chain
    cmpw $0x3941,%cx
    jne chain
    movw $0x5750,%ax
    movw $0x4139,%bx
    popf
    iret
event:
    cmpw $0x1605,%ax
    jne leaving
    movw $0,%cs:request
    movw $0,%cs:request+2
    jmp chain
leaving:
    cmpw $0x1606,%ax
    jne chain
    cmpw $0x5a31,%cs:request
    jne chain
    cmpw $0xa5ce,%cs:request+2
    jne chain
    pushw %ax
    smsw %ax
    testw $1,%ax
    popw %ax
    jnz chain
    movw $0,%cs:request
    movw $0,%cs:request+2
    /* Let every previously registered DOS driver finish its exit first. */
    popf
    pushf
    lcall *%cs:old
    pushf
    pushal
    pushw %ds
    pushw %es
    pushw %fs
    pushw %gs
    movb $'P',%al
    outb %al,$0xe9
    call wp_apm_seq
    movb $'f',%al
    outb %al,$0xe9
    popw %gs
    popw %fs
    popw %es
    popw %ds
    popal
    popf
    iret
chain:
    popf
    ljmp *%cs:old
.include "APMSEQ.S"
end_resident:
install:
    movw $0xd7eb,%ax
    movw $0x5057,%bx
    movw $0x3941,%cx
    int $0x2f
    cmpw $0x5750,%ax
    jne probe
    cmpw $0x4139,%bx
    je exit
probe:
    smsw %ax
    testw $1,%ax
    jnz exit
    movw $0x5300,%ax
    xorw %bx,%bx
    int $0x15
    jc exit
    cmpw $0x504d,%bx
    jne exit
    cmpw $0x0100,%ax
    jb exit
    cmpw $0x0102,%ax
    ja exit
    movw %ax,%cs:firmwarever
    /* The TSR has no use for the environment block it inherited from DOS. */
    movw %cs:0x2c,%ax
    testw %ax,%ax
    jz vector
    movw %ax,%es
    movb $0x49,%ah
    int $0x21
    movw $0,%cs:0x2c
vector:
    movw $0x352f,%ax
    int $0x21
    movw %bx,%cs:old
    movw %es,%cs:old+2
    pushw %cs
    popw %ds
    movw $handler,%dx
    movw $0x252f,%ax
    int $0x21
    movw $end_resident,%dx
    addw $15,%dx
    movb $4,%cl
    shrw %cl,%dx
    movw $0x3100,%ax
    int $0x21
exit:
    movw $0x4c00,%ax
    int $0x21
