/* APM owns the sleeping CPU on real-mode Windows. A protected/V86 system
   keeps its firmware connection with its own virtual power manager. */
#include "APMSLEEP.H"
static BOOL rm_sleep;
static unsigned apm_choices,native_item,preferred16=2;
static HWND native_shell;
unsigned __cdecl pn_cpu(void);
unsigned __cdecl wp_apmreal(void);
static int bios16(unsigned fn,unsigned bx,unsigned cx,struct wp_apm_result *result)
{
    union REGS in,out;
    in.w.ax=fn;in.w.bx=bx;in.w.cx=cx;int86(0x15,&in,&out);
    result->ax=out.w.ax;result->bx=out.w.bx;result->cx=out.w.cx;return !out.w.cflag;
}
#if !defined(PN_WIN1) && !defined(PN_WIN2)
static unsigned sleep_menu(HMENU menu,unsigned depth)
{
    int i,n=menu?GetMenuItemCount(menu):0;
    if(depth>=5||n>100)return 0;
    for(i=0;i<n;++i){
        HMENU sub;unsigned command,state;char buf[64],norm[64];int a,b=0;
        state=GetMenuState(menu,i,MF_BYPOSITION);
        if(state==(unsigned)-1 || (state&(MF_DISABLED|MF_GRAYED)))continue;
        sub=GetSubMenu(menu,i);
        if(sub){command=sleep_menu(sub,depth+1);if(command)return command;continue;}
        if(!GetMenuString(menu,i,buf,sizeof(buf),MF_BYPOSITION))continue;
        for(a=0;buf[a] && buf[a]!='\t' && b<62;a++){
            char c=buf[a];if(c=='&'||c==' '||c=='.')continue;
            if(c>='A'&&c<='Z')c+='a'-'A';norm[b++]=c;
        }
        norm[b]=0;
        if(!lstrcmp(norm,"suspend")||!lstrcmp(norm,"standby")){
            command=GetMenuItemID(menu,i);if(command && command!=(unsigned)-1)return command;
        }
    }
    return 0;
}
#endif
static void sleep16_scan(void)
{
    unsigned i;apm_choices=0;native_item=0;native_shell=0;
    rm_sleep=pn_cpu()&&wp_apmreal();
    if(rm_sleep)for(i=1;i<=2;i++)
        if(wp_apm_request(i,bios16,1)==WP_RETURNED)apm_choices|=1u<<(i-1);
#if !defined(PN_WIN1) && !defined(PN_WIN2)
    native_shell=FindWindow("PROGMAN",NULL);
    if(native_shell)native_item=sleep_menu(GetMenu(native_shell),0);
#endif
}
static unsigned sleep16_route(void)
{
    if(preferred16==1)return apm_choices?1:2;
    if(preferred16==0)return native_item?0:2;
    return native_item?0:(apm_choices?1:2);
}
static void sleep16_controls(void)
{
    unsigned route=sleep16_route();
    SetWindowText(ownertext,"Sleep via");
    EnableWindow(osradio,native_item!=0);EnableWindow(drvradio,apm_choices!=0);
    SetWindowText(drvradio,"WINPOWER APM");
    SendMessage(osradio,BM_SETCHECK,route==0,0);SendMessage(drvradio,BM_SETCHECK,route==1,0);
    SetWindowText(buttons[0],"Standby");SetWindowText(buttons[1],"Suspend");
    EnableWindow(buttons[0],route==1 && (apm_choices&1));
    EnableWindow(buttons[1],route==0 || (route==1 && (apm_choices&2)));
    SetWindowText(buttons[2],"Hibernate");EnableWindow(buttons[2],FALSE);
    SetWindowText(buttons[3],"Back");SetWindowText(sleep_tab,"Power");
    InvalidateRect(panel,0,TRUE);
}
static void sleep16_page(HWND parent,BOOL open)
{
    sleep_page=open;
    if(open){
        preferred16=GetProfileInt("WINPOWER","SleepOwner",2);
        sleep16_scan();sleep16_controls();
    }else{
        SetWindowText(ownertext,"Control");SetWindowText(drvradio,"WINPOWER driver");
        SetWindowText(buttons[0],"Power off");SetWindowText(buttons[1],"Restart");
        SetWindowText(buttons[2],"Refresh");SetWindowText(buttons[3],"About");SetWindowText(sleep_tab,"Sleep");
        EnableWindow(buttons[0],supervised);EnableWindow(buttons[1],supervised);EnableWindow(buttons[2],TRUE);
        EnableWindow(osradio,supervised);EnableWindow(drvradio,supervised);
        radios();apmtext();InvalidateRect(panel,0,TRUE);
    }
    InvalidateRect(parent,0,TRUE);SetFocus(sleep_tab);
}
static void sleep16_click(HWND parent,unsigned id)
{
    unsigned route,state;
    if(id==104||id==107){sleep16_page(parent,FALSE);return;}
    if(id==105||id==106){
        sleep16_scan();if((id==105&&!native_item)||(id==106&&!apm_choices)){sleep16_controls();return;}
        if(WriteProfileString("WINPOWER","SleepOwner",id==105?"0":"1"))
            preferred16=GetProfileInt("WINPOWER","SleepOwner",2);
        sleep16_controls();return;
    }
    if(id!=101&&id!=102)return;
    sleep16_scan();route=sleep16_route();state=id==101?1:2;
    if(route==2||(route==0&&state==1)||(route==1&&!(apm_choices&(1u<<(state-1))))){sleep16_controls();return;}
    if(MessageBox(parent,state==1?"Request standby for this session?":"Suspend this Windows session?","WINPOWER",MB_YESNO|MB_DEFBUTTON2)!=IDYES)return;
    if(!route){if(native_shell&&native_item)PostMessage(native_shell,WM_COMMAND,native_item,0);}
    else {
        union REGS in,out;in.h.ah=0x0d;int86(0x21,&in,&out);
        if(wp_apm_sleep(state,bios16)!=WP_RETURNED)MessageBox(parent,"The APM firmware declined this request.","WINPOWER",MB_OK);
    }
    sleep16_scan();sleep16_controls();InvalidateRect(parent,0,TRUE);
}
static void sleep16_draw(HWND window,HDC dc,RECT box)
{
    static const char *const levels[]={"State","S0","S1 / S2","S3","S4","S5","Hybrid","APM"};
    const char *why[8];TEXTMETRIC tm;int i,x=box.right/4,y=1,row;
    unsigned route=sleep16_route();
    why[0]="Selection / reason";why[1]="Current running session";
    why[2]="Windows exposes no exact ACPI level";
    why[3]=native_item?"The Windows Suspend command chooses the level":"No native ACPI suspend command";
    why[4]="No Windows session-image service";why[5]="Use Power off in Power Center";
    why[6]="Needs standby and an OS hibernation image";
    why[7]=route==1?"Use the supported APM action below":(rm_sleep?"No available firmware sleep request":"Protected mode owns firmware access");
    GetTextMetrics(dc,&tm);row=(box.bottom-2)/8;if(row>tm.tmHeight+5)row=tm.tmHeight+5;
    if(row<1)return;
    FillRect(dc,&box,(HBRUSH)GetStockObject(WHITE_BRUSH));SetBkMode(dc,TRANSPARENT);
    for(i=0;i<8;++i,y+=row){
        COLORREF color=i?RGB(0,0,0):WP_PAPER;
        if(!i)pn_area(dc,0,y,box.right,y+row,WP_TEAL);
        else if(i==4||i==7)pn_area(dc,1,y,box.right-1,y+1,WP_SLATE);
        SetTextColor(dc,color);TextOut(dc,5,y+1,levels[i],lstrlen(levels[i]));
        TextOut(dc,x,y+1,why[i],lstrlen(why[i]));
    }
    (void)window;
}
