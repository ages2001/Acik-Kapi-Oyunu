WINPOWER v1.0
Power Center for DOS and Windows

Start with INSTALL.TXT. Keep all files for your operating system together.

  bin/DOS        DOS utilities             bin/NT3       NT 3.1, 3.50, 3.51
  bin/WIN1       Windows 1.x               bin/NT4       NT 4.0
  bin/WIN2       Windows 2.x               bin/2KXP      2000 and XP x86
  bin/WIN386     Windows/386 2.11          bin/XPAMD64   XP x64
  bin/WIN3       Windows 3.x               bin/NT6X86    Vista / 7 x86 and later
  bin/WIN9X      Windows 95, 98, Me        bin/NT6AMD64  Vista / 7 x64 and later

The main window reports the Windows release and architecture, ACPI and APM
revisions, power source, battery and remaining runtime. N/A means the
corresponding value is unavailable. The hourglass stays visible when a
machine has no battery or cannot estimate its remaining runtime.

Power off and Restart ask Windows to close the session. The Control row
shows who owns the final action. Use the supervised Windows loader on
Windows 1/2/3 to enable that choice. OS is the initial shutdown owner.
Windows 98 and Me complete the last reset themselves to finish FAT cleanup.
Vista and later complete shutdown and restart through Windows.

Open Sleep or press Alt+S to inspect each state and its availability.
Suspend and Hibernate have independent owners where supported. A disabled
choice has no usable route in the current configuration. On supported NT
systems a selected standby state is a minimum. Windows decides which real
state satisfies that minimum and the active device constraints. Selecting
a row displays its explanation. Hybrid sleep also needs an active Windows
power plan and a platform that can write an image on the way into standby.
On Windows 1/2/3 the firmware route uses APM standby and suspend. APM does
not provide ACPI S-state numbers.

UITEST.TXT lists the scope, working configurations and open limitations.
UIVIEW.PNG is captured from a real Windows 7 guest. TESTS.TXT contains the
Standard VGA results. FIRMWARE.TXT covers firmware revisions and the
shutdown qualification. BUILD.TXT describes reproduction and verification.
The sources, binaries and per-file SHA-256 are included in this archive.
