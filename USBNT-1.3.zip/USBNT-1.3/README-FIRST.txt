USBNT 1.3 - VERSIONED VALIDATION CANDIDATE

The source, build inputs, tools, bin installation layout and three OEM images
are current. All 12 distributed PE files use 1.3.0.0 and match the separately
rebuilt/tested frozen candidate. Read CHANGELOG.md and RELEASE-1.3-STATUS.md.

This is not a universal completed release. Unsupported controller sleep
topologies and untested OS/hardware combinations remain. Complete evidence,
RLTKLANT, custom QEMU and DELIVERY-STATUS.txt are in the enclosing combined
handoff archive. Historical relative validation links refer to that archive.

bin/usbinst.exe installs on an existing Windows system; review README.md for
target-specific instructions. bin/OEMDISK and bin/USBNT*.IMG are text-mode setup
payloads. Payload readback does not certify fresh OS setup on every platform.
Host compiler/dependency packages and Windows media remain external inputs.

MANIFEST.json lists every entry size and SHA-256. The packager checks each ZIP
entry after writing. English docs describe exact scope, not physical support.
