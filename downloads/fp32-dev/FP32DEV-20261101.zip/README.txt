FP32 LEGACY PORT - DEVELOPMENT CHECKPOINT - 2026-11-01

THIS IS NOT A COMPLETED FLASH PLAYER PORT OR INSTALLER.
The original Adobe Flash Player 32.0.0.465 remains the target engine.
It has not reached its player window or played a SWF on these legacy guests.
Do not replace a working FP10 installation with this checkpoint.

Verified components:
  File adapter: 12 checks on NT 3.1, Windows 95 RTM, Win3.1 + Win32s 1.30c.
  Core adapter: 7 checks on NT 3.1 and Windows 95, real concurrent threads.
  Command-line adapter: 33 NT 3.1 checks. Shell execution: 9 NT 3.1 checks.
  Single LFENCE trampoline: 512 emulator contract checks.
  SSE2 hardware gate: English error and exit on hardware without SSE2.
  Separate WINSIMD research: four CPUs, 342 affinity rounds and 640 worker
  lifetimes without XMM/MXCSR/x87 mismatches; not a production driver.

Current startup blocker:
  On the SSE2/XMM-enabled NT 3.1 guest, original SSE2 initialization executes.
  Keeping FP32.EXE alone in C:\FP32\APP passes its original DLL-neighbor check.
  Startup then reaches missing CryptAcquireContextA at 0x00becc40.
  Original RNG callers deliberately fault if acquisition/generation fails.
  A real cryptographic backend is required; no dummy randomness or bypass exists.
  Win32s lacks native threads; no substitute thread runtime is implemented.
  Full sound/video/input/menu/game tests and FP32 setup remain unfinished.
  No FP32 GPU acceleration, SSE-free operation or all-OS support is claimed.

Contents:
  NT31-DIAGNOSTIC: modified original FP32 and tracing compatibility proxies.
  COMPONENTS: adapters and independent test programs, not the player.
  SOURCE: current FP32 source, required shared FP10 and installer sources.
  EVIDENCE: logs/reports/screenshots, including failures and current blockers.
  CHECKPOINT: preserved FP10 source/build snapshot, not a completed FP10 runtime.

Diagnostic guest layout:
  Copy NT31-DIAGNOSTIC\APP to C:\FP32\APP (EXE only; no DLLs beside it).
  Copy the NT31-DIAGNOSTIC DLLs and COMPONENTS to C:\FP32.
  Set the working directory to C:\FP32, then run:
    DEBUG32.EXE C:\FP32\APP\FP32.EXE -relaunched
  DEBUG32 stops the child after 30 seconds. This is a diagnostic invocation,
  not the final launcher or a working SWF player. The test guest also needs
  usable SSE2 and verified per-thread XMM preservation; a CPUID bit is insufficient.
  NT31-DIAGNOSTIC\EARLIER contains previous CPU experiments for reproducibility.
  C:\FP32 is test staging, not the final default installation path.

The NTCPUPAE fix and WINSIMD research packages are separate downloads; no kernel
patcher or research driver is silently installed by these files.
SOURCE/fp32/original/FLASH32.EXE is the unmodified supplied player.
SHA-256 a4b333ac1da12026989549015303d82231982838bccfb544ba5fd188746066f0
See SOURCE/fp32/README.md and STATUS.json for exact limits.
No guest OS images, system DLLs, compiler binaries or firmware are bundled.
SHA256SUMS.txt lists every payload file; ZIP verification checks all CRCs/hashes.
