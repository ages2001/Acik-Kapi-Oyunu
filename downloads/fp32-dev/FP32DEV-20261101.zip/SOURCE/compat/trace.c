typedef unsigned long U32;
typedef void *H;
#define API __declspec(dllimport)
#define W __stdcall
API H W CreateFileA(const char*,U32,U32,void*,U32,U32,H);
API U32 W SetFilePointer(H,long,long*,U32);
API int W WriteFile(H,const void*,U32,U32*,void*);
API int W CloseHandle(H);
API H W CreateMutexA(void*,int,const char*);
API U32 W WaitForSingleObject(H,U32);
API int W ReleaseMutex(H);
API void W ExitProcess(U32);
#ifdef FP_GDI
extern int W fp_gdi_main(U32);
#endif
int W DllMain(H module,U32 reason,void *reserved){
#ifdef FP_GDI
return fp_gdi_main(reason);
#else
return 1;
#endif
}
void W FpObserve(const char *name,U32 ret){
 char out[256];U32 n=0,w,i;H h,lock;const char *hex="0123456789ABCDEF";
 while(*name && n<200)out[n++]=*name++;
 out[n++]=' ';out[n++]='@';out[n++]=' ';
 for(i=0;i<8;i++)out[n++]=hex[(ret>>(28-4*i))&15];
 out[n++]='\r';out[n++]='\n';
 lock=CreateMutexA(0,0,"FP10PortDiagnosticLog");
 if(!lock)return;
 if(WaitForSingleObject(lock,5000)>0x80){CloseHandle(lock);return;}
 h=CreateFileA("C:\\FP10\\TRACE.LOG",0x40000000,3,0,4,0x80,0);
 if(h!=(H)-1){SetFilePointer(h,0,0,2);WriteFile(h,out,n,&w,0);CloseHandle(h);}
 ReleaseMutex(lock);CloseHandle(lock);

}

void W FpMissing(const char *name,U32 ret){FpObserve(name,ret);ExitProcess(120);}
