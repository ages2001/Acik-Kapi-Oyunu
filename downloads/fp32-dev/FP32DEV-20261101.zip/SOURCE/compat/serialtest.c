/* Local QEMU test automation only. Not part of the distributed player. */
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
static HANDLE port;static HWND player;static char output[2048];static DWORD used;
static int same(const char*a,const char*b){while(*a&&*a==*b){a++;b++;}return *a==*b;}
static void put(const char*s){while(*s&&used<sizeof(output)-2)output[used++]=*s++;}
static void number(DWORD n){char b[12];int k=0;do{b[k++]='0'+n%10;n/=10;}while(n);while(k&&used<sizeof(output)-2)output[used++]=b[--k];}
static void flush(void){DWORD at=0,n;output[used++]='\r';output[used++]='\n';while(at<used){if(!WriteFile(port,output+at,used-at,&n,0)||!n)break;at+=n;}used=0;}
static DWORD integer(char**s){DWORD n=0;while(**s==' ')(*s)++;while(**s>='0'&&**s<='9')n=n*10+*(*s)++-'0';return n;}
static BOOL CALLBACK find(HWND w,LPARAM unused){char cls[64];GetClassNameA(w,cls,sizeof(cls));if(IsWindowVisible(w)&&same(cls,"ShockwaveFlash")){player=w;return FALSE;}return TRUE;}
static HWND target(void){player=0;EnumWindows(find,0);return player;}
static void field(const char*name,DWORD n){put(name);number(n);put(" ");}
static void status(void){RECT r;POINT p;DWORD pid=0;HWND w=target();field("hwnd=",(DWORD)w);if(w){GetWindowThreadProcessId(w,&pid);field("pid=",pid);GetClientRect(w,&r);field("width=",r.right);field("height=",r.bottom);p.x=p.y=0;ClientToScreen(w,&p);field("client_x=",p.x);field("client_y=",p.y);}GetCursorPos(&p);field("cursor_x=",p.x);field("cursor_y=",p.y);field("foreground=",(DWORD)GetForegroundWindow());field("tick=",GetTickCount());}
static BOOL CALLBACK list(HWND w,LPARAM unused){char cls[64],title[160];RECT r;if(!IsWindowVisible(w))return TRUE;GetClassNameA(w,cls,sizeof(cls));GetWindowTextA(w,title,sizeof(title));GetWindowRect(w,&r);put("WINDOW ");field("hwnd=",(DWORD)w);field("x=",r.left);field("y=",r.top);field("w=",r.right-r.left);field("h=",r.bottom-r.top);put(cls);put(" | ");put(title);flush();return TRUE;}
static void command(char*line){char*s=line,*arg;DWORD code=0;BOOL ok=FALSE;while(*s&&*s!=' ')s++;if(*s)*s++=0;arg=s;
 if(same(line,"PING")){put("OK PONG ");field("tick=",GetTickCount());flush();return;}
 if(same(line,"STATUS")){put("OK ");status();flush();return;}
 if(same(line,"ENUM")){EnumWindows(list,0);put("OK END");flush();return;}
 if(same(line,"RUN")){STARTUPINFOA si;PROCESS_INFORMATION pi;DWORD i;for(i=0;i<sizeof(si);i++)((BYTE*)&si)[i]=0;si.cb=sizeof(si);ok=CreateProcessA(0,arg,0,0,FALSE,0,0,0,&si,&pi);if(ok){put("OK pid=");number(pi.dwProcessId);CloseHandle(pi.hThread);CloseHandle(pi.hProcess);flush();return;}}
 else if(same(line,"COPY")){while(*s&&*s!='|')s++;if(*s){*s++=0;ok=CopyFileA(arg,s,FALSE);}else SetLastError(ERROR_INVALID_PARAMETER);}
 else if(same(line,"CLICK")||same(line,"POST")||same(line,"MOVE")){DWORD x=integer(&s),y=integer(&s),hold=integer(&s);POINT p,q;HWND w=target();if(!hold)hold=120;if(w){SetForegroundWindow(w);Sleep(150);p.x=x;p.y=y;ClientToScreen(w,&p);mouse_event(MOUSEEVENTF_MOVE|MOUSEEVENTF_ABSOLUTE,(DWORD)p.x*65535/(GetSystemMetrics(SM_CXSCREEN)-1),(DWORD)p.y*65535/(GetSystemMetrics(SM_CYSCREEN)-1),0,0);Sleep(150);GetCursorPos(&q);field("screen_x=",q.x);field("screen_y=",q.y);field("window_at_point=",(DWORD)WindowFromPoint(q));if(!same(line,"MOVE")){if(same(line,"POST")){PostMessageA(w,WM_MOUSEMOVE,0,MAKELPARAM(x,y));PostMessageA(w,WM_LBUTTONDOWN,MK_LBUTTON,MAKELPARAM(x,y));Sleep(hold);PostMessageA(w,WM_LBUTTONUP,0,MAKELPARAM(x,y));}else{mouse_event(MOUSEEVENTF_LEFTDOWN,0,0,0,0);Sleep(hold);mouse_event(MOUSEEVENTF_LEFTUP,0,0,0,0);}}ok=TRUE;}else SetLastError(ERROR_INVALID_WINDOW_HANDLE);}
 else if(same(line,"KEY")){DWORD key=integer(&s),hold=integer(&s);HWND w=target();if(!hold)hold=100;if(w){SetForegroundWindow(w);keybd_event((BYTE)key,(BYTE)MapVirtualKeyA(key,0),0,0);Sleep(hold);keybd_event((BYTE)key,(BYTE)MapVirtualKeyA(key,0),KEYEVENTF_KEYUP,0);ok=TRUE;}else SetLastError(ERROR_INVALID_WINDOW_HANDLE);}
 else if(same(line,"PLACE")){DWORD x=integer(&s),y=integer(&s);HWND w=target();ok=w&&SetWindowPos(w,HWND_TOP,x,y,0,0,SWP_NOSIZE|SWP_SHOWWINDOW);}
 else if(same(line,"CLOSE")){HWND w=target();ok=w&&PostMessageA(w,WM_CLOSE,0,0);}
 else if(same(line,"MEM")){MEMORYSTATUS m;m.dwLength=sizeof(m);GlobalMemoryStatus(&m);put("OK ");field("total=",m.dwTotalPhys);field("available=",m.dwAvailPhys);field("page_available=",m.dwAvailPageFile);flush();return;}
 else if(same(line,"READ")){HANDLE f=CreateFileA(arg,GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,0,OPEN_EXISTING,0,0);BYTE b[64];DWORD n,i;const char*hex="0123456789abcdef";if(f!=INVALID_HANDLE_VALUE){while(ReadFile(f,b,sizeof(b),&n,0)&&n){put("DATA ");for(i=0;i<n;i++){output[used++]=hex[b[i]>>4];output[used++]=hex[b[i]&15];}flush();}CloseHandle(f);put("OK END");flush();return;}}
 else{SetLastError(ERROR_INVALID_FUNCTION);}
 code=GetLastError();put(ok?"OK":"ERROR ");if(!ok)number(code);flush();
}
void WINAPI entry(void){DCB d;COMMTIMEOUTS t;DWORD i,n;char line[1024],c;DWORD length=0;port=CreateFileA("COM1",GENERIC_READ|GENERIC_WRITE,0,0,OPEN_EXISTING,0,0);if(port==INVALID_HANDLE_VALUE)ExitProcess(GetLastError());SetupComm(port,4096,4096);for(i=0;i<sizeof(d);i++)((BYTE*)&d)[i]=0;d.DCBlength=sizeof(d);GetCommState(port,&d);d.BaudRate=115200;d.ByteSize=8;d.Parity=NOPARITY;d.StopBits=ONESTOPBIT;d.fBinary=TRUE;d.fParity=FALSE;d.fOutxCtsFlow=FALSE;d.fOutxDsrFlow=FALSE;d.fDtrControl=DTR_CONTROL_ENABLE;d.fDsrSensitivity=FALSE;d.fOutX=d.fInX=FALSE;d.fRtsControl=RTS_CONTROL_ENABLE;if(!SetCommState(port,&d))ExitProcess(GetLastError());for(i=0;i<sizeof(t);i++)((BYTE*)&t)[i]=0;t.WriteTotalTimeoutConstant=5000;SetCommTimeouts(port,&t);PurgeComm(port,PURGE_RXCLEAR|PURGE_TXCLEAR);put("READY FP10TEST 1");flush();for(;;){if(!ReadFile(port,&c,1,&n,0))ExitProcess(GetLastError());if(!n)continue;if(c=='\r'||c=='\n'){if(length){line[length]=0;command(line);length=0;}}else if(length<sizeof(line)-1)line[length++]=c;else length=0;}}
