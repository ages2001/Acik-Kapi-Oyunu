#define WIN32_LEAN_AND_MEAN
#include <windows.h>

/* The DLL and its CPU detection run on a 386 baseline. This is a hardware
   requirement check, not certification of OS XMM context preservation. */
BOOL WINAPI FpHasSse2(void) {
    DWORD before, after, a, b, c, d;
    __asm__ volatile("pushfl; popl %0":"=r"(before));
    after = before ^ (1u<<21);
    __asm__ volatile("pushl %0; popfl"::"r"(after):"cc","memory");
    __asm__ volatile("pushfl; popl %0":"=r"(after));
    __asm__ volatile("pushl %0; popfl"::"r"(before):"cc","memory");
    if (!((before^after)&(1u<<21))) return FALSE;
    a=0; c=0;
    __asm__ volatile("cpuid":"+a"(a),"=b"(b),"+c"(c),"=d"(d));
    if(a<1)return FALSE;
    a=1; c=0;
    __asm__ volatile("cpuid":"+a"(a),"=b"(b),"+c"(c),"=d"(d));
    return (d&(1u<<26))!=0;
}

void WINAPI FpRequireSse2(void) {
    if(!FpHasSse2()) {
        MessageBoxA(0,
          "Flash Player 32 requires an SSE2-capable processor.\r\n\r\n"
          "SSE2 was not detected. Flash Player 32 will now close.\r\n"
          "Use the non-SSE2 build of Flash Player 10 on this processor.",
          "Flash Player 32 - SSE2 required",MB_OK|MB_ICONSTOP);
        ExitProcess(ERROR_NOT_SUPPORTED);
    }
}
BOOL WINAPI DllMain(HINSTANCE instance,DWORD reason,LPVOID reserved){return TRUE;}
