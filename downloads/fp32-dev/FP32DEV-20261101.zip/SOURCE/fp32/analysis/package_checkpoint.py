"""Package the full FP32 diagnostic checkpoint; never label it a working port."""
from pathlib import Path
import hashlib
import json
import sys
import zipfile
from original import original_player

root = Path(__file__).resolve().parents[2]
destination = Path(sys.argv[1]) if len(sys.argv) > 1 else root/'deliverables/FP32DEV.zip'
destination.parent.mkdir(parents=True, exist_ok=True)
files = {}
def add(path, name):
    assert path.is_file(), path
    assert name not in files, name
    files[name] = path.read_bytes()

readme = r'''FP32 LEGACY PORT - DEVELOPMENT CHECKPOINT - 2026-11-01

THIS IS NOT A COMPLETED FLASH PLAYER PORT OR INSTALLER.
The original Adobe Flash Player 32.0.0.465 remains the target engine.
It has not reached its player window or played a SWF on these legacy guests.
Do not replace a working FP10 installation with this checkpoint.

Verified components:
  File adapter: 12 checks on NT 3.1, Windows 95 RTM, Win3.1 + Win32s 1.30c.
  Core adapter: 7 checks on NT 3.1 and Windows 95, real concurrent threads.
  Command-line adapter: 33 NT 3.1 checks. Shell execution: 9 NT 3.1 checks.
  Single LFENCE trampoline: 512 emulator contract checks.
  SSE2 hardware gate: English error and exit on hardware without SSE2.
  Separate WINSIMD research: four CPUs, 342 affinity rounds and 640 worker
  lifetimes without XMM/MXCSR/x87 mismatches; not a production driver.

Current startup blocker:
  On the SSE2/XMM-enabled NT 3.1 guest, original SSE2 initialization executes.
  Keeping FP32.EXE alone in C:\FP32\APP passes its original DLL-neighbor check.
  Startup then reaches missing CryptAcquireContextA at 0x00becc40.
  Original RNG callers deliberately fault if acquisition/generation fails.
  A real cryptographic backend is required; no dummy randomness or bypass exists.
  Win32s lacks native threads; no substitute thread runtime is implemented.
  Full sound/video/input/menu/game tests and FP32 setup remain unfinished.
  No FP32 GPU acceleration, SSE-free operation or all-OS support is claimed.

Contents:
  NT31-DIAGNOSTIC: modified original FP32 and tracing compatibility proxies.
  COMPONENTS: adapters and independent test programs, not the player.
  SOURCE: current FP32 source, required shared FP10 and installer sources.
  EVIDENCE: logs/reports/screenshots, including failures and current blockers.
  CHECKPOINT: preserved FP10 source/build snapshot, not a completed FP10 runtime.

Diagnostic guest layout:
  Copy NT31-DIAGNOSTIC\APP to C:\FP32\APP (EXE only; no DLLs beside it).
  Copy the NT31-DIAGNOSTIC DLLs and COMPONENTS to C:\FP32.
  Set the working directory to C:\FP32, then run:
    DEBUG32.EXE C:\FP32\APP\FP32.EXE -relaunched
  DEBUG32 stops the child after 30 seconds. This is a diagnostic invocation,
  not the final launcher or a working SWF player. The test guest also needs
  usable SSE2 and verified per-thread XMM preservation; a CPUID bit is insufficient.
  NT31-DIAGNOSTIC\EARLIER contains previous CPU experiments for reproducibility.
  C:\FP32 is test staging, not the final default installation path.

The NTCPUPAE fix and WINSIMD research packages are separate downloads; no kernel
patcher or research driver is silently installed by these files.
SOURCE/fp32/original/FLASH32.EXE is the unmodified supplied player.
SHA-256 a4b333ac1da12026989549015303d82231982838bccfb544ba5fd188746066f0
See SOURCE/fp32/README.md and STATUS.json for exact limits.
No guest OS images, system DLLs, compiler binaries or firmware are bundled.
SHA256SUMS.txt lists every payload file; ZIP verification checks all CRCs/hashes.
'''
files['README.txt'] = readme.encode('ascii')
add(root/'fp32/reports/CURRENT-STATE.json','STATUS.json')
add(original_player(),'SOURCE/fp32/original/FLASH32.EXE')
add(root/'fp32/checkpoints/fp10-before-fp32.zip','CHECKPOINT/fp10-before-fp32.zip')
for name in ('FP32TEST.EXE','FP32LF.EXE'):
    add(root/'fp32/build'/name,'NT31-DIAGNOSTIC/EARLIER/'+name)
add(root/'fp32/build/FP32GATE.EXE','NT31-DIAGNOSTIC/APP/FP32.EXE')
add(root/'fp32/build/FPCPU.DLL','NT31-DIAGNOSTIC/FPCPU.DLL')
proxies = json.loads((root/'fp32/reports/build-proxies.json').read_text())
for row in proxies:
    add(root/'fp32/build'/row['proxy'],'NT31-DIAGNOSTIC/'+row['proxy'])
for name in ('F32FILE.DLL','F32CORE.DLL','FILETEST.EXE','CORETEST.EXE','CAPS32.EXE','DEBUG32.EXE','SLIST32.EXE','CPUGATE.EXE','ARGTEST.EXE','GUIDTEST.EXE','SHLTEST.EXE','SHCHILD.EXE'):
    add(root/'fp32/build'/name,'COMPONENTS/'+name)
add(root/'compat/RUNWAIT.EXE','COMPONENTS/RUNWAIT.EXE')
add(root/'compat/SMOKE.SWF','NT31-DIAGNOSTIC/SMOKE.SWF')
for folder in ('fp32/analysis','fp32/compat','compat','analysis','bin','installer'):
    for p in sorted((root/folder).iterdir()):
        if p.is_file() and p.suffix.lower() in ('.py','.c','.h','.asm','.json','.sh','.md','.txt','.rc','.ico','.tsv'):
            add(p,'SOURCE/'+p.relative_to(root).as_posix())
add(root/'fp32/README.md','SOURCE/fp32/README.md')
add(root/'bin/rea','SOURCE/bin/rea')
add(root/'bin/run-tool','SOURCE/bin/run-tool')
for p in sorted((root/'fp32/reports').iterdir()):
    if p.is_file() and p.suffix.lower() in ('.json','.txt','.md','.log'):
        add(p,'EVIDENCE/'+p.name)
for name in json.loads(files['STATUS.json'])['test_screenshots']:
    add(root/name,'EVIDENCE/screenshots/'+Path(name).name)
manifest = {name:hashlib.sha256(data).hexdigest() for name,data in sorted(files.items())}
files['SHA256SUMS.txt'] = ''.join(f'{digest}  {name}\n' for name,digest in manifest.items()).encode('utf8')
with zipfile.ZipFile(destination,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,data in sorted(files.items()): z.writestr(name,data)
with zipfile.ZipFile(destination) as z:
    assert z.testzip() is None
    for name,digest in manifest.items(): assert hashlib.sha256(z.read(name)).hexdigest()==digest, name
receipt={'file':destination.name,'bytes':destination.stat().st_size,
         'sha256':hashlib.sha256(destination.read_bytes()).hexdigest(),'payload_files':len(manifest),
         'verification':'Every ZIP CRC and every payload SHA-256 verified.',
         'completed_port':False,'player_playback_verified':False}
destination.with_suffix('.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
