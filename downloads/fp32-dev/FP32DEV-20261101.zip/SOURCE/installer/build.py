from pathlib import Path
import subprocess,sys,struct,zlib,json,hashlib,argparse
parser=argparse.ArgumentParser()
parser.add_argument("--payload-dir",type=Path)
args=parser.parse_args()
root=Path('/workspace/fp10-port');out=root/'installer';b=root/'tools/usr/bin';libs=root/'tools/usr/i686-w64-mingw32/lib'
subprocess.run([str(b/'clang-19'),'--target=i686-w64-windows-gnu','-isystem',str(root/'tools/usr/share/mingw-w64/include'),'-march=i386','-mno-sse','-mno-sse2','-ffreestanding','-fno-stack-protector','-fno-builtin','-Os','-Wall','-c',str(out/'setup.c'),'-o',str(out/'setup.obj')],check=True)
subprocess.run([sys.executable,str(out/'make_icons.py')],check=True)
subprocess.run([str(b/'i686-w64-mingw32-windres'),'--preprocessor='+str(b/'clang-19'),'--preprocessor-arg=-E','--preprocessor-arg=-x','--preprocessor-arg=c','-i',str(out/'icons.rc'),'-O','coff','-o',str(out/'icons.obj')],check=True)
subprocess.run([str(b/'lld-link-19'),'/nologo','/subsystem:windows,3.10','/osversion:3.10','/entry:entry@0','/nodefaultlib','/safeseh:no','/machine:x86','/out:'+str(out/'SETUP.EXE'),str(out/'setup.obj'),str(out/'icons.obj'),*[str(libs/('lib'+n+'.a')) for n in ['kernel32','user32','gdi32','advapi32']]],check=True)
sys.path.insert(0,str(root/'analysis'));from pad_legacy_pe import pad_image
pad_image(out/'SETUP.EXE')
proxy_names=sorted(row['proxy'] for row in json.loads((root/'compat/trace-proxies.json').read_text()))
payload=args.payload_dir or root/'compat'
files=[('FP10.EXE',payload/('FP10.EXE' if args.payload_dir else 'FPTRACE.EXE'))]+[(name,payload/name) for name in proxy_names]
exe=(out/'SETUP.EXE').read_bytes();base=len(exe);offset=len(files)*28;table=b'';data=b'';manifest=[]
for name,p in files:
 raw=p.read_bytes();table+=struct.pack('<16sIII',name.encode(),offset,len(raw),zlib.crc32(raw));data+=raw;offset+=len(raw);manifest.append({'name':name,'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)})
(out/'SETUP.EXE').write_bytes(exe+table+data+struct.pack('<III',0x31504b46,base,len(files)))
(out/'manifest.json').write_text(json.dumps(manifest,indent=2));print('Built development installer:',(out/'SETUP.EXE').stat().st_size)
