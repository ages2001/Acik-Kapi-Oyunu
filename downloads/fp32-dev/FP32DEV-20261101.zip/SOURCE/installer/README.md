# NT 3.1 installer development target

This is an experimental installer, not the completed port or universal release.
Build with `/workspace/fp10-analysis-tools/bin/python installer/build.py`.
It embeds the current compatibility runtime in one SETUP.EXE and requires NT 3.1.
The user-requested FP32 universal installer remains a later milestone.

Intended behavior under validation:
- Default destination C:\FP10; no existing payload file is overwritten.
- CRC32 validation of the entire embedded payload before installation writes.
- Preserve the existing .swf default registry value, including its type and bytes.
- Own class Ages2001.FP10.SWF, with quoted executable and argument paths.
- Program Manager group with exactly player and uninstall items.
- Remove only the listed payload files; reject modified or in-use files before
  changing associations. Preserve unrelated directory contents and shell items.
- Schedule the running uninstaller for deletion on restart.

Open implementation/testing issues:
- Runtime compatibility remains incomplete, so this must not be released as finished.
- Setup has a confirmation dialog and fixed default path; no path chooser yet.
- Recovery from abrupt process termination or power loss is not implemented.
- Uninstall failures after registry changes need further recovery handling.
- Verify empty program group removal and reinstall behavior in the guest.
- Audio driver installation still uses the operating system's normal driver setup.

A copy of the VM disk was saved as nt31/before-installer.raw before test installation.
