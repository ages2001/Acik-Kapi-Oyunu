# NT 3.1 CryptoAPI RNG bridge

The provider is RSABASE.DLL extracted from the user-supplied NT4 SP1 disk.
Its SHA-256 is 2ecf09e64b95d30f9ab578ff41c274db2844790a0713689c72ece9349f16e349.
No provider executable section is changed. The import descriptor for KERNEL32
points to FPCRK.DLL, header minimum versions are lowered, and zero-filled raw
section tails are materialized for the NT 3.1 loader. The build asserts that
all executable section bytes equal the supplied original.

FPCRK forwards native exports and supplies the existing ANSI locale adapters.
DisableThreadLibraryCalls returns FALSE/ERROR_CALL_NOT_IMPLEMENTED; the CSP's
DllMain ignores that optional result and already accepts thread notifications.
The provider's algorithms and entropy collection have not been replaced.

F32A bridges CryptAcquireContextA/W, CryptGenRandom and CryptReleaseContext to
CPAcquireContext, CPGenRandom and CPReleaseContext. Only ephemeral
PROV_RSA_FULL/CRYPT_VERIFYCONTEXT contexts are supported. Unknown providers,
named containers, other provider types and persistent-key flags fail explicitly.
A native critical section serializes calls to this historical provider.
This does not implement all CryptoAPI operations or certify modern security.

## Validation

- Direct CSP acquisition, two 4096-byte outputs, distinct/nonzero buffer checks
  and release passed on the NT 3.1 SSE2 UP guest.
- 17 bridge checks passed: invalid arguments/provider requests, wide acquisition,
  native output, invalid release flags, release and stale-handle rejection,
  four concurrent workers and distinct sample checks.
- Four workers generated 524288 bytes in 31440 ms, all workers completed, zero
  failures. The original 30-second test timeout was insufficient; a 60-second
  test limit completed without reducing the workload. This is a bounded
  functional test, not an entropy-quality proof or an application performance test.
- Logs: nt31-csp-direct-test.log and nt31-crypto-rng-tests.log.

No original Flash cryptographic failure branch is disabled. Full Flash startup
and playback are validated separately; passing this component is not playback.
