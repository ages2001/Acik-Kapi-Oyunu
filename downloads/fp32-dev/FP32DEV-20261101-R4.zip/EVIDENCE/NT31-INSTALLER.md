# FP32 NT 3.1 development installer validation

The original player remains APP\FP32.EXE. A small parent FP32.EXE launcher sets
its DLL working directory and forwards one file path. SETUP32.EXE is one file
containing all 23 runtime payload files, including the actual RSA CSP adapter.
The separate XMM research driver is a documented prerequisite, not silently
installed. This is not the requested universal installer or a completed port.

## Tested behavior

- Native Next/Back/Cancel and Finish workflow, editable destination, review and
  progress tied to payload validation/copy work. Welcome text no longer clips.
  The status control background matches the window; the white editable field
  and unfilled part of the progress bar are intentional controls.
- Added Ctrl+A selection in the path field because NT 3.1's standard EDIT does
  not provide it automatically. The updated path-validation screen confirms
  replacement of the whole previous path.
- Custom installation to C:\FP32 A completed. Its shell association exposed
  native NT 3.1's automatic quoting of substituted filenames: quoting %1 again
  produced doubled quotes and split RED A.SWF. The corrected association leaves
  %1 unquoted while keeping the executable path quoted. This is an NT 3.1 shell
  contract, not a rule to assume for later Windows.
- Native ExtractIcon displays both the embedded red cross and the original
  player icon correctly. Program Manager AddItem nevertheless substitutes a
  generic icon for an icon-source path containing spaces. Quoted/unquoted paths
  and explicit working directories reproduced this. Paths without spaces work.
  The current NT31 wizard rejects space-containing installation folders with
  an inline explanation. This limitation does not prohibit spaces in SWF names.
- Cancelling after a rejected path left the association/class/group report
  byte-for-byte equal to the pre-install report.
- The corrected current package installed at the default C:\FP10. Its group
  contains exactly Flash Player 32 and Uninstall Flash Player 32, with the
  original engine icon and uninstaller icon index 1. The registry command is
  "C:\FP10\FP32.EXE" %1.
- Native ShellExecute on RED A.SWF returned 33 and displayed the red stage.
  A real double-click in NT 3.1 File Manager also opened that same file in the
  installed original FP32 (screenshots 582 and 583).
- The earlier custom installation's uninstaller removed the player/class/group,
  restored .swf to ShockwaveFlash.ShockwaveFlash with identical type/bytes,
  and preserved test user files in both the root and APP subfolder. A restart
  removed the scheduled UNINST.EXE. See installer-custom-preservation.json.

The guest disk was backed up before installer tests. An offline transfer of the
current installer was read back and compared byte-for-byte before use. All 23
embedded payload CRC32/SHA256 values were checked against the build manifest.
Tested pre-icon setup SHA256: 3a1f7b19b6a0aeb3b12cff17b3a214b213a1faf7b1848e15e695a2cc91268016.

The final icon-bearing launcher was rebuilt into SETUP32.EXE (19,313,296 bytes),
SHA256 5d3f788ea9a4ab2fdfabd7337cbcfb7d909ded059f858df84f7be2f91e17dc3a.
All 23 current embedded payload hashes/CRCs match the manifest. The launcher
passes native icon extraction and no-file startup on NT31. The installer UI
and logic are unchanged; a fresh installation of this final payload is pending.

The current installer also rejected uninstall while the installed player was
open, before deleting files or changing the association/class/shortcut records.
The before/after native shell report is byte-for-byte identical (excluding the
prior ShellExecute return line); see installer-in-use-rejected.log.

## Remaining scope

The native NT 3.1 installer is only a development target. Other OS defaults,
Win9x/Win32s shell APIs and complete runtime compatibility remain unfinished.
Power-loss recovery and recovery after a partially completed uninstall are not
implemented. A successful install does not certify all games, performance,
GPU support, every media codec or production XMM state preservation.
