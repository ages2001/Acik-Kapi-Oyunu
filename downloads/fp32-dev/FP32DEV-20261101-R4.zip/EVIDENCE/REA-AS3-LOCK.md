# Original FP32 AS3 lock analysis with REA

REA 6.8.0 / Ghidra 12.1.4 analyzed the exact supplied FP32 executable, SHA-256
 a4b333ac1da12026989549015303d82231982838bccfb544ba5fd188746066f0.
The seed at 0x00c096d0 was selected from the native guest missing-API trace
(return address 0x00c096f5) and the observed x86 function prologue. It is an
analyst-provided seed, not an automatic function discovery.

The completed evidence is rea-as3-lock.json. Ghidra pseudocode shows two
TryEnterCriticalSection calls, at object offsets +0x0c and +0x48. On failure,
FP32 inspects a TLS value and enters the lock directly or through a helper.
Both successful critical regions eventually call native LeaveCriticalSection.
This supports implementing a real nonblocking ownership attempt that interoperates
with native Enter/Leave, including recursion and native waiters. A success stub
would enter protected work without synchronization. Returning false always would
avoid the fast path without implementing the requested API contract.

The pseudocode is decompiler-derived, not Adobe source. Other helper meanings,
indirect paths and entire-application correctness are not inferred from it.
Native UP and four-CPU adapter tests and actual AS3 graphics are recorded in
TRY-CRITICAL-SECTION.md. No original FP32 locking branch was patched out.
