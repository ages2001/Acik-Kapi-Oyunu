# NT 3.1 TryEnterCriticalSection adaptation

Original FP32 stopped while opening AS3REF.SWF at a missing
TryEnterCriticalSection call, with return address 0x00c096f5. The diagnostic
proxy exited with code 120; this was not the debugger watchdog.

The original function begins at 0x00c096d0. Local instruction decoding shows
that a failed try enters a contended path, while a successful try skips that
path. A REA/Ghidra analysis of this exact original function is also retained.

NT 3.1 NTDLL RtlEnterCriticalSection at 0x771ac0d0 increments LockCount at +4,
stores the owning thread ID at +12 and recursion depth at +8. Its free count
is -1. RtlLeaveCriticalSection at 0x771ac130 clears ownership on final release,
decrements LockCount atomically, and wakes a native waiter when nonnegative.
The adapter atomically claims -1 to 0; recursive ownership delegates to native
EnterCriticalSection. Failed tries leave the count unchanged, so they cannot
create phantom waiters. Other critical-section APIs remain native.

TRYLOCK.EXE passed 14 checks on the actual NT 3.1 SSE2 guest. These include
recursive try/native interoperability, a rejected contender without queue
mutation, a native blocked waiter released by a try owner, LastError
preservation, and four mixed native/try workers. All 8,000 protected increments
completed with zero overlapping owners and the final native lock state free.
The original FP32 then rendered the AS3 reference shapes (screenshot 528).
This is not a Win32s synchronization implementation.

The identical TRYLOCK.EXE and F32K.DLL also passed all 14 checks and 8,000
protected increments on the copied four-CPU NT 3.1 guest, with zero overlaps.
See nt31-mp-trylock.log. This does not validate Win9x or Win32s lock layouts.
