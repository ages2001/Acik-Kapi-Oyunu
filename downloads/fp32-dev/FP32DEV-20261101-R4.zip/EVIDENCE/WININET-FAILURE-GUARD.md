# Original FP32 WinINet failure guard

The R3 NT 3.1 Takeover test exited before a usable player window. Native
debugging captured an access violation at EIP 0, with return address 0x006b13b4
and the InternetOpenA arguments on the faulting worker stack.

REA/Ghidra recovered original function 0x006b112a. Its first WinINet load
failure sets initialization state 0x01121374 to 2. A subsequent request treats
any nonzero state as initialized and calls the InternetOpenA pointer at
0x01121378. With no WinINet provider, that pointer is null. Partial export
resolution can also leave a non-null first pointer with failure state 2.

The adapter redirects five instruction bytes (four whole instructions) at 0x006b13a7 into an RX
section. It requires both a non-null InternetOpenA pointer and ready state 1.
Otherwise it jumps to the original request-failure cleanup at 0x006b11ec.
The ready path replays the displaced xor and three zero pushes before returning
to 0x006b13ac. Registers, flags and stack contracts are checked with Unicorn
at two image bases. The temporary instruction-pointer-relative address avoids
adding an absolute relocation. The input hash and original site bytes are
checked; this builder is specific to the verified FP32 32.0.0.465 input chain.

This is a compatibility patch to the original Adobe executable. It does not
change the SWF, implement WinINet, or fabricate successful network requests.
Games requiring online resources may still fail to load those resources.

Evidence: takeover-debug.log, takeover-api.log,
rea-takeover-network-call.json, rea-takeover-network-summary.json,
network-guard-build.json and network-guard-emulator.json.

The first null-only candidate reached Takeover's Start screen and animated
intro in the native NT 3.1 guest. Its AC97 output was non-silent. That candidate's
receipts are retained separately; final-candidate native results are recorded
in network-guard-native.json when tested. These observations are not a full
playthrough, acceptable-performance result, or universal OS certification.
