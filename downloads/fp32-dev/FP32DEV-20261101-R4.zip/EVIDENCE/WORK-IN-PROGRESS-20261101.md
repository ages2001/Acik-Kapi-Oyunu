# Active continuation (not a release)

- User requires the dark-red app logo, not the SWF-document icon. Source group
  200 in the supplied original matches the reference. Internet search found
  https://en.wikipedia.org/wiki/File:Adobe_Flash_Player_32.svg (page fetch 403).
  Current source selects group 200 with 16/32px VGA16 fallbacks. Original
  high-color resource bytes remain present. Old Cirrus VGA rendered maroon as
  magenta; WINVBE true-color verification and final VGA retest are pending.
- User-supplied NTLDR and NTDETECT.COM were copied only into nt31-game-lab.raw,
  after clean shutdown and with backups/readback verification. Guest RAM now
  reports 536936448 bytes (previously 66650112 despite QEMU -m 512).
- SM63 Runouw intro has real AC97 sound: captures/sm63-opening-512mb,
  reports/SM63-RUNOUW.wav and .mp3, sm63-runouw-audio.json, screenshot 607.
  6-second excerpt peak 7305, RMS 944.29. This is not all-audio certification.
- SM63 Start, Story, File A, Create and first level reached in this lab. Z
  tutorial dismissal was unreliable in this run; no full gameplay/jump pass.
- WINVBE installed on lab clone only, switched to 800x600x32 and standard VGA
  QEMU hardware. Original nt31-simd.raw and other checkpoints remain preserved.
- Initial SAVETEST.SWF run found a storage failure (resolved below): SharedObject.getLocal returns null,
  and the counter is lost on reopen. Its source is fixtures/save-as/frame_1.
- Dynamic API trace identifies missing SHGetFolderPathW, folder=0x1a,
  flags=0, token=0, original caller return 0x004d35c7, function 0x004d358e.
  REA/Ghidra analysis completed: rea-folder-path.json confirms the dynamic
  shell callback and its failure fallback in the original executable.
- User explicitly notes NT3.xx and Win3.1x/Win32s have no native AppData.
  Revised source profile.c provisions <installation>\UserData with full NT SID
  encoded losslessly into 8-character components; Win32s selects Default.
  FP32_USERDATA is a private child-process environment variable, not an OS
  AppData installation. Native SHGetFolderPathW is used when available.
- FAT on this NT31 guest rejects long directory components with error 123.
  Native probe: short D:\PROFTEST succeeds, Long Folder Name fails. Flash also
  uses long storage directory/object names. A scoped persistent short-name
  mapping layer now passes 48 native checks, including a deliberate alias-hash
  collision and corrupt-map rejection. See nt31-maptest.log.
- HeapLock/Unlock were observed missing on player close. Native NT31 NTDLL
  RtlLockHeap/RtlUnlockHeap are VOID-returning, ret 4. RtlValidateHeap takes
  ONE argument (ret 4), unlike modern versions. Initial wrong three-argument
  validation caused the 16-check probe to report 4 errors. Source now uses
  the verified one-argument ABI; rerun passed 16 checks, zero errors. Native NTDLL
  file matches reference SHA256 7896b84445d58a9d1cb18043a89b029f3901f53d37fba9f70437b65fe9501c94.
- Publish R3 only as an incomplete development checkpoint. Public R2 remains
  historical; it has the document icon and no working save support.
- User requires no missing required API/entry points at completion. Preserve
  a truthful static/runtime inventory; do not replace missing functionality
  with success stubs. Other OS runtimes and extensive tests remain unfinished.

- Persistence update: dynamic CryptoAPI resolution now reaches the real F32A
  provider; extended-path directory queries, GetLongPathNameW and SHLWAPI
  Unicode substring operations are implemented. The original FP32 AS2 probe
  now opens a SharedObject, flushes counter 1, and reloads it after player
  restart AND a clean Windows reboot. Physical SOL AMF counter verified while
  VM stopped. Evidence: nt31-save-persistence.json, screenshots 629/630/634.
  This supersedes the earlier null-object failure; other OSes, games, AS3,
  account isolation and uninstall/reinstall are not certified.

## R3 follow-up verification

- Optional tracing: eight native checks pass, including quiet mode, opt-in mode,
  required missing API exit 120, and fatal exception filter logging with last
  error preserved. Fatal reporting remains independent of FP32_TRACE.
- Automation BSTR allocation: 12 native checks pass, including ordinal/name
  identity, NULL/empty strings, byte-length prefix, UTF-16 and independent copies.
- Launcher child working directory now remains absolute at a drive root.
- SM63 still produces a dynamic StarcoinMessage after Start. A fresh SWF path
  and an external diagnostic wrapper reproduce it. The supplied game hash is
  unchanged. Native Linux Adobe FP32 reaches the regular menu; this comparison
  alone does not identify the cause and is not a supported-Windows baseline.
- REA/Ghidra inspected the native NT3.1 heap snapshot and allocation code. The
  experimental HeapWalk test passes ordinary allocations but misses a 2 MiB
  allocation that NT3.1 does not link into its heap segments. Two of 751 checks
  fail. heap_walk.c is EXCLUDED from build_nt31.py; HeapWalk remains diagnostic.
- Current full runtime support remains limited to the recorded NT3.1 fixtures;
  no all-OS, all-game, GPU, full-menu, non-SSE2 FP32 or YMM/ZMM completion claim.
