# FP32 startup evidence

Original SHA-256: a4b333ac1da12026989549015303d82231982838bccfb544ba5fd188746066f0.

The bounded native NT 3.1 debugger observed an illegal instruction at 0x0044b3a0
after the single LFENCE adaptation. The original instruction sequence is:

```
0044b3a0  movd     xmm0, dword ptr [0x010ebb20]
0044b3a8  cvtdq2ps xmm0, xmm0
0044b3ab  movss    dword ptr [0x0113d308], xmm0
0044b3b3  ret
```

REA 6.8.0 with Ghidra 12.1.4 initially timed out at its 300-second import limit.
Increasing the wrapper default to 900 seconds allowed full analysis to complete,
but the automatic analysis had not created a function at this observed address.
`analysis/startup-seeds.tsv` declares the address as a function based on the
runtime fault and its instruction boundaries. This is an analyst-provided seed,
not an automatic discovery. REA reports one function created, zero seed failures.

The successful `rea-simd-seeded.json` contains the recovered pseudocode:

```
void observed_sse2_static_initializer(void) {
    DAT_0113d308 = (float)DAT_010ebb20;
}
```

This explains the numeric initialization that executes before the GUI. The
initializer's stored input in the original file is -32767. The report has no
resolved callers; an empty caller list is not proof that no indirect caller
exists. Pseudocode is decompiler output, not Adobe source. No equivalent scalar
replacement has been validated, and the many other SIMD sites remain unchanged.

The installed REA provider creates a new temporary Ghidra project for each
operation. REA_GHIDRA_PROJECT_PATH was not a supported reuse option in this
version; the separate persistent import did not eliminate REA import time.
The wrapper now honors an explicit REA_GHIDRA_STARTUP_TIMEOUT_MS override.

This analysis is useful for locating concrete compatibility work. It does not
automatically generate correct API implementations or make the full port a
short task.
