# NULL window-procedure compatibility

Original FP32 helper teardown at 0x007487fa calls SetWindowLongW(hwnd,
GWL_WNDPROC, 0), then DestroyWindow. On the NT 3.1 guest, the native USER32
callback attempts to call address zero for WM_DESTROY. The failed helper is a
STATIC popup, originally registered with a valid system window procedure.
The provider/RNG and DLL ordinal fixes are already passed before this point.

Later USER32 behavior is a no-op: return the existing procedure and preserve
LastError and the window's ANSI/Unicode mode. Reference: the Wine user32 test
suite documents this contract for both A and W APIs:
https://github.com/wine-mirror/wine/blob/master/dlls/user32/tests/win.c
(search test_SetWindowLong, NULL GWLP_WNDPROC). This is a behavioral reference,
not a new claim that a modern Windows VM was tested here.

The FP32-only adapter handles exactly the NULL GWL_WNDPROC assignment by reading
the existing native procedure and preserving LastError on success. Other
indices and non-NULL subclassing remain native calls. It does not suppress
messages, replace Flash's window procedure or skip DestroyWindow.

WNDPROC.EXE checks the observed native baseline, A/W no-op behavior, preserved
encoding/error, real message delivery, clearing user data, non-NULL subclassing,
invalid handles and exactly-once WM_DESTROY delivery. Runtime results are saved
separately in nt31-wndproc-tests.log once the test has completed.
