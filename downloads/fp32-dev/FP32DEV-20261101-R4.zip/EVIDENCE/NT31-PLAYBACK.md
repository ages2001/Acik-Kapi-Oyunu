# Original FP32 playback checkpoint on NT 3.1

This report covers the original supplied Adobe Flash Player 32.0.0.465 through
compatibility DLLs, not a replacement renderer or modified user game.
Configuration: QEMU TCG Pentium III + SSE2, one CPU, 64 MiB, classic VGA16,
AC97 with AUDIONT 1.1, WINSIMD 1.1 and the current exact-kernel XMM research guard.

## Verified observations

- Native player menu bar and Ctrl+O dialog; About shows 32.0.0.465, SSE2 and the
  requested English port credits. Correct original 1996-2020 copyright shown.
- SMOKE.SWF: red stage. ACTION.SWF: AS2 timed moving square changes position.
- AS3REF.SWF: expected reference shapes drawn after TryEnterCriticalSection fix.
- AVTEST.SWF: expected 440 Hz PCM tone captured from actual QEMU AC97 output.
  The median crossing period yields 441 Hz because of sample quantization;
  the included short WAV is actual captured output, not a source-file copy.
- VIDEO.SWF: two decoded frames differ in 8,535 pixels within the 320x240 stage.
  This is one FLV1/MP3 fixture, not H.264/all-codec or frame-rate certification.
- KEYIN.SWF: native mouse input changes the target green and increments both
  down/accepted counters to one. A Z press/release increments key-down and key-up
  once each (the baseline already had one release from opening the fixture).
- Super Mario 63: loads, native Start/Story/File A/Create clicks advance into the
  first level, right-arrow input moves the scene and opens the tutorial, and Z
  eventually dismisses the tutorial. No SWF modifications or posted mouse messages.
  Jump was not confirmed; this is not a complete game pass.

The game's first-level counter ranged approximately 1-5 FPS. That does not meet
an acceptable-performance claim. VGA16 color conversion is visibly limited and
no GPU acceleration is validated. Host Ghidra work overlapped part of testing;
no independent controlled performance comparison has been made.

## Analysis and runtime fixes

The RNG bridge uses a real user-supplied NT4 CSP, with provider executable bytes
unchanged. Proxy ordinal contracts, NULL window-procedure semantics, WOW64
absence and native critical-section interoperability were corrected. REA/Ghidra
confirmed the original AS3 lock function's try/enter/leave contract; evidence and
native UP/MP tests are retained separately. Missing APIs still fail explicitly.

The parent FP32.EXE launcher starts APP\FP32.EXE with the correct working directory
and a normal file argument, without DEBUG32 or its test timeout. A path containing
spaces opens. The original -relaunched flag should not be combined with a file
argument. Diagnostic runs may intentionally end with watchdog exit 99; this is
not itself a player crash.

## Scope limits

The other uploaded games remain pending this FP32 round. isaac.swf and smbc.swf
could not be transferred because each exceeds the environment's 32 MiB limit.
NT3.51/NT4/Win9x/Win32s full-player validation, all menu commands, broader media,
performance and production SIMD state handling remain incomplete. Component
checks on another OS are not a successful player port on that OS.
