DIAGNOSTIC ONLY. Unimplemented calls are logged to C:\FP10\TRACE.LOG and terminate with code 120. This is not a compatibility layer and never reports success for missing APIs.
