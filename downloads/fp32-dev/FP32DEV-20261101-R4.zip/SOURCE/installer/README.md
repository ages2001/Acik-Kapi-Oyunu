# Native NT 3.1 development installers

Both products use the same wizard, progress, extraction, association and uninstall
code, selected by product.h. These are NT 3.1 development packages, not universal
or completed player releases.

Build with the prepared Python/toolchain:

```
python installer/build.py --product 10
python fp32/analysis/build_launcher.py
python installer/build.py --product 32
```

FP10 outputs installer/SETUP.EXE. FP32 outputs fp32/build/SETUP32.EXE and embeds
the current compatibility proxies, real RSA provider adapter, parent launcher,
and the adapted original Adobe executable alone under APP. It requires usable
SSE2 and a separately loaded compatible XMM-preservation driver; setup does not
silently install the research kernel hook.

The wizard provides Next/Back/Cancel, editable path, review, progress and Finish.
The default remains C:\FP10 on NT 3.1. The parent directory must already exist.
NT 3.1 Program Manager fails to extract shortcut icons when the icon source
folder contains spaces, despite native ExtractIcon accepting the same path.
The wizard therefore rejects spaces in the installation directory on this target.
SWF filenames with spaces are supported by the tested native shell association.
Other OS-specific defaults and shell integration remain unimplemented here.

The package validates all embedded CRCs before installation writes, refuses
existing payload files, and backs up the previous .swf registry type/value bytes.
NT 3.1's shell quotes a substituted filename itself: its association command uses
an unquoted %1 placeholder to avoid doubled quotes around filenames with spaces.
The executable path remains quoted. Do not assume this rule for other OS shells.

Setup creates two Program Manager shortcuts. The FP32 player icon comes from
APP\FP32.EXE; the red-cross uninstall icon is index 1 in UNINST.EXE. Uninstall
checks payload CRCs and in-use files before changing associations, removes only
owned files and shortcuts, and preserves unrelated files. APP is removed only
when empty. The running uninstaller is scheduled for removal at restart.

Abrupt termination/power-loss recovery and recovery after partial uninstall
failure are not complete. Player runtime, performance, broader OS support and
all-OS installation remain release gates. Current FP32 evidence is in
fp32/reports/; historical FP10 wizard tests are in reports/INSTALLER-WIZARD.md.
