# Universal Flash Player 10 port installer

One distributable setup executable must cover all target operating systems.
All project UI, documentation, setup text, and About text must be English.
Do not mark a platform supported until the runtime and installation are tested.

| OS family | Default install directory | Status |
| --- | --- | --- |
| Windows 3.1x with Win32s 1.30c | C:\FP10 | Runtime not ported or tested |
| Windows NT 3.1 / 3.5 / 3.51 | C:\FP10 | Basic playback tested on NT 3.1 only |
| Windows 95 / 98 / ME | C:\Program Files\Flash Player 10 | Runtime not ported or tested |
| Windows NT 4 and later | C:\Program Files\Flash Player 10 | Runtime not tested |

Setup must create exactly two application shortcuts: Flash Player 10 and
Uninstall Flash Player 10, using the appropriate shell for each OS. Register
.swf to open with the installed player on double click. Preserve the previous
association for restoration on uninstall; never remove unrelated user files.
Use the Windows 95 compatibility implementation as the starting point for
Win32s, but account explicitly for the missing thread and Win32 functionality.

Required About text (exact wording supplied by the user):

Ported to Windows NT3.1/3.5x/4 , Windows 95/98/ME and Windows 3.1x with Win32s
Ported by ages2001

The About wording is a requested final product requirement, not current evidence
that these platforms are supported. Runtime verification must precede release.

Required representative content includes user-supplied Super Mario 63 (2010),
as well as graphics, ActionScript, sound, video, interaction, and performance tests.
Use AUDIONT for NT 3.1 and WINAUDIO for Windows 95 and Windows 3.1 as supplied by
the user; validate actual device functionality in each guest.

## Updated sequencing and version target

User update: complete the NT 3.1 Flash Player 10 milestone and deliver its ZIP first.
After that delivery, switch subsequent porting work to Flash Player 32.0.0.465
for all target OS families. Do not silently replace the in-progress NT 3.1 FP10
milestone with FP32. FP32 compatibility, CPU requirements, and distribution paths
must be evaluated independently; the universal installer requirement persists.

## Additional requested UI work (2026-10-30)

After the player interaction bugs are fixed:
- Replace the confirmation-only flow with a conventional Next / Back / Cancel
  wizard, including an editable destination path and a final review page.
- Preserve the requested OS-specific default paths; changing a path must update
  payload extraction, both shortcuts, SWF registration and uninstall state.
- Eliminate white rectangular control-background artifacts before and during
  installation. The progress status STATIC currently paints a white rectangle
  against the button-face background; handle native control colors consistently.
- Keep the progress bar and red-cross uninstall shortcut icon already implemented.
- Verify every menu command and button, including cancellation and back navigation.

## Saved-game storage requirement (2026-11-01)

NT 3.xx and Windows 3.1x with Win32s have no native AppData model to assume.
Use application-owned `<installation>\UserData`, preserving it during uninstall
and updates. NT user keys must remain stable across account renaming; Win32s
must not depend on NT access tokens. Do not add saved games or their mapping
metadata to the uninstall payload manifest. See `fp32/SAVED-GAMES.md`.
