/* NT 3.1 CryptoAPI RNG bridge to the supplied, import-adapted NT4 RSA CSP.
   The CSP's algorithms and entropy collection are unchanged. This adapter
   supports ephemeral PROV_RSA_FULL contexts only, not persisted key stores. */
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <wincrypt.h>
static CRITICAL_SECTION provider_lock;
static HMODULE provider_module;
static BOOL (WINAPI *cp_acquire)(HCRYPTPROV*,LPSTR,DWORD,void*);
static BOOL (WINAPI *cp_random)(HCRYPTPROV,DWORD,BYTE*);
static BOOL (WINAPI *cp_release)(HCRYPTPROV,DWORD);
BOOL WINAPI fp_crypto_main(DWORD reason)
{
    if(reason==DLL_PROCESS_ATTACH)InitializeCriticalSection(&provider_lock);
    else if(reason==DLL_PROCESS_DETACH)DeleteCriticalSection(&provider_lock);
    return TRUE;
}
static void lock(void){EnterCriticalSection(&provider_lock);}
static void unlock(void){LeaveCriticalSection(&provider_lock);}
static BOOL load_provider(void)
{
    char path[MAX_PATH];DWORD n,i,error;HMODULE module;
    if(provider_module)return TRUE;
    n=GetModuleFileNameA(GetModuleHandleA("F32A.DLL"),path,sizeof(path));
    if(!n||n>=sizeof(path)){SetLastError(ERROR_BAD_PATHNAME);return FALSE;}
    for(i=n;i&&path[i-1]!='\\';i--);
    if(!i||i+10>sizeof(path)){SetLastError(ERROR_BAD_PATHNAME);return FALSE;}
    {const char *name="FPRSA.DLL";while(*name)path[i++]=*name++;path[i]=0;}
    module=LoadLibraryA(path);if(!module)return FALSE;
    cp_acquire=(void*)GetProcAddress(module,"CPAcquireContext");
    cp_random=(void*)GetProcAddress(module,"CPGenRandom");
    cp_release=(void*)GetProcAddress(module,"CPReleaseContext");
    if(!cp_acquire||!cp_random||!cp_release){error=ERROR_PROC_NOT_FOUND;FreeLibrary(module);SetLastError(error);return FALSE;}
    provider_module=module;return TRUE;
}
BOOL WINAPI fp_CryptAcquireContextA(HCRYPTPROV *result,LPCSTR container,LPCSTR provider,DWORD type,DWORD flags)
{
    BOOL ok;DWORD table[7]={1,0,0,PROV_RSA_FULL,0,0,0};
    if(!result){SetLastError(ERROR_INVALID_PARAMETER);return FALSE;}
    *result=0;
    if(type!=PROV_RSA_FULL){SetLastError(NTE_BAD_PROV_TYPE);return FALSE;}
    if(provider&&lstrcmpA(provider,"Microsoft Base Cryptographic Provider v1.0")){SetLastError(NTE_PROV_TYPE_NOT_DEF);return FALSE;}
    if(container){SetLastError(NTE_BAD_KEYSET);return FALSE;}
    if(flags!=CRYPT_VERIFYCONTEXT){SetLastError(NTE_BAD_FLAGS);return FALSE;}
    lock();ok=load_provider();if(ok)ok=cp_acquire(result,0,flags,table);unlock();return ok;
}
BOOL WINAPI fp_CryptAcquireContextW(HCRYPTPROV *result,LPCWSTR container,LPCWSTR provider,DWORD type,DWORD flags)
{
    if(provider&&lstrcmpW(provider,L"Microsoft Base Cryptographic Provider v1.0")){
        if(result)*result=0;SetLastError(NTE_PROV_TYPE_NOT_DEF);return FALSE;
    }
    return fp_CryptAcquireContextA(result,container?"unsupported":0,0,type,flags);
}
BOOL WINAPI fp_CryptGenRandom(HCRYPTPROV context,DWORD length,BYTE *buffer)
{
    BOOL ok;
    if(length&&!buffer){SetLastError(ERROR_INVALID_PARAMETER);return FALSE;}
    lock();if(!provider_module){unlock();SetLastError(NTE_BAD_UID);return FALSE;}
    ok=cp_random(context,length,buffer);unlock();return ok;
}
BOOL WINAPI fp_CryptReleaseContext(HCRYPTPROV context,DWORD flags)
{
    BOOL ok;
    lock();if(!provider_module){unlock();SetLastError(NTE_BAD_UID);return FALSE;}
    ok=cp_release(context,flags);unlock();return ok;
}
