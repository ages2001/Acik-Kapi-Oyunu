#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <objbase.h>

/* Use the OS RPC UUID generator, including its native concurrency handling. */
HRESULT WINAPI fp_CoCreateGuid(GUID *guid)
{
    typedef LONG (WINAPI *CreateUuid)(GUID *);
    HMODULE module;
    CreateUuid create;
    LONG status;
    DWORD error;
    if (!guid) return E_INVALIDARG;
    module = LoadLibraryA("RPCRT4.DLL");
    if (!module) return HRESULT_FROM_WIN32(GetLastError());
    create = (CreateUuid)GetProcAddress(module, "UuidCreate");
    if (!create) { error = GetLastError(); FreeLibrary(module); return HRESULT_FROM_WIN32(error); }
    status = create(guid);
    FreeLibrary(module);
    /* RPC_S_UUID_LOCAL_ONLY is a generated UUID with machine-local uniqueness. */
    if (status == RPC_S_OK || status == RPC_S_UUID_LOCAL_ONLY) return S_OK;
    return HRESULT_FROM_WIN32(status);
}
