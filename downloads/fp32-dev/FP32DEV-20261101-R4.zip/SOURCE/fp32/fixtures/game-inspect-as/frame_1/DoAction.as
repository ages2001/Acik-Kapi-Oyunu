stop();
_root.createEmptyMovieClip("game",1);
_root.game._lockroot = true;
_root.game.loadMovie("D:/SM63NEW.SWF");
_root.createTextField("status",100000,0,303,450,130);
_root.status.background = true;
_root.status.backgroundColor = 16777215;
_root.status.textColor = 0;
_root.lastUpdate = 0;
_root.onEnterFrame = function() {
 if (getTimer() - _root.lastUpdate < 1000) { return; }
 _root.lastUpdate = getTimer();
 var g = _root.game;
 var s = "DIAGNOSTIC WRAPPER / original SWF unmodified\nFrame: " + g._currentframe + "/" + g._totalframes + " bytes: " + g.getBytesLoaded() + "/" + g.getBytesTotal() + "\n";
 var m = g.getInstanceAtDepth(-9604);
 s += "Depth -9604: " + m + " frame: " + m._currentframe + " visible: " + m._visible + "\n";
 var count = 0;
 for (var k in g) {
  if (typeof(g[k]) == "movieclip" && count < 10) {
   s += k + ":d" + g[k].getDepth() + ":f" + g[k]._currentframe + " ";
   count++;
  }
 }
 _root.status.text = s;
};
