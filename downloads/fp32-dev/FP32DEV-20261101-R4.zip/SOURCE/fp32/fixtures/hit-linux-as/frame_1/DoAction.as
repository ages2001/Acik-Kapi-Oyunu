stop();
_global.fpHitOriginal = MovieClip.prototype.hitTest;
_global.fpHitLog = "No positive star-coin hit recorded.";
_global.fpHitCount = 0;
MovieClip.prototype.hitTest = function() {
 var answer = _global.fpHitOriginal.apply(this, arguments);
 if (answer && this._name == "box" && this._parent.StarCoinNum != undefined) {
  var p = this._parent;
  var b = this.getBounds(_level0.game);
  _global.fpHitCount++;
  _global.fpHitLog = "Hit " + _global.fpHitCount + " coin=" + p.StarCoinNum + " target=" + this + "\n";
  _global.fpHitLog += "point=" + arguments[0] + "," + arguments[1] + " shape=" + arguments[2] + "\n";
  _global.fpHitLog += "bounds=" + b.xMin + "," + b.yMin + " to " + b.xMax + "," + b.yMax + " visible=" + p._visible + "\n";
  _global.fpHitLog += "rootFrame=" + _level0.game._currentframe + " char=" + _level0.game.Course.Char._x + "," + _level0.game.Course.Char._y;
 }
 return answer;
};
_root.createEmptyMovieClip("game",1);
_root.game._lockroot = true;
_root.game.loadMovie("file:///workspace/attachments/76eae39b-248c-45ba-9c38-3f9ce76b0cae/Super_Mario_63_2010.swf");
_root.createTextField("status",100000,0,303,450,130);
_root.status.background = true;
_root.status.backgroundColor = 16777215;
_root.status.textColor = 0;
_root.lastUpdate = 0;
_root.onEnterFrame = function() {
 if (getTimer() - _root.lastUpdate < 1000) { return; }
 _root.lastUpdate = getTimer();
 _root.status.text = "HIT DIAGNOSTIC / game file unmodified\n" + _global.fpHitLog;
};
