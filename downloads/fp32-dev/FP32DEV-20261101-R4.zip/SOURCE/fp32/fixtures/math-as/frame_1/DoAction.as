stop();
createTextField("status",1000,0,0,450,300);
status.background = true; status.backgroundColor = 16777215; status.textColor = 0;
function eq(a,b) { return a == b; }
function lt(a,b) { return a < b; }
function add(a,b) { return a + b; }
var z = Number("0"); var o = Number("1"); var nan = Number("x");
status.text = "Original FP32 AS2 numeric diagnostic\n" +
 "0 == 1: " + eq(z,o) + " (expected false)\n" +
 "1 == 1: " + eq(o,o) + " (expected true)\n" +
 "0 < 1: " + lt(z,o) + " (expected true)\n" +
 "1 < 0: " + lt(o,z) + " (expected false)\n" +
 "NaN == 1: " + eq(nan,o) + " (expected false)\n" +
 "NaN < 1: " + lt(nan,o) + " (AVM1: undefined)\n" +
 "undefined == false: " + eq(undefined,false) + "\n" +
 "0 + 1: " + add(z,o) + " (expected 1)\n" +
 "isNaN(Number(x)): " + isNaN(nan) + " (expected true)\n" +
 "1/0: " + (o/z) + " / 0/0: " + (z/z) + "\n" +
 "Math.sin(1): " + Math.sin(o);
