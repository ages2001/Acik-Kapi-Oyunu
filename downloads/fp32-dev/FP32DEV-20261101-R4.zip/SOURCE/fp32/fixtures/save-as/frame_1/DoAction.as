stop();
_root.createTextField("status",1000,10,10,430,230);
_root.status.background = true;
_root.status.backgroundColor = 16777215;
_root.status.textColor = 0;
_root.store = SharedObject.getLocal("Ages2001FP32PersistenceProbe");
_root.loaded = _root.store.data.counter;
_root.counter = isNaN(Number(_root.loaded)) ? 0 : Number(_root.loaded);
if (_root.loaded == undefined) { _root.counter = 0; }
_root.result = "No write requested";
_root.update = function() {
 _root.status.text = "FP32 save persistence test\nSharedObject type: " + typeof(_root.store) + " / " + typeof(SharedObject) + "\nLoaded from disk: " + _root.loaded + "\nCurrent counter: " + _root.counter + "\nFlush result: " + _root.result + "\nPress S to increment and save.\nClose and reopen this same SWF to verify.\nRepeat after restarting Windows.\nOnly this probe's own SharedObject is modified.";
};
_root.listener = new Object();
_root.listener.onKeyDown = function() {
 if (Key.getCode() == 83) {
  _root.counter++;
  _root.store.data.counter = _root.counter;
  _root.store.data.marker = "FP32-PERSISTENCE-V1";
  _root.result = _root.store.flush();
  _root.update();
 }
};
Key.addListener(_root.listener);
_root.update();
