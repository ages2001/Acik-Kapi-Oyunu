stop();
var s = "Shape hit tests / original AVM1 / SWF8\n";
function box(n,x,y,triangle) {
 var r = _root.createEmptyMovieClip(n,_root.getNextHighestDepth());
 r.beginFill(16711680);r.moveTo(x,y);r.lineTo(x+60,y);
 if(!triangle){r.lineTo(x+60,y+60);}
 r.lineTo(x,y+60);r.lineTo(x,y);r.endFill();return r;
}
function check(r) {
 s += r._name + " NN=" + r.hitTest(NaN,NaN,true) + " N0=" + r.hitTest(NaN,0,true) + " 0N=" + r.hitTest(0,NaN,true) + " II=" + r.hitTest(Infinity,Infinity,true) + "\n";
}
check(box("origin",0,0,false));
check(box("positive",100,100,false));
check(box("negative",-30,-30,false));
check(box("triOrigin",0,0,true));
check(box("triPositive",100,100,true));
check(box("triNegative",-30,-30,true));
var moved=box("translated",0,0,false);moved._x=100;moved._y=100;check(moved);
moved._name="scaled";moved._xscale=70;moved._yscale=30;check(moved);
moved._name="rotated";moved._rotation=30;check(moved);
var bound = moved.getBounds(_root);
s += "Finite inside tri=" + _root.triPositive.hitTest(110,110,true) + " outside=" + _root.triPositive.hitTest(10,10,true) + "\n";
_root.createTextField("report",100000,0,0,450,433);report.background=true;report.backgroundColor=16777215;report.textColor=0;report.text=s;
