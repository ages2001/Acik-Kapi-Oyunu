FP32 LEGACY PORT - DEVELOPMENT CHECKPOINT - 2026-11-01 R4

THIS IS NOT A COMPLETED CROSS-PLATFORM PORT. THE INSTALLER IS NT 3.1 ONLY.
Original FP32 playback has been verified only for the specific NT 3.1 tests
listed below. Keep a working installation and guest disk backup.

Contents:
  SETUP32.EXE: single-file NT 3.1 development installer, default C:\FP32.
  NT31-DIAGNOSTIC/APP/FP32.EXE: adapted original player, EXE alone in this folder.
  NT31-DIAGNOSTIC/*.DLL: compatibility DLLs, including the adapted RSA provider.
  NT31-DIAGNOSTIC/*.SWF: small test fixtures; user games are not bundled here.
  COMPONENTS: independent test executables and DEBUG32.EXE.
  WINSIMD-QUERY: the required query-bearing NT31 XMM research driver and loader.
  SOURCE: source/scripts and unmodified supplied FP32 and RSA provider inputs.
  EVIDENCE: logs, screenshots, analysis and a short captured audio recording.
  CHECKPOINT: earlier FP10 source/build snapshot; not a completed release.

Copy NT31-DIAGNOSTIC contents and COMPONENTS into C:\FP32 on the prepared
NT 3.1 guest. The separate WINSIMD XMM research prerequisite is not silently
installed. On a disposable supported NT31 test VM, copy WINSIMD-QUERY's
XMMGUARD.SYS and LOADXMM.EXE into C:\FP32, then run LOADXMM.EXE before the
player. Read GUARD.LOG and the included WINSIMD notes. The older public R2
guard lacks the required readiness query. A running driver cannot be replaced
without rebooting. The research hook's installation-rendezvous limitation
remains; this is not a production SIMD release.
This package includes no guest disk, OS kernel, HAL, compiler or
firmware. RSABASE.DLL is the sole bundled original system-provider build input.
Every payload hash is listed in SHA256SUMS.txt and verified during packaging.
The source paths in the following notes are relative to SOURCE in this ZIP.

# Original Flash Player 32 legacy port work

Target: the user-supplied Adobe Flash Player 32.0.0.465 standalone executable.
SHA-256: a4b333ac1da12026989549015303d82231982838bccfb544ba5fd188746066f0.
The original Adobe engine remains the runtime; no replacement SWF engine is used.

This is a development checkpoint, not a completed cross-platform port or setup.
Original FP32 now opens its window and plays specific SWF fixtures on NT 3.1.
The other requested operating systems do not yet run the complete FP32 runtime.
See `reports/CURRENT-STATE.json` for the current test scope and outstanding work.

## Actual NT 3.1 results, 2026-11-01

The earlier checkpoint used QEMU TCG, Pentium III with SSE2, one CPU, 64 MiB
RAM and classic VGA. The current cloned game lab uses the supplied boot files
and reports 512 MiB, with WINVBE 800x600x32 and AC97/AUDIONT 1.1. WINSIMD 1.1 enables
CPU features; the separate WINSIMD 1.2 research driver preserves XMM/MXCSR across
thread switches. The current research binary passes four-worker tests on this
UP guest and on an exact supported four-CPU NT 3.1 kernel. It is not production
support for arbitrary kernels and does not preserve YMM/ZMM.

Verified with the original player:

- The native player window, menu bar and Ctrl+O Open dialog appear.
- SMOKE.SWF renders its red stage; ACTION.SWF changes a sprite's position over time.
- AS3REF.SWF renders the ActionScript 3 reference shapes after the critical-section
  adaptation. This is one AVM2 graphics fixture, not full AS3 coverage.
- AVTEST.SWF produces sound through the actual QEMU AC97 output. The expected
  440 Hz PCM tone is present; a recording and measurement are included.
- VIDEO.SWF decodes and displays different video frames. This small FLV1/MP3
  fixture does not establish H.264, every codec, frame rate or long-term stability.
- The SM63 CPU-feature candidate fixes the false title-scene Star Coin overlay.
  The untouched game has reached the fourth tutorial area with real movement,
  jumps, ordinary coin collection and hover-FLUDD acquisition/use. The real
  progress save/reopen check is still pending; roughly 3-8 FPS is inadequate.
- The query-aware build installs and opens on the exact four-CPU NT3.1 MP copy.
  Its shape-hit-test fixture passes. An AS2 SharedObject fixture saves and reads
  counter 1 across both player restart and Windows reboot. This is not a full
  SM63 save or SMP gameplay/performance pass.

VGA16 quantizes/dithers the source colors. No FP32 GPU acceleration is validated.
No acceptable game-performance claim or complete playthrough is made.

## Compatibility changes that enabled playback

The supplied NT4 SP1 RSA base CSP is adapted as FPRSA.DLL. Its executable sections
are unchanged. FPCRK.DLL supplies three kernel compatibility exports. F32A.DLL
bridges ephemeral PROV_RSA_FULL CryptAcquireContextA/W, CryptGenRandom and
CryptReleaseContext to that real provider. Seventeen native guest checks pass,
including four concurrent workers generating 512 KiB. This is functional testing,
not a cryptographic audit; persistent containers and the wider CryptoAPI remain
unsupported. See `reports/CRYPTO-PROVIDER.md`.

Proxy generation now preserves 36 original ordinal import contracts, including
Winsock WSAStartup ordinal 115 and OLE Automation string exports. Native/proxy
Winsock name and ordinal lookups resolve to the same function and startup succeeds.
GetSystemWow64DirectoryW reports the documented absence of WOW64 on a 32-bit OS.

On NT 3.1, SetWindowLong with GWL_WNDPROC and NULL installs a NULL procedure.
The newer contract leaves the old procedure intact. Adapting that case prevents
a real FP32 teardown crash; ten native-window checks pass. Other SetWindowLong
operations remain native. See `reports/NULL-WNDPROC.md`.

TryEnterCriticalSection interoperates with NT 3.1's native critical-section
ownership, recursion and waiter protocol. Fourteen native checks pass, including
8,000 protected increments by four mixed native/try workers without overlapping
owners. This removed the next actual AS3 blocker. See `reports/TRY-CRITICAL-SECTION.md`.

The reused graphics/input adapters include the earlier FP10 bitmap and input-queue
fixes. Their earlier tests do not automatically establish all FP32 game behavior.
Missing exports still stop diagnostic execution; they do not pretend to succeed.

## Component tests on other systems

F32FILE.DLL passes 12 file checks on NT 3.1, Windows 95 RTM and Windows 3.1 with
Win32s 1.30c. Unicode names must round-trip through the native ANSI code page.
F32CORE.DLL passes seven checks on NT 3.1 and Windows 95, including four real
producer threads and exactly-once retrieval of 2,048 nodes.
The command-line adapter passes 33 NT 3.1 checks; shell execution passes nine.

These are component tests, not complete player compatibility. Win32s CreateThread
returns ERROR_CALL_NOT_IMPLEMENTED, EnterCriticalSection is a no-op and native
WaitForSingleObject returns immediately. A distinct threading/synchronization
runtime is still needed there. Full Win9x Unicode/API proxy integration is pending.
NT 3.51 and NT4 runtime validation remains pending. NT 3.5, Win98 and ME images
have not been staged, so those versions must not be reported tested.

## SSE2 and REA analysis

FP32 retains SSE2. The hardware gate reports an English error and exits without
hardware SSE2. CPUID support alone does not prove that the OS preserves XMM state.
Original WINSIMD 1.1 failed a two-thread preservation test; the research guard is
therefore a separate prerequisite on this exact NT 3.1 configuration.

The earlier one-site LFENCE adapter passed 512 emulator contract cases. The next
original fault was MOVD/CVTDQ2PS/MOVSS at 0x0044b3a0. REA 6.8.0/Ghidra 12.1.4
recovered its integer-to-float initialization using a runtime-derived function
seed. Static analysis contains thousands of functions with SIMD instructions;
this is not a few isolated replacements or a validated non-SSE2 FP32 path.
REA evidence is decompiler output, not recovered Adobe source. Runtime traces and
native API tests determine which compatibility contracts are implemented.

## Reproduction

The current source includes the SM63 CPU-feature correction. On NT31,
it requires the **query-bearing** XMM guard built by
`python winsimd-1.2/scripts/build_nt31_query.py`, not the earlier public R2 guard.
Its output is `winsimd-1.2/out/query-candidate/XMMGUARD.SYS`. The regular
`build_nt31_guard.py` still builds the earlier interface. Install the query
candidate only in a separate test VM with the existing LOADXMM procedure;
the FP32 installer does not yet install this driver. Native UP and four-CPU MP
query checks pass. The MP candidate also passes four workers, 181 affinity
rounds and 640 worker lifetimes without XMM/MXCSR/x87 mismatches. Full SM63
saved-game/performance validation remains pending. See
`reports/query-driver-native-status.json` and `reports/SM63-CPU-FEATURE-NOTES.md`.

Use `/workspace/fp10-analysis-tools/bin/python` in the prepared workspace, with
pefile, capstone, Unicorn, Clang 19, LLD, NASM, MinGW headers/import libraries,
QEMU and mtools. `FP32_ORIGINAL` may select the supplied EXE; its hash is checked.
The CSP builder also verifies the exact supplied NT4 RSABASE.DLL hash.

```
python fp32/analysis/build_file_adapter.py
python fp32/analysis/build_core_adapter.py
python fp32/analysis/build_csp_probe.py
python fp32/analysis/build_nt31.py
python fp32/analysis/lfence_probe.py
python fp32/analysis/build_cpu_gate.py
python fp32/analysis/build_network_guard.py
python fp32/analysis/test_network_guard.py
python fp32/analysis/build_launcher.py
python installer/build.py --product 32
```

Keep FP32.EXE alone in C:\FP32\APP, with the compatibility DLLs in C:\FP32.
The original DLL-neighbor restriction remains intact. The diagnostic invocation is:

```
DEBUG32.EXE /timeout=600 C:\FP32\APP\FP32.EXE -relaunched
```

DEBUG32 sets the parent working directory and stops its child at the selected
limit (default 30 seconds, maximum 600); this intentional exit is not a crash.
Open SWFs using the native Ctrl+O dialog, or use the new parent-directory
FP32.EXE launcher with one file path. The launcher starts APP\FP32.EXE with the
correct DLL working directory and no debugger/time limit. A quoted filename
containing a space renders successfully. Local paths are resolved before changing
the child working directory. Do not add `-relaunched` to a filename argument.
The candidate NT3.1 installer now defaults to C:\FP32 and allows a custom path.
Its default/custom-path wizard, progress and completed installation have been
checked on the MP copy. Other-OS installation remains gated; do not infer a
universal setup from this NT3.1 result.

## Remaining release work

Complete original menu/button/input and representative-game tests, measured
performance, broader audio/video behavior, and SM63 real progress persistence.
The FP32 NT 3.1 installer is under active validation. Cross-platform installation
and final per-OS VGA tests are not complete. Earlier FP10 wizard
sources/checkpoints are retained; they are not an FP32 installer.
The supplied isaac.swf and smbc.swf exceed the environment's 32 MiB transfer limit
and have not been tested. No all-OS support, GPU acceleration, production SIMD
state preservation or completed FP32/FP10 release is implied by this checkpoint.

## Original icon and requested games

R3 selects the original dark-red application logo (group 200), preserving its
high-color frames byte for byte and adding legacy 16-color fallbacks. R2 could
select the SWF document icon. The program shortcut now references the launcher;
the separate uninstaller retains its red cross. See `reports/ORIGINAL-ICON.md`.

Additional test inputs have been downloaded: Final Fantasy Sonic X6, MMS RPG
1-4, Sonic RPG 10 v1.3.6, Mega Man X Virus Mission and Takeover. Their SWF
containers were validated. Bounded NT3.1 menu/intro/input observations are in
`reports/r3-game-followup.json`; these are not full gameplay certifications.
SM63 remains first in the test order. Sources/hashes are in
`reports/GAME-INPUTS.md` and `reports/game-inputs.json`; game files are not
bundled in the development ZIP.

Saved-game storage on NT 3.xx / Win32s must use application-owned UserData, not an assumed OS AppData directory. See [SAVED-GAMES.md](SAVED-GAMES.md) for the contract and current validation limits.

## R3 continuation

Legacy saved-game storage uses installation-owned UserData. The native mapping
regression passes 48 checks and the original player reads the same AS2
SharedObject after application and Windows restarts. Automation BSTR allocation
passes 12 native checks. Routine tracing is opt-in with FP32_TRACE=1; fatal
exception/missing-API diagnostics remain enabled (8 native checks). The launcher
now supplies an absolute working directory when installed at a drive root.

SM63 still creates an unexpected Star Coin overlay after Start. This reproduces
with a fresh movie path and through a diagnostic wrapper; the original SWF is
unmodified. A Linux Adobe projector comparison reached the normal menu, but
this is not a supported-Windows comparison or proof of the cause. Full gameplay
remains blocked. The experimental HeapWalk implementation failed its large
allocation coverage check and is excluded from the product build.

## R4 WinINet compatibility guard

R3 Takeover startup failed at a null InternetOpenA call in the original
executable. REA/Ghidra and the native fault stack identify a cached WinINet
initialization failure. R4 checks the function pointer and initialization state
before using the existing request-failure path. No networking session or
success result is fabricated. The builder pins its input SHA-256 and validates
the patched instructions. All 4,096 x86 contract cases pass at two image bases,
including partial export initialization with a non-null first pointer.
See `reports/WININET-FAILURE-GUARD.md` and the separate native evidence.

The first null-only candidate reached Takeover's menus, campaign map and
non-silent intro audio. Combat was not certified after the loading transition.
Additional bounded R3 results include FFSX6's prologue, MMS RPG 1 dialogue input,
Sonic RPG 10's intro and one Mega Man X Virus Mission Attack turn.
These do not remove the SM63 blocker or establish full game/OS compatibility.
