FP32 LEGACY PORT - DEVELOPMENT CHECKPOINT - 2026-10-30

THIS IS NOT A COMPLETED FLASH PLAYER PORT OR INSTALLER.
The original Adobe Flash Player 32.0.0.465 remains the target engine.
It has not reached its player window or played a SWF on these legacy guests.
Do not replace a working FP10 installation with this checkpoint.

Verified:
  File adapter: 12/12 checks on NT 3.1, Windows 95 RTM, Win3.1 + Win32s 1.30c.
  Core adapter: 7/7 checks on NT 3.1 and Windows 95, real concurrent threads.
  Single LFENCE trampoline: 512 emulator contract checks; guest advances past it.

Unresolved:
  FP32 then faults on MOVD XMM0 at 0x0044b3a0, before opening its GUI.
  Win32s has no native threads; no substitute thread runtime is implemented.
  Other API gaps, full sound/video/input/menu/game tests and FP32 setup remain.
  No FP32 GPU acceleration, full SSE-free operation or all-OS support is claimed.

Contents:
  NT31-DIAGNOSTIC: modified original FP32 plus 18 tracing compatibility proxies.
  COMPONENTS: tested adapters and independent test programs, not the player.
  SOURCE: current FP32 source, required shared FP10 sources and installer sources.
  EVIDENCE: actual logs, reports and guest screenshots, including failed attempts.
  CHECKPOINT: preserved FP10 source/build checkpoint, not a completed FP10 runtime.

On a disposable NT 3.1 test guest, copy NT31-DIAGNOSTIC and COMPONENTS into C:\FP32.
DEBUG32.EXE observes startup and stops a child after 30 seconds; it is diagnostic.
For the one-site CPU adaptation: DEBUG32.EXE C:\FP32\FP32LF.EXE C:\FP32\SMOKE.SWF
FILETEST.EXE must be beside F32FILE.DLL. It writes C:\F32FILE.LOG.
CORETEST.EXE needs C:\FP32\F32CORE.DLL and writes C:\FP32\SLIST.LOG.
CORETEST requires native threads and is not a Win32s thread implementation.
C:\FP32 is test staging, not a finalized default installation path.

SOURCE/fp32/original/FLASH32.EXE is the unmodified supplied player.
SHA-256 a4b333ac1da12026989549015303d82231982838bccfb544ba5fd188746066f0
Build instructions and exact limitations: SOURCE/fp32/README.md and STATUS.json.
No guest OS images, system DLLs, compiler binaries or firmware are bundled.
SHA256SUMS.txt lists every payload file. ZIP verification also checks CRCs.
