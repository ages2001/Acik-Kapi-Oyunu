#define WIN32_LEAN_AND_MEAN
#include <windows.h>
/* Guest-only bounded debugger: observes actual startup faults without changing
   target memory or reporting an unsupported API as successful. */
static HANDLE logh;
static void value(const char*s,DWORD v){char b[160];DWORD n=0,i,w;const char*x="0123456789ABCDEF";while(*s)b[n++]=*s++;b[n++]=' ';for(i=0;i<8;i++)b[n++]=x[(v>>(28-4*i))&15];b[n++]='\r';b[n++]='\n';WriteFile(logh,b,n,&w,0);FlushFileBuffers(logh);}
void WINAPI entry(void){STARTUPINFOA si;PROCESS_INFORMATION pi;DEBUG_EVENT e;DWORD i,start,status;BOOL done=FALSE;static char fallback[]="C:\\FP32\\FP32TEST.EXE C:\\FP32\\SMOKE.SWF";char*command=GetCommandLineA();
 if(*command=='"'){command++;while(*command&&*command!='"')command++;if(*command)command++;}else while(*command&&*command!=' ')command++;while(*command==' ')command++;if(!*command)command=fallback;
 for(i=0;i<sizeof(si);i++)((BYTE*)&si)[i]=0;si.cb=sizeof(si);
 logh=CreateFileA("C:\\FP32\\DEBUG.LOG",GENERIC_WRITE,FILE_SHARE_READ,0,CREATE_ALWAYS,0,0);
 value("Start tick",GetTickCount());
 if(!DeleteFileA("C:\\FP32\\TRACE.LOG")&&GetLastError()!=ERROR_FILE_NOT_FOUND){value("Trace cleanup error",GetLastError());CloseHandle(logh);ExitProcess(2);}
 if(!CreateProcessA(0,command,0,0,FALSE,DEBUG_ONLY_THIS_PROCESS,0,"C:\\FP32",&si,&pi)){value("CreateProcess error",GetLastError());CloseHandle(logh);ExitProcess(1);}
 start=GetTickCount();while(!done){
  if(!WaitForDebugEvent(&e,1000)){if(GetTickCount()-start>30000){value("Watchdog termination",99);TerminateProcess(pi.hProcess,99);}continue;}
  status=DBG_CONTINUE;
  switch(e.dwDebugEventCode){
   case CREATE_PROCESS_DEBUG_EVENT:value("Image base",(DWORD)e.u.CreateProcessInfo.lpBaseOfImage);value("Entry",(DWORD)e.u.CreateProcessInfo.lpStartAddress);if(e.u.CreateProcessInfo.hFile)CloseHandle(e.u.CreateProcessInfo.hFile);break;
   case LOAD_DLL_DEBUG_EVENT:value("DLL base",(DWORD)e.u.LoadDll.lpBaseOfDll);if(e.u.LoadDll.hFile)CloseHandle(e.u.LoadDll.hFile);break;
   case EXCEPTION_DEBUG_EVENT:{BYTE code[16];DWORD n;value("Exception",e.u.Exception.ExceptionRecord.ExceptionCode);value("Address",(DWORD)e.u.Exception.ExceptionRecord.ExceptionAddress);value("First chance",e.u.Exception.dwFirstChance);if(ReadProcessMemory(pi.hProcess,e.u.Exception.ExceptionRecord.ExceptionAddress,code,sizeof(code),&n)){for(i=0;i<n;i+=4)value("Instruction DWORD",*(DWORD*)(code+i));}if(e.u.Exception.ExceptionRecord.ExceptionCode!=EXCEPTION_BREAKPOINT)status=DBG_EXCEPTION_NOT_HANDLED;break;}
   case CREATE_THREAD_DEBUG_EVENT:value("Thread start",(DWORD)e.u.CreateThread.lpStartAddress);CloseHandle(e.u.CreateThread.hThread);break;
   case EXIT_PROCESS_DEBUG_EVENT:value("Exit",e.u.ExitProcess.dwExitCode);done=TRUE;break;
  }
  ContinueDebugEvent(e.dwProcessId,e.dwThreadId,status);
 }
 CloseHandle(pi.hThread);CloseHandle(pi.hProcess);CloseHandle(logh);ExitProcess(0);
}
