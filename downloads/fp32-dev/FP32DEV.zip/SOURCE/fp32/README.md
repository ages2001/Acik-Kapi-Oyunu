# Original Flash Player 32 legacy port work

Active target: the user-supplied Adobe Flash Player 32.0.0.465 standalone EXE.
SHA-256: a4b333ac1da12026989549015303d82231982838bccfb544ba5fd188746066f0.
The user's current instruction supersedes waiting for a completed FP10 milestone.
The FP10 source, host DLLs and validation state were checkpointed first.

This directory contains actual analysis and experimental adapters, not a completed
player or an installer claiming support. The original Adobe engine remains the
runtime; no replacement SWF engine is being introduced.

The initial inventory has 651 imports across immediate and delayed imports.
Relative to the supplied system DLLs, missing export counts are NT 3.1: 205,
NT 3.51: 134, NT 4 SP1: 67, Win95: 150. Win32s has 145 missing exports and at
least 158 imports that resolve to error-120 stubs. Presence of an export does
not prove working semantics, especially for Win9x Unicode exports and Win32s.

Win32s CreateThread explicitly returns failure with ERROR_CALL_NOT_IMPLEMENTED;
its EnterCriticalSection is a no-op and WaitForSingleObject returns immediately.
A Win95 adapter alone therefore cannot establish Flash's concurrent runtime on
Win32s. Thread scheduling, synchronization, Unicode and virtual-memory behavior
need distinct implementation/validation there.

Linear executable-section disassembly finds 74,190 candidate XMM/YMM instructions
and 23 CPUID candidates. This is not a reachability proof and does not establish
that CPU-feature filtering can safely select non-SSE fallbacks in FP32.

Targets remain NT 3.1/3.5x/4+, Win95/98/ME and Win3.1x+Win32s, with sound/video,
original menus, input, requested credits, one installer with editable destination
and progress, two shortcuts, association restoration on uninstall, and final
classic-VGA tests. NT 3.5, Win98 and ME images have not been supplied/staged;
these versions must not be reported tested based on another OS.

## Verified components (2026-10-30)

`F32FILE.DLL` adapts CreateFileW, GetFileAttributesW and DeleteFileW to the native
ANSI filesystem APIs on Win9x/Win32s. Code-page conversion must round-trip exactly;
unrepresentable names fail instead of silently opening a different file. The
same binary passes 12 checks on NT 3.1, Windows 95 RTM and Windows 3.1 + Win32s
1.30c: loading/exports, create, write, seek, read, sharing exclusion, attributes,
existing-file protection, delete, missing-file error, lossy-name rejection and
null-path rejection. These tests use short ASCII paths plus a deliberately
unrepresentable Unicode name; they do not validate all code pages or long paths.

`F32CORE.DLL` supplies SList initialization/push/pop, pointer encoding/decoding
and the NULL-thread-ID adaptation. Seven checks pass on NT 3.1 and Windows 95,
including four real producer threads and exactly-once retrieval of 2,048 nodes.
The process exits normally with code 0 on both systems. This adapter requires
native threads; it does not provide threading for Win32s. Its SList operations
are synchronized by a process-local lock, not lock-free.

The core implementations are included in the NT 3.1 FP32 diagnostic proxy. The
ANSI file adapter is independently validated; a complete Win9x/Win32s proxy set
using it has not yet been integrated or validated.

## Actual FP32 startup result

After implementing InitializeSListHead, the original FP32 code fails on the
Pentium II guest at 0x009b3204 (`LFENCE`). `FP32LF.EXE` adapts only that observed
barrier using a register/flags-preserving CPUID trampoline. Its register, flags,
stack and displaced-load contract passes 512 emulator cases. This does not test
CPU memory ordering or establish a generally SSE-free player.

The guest then reaches another real illegal-instruction fault at 0x0044b3a0:
`MOVD XMM0,[0x010ebb20]`, followed by `CVTDQ2PS` and `MOVSS`. This is before the
player window opens. The FP32 diagnostic build therefore does not play SWFs yet.
The trace file captured alongside the first run predates that run. A fresh run
with DEBUG32 trace cleanup confirms the same fault (`startup-lfence-fresh-debug.txt`)
and creates no missing-API trace. Missing API calls abort explicitly in diagnostic
proxies; they do not pretend to have succeeded.

WINSIMD enables CPU features but does not provide per-thread XMM preservation on
these early systems. The earlier NT 3.1 two-thread test recorded 33/33 register
mismatches; simply enabling SSE2 would not establish correct playback.

## Reproduction in the prepared workspace

Use `/workspace/fp10-analysis-tools/bin/python` for the scripts below. The setup
has pefile, capstone, Unicorn, Clang 19, LLD, NASM, MinGW headers/import libraries,
QEMU and mtools. `FP32_ORIGINAL` can point to the supplied EXE; its SHA-256 is
checked before building or auditing. Guest OS files and compiler binaries are
not included in the diagnostic bundle.

```
python fp32/analysis/build_file_adapter.py
python fp32/analysis/build_core_adapter.py
python fp32/analysis/build_nt31.py
python fp32/analysis/lfence_probe.py
python fp32/analysis/test_lfence_probe.py
```

Run FILETEST.EXE beside F32FILE.DLL on each guest. It writes C:\F32FILE.LOG and
shows its result. CORETEST.EXE expects C:\FP32\F32CORE.DLL, writes
C:\FP32\SLIST.LOG and exits; use RUNWAIT.EXE to record its actual exit status.
These are test tools, not installer shortcuts or substitute players.

`bin/start-win95-fp32-tests.sh` enables local serial automation.
Set `FP10_SERIAL_SOCKET=/workspace/fp10-port/win95/test-serial.sock` for Win95
commands; without it, serial-test.py retains the NT 3.1 default. Windows 95's
supplied image currently does not expose drive A: even with a mounted floppy;
files were copied offline only after QEMU stopped. AC97 is present, but its
Windows 95 sound-driver installation remains pending.
