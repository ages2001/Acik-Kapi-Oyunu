"""Package the full FP32 diagnostic checkpoint; never label it a working port."""
from pathlib import Path
import hashlib
import json
import sys
import zipfile
from original import original_player

root = Path(__file__).resolve().parents[2]
destination = Path(sys.argv[1]) if len(sys.argv) > 1 else root/'deliverables/FP32DEV.zip'
destination.parent.mkdir(parents=True, exist_ok=True)
files = {}
def add(path, name):
    assert path.is_file(), path
    assert name not in files, name
    files[name] = path.read_bytes()

readme = '''FP32 LEGACY PORT - DEVELOPMENT CHECKPOINT - 2026-10-30

THIS IS NOT A COMPLETED FLASH PLAYER PORT OR INSTALLER.
The original Adobe Flash Player 32.0.0.465 remains the target engine.
It has not reached its player window or played a SWF on these legacy guests.
Do not replace a working FP10 installation with this checkpoint.

Verified:
  File adapter: 12/12 checks on NT 3.1, Windows 95 RTM, Win3.1 + Win32s 1.30c.
  Core adapter: 7/7 checks on NT 3.1 and Windows 95, real concurrent threads.
  Single LFENCE trampoline: 512 emulator contract checks; guest advances past it.

Unresolved:
  FP32 then faults on MOVD XMM0 at 0x0044b3a0, before opening its GUI.
  Win32s has no native threads; no substitute thread runtime is implemented.
  Other API gaps, full sound/video/input/menu/game tests and FP32 setup remain.
  No FP32 GPU acceleration, full SSE-free operation or all-OS support is claimed.

Contents:
  NT31-DIAGNOSTIC: modified original FP32 plus 18 tracing compatibility proxies.
  COMPONENTS: tested adapters and independent test programs, not the player.
  SOURCE: current FP32 source, required shared FP10 sources and installer sources.
  EVIDENCE: actual logs, reports and guest screenshots, including failed attempts.
  CHECKPOINT: preserved FP10 source/build checkpoint, not a completed FP10 runtime.

On a disposable NT 3.1 test guest, copy NT31-DIAGNOSTIC and COMPONENTS into C:\\FP32.
DEBUG32.EXE observes startup and stops a child after 30 seconds; it is diagnostic.
For the one-site CPU adaptation: DEBUG32.EXE C:\\FP32\\FP32LF.EXE C:\\FP32\\SMOKE.SWF
FILETEST.EXE must be beside F32FILE.DLL. It writes C:\\F32FILE.LOG.
CORETEST.EXE needs C:\\FP32\\F32CORE.DLL and writes C:\\FP32\\SLIST.LOG.
CORETEST requires native threads and is not a Win32s thread implementation.
C:\\FP32 is test staging, not a finalized default installation path.

SOURCE/fp32/original/FLASH32.EXE is the unmodified supplied player.
SHA-256 a4b333ac1da12026989549015303d82231982838bccfb544ba5fd188746066f0
Build instructions and exact limitations: SOURCE/fp32/README.md and STATUS.json.
No guest OS images, system DLLs, compiler binaries or firmware are bundled.
SHA256SUMS.txt lists every payload file. ZIP verification also checks CRCs.
'''
files['README.txt'] = readme.encode('ascii')
add(root/'fp32/reports/CURRENT-STATE.json','STATUS.json')
add(original_player(),'SOURCE/fp32/original/FLASH32.EXE')
add(root/'fp32/checkpoints/fp10-before-fp32.zip','CHECKPOINT/fp10-before-fp32.zip')
for name in ('FP32TEST.EXE','FP32LF.EXE'):
    add(root/'fp32/build'/name,'NT31-DIAGNOSTIC/'+name)
proxies = json.loads((root/'fp32/reports/build-proxies.json').read_text())
for row in proxies:
    add(root/'fp32/build'/row['proxy'],'NT31-DIAGNOSTIC/'+row['proxy'])
for name in ('F32FILE.DLL','F32CORE.DLL','FILETEST.EXE','CORETEST.EXE','CAPS32.EXE','DEBUG32.EXE','SLIST32.EXE'):
    add(root/'fp32/build'/name,'COMPONENTS/'+name)
add(root/'compat/RUNWAIT.EXE','COMPONENTS/RUNWAIT.EXE')
add(root/'compat/SMOKE.SWF','NT31-DIAGNOSTIC/SMOKE.SWF')
for folder in ('fp32/analysis','fp32/compat','compat','analysis','bin','installer'):
    for p in sorted((root/folder).iterdir()):
        if p.is_file() and p.suffix.lower() in ('.py','.c','.h','.asm','.json','.sh','.md','.txt','.rc','.ico','.tsv'):
            add(p,'SOURCE/'+p.relative_to(root).as_posix())
add(root/'fp32/README.md','SOURCE/fp32/README.md')
add(root/'bin/rea','SOURCE/bin/rea')
add(root/'bin/run-tool','SOURCE/bin/run-tool')
for p in sorted((root/'fp32/reports').iterdir()):
    if p.is_file() and p.suffix.lower() in ('.json','.txt','.md','.log'):
        add(p,'EVIDENCE/'+p.name)
for name in json.loads(files['STATUS.json'])['test_screenshots']:
    add(root/name,'EVIDENCE/screenshots/'+Path(name).name)
manifest = {name:hashlib.sha256(data).hexdigest() for name,data in sorted(files.items())}
files['SHA256SUMS.txt'] = ''.join(f'{digest}  {name}\n' for name,digest in manifest.items()).encode('utf8')
with zipfile.ZipFile(destination,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,data in sorted(files.items()): z.writestr(name,data)
with zipfile.ZipFile(destination) as z:
    assert z.testzip() is None
    for name,digest in manifest.items(): assert hashlib.sha256(z.read(name)).hexdigest()==digest, name
receipt={'file':destination.name,'bytes':destination.stat().st_size,
         'sha256':hashlib.sha256(destination.read_bytes()).hexdigest(),'payload_files':len(manifest),
         'verification':'Every ZIP CRC and every payload SHA-256 verified.',
         'completed_port':False,'player_playback_verified':False}
destination.with_suffix('.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
