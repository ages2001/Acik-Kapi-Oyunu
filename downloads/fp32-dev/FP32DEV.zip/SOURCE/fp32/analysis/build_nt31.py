"""Build an NT 3.1 diagnostic adaptation of original FP32; never fake missing APIs."""
from pathlib import Path
import ast
import hashlib
import json
import subprocess
import sys
import pefile
from original import original_player

root = Path(__file__).resolve().parents[2]
work = root/'fp32'
out = work/'build'
src = original_player()
tool = root/'tools/usr/bin'
libs = root/'tools/usr/i686-w64-mingw32/lib'
out.mkdir(exist_ok=True)
def run(args):
    subprocess.run([str(a) for a in args], check=True)
def compile_c(name, flags=()):
    run([tool/'clang-19', '--target=i686-w64-windows-gnu', '-isystem', root/'tools/usr/share/mingw-w64/include',
         '-march=i386', '-mno-sse', '-mno-sse2', '-ffreestanding', '-fno-stack-protector', '-fno-builtin',
         '-Os', *flags, '-c', out/(name+'.c'), '-o', out/(name+'.obj')])

# Reuse the FP10 API implementations without running or overwriting its build.
metadata = {}
for node in ast.parse((root/'compat/build_trace.py').read_text()).body:
    if isinstance(node, ast.Assign):
        for target in node.targets:
            if isinstance(target, ast.Name) and target.id in ('implemented','user_impl','gdi_impl','ole_impl'):
                metadata[target.id] = ast.literal_eval(node.value)
sources = ['trace', 'kernel', 'locale', 'user', 'gdi', 'registry', 'ole']
for name in sources:
    text = (root/'compat'/f'{name}.c').read_text()
    text = text.replace(r'C:\\FP10\\', r'C:\\FP32\\')
    if name == 'user':
        text = text.replace('Flash Player 10.3.183.90', 'Flash Player 32.0.0.465').replace('About Flash Player 10', 'About Flash Player 32')
    (out/(name+'.c')).write_text(text)
    compile_c(name, ['-DFP_SOFTWARE_RGB'] if name == 'gdi' else [])
(out/'trace-gdi.c').write_text((out/'trace.c').read_text())
compile_c('trace-gdi', ['-DFP_GDI'])

extra = {}
extra_source = work/'compat/kernel_extra.c'
if extra_source.exists():
    (out/'kernel_extra.c').write_text(extra_source.read_text())
    compile_c('kernel_extra')
    extra = json.loads((work/'compat/kernel_extra_exports.json').read_text())
metadata['implemented'].update(extra)
impl = {'kernel32.dll': metadata['implemented'], 'user32.dll': metadata['user_impl'],
        'gdi32.dll': metadata['gdi_impl'], 'ole32.dll': metadata['ole_impl'],
        'advapi32.dll': {'RegCreateKeyExA':36, 'RegCreateKeyExW':36}}
objects = {'kernel32.dll':['kernel','locale'] + (['kernel_extra'] if extra else []),
           'user32.dll':['user'], 'gdi32.dll':['gdi'], 'ole32.dll':['ole'], 'advapi32.dll':['registry']}
names = {'kernel32.dll':'F32K.DLL', 'advapi32.dll':'F32A.DLL', 'user32.dll':'F32U.DLL',
         'gdi32.dll':'F32G.DLL', 'ole32.dll':'F32O.DLL', 'oleaut32.dll':'F32OA.DLL',
         'comdlg32.dll':'F32CD.DLL', 'shell32.dll':'F32S.DLL', 'ws2_32.dll':'F32W.DLL',
         'shlwapi.dll':'F32SH.DLL', 'mscms.dll':'F32CM.DLL', 'wininet.dll':'F32I.DLL',
         'crypt32.dll':'F32C.DLL', 'urlmon.dll':'F32R.DLL', 'version.dll':'F32V.DLL',
         'winmm.dll':'F32M.DLL', 'dsound.dll':'F32D.DLL', 'psapi.dll':'F32P.DLL'}
p = pefile.PE(str(src))
native = {f.name.lower():f for f in (root/'nt31/system32').iterdir() if f.is_file()}
report = []
for kind, entries in [('load',p.DIRECTORY_ENTRY_IMPORT), ('delay',p.DIRECTORY_ENTRY_DELAY_IMPORT)]:
    for lib in entries:
        key = lib.dll.decode().lower()
        target = names[key]
        provider = 'wsock32.dll' if key == 'ws2_32.dll' else key
        available = set()
        if provider in native:
            q = pefile.PE(str(native[provider]))
            for e in q.DIRECTORY_ENTRY_EXPORT.symbols:
                available.add('#'+str(e.ordinal))
                if e.name:
                    available.add(e.name.decode())
        defs = ['LIBRARY '+target, 'EXPORTS']
        assembly = ['bits 32', 'section .text', 'extern _FpMissing@8']
        missing = []
        for idx, item in enumerate(lib.imports):
            name = item.name.decode() if item.name else '#'+str(item.ordinal)
            exported = name if item.name else 'ordinal'+str(item.ordinal)
            ordinal = '' if item.name else f' @{item.ordinal} NONAME'
            if name in impl.get(key, {}):
                defs.append(f'{exported}=_fp_{name}@{impl[key][name]}{ordinal}')
            elif name in available:
                defs.append(f'{exported}={provider[:-4]}.{name}{ordinal}')
            else:
                missing.append(name)
                defs.append(f'{exported}=missing{idx}{ordinal}')
                assembly += [f'global _missing{idx}',f'_missing{idx}:','mov eax,[esp]','push eax',
                             f'push label{idx}','call _FpMissing@8','int3','section .rdata',
                             f"label{idx}: db '{key}!{name}',0",'section .text']
        stem = target[:-4]
        (out/(stem+'.def')).write_text('\n'.join(defs)+'\n')
        (out/(stem+'.asm')).write_text('\n'.join(assembly)+'\n')
        run([tool/'nasm','-f','win32',out/(stem+'.asm'),'-o',out/(stem+'.obj')])
        run([tool/'lld-link-19','/nologo','/dll','/subsystem:windows,3.10','/osversion:3.10',
             '/entry:DllMain@12','/nodefaultlib','/safeseh:no','/machine:x86',
             '/def:'+str(out/(stem+'.def')),'/out:'+str(out/target),
             out/('trace-gdi.obj' if key=='gdi32.dll' else 'trace.obj'),out/(stem+'.obj'),
             *[out/(n+'.obj') for n in objects.get(key,[])],
             *[libs/('lib'+n+'.a') for n in ('kernel32','user32','gdi32','advapi32')]])
        q = pefile.PE(str(out/target))
        for e in q.DIRECTORY_ENTRY_EXPORT.symbols:
            if e.forwarder and e.forwarder.startswith(b'_'):
                assert e.forwarder.startswith(('_'+provider[:-4]+'.').encode())
                q.set_bytes_at_rva(e.address,e.forwarder[1:]+b'\0')
        q.write(str(out/target))
        address = lib.struct.Name if kind=='load' else lib.struct.szName
        assert len(target) <= len(lib.dll)
        if kind=='delay':
            assert lib.struct.grAttrs & 1, 'Expected RVA-based delay descriptor'
        p.set_bytes_at_rva(address,target.encode()+bytes(len(lib.dll)+1-len(target)))
        report.append({'kind':kind,'original':key,'proxy':target,'unimplemented_calls_abort':missing})

# This is a diagnostic copy: changing header minimums does not assert OS support.
p.OPTIONAL_HEADER.MajorOperatingSystemVersion = 3
p.OPTIONAL_HEADER.MinorOperatingSystemVersion = 10
p.OPTIONAL_HEADER.MajorSubsystemVersion = 3
p.OPTIONAL_HEADER.MinorSubsystemVersion = 10
p.OPTIONAL_HEADER.DATA_DIRECTORY[4].VirtualAddress = 0
p.OPTIONAL_HEADER.DATA_DIRECTORY[4].Size = 0
p.write(str(out/'FP32TEST.EXE'))
sys.path.insert(0,str(root/'analysis'))
from pad_legacy_pe import pad_image
padding = [pad_image(out/'FP32TEST.EXE')]+[pad_image(out/n) for n in names.values()]
(work/'reports/build-proxies.json').write_text(json.dumps(report,indent=2)+'\n')
(work/'reports/build-padding.json').write_text(json.dumps(padding,indent=2)+'\n')
manifest = {n:hashlib.sha256((out/n).read_bytes()).hexdigest() for n in ['FP32TEST.EXE',*names.values()]}
(work/'reports/build-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('Built diagnostic FP32 plus',len(names),'proxies; unimplemented calls abort, CPU code unchanged.')
