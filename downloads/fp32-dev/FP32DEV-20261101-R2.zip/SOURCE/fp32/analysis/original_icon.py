"""Preserve the original player's first icon group without redrawing it."""
import hashlib
import json
import struct
import subprocess
import pefile
from original import original_player, SHA256


def resources(path):
    pe = pefile.PE(str(path))
    result = {}
    for kind in pe.DIRECTORY_ENTRY_RESOURCE.entries:
        if kind.id not in (3, 14):
            continue
        for name in kind.directory.entries:
            language = name.directory.entries[0]
            data = language.data.struct
            result[kind.id, name.id] = pe.get_data(data.OffsetToData, data.Size)
    return result


def first_group(path):
    data = resources(path)
    group_id = min(key[1] for key in data if key[0] == 14)
    group = data[14, group_id]
    count = struct.unpack_from('<H', group, 4)[0]
    entries = []
    for index in range(count):
        entry = group[6 + index * 14:20 + index * 14]
        icon_id = struct.unpack_from('<H', entry, 12)[0]
        frame = data[3, icon_id]
        assert len(frame) == struct.unpack_from('<I', entry, 8)[0]
        entries.append((entry[:12], frame))
    return group_id, entries


def prepare_icon(out, tools):
    # Keep every original group and ID: NT 3.1 icon selection differs from
    # modern Windows when the first group contains only 32-bit images.
    data = resources(original_player())
    lines = ['LANGUAGE 9, 1']
    for (kind, resource_id), payload in sorted(data.items()):
        path = out / f'original-icon-{kind}-{resource_id}.bin'
        path.write_bytes(payload)
        lines.append(f'{resource_id} {kind} "{path.as_posix()}"')
    rc = out / 'original-icon.rc'
    rc.write_text('\n'.join(lines) + '\n')
    subprocess.run([str(tools/'bin/i686-w64-mingw32-windres'),
                    '--preprocessor='+str(tools/'bin/clang-19'),
                    '--preprocessor-arg=-E', '--preprocessor-arg=-x',
                    '--preprocessor-arg=c', '-i', str(rc), '-O', 'coff',
                    '-o', str(out/'original-icon.obj')], check=True)


def verify_icon(executable, report):
    assert resources(original_player()) == resources(executable), 'Icon resource mismatch'
    source_id, original = first_group(original_player())
    output_id, embedded = first_group(executable)
    assert original == embedded, 'Launcher icon differs from the supplied player'
    report.write_text(json.dumps({
        'source_sha256': SHA256, 'source_group': source_id,
        'launcher_group': output_id, 'all_frames_byte_identical': True,
        'all_icon_and_group_resources_byte_identical': True,
        'resource_count': len(resources(executable)),
        'frames': [{'width': meta[0] or 256, 'height': meta[1] or 256,
                    'bytes': len(frame), 'sha256': hashlib.sha256(frame).hexdigest()}
                   for meta, frame in original],
        'launcher_sha256': hashlib.sha256(executable.read_bytes()).hexdigest()
    }, indent=2) + '\n')
