# FP32 legacy-port development checkpoint

[Download the latest combined FP10 + FP32 R2 runtime/source ZIP](FP10-FP32-20261102-R2-RUNTIME-DEV.zip?raw=true) (12,300,559 bytes). Both complete runtime directories, sources and native test evidence are included. This remains **a development build, not a finished port or universal installer**. Current diagnostic API gaps: **FP10 49 / FP32 85**.

R2 adds Unicode number/currency formatting to both players and Winsock create/close events to FP10. Each kernel DLL passes 1,350 reference comparisons per NT3.1/NT3.51 plus 25/19 contract checks; FP10 events pass 19 checks per OS. [Sources, exact checks and limitations](followup/number-format-events-20261102/README.md).

The [preceding combined runtime](FP10-FP32-20261102-RUNTIME-DEV.zip?raw=true) passed SM63 File A-to-B copying and loading after player and Windows restart. Native classic VGA was measured at 640x480x4, but colors remain wrong and gameplay is slow. [Screenshots and save evidence](followup/sm63-mixer-regression-20261102/README.md). SM63 has not been replayed with the latest three functional DLL changes; other runtime differences are PE timestamps/checksums only.

R2 ZIP SHA-256: `4230b1835696a843c5c7c0edc2922cb6a186825e5972eb3610de4d788336c743`. All 44 runtime files and payload hashes were verified.

## Historical R4 installer checkpoint

[Download the complete R4 ZIP](FP32DEV-20261101-R4.zip?raw=true), including
source and the required XMM-query research driver. The
[NT 3.1 development installer](SETUP32-20261101-R4.EXE?raw=true) is also available.
**This is not a completed cross-platform port.** The original Adobe FP32 engine
remains in use. Games and guest OS disks are not bundled.

R4 fixes the false SM63 Star Coin overlay by reporting SSE/SSE2 together with
actual OS context readiness. The newly installed four-CPU NT 3.1 build reaches
the normal menu after Start and file selection after Story. The separate UP
gameplay experiment has now completed the tutorial, delivered the first Shine
in the castle Orb room, saved, closed the player and loaded File A in a new
engine process. The same save also loaded after an orderly Windows restart
and normal cold boot. Castle Grounds loads with one Shine, and the native SOL
bytes are unchanged after both restarts. See [actual SM63 save evidence](followup/sm63-first-save-20261102/README.md).
This session used the diagnostic CPU-feature DLL and existing XMM guard;
it was not a full R4 installer test. Adequate speed remains unverified:
observed UP gameplay was roughly 3-8 FPS.

The installer defaults to `C:\FP32` and supports a custom folder. Its wizard,
progress and installation were checked on the MP copy. It is **NT 3.1 only**
and currently requires a destination without spaces for Program Manager icons.
Next/Back, uninstall and save-retention evidence from R3 remains historical;
R4 does not claim a new complete uninstall/reinstall pass.

## Required XMM prerequisite

Use a disposable supported NT 3.1 test VM. Copy `WINSIMD-QUERY/XMMGUARD.SYS`
and `LOADXMM.EXE` from the ZIP into `C:\FP32`, then run `LOADXMM.EXE` and
check `C:\FP32\GUARD.LOG`. The old public WINSIMD R2 guard does not implement
this readiness query. A running guard cannot be replaced without rebooting.
The player installer does not install this prerequisite automatically.

The query-bearing driver passed four native protocol checks on UP and MP.
On four CPUs, four workers completed 181 affinity rounds with no XMM/MXCSR/x87
mismatches; 640 worker lifetimes also completed with zero failures. Exact-kernel
checks, the 512-entry table and the unresolved installation-rendezvous limit
remain. This is research code, not a universal or production SIMD driver.

## Validation and remaining work

- The installed MP player passes the non-finite shape-hit-test fixture.
- An AS2 SharedObject fixture wrote counter 1 and loaded it after both player
  restart and Windows reboot. This is not a full SM63 save pass. Private
  UserData storage does not require an OS AppData directory.
- The startup gate stops when context readiness is absent and recommends
  Flash Player 10. The WinINet retry guard passes 4,096 emulated contracts;
  full Takeover gameplay/network behavior is not certified.
- Native 4bpp GDI dark red appears pink in both QEMU VGA models tested. The
  independent native color probe reproduces it outside Flash. The icon source
  is unchanged; final VGA color validation remains open.
- R4 has 123 unimplemented imports. The later component development tree has
  118 after the [memory/GUID](followup/memory-guid-20261102/README.md) and
  [thread/affinity](followup/thread-affinity-20261102/README.md) follow-ups.
  Full Win9x, Win32s,
  NT3.5x/NT4 integration, Win32s threading, universal installation, full game,
  menu and media coverage, GPU acceleration and YMM/ZMM preservation are open.

See [R4 changes](R4-CHANGELOG.txt), [status](STATUS.json),
[SM63 evidence](SM63-CPU-FEATURE-NOTES.md),
[XMM query tests](query-driver-native-status.json),
[installer evidence](r4-installer-path-candidate.json),
[MP save test](mp-query-save-fixture.json) and [save storage](SAVED-GAMES.md).
Back up the entire UserData tree, including its name maps.

![New FP32 default path](screenshots/804-fp32-default-path.png)
![SM63 Start after installing R4 on MP](screenshots/822-mp-sm63-menu.png)
![Saved counter after Windows reboot](screenshots/815-mp-save-after-reboot.png)

ZIP: 43,621,446 bytes, 684 payload files.
All ZIP CRCs and payload SHA-256 hashes were verified.
SHA-256: `641fd1765c48e09ce90b70b7c5151d8c3bbd325e3102104783b50483fa90b224`

Installer SHA-256: `107efab3e1e8d296b6f1a722b9188a5250b2e42540e6ad4276e963be603cda3a`

[Historical R3 notes](R3-README.md), [R3 ZIP](FP32DEV-20261101-R3.zip?raw=true)
and [R3 follow-up](R3-FOLLOWUP.md) remain available unchanged. Separate packages:
[WINSIMD R2 research checkpoint](../winsimd-1.2-dev/README.md) and
[NT 3.1 MP patch r2 with source](../ntcpupae-2026-10-30/NTCPUPAE-NT31-FIX-r2.zip?raw=true).

## Mixer component follow-up (2026-11-02)

[Download the FP10/FP32 mixer component and source ZIP](followup/FP10-FP32-MIXER-20261102-COMPONENTS.zip?raw=true). Eight mixer imports per player now pass 40 native checks each on NT3.1 and NT3.51. At that checkpoint the development counts were **FP10 53 / FP32 88**; neither port is complete. The original DirectSound PCM experiment is included separately and stays disabled. [Evidence and limitations](followup/mixer-20261102/README.md). Published full installers remain unchanged.

[ANSI version verification component/source ZIP](followup/FP32-VERSION-ANSI-20261102-COMPONENTS.zip?raw=true): 20 native checks per NT3.1/NT3.51, zero failures. At that checkpoint the counts were **FP10 53 / FP32 87**. [Details](followup/version-ansi-20261102/README.md).
