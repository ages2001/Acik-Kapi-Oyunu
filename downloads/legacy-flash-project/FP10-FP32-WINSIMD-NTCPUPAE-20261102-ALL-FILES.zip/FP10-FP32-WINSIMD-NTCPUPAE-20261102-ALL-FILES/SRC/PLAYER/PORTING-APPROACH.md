# Porting approach and current scope

The player is the supplied original Adobe Flash Player 10.3.183.90 standalone
debug executable. This project does not implement a replacement Flash engine.
Adobe's ActionScript virtual machines, SWF parser, rendering code and media
engine remain in that executable.

Original executable SHA-256:
`c72b5cf816033bb63ab56a5508f372b11672379d5fe537d9aef7cc4cd00565ed`.

The port changes CPU feature dispatch and PE imports/layout, and supplies
compatibility DLLs for Windows API behavior missing or different on early NT.
For example, the DIB bridge implements bitmap memory synchronization and
clipping expected by the original renderer. The setup program, uninstall
program, native API tests and small diagnostic SWFs are project code.
Those test SWFs are not replacement implementations of the player or games.

Super Mario 63 was inspected read-only to understand its button handling.
Its uploaded file and the guest's `C:\FP10\TESTS\MARIO.SWF` have the same SHA-256:
`6f8dc22d74963cb75928fcac6ad67769384c3088bb419f9995e24b81d8411e1c`.
No game modification is used to bypass the input problem.

The current work is an experimental NT 3.1 FP10 port. Tests use a QEMU Pentium II
without SSE/SSE2, but these tests do not prove every possible Flash code path.
Universal OS support, complete menu/game coverage and the FP32 phase are not
complete. The NT 3.1 installer wizard is implemented and tested at two paths;
its embedded runtime still uses the older baseline payload. WINVBE testing uses software display
output; hardware GPU acceleration has not been implemented or verified.

The released R2 ZIP predates the current input queue and GDI clip-snapshot work.
See `reports/INPUT-QUEUE-INVESTIGATION.md` and `reports/GDI-CLIP-CACHE.md` for the
new experimental results and their limits.

REA analysis of the original Flash presentation and bitmap-allocation functions
is recorded in `reports/REA-ORIGINAL-FLASH.md`. New partial scanline uploads are
validated in `reports/GDI-DIRTY-ROWS.md`. These changes are not in the R2 ZIP.
