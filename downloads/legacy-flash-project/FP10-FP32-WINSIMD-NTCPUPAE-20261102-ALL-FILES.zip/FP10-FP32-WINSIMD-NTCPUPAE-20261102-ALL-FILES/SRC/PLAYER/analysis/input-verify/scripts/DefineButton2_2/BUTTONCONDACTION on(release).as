on(release){
   gotoAndStop(2);
   stop();
}
