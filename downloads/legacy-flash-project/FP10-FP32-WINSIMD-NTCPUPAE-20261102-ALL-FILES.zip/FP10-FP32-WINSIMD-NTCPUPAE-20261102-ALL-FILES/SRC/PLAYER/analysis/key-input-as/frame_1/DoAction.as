stop();
_root.createTextField("diagnostic",1000,0,0,440,70);
_root.diagnostic.background = true;
_root.diagnostic.backgroundColor = 16777215;
_root.diagnostic.textColor = 0;
_root.downs = 0;
_root.hits = 0;
_root.keydowns = 0;
_root.keyups = 0;
_root.lastkey = 0;
_root.listener = new Object();
_root.listener.onKeyDown = function() { _root.keydowns++; _root.lastkey = Key.getCode(); };
_root.listener.onKeyUp = function() { _root.keyups++; };
Key.addListener(_root.listener);
var test = _root.createEmptyMovieClip("target",100);
test._x = 160;
test._y = 110;
test.beginFill(16711680);
test.moveTo(0,0);
test.lineTo(120,0);
test.lineTo(120,80);
test.lineTo(0,80);
test.lineTo(0,0);
test.endFill();
test.onEnterFrame = function() {
 this.hl = this.hitTest(_root._xmouse,_root._ymouse,true);
 _root.diagnostic.text = "Mouse: " + _root._xmouse + ", " + _root._ymouse + "  Hit: " + this.hl + "\nDown events: " + _root.downs + "  Accepted: " + _root.hits + "\nKey down/up: " + _root.keydowns + "/" + _root.keyups + " Code: " + _root.lastkey + " Z: " + Key.isDown(90);
};
test.onMouseDown = function() {
 _root.downs++;
 if (this.hl) {
  _root.hits++;
  this.clear();
  this.beginFill(65280);
  this.moveTo(0,0);
  this.lineTo(120,0);
  this.lineTo(120,80);
  this.lineTo(0,80);
  this.lineTo(0,0);
  this.endFill();
 }
};
