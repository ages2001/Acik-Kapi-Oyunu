_root.bgsong.stop();
