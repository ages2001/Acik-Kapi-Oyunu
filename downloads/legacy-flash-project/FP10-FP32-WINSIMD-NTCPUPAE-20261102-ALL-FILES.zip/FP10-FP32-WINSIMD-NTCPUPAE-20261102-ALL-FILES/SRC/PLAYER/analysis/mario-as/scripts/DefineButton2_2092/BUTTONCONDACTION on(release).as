on(release){
   NewgroundsAPI.loadNewgrounds();
}
