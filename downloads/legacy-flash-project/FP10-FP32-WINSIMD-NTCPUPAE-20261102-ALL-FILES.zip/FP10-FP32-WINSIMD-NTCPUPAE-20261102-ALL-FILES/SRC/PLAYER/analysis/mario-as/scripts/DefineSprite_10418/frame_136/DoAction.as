_root.StopBGsong();
