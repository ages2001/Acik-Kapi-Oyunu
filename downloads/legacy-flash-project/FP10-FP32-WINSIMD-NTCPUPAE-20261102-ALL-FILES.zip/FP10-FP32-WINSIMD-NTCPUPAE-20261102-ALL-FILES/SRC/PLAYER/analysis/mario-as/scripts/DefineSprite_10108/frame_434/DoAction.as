Skip = function()
{
   gotoAndStop("end");
};
