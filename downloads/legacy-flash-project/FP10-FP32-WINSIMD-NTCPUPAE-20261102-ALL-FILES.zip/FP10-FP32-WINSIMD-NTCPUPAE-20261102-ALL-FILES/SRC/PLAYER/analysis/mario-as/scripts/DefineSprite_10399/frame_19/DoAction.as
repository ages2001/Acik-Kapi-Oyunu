onEnterFrame = null;
