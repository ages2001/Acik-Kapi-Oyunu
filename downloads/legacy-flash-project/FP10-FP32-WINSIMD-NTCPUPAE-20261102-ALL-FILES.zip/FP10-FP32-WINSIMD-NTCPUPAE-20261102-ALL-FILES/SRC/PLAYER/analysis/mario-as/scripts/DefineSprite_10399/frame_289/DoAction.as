stop();
_parent.play();
