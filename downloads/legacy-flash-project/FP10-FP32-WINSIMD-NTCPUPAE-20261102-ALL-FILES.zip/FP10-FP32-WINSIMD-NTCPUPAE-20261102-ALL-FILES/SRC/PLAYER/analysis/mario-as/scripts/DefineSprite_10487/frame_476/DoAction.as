_root.CinemaMessageFrame = 2;
_root.CinemaMessage = "<b><i>Kamek:</i>  I\'ll offer you and Peach a ride out of here.";
lastframeZ = _root.KeyZ();
stop();
onEnterFrame = function()
{
   if(_root.KeyZ() == true && lastframeZ !== true && _root.CinemaMessageFinished == true)
   {
      _root.CinemaMessage = "";
      onEnterFrame = null;
      play();
   }
   lastframeZ = _root.KeyZ();
};
