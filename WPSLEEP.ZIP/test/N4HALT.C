/* NT4 regression probe: ordinary EWX_SHUTDOWN, no firmware writes. */
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
void *memset(void *p,int c,size_t n){BYTE *q=p;while(n--)*q++=(BYTE)c;return p;}
static char text[1200],value[8];
void WINAPI WinMainCRTStartup(void){
 OSVERSIONINFOA os;HKEY key;DWORD type=0,size=sizeof(value),error,got;HANDLE token=0,device,file;
 TOKEN_PRIVILEGES tp;BOOL accepted=FALSE;
 ZeroMemory(&os,sizeof(os));os.dwOSVersionInfoSize=sizeof(os);
 if(!GetVersionExA(&os)||os.dwPlatformId!=VER_PLATFORM_WIN32_NT||os.dwMajorVersion!=4)ExitProcess(1);
 error=RegOpenKeyExA(HKEY_LOCAL_MACHINE,"Software\\Microsoft\\Windows NT\\CurrentVersion\\Winlogon",0,KEY_QUERY_VALUE,&key);
 if(!error){error=RegQueryValueExA(key,"PowerdownAfterShutdown",0,&type,(BYTE*)value,&size);RegCloseKey(key);}
 if(error||type!=REG_SZ||size!=2||value[0]!='0'||value[1]){
  MessageBoxA(0,"Probe requires PowerdownAfterShutdown REG_SZ 0.","NT4 shutdown probe",MB_OK);ExitProcess(1);
 }
 device=CreateFileA("\\\\.\\PN4LAB",GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,0,OPEN_EXISTING,0,0);
 if(device!=INVALID_HANDLE_VALUE){CloseHandle(device);MessageBoxA(0,"Probe requires the NT4 backend to be absent.","NT4 shutdown probe",MB_OK);ExitProcess(1);}
 error=GetLastError();if(error!=ERROR_FILE_NOT_FOUND&&error!=ERROR_PATH_NOT_FOUND)ExitProcess(1);
 if(MessageBoxA(0,"Invoke ordinary ExitWindowsEx(EWX_SHUTDOWN)?\r\nFlags = 1. No power-off or reboot flag.\r\nPowerdownAfterShutdown = REG_SZ 0. Backend absent.","NT4 shutdown probe",MB_YESNO|MB_DEFBUTTON2|MB_ICONQUESTION)!=IDYES)ExitProcess(0);
 error=0;
 if(!OpenProcessToken(GetCurrentProcess(),TOKEN_ADJUST_PRIVILEGES|TOKEN_QUERY,&token))error=GetLastError();
 else {
  tp.PrivilegeCount=1;tp.Privileges[0].Attributes=SE_PRIVILEGE_ENABLED;
  if(!LookupPrivilegeValueA(0,"SeShutdownPrivilege",&tp.Privileges[0].Luid))error=GetLastError();
  else {SetLastError(0);if(!AdjustTokenPrivileges(token,FALSE,&tp,0,0,0))error=GetLastError();else error=GetLastError();}
 }
 if(!error){accepted=ExitWindowsEx(EWX_SHUTDOWN,0);if(!accepted)error=GetLastError();}
 wsprintfA(text,"WINPOWER NT4 ordinary-shutdown API probe\r\nOS: %lu.%lu build %lu\r\nPowerdownAfterShutdown: REG_SZ 0\r\nBackend: absent\r\nExitWindowsEx flags: 1 (EWX_SHUTDOWN)\r\nAPI accepted: %u\r\nWindows error: %lu\r\n",os.dwMajorVersion,os.dwMinorVersion,os.dwBuildNumber,accepted,error);
 file=CreateFileA("C:\\N4HALT.TXT",GENERIC_WRITE,FILE_SHARE_READ,0,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,0);
 if(file!=INVALID_HANDLE_VALUE){WriteFile(file,text,lstrlenA(text),&got,0);FlushFileBuffers(file);CloseHandle(file);}
 if(token)CloseHandle(token);
 if(error)MessageBoxA(0,text,"NT4 shutdown probe failed",MB_OK|MB_ICONEXCLAMATION);
 ExitProcess(error?1:0);
}
