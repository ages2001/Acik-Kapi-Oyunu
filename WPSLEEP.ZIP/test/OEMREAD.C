/* Replay an in-memory table map. No hardware callbacks are installed. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "FWTABLE.H"
#include "OSNAME.H"
#include "S5.H"

struct dump {
    unsigned char *data;
    size_t length;
};

static int read_dump(void *arg, pn_address pos, unsigned char *out, unsigned count)
{
    const struct dump *dump = (const struct dump *)arg;
    if (pos > dump->length || count > dump->length - (size_t)pos) return 0;
    memcpy(out, dump->data + (size_t)pos, count);
    return 1;
}

static int read_profile(struct dump *dump, const char *name, unsigned work_size,
                        unsigned node_count, unsigned arena_size)
{
    struct pn_amlctx ctx;
    struct pn_acpi caps;
    unsigned char *work = malloc(work_size);
    int decoded;
    memset(&ctx, 0, sizeof(ctx));
    ctx.arena = malloc(arena_size);
    ctx.nodes = calloc(node_count, sizeof(*ctx.nodes));
    if (!work || !ctx.arena || !ctx.nodes) {
        free(work);
        free(ctx.arena);
        free(ctx.nodes);
        return 0;
    }
    ctx.capacity = node_count;
    ctx.arena_size = arena_size;
    pn_amlctx = &ctx;
    decoded = pn_tables(read_dump, dump, 16, &caps, work, work_size);
    printf("%s %d %u %u %u %u %u %u %u %u\n", name, decoded, caps.where,
           caps.reset_ok, caps.off_ok, ctx.tables, ctx.loaded, ctx.prepare,
           caps.sleepa, caps.sleepb);
    pn_amlctx = NULL;
    free(ctx.nodes);
    free(ctx.arena);
    free(work);
    return decoded;
}

int main(int argc, char **argv)
{
    FILE *file;
    long size;
    struct dump dump;
    struct wp_fwtable fadt;
    const unsigned char *header;
    unsigned long table_length;
    char label[32];
    int ok;
    if (argc != 2 || !(file = fopen(argv[1], "rb"))) return 1;
    if (fseek(file, 0, SEEK_END) || (size = ftell(file)) < 4096 + 116 ||
        size > 32L * 1024L * 1024L || fseek(file, 0, SEEK_SET)) {
        fclose(file);
        return 1;
    }
    dump.length = (size_t)size;
    dump.data = malloc(dump.length);
    if (!dump.data || fread(dump.data, 1, dump.length, file) != dump.length) {
        free(dump.data);
        fclose(file);
        return 1;
    }
    fclose(file);
    header = dump.data + 4096;
    table_length = header[4] | ((unsigned long)header[5] << 8) |
                   ((unsigned long)header[6] << 16) | ((unsigned long)header[7] << 24);
    if (table_length > dump.length - 4096 || !wp_fadt(header, table_length, &fadt)) {
        free(dump.data);
        return 2;
    }
    pn_acpitext(2, fadt.revision, fadt.minor_valid ? fadt.minor_revision : 0xffff, label);
    printf("FADT %s\n", label);
    /* These limits match ACPIDOS.C and the full NT AML backend in NTAML.C. */
    ok = read_profile(&dump, "DOS", 60000, 1150, 60000);
    ok &= read_profile(&dump, "NT", 262144, 4096, 262144);
    free(dump.data);
    return ok ? 0 : 1;
}
