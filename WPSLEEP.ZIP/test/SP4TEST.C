/* Run the Microsoft Windows 2000 SP4 CD on a marked, private QA copy.
   The same EXE named V.EXE only records the installed Windows version. */
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
static void report(const char *name, const char *message) {
    DWORD count;
    HANDLE f = CreateFileA(name, GENERIC_WRITE, FILE_SHARE_READ, NULL, OPEN_ALWAYS, 0, NULL);
    if (f == INVALID_HANDLE_VALUE) ExitProcess(2);
    SetFilePointer(f, 0, NULL, FILE_END);
    WriteFile(f, message, lstrlenA(message), &count, NULL);
    WriteFile(f, "\r\n", 2, &count, NULL);
    FlushFileBuffers(f);
    CloseHandle(f);
}
void WINAPI WinMainCRTStartup(void) {
    OSVERSIONINFOA version = {sizeof(version)};
    STARTUPINFOA start = {sizeof(start)};
    PROCESS_INFORMATION process;
    CHAR path[MAX_PATH], cd[] = "D:\\", command[] = "D:\\W2KSP4.EXE -u -n -z", text[256];
    DWORD result, count, zero = 0, status[8];
    HANDLE token, device;
    TOKEN_PRIVILEGES privilege;
    CHAR *shortname;
    if (GetFileAttributesA("A:\\WPGUEST.ID") == INVALID_FILE_ATTRIBUTES || !GetVersionExA(&version) ||
        version.dwPlatformId != VER_PLATFORM_WIN32_NT || version.dwMajorVersion != 5 || version.dwMinorVersion != 0) ExitProcess(1);
    GetModuleFileNameA(NULL, path, MAX_PATH);
    shortname = path + lstrlenA(path);
    while (shortname > path && shortname[-1] != '\\') --shortname;
    wsprintfA(text, "Windows %lu.%lu build %lu, %s", version.dwMajorVersion, version.dwMinorVersion, version.dwBuildNumber, version.szCSDVersion);
    if (!lstrcmpiA(shortname, "V.EXE")) { report("A:\\SP4READ.TXT", text); ExitProcess(0); }
    if (lstrcmpiA(shortname, "P.EXE") || version.szCSDVersion[0]) ExitProcess(3);
    report("A:\\SP4INST.TXT", text);
    for (; cd[0] <= 'Z'; ++cd[0]) {
        if (GetDriveTypeA(cd) != DRIVE_CDROM) continue;
        lstrcpyA(path, cd); lstrcatA(path, "W2KSP4.EXE");
        if (GetFileAttributesA(path) != INVALID_FILE_ATTRIBUTES) break;
    }
    if (cd[0] > 'Z') ExitProcess(4);
    command[0] = cd[0]; report("A:\\SP4INST.TXT", command);
    if (!CreateProcessA(path, command, NULL, NULL, FALSE, 0, NULL, NULL, &start, &process)) ExitProcess(5);
    CloseHandle(process.hThread);
    WaitForSingleObject(process.hProcess, INFINITE);
    if (!GetExitCodeProcess(process.hProcess, &result)) ExitProcess(6);
    CloseHandle(process.hProcess);
    wsprintfA(text, "Microsoft updater exit code %lu", result); report("A:\\SP4INST.TXT", text);
    if (result != 0 && result != 3010) ExitProcess(7);
    device = CreateFileA("\\\\.\\PN5LAB", GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, OPEN_EXISTING, 0, NULL);
    if (device == INVALID_HANDLE_VALUE || !DeviceIoControl(device, 0x22600c, &zero, sizeof(zero), NULL, 0, &count, NULL) ||
        !DeviceIoControl(device, 0x226000, NULL, 0, status, sizeof(status), &count, NULL) || count != sizeof(status) || (status[5] & 1)) ExitProcess(8);
    CloseHandle(device);
    if (!OpenProcessToken(GetCurrentProcess(), TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY, &token)) ExitProcess(9);
    privilege.PrivilegeCount = 1; privilege.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;
    if (!LookupPrivilegeValueA(NULL, SE_SHUTDOWN_NAME, &privilege.Privileges[0].Luid)) ExitProcess(10);
    SetLastError(ERROR_SUCCESS);
    if (!AdjustTokenPrivileges(token, FALSE, &privilege, 0, NULL, NULL) || GetLastError()) ExitProcess(11);
    CloseHandle(token);
    report("A:\\SP4INST.TXT", "Windows owns the service pack installation restart.");
    ExitProcess(ExitWindowsEx(EWX_REBOOT, 0) ? 0 : 12);
}
