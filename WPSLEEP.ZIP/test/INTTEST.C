#include <assert.h>
#include <stdio.h>
#include <string.h>
#include "INTENT.H"
static unsigned char image[0x3c000],stack[256],stub[14];
static unsigned long imagebase;
static int deny;
static void put(unsigned char *p,unsigned long x) {
 p[0]=(unsigned char)x;p[1]=(unsigned char)(x>>8);p[2]=(unsigned char)(x>>16);p[3]=(unsigned char)(x>>24);
}
static int readmem(void *a,unsigned long p,unsigned char *out,unsigned n) {
 (void)a;if(deny)return 0;
 if(p>=imagebase&&p-imagebase<=sizeof(image)&&n<=sizeof(image)-(p-imagebase))memcpy(out,image+(p-imagebase),n);
 else if(p>=0x100000&&p-0x100000<=sizeof(stack)&&n<=sizeof(stack)-(p-0x100000))memcpy(out,stack+(p-0x100000),n);
 else if(p>=0x77000000&&p-0x77000000<=sizeof(stub)&&n<=sizeof(stub)-(p-0x77000000))memcpy(out,stub+(p-0x77000000),n);
 else return 0;
 return 1;
}
int main(void) {
 struct pn_userregs r;unsigned k;
 static const unsigned char c31[]={0x6a,0,0xe8,0x0e,0x4b,0,0,0x56,0xe8,0x18,0x7f,0xff,0xff,0x83,0xe3,2};
 static const unsigned char c351[]={0x6a,0,0xff,0x15,0x9c,0x15,0x16,2,0x53,0xe8,0xb0,0xf7,0xff,0xff};
 static const unsigned char alt[]={0x6a,0,0xff,0x15,0x9c,0x15,0x16,2,0x6a,0,0x6a,0x13};
 static const unsigned char sc[]={0xb8,0,0,0,0,0x8d,0x54,0x24,4,0xcd,0x2e,0xc2,4,0};
 for(k=31;k<=351;k+=320) {
  memset(image,0,sizeof(image));memset(stack,0,sizeof(stack));memcpy(stub,sc,sizeof(sc));
  imagebase=k==31?0x2440000:0x2160000;
  image[0]='M';image[1]='Z';put(image+60,0x80);put(image+0x80,0x4550);image[0x84]=0x4c;image[0x85]=1;image[0x96]=2;
  put(image+0x88,k==31?0x2de1235c:0x3457cc1d);put(image+0xd0,k==31?0x30000:0x2c000);put(image+0xd8,k==31?0x36c2a:0x30f1e);
  put(stub+1,k==31?0x9c:0xad);r.eip=0x7700000b;r.esp=0x100000;r.edi=0x100040;r.ebx=1;
  if(k==31){memcpy(image+0xadeb,c31,sizeof(c31));put(stack,imagebase+0xadf2);}
  else {memcpy(image+0x439b,c351,sizeof(c351));put(stack,imagebase+0x43a3);put(stack+0x94,1);}
  assert(pn_intent(k,&r,readmem,0)==1);
  r.ebx=3;put(stack+0x94,3);assert(pn_intent(k,&r,readmem,0)==2);
  r.ebx=2;put(stack+0x94,2);assert(pn_intent(k,&r,readmem,0)==2);
  r.ebx=0;put(stack+0x94,0);assert(pn_intent(k,&r,readmem,0)==0);
  r.ebx=1;put(stack+0x94,1);deny=1;assert(pn_intent(k,&r,readmem,0)==0);deny=0;
  stub[9]=0;assert(pn_intent(k,&r,readmem,0)==0);stub[9]=0xcd;
  stack[4]=1;assert(pn_intent(k,&r,readmem,0)==0);stack[4]=0;
  image[0x84]^=1;assert(pn_intent(k,&r,readmem,0)==0);image[0x84]^=1;
  stack[0]^=1;assert(pn_intent(k,&r,readmem,0)==0);stack[0]^=1;
  if(k==31){
   /* A moved call site in another build is found by pattern, not offset. */
   memcpy(image+0x9000,c31,sizeof(c31));put(stack,imagebase+0x9007);
   r.ebx=1;assert(pn_intent(k,&r,readmem,0)==1);put(stack,imagebase+0xadf2);
  }
  if(k==351) {
   r.edi=0xffffffffUL;assert(pn_intent(k,&r,readmem,0)==0);r.edi=0x100040;
   memcpy(image+0x42ef,alt,sizeof(alt));put(stack,imagebase+0x42f7);
   r.ebx=5;assert(pn_intent(k,&r,readmem,0)==1);r.ebx=10;assert(pn_intent(k,&r,readmem,0)==1);
   r.ebx=11;assert(pn_intent(k,&r,readmem,0)==2);r.ebx=0;assert(pn_intent(k,&r,readmem,0)==0);
  }
 }
 {
  static const unsigned char c350[]={0x6a,0,0xff,0x15,0x48,0xcd,0x1e,2,0x53,0xe8,0xa0,0x44,0,0};
  memset(image,0,sizeof(image));memset(stack,0,sizeof(stack));memcpy(stub,sc,sizeof(sc));
  imagebase=0x21c0000;image[0]='M';image[1]='Z';put(image+60,0x80);put(image+0x80,0x4550);image[0x84]=0x4c;image[0x85]=1;image[0x96]=2;
  put(image+0x88,0x2fce5340);put(image+0xd0,0x3c000);put(image+0xd8,0x3d37d);
  put(stub+1,0xa5);r.eip=0x7700000b;r.esp=0x100000;r.edi=1;r.ebx=0;
  memcpy(image+0x1c57,c350,sizeof(c350));put(stack,imagebase+0x1c5f);
  assert(pn_intent(350,&r,readmem,0)==1);
  r.edi=8;assert(pn_intent(350,&r,readmem,0)==1);
  r.edi=2;assert(pn_intent(350,&r,readmem,0)==2);
  r.edi=3;assert(pn_intent(350,&r,readmem,0)==2);
  r.edi=0;assert(pn_intent(350,&r,readmem,0)==0);r.edi=1;
  image[0x1c59]^=1;assert(pn_intent(350,&r,readmem,0)==0);image[0x1c59]^=1;
  stub[1]^=1;assert(pn_intent(350,&r,readmem,0)==0);stub[1]^=1;
  stack[0]^=1;assert(pn_intent(350,&r,readmem,0)==0);stack[0]^=1;
  image[0x84]^=1;assert(pn_intent(350,&r,readmem,0)==0);image[0x84]^=1;
  deny=1;assert(pn_intent(350,&r,readmem,0)==0);deny=0;
 }
 assert(pn_intent(352,&r,readmem,0)==0);
 puts("PASS: Winlogon off/restart distinction, alternate caller, unknown image, caller, syscall, nonresident data and overflow rejection");return 0;
}
