"""Test a complete v1.0 rebuild in a fresh source tree with no bin directory."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import tempfile


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--report", type=Path, help="Write a JSON build record outside the project")
    args = parser.parse_args()
    project = Path(__file__).resolve().parent.parent
    if args.report and (args.report.resolve() == project or project in args.report.resolve().parents):
        parser.error("Select a report path outside the project.")
    with tempfile.TemporaryDirectory() as directory:
        work = Path(directory)
        shutil.copytree(project / "src", work / "src")
        shutil.copytree(project / "test", work / "test")
        assert not (work / "bin").exists()
        fresh = work / "built"
        subprocess.run(["sh", str(work / "src/BLDFIRM.SH"), "--all", str(fresh)], check=True)
        subprocess.run(["sh", str(work / "test/CHECK.SH")], check=True)
        ready = project / "bin"
        expected = {file.relative_to(ready) for file in ready.rglob("*") if file.is_file()}
        actual = {file.relative_to(fresh) for file in fresh.rglob("*") if file.is_file()}
        if actual != expected:
            raise ValueError("Rebuilt file set differs from the release")
        digests = {}
        for relative in sorted(expected):
            data = (fresh / relative).read_bytes()
            if data != (ready / relative).read_bytes():
                raise ValueError("Rebuilt file differs: " + relative.as_posix())
            digests["bin/" + relative.as_posix()] = hashlib.sha256(data).hexdigest()
    result = {"release": "WINPOWER v1.0 with sleep controls",
              "inputs": "src and test copied into a new directory. No release binaries in the build tree.",
              "commands": ["sh src/BLDFIRM.SH --all OUTPUT_DIR", "sh test/CHECK.SH"],
              "host_checks": "passed", "files_built_and_compared": len(digests), "sha256": digests}
    if args.report:
        args.report.write_text(json.dumps(result, indent=2) + "\n", encoding="ascii")
    print("Complete source-only rebuild, byte comparisons and host tests passed for %d files." % len(digests))


if __name__ == "__main__":
    main()
