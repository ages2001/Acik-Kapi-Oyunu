#include <assert.h>
#include <stdio.h>
#include <string.h>
#include <limits.h>
#include "S5.H"
static unsigned char ram[65536],work[32768];
static const unsigned char sleep_aml[]={8,'_','S','5','_',0x12,6,2,0x0a,5,0x0a,6};
static const unsigned char safe_aml[]={8,'T','E','S','T',0};
static const unsigned char hook_aml[]={0x14,6,'_','P','T','S',1};
static const unsigned char noop[]={0xa3};
static unsigned reads;
static void put(unsigned char *p,unsigned long v){unsigned i;for(i=0;i<4;i++){p[i]=(unsigned char)v;v>>=8;}}
static void checksum(unsigned char *p,unsigned n,unsigned at){unsigned i;unsigned char sum=0;p[at]=0;for(i=0;i<n;i++)sum=(unsigned char)(sum+p[i]);p[at]=(unsigned char)(0-sum);}
static void header(unsigned char *p,const char *sig,unsigned n){memset(p,0,n);memcpy(p,sig,4);put(p+4,n);p[8]=1;}
static int readram(void *unused,unsigned long addr,unsigned char *out,unsigned n){(void)unused;assert(++reads<10000);if(addr>sizeof(ram)||n>sizeof(ram)-addr)return 0;memcpy(out,ram+addr,n);return 1;}
static void aml_table(unsigned address,const char *signature,const unsigned char *aml,unsigned size){header(ram+address,signature,36+size);memcpy(ram+address+36,aml,size);checksum(ram+address,36+size,9);}
static void setup(unsigned ssdt_count,int dsdt_sleep){
 unsigned i;
 memset(ram,0,sizeof(ram));reads=0;
 memcpy(ram+16,"RSD PTR ",8);put(ram+32,128);checksum(ram+16,20,8);
 header(ram+128,"RSDT",36+4*(ssdt_count+1));put(ram+164,1024);
 for(i=0;i<ssdt_count;i++)put(ram+168+4*i,8192+128*i);
 checksum(ram+128,36+4*(ssdt_count+1),9);
 header(ram+1024,"FACP",276);put(ram+1064,4096);put(ram+1088,0x604);ram[1113]=2;
 /* Reset is independent from sleep eligibility. */
 put(ram+1136,0x400);ram[1140]=1;ram[1141]=8;ram[1143]=1;put(ram+1144,0xcf9);ram[1152]=6;
 checksum(ram+1024,276,9);
 aml_table(4096,"DSDT",dsdt_sleep?sleep_aml:noop,dsdt_sleep?sizeof(sleep_aml):sizeof(noop));
 for(i=0;i<ssdt_count;i++)aml_table(8192+128*i,"SSDT",noop,sizeof(noop));
}
static void check(int off){struct pn_acpi p;reads=0;assert(pn_tables(readram,0,16,&p,work,sizeof(work)));assert(p.reset_ok);assert(p.off_ok==(unsigned)off);if(off)assert(p.sleepa==5&&p.sleepb==6);}
int main(void){
#ifdef PN_MULTI_S5
 struct pn_s5ns state;unsigned a=99,b=98,i;
 /* No answer before a complete namespace; failed additions stay failed. */
 pn_ns_begin(&state);assert(!pn_ns_sleep(&state,&a,&b)&&a==99&&b==98);
 assert(pn_ns_add(&state,sleep_aml,sizeof(sleep_aml)));
 assert(pn_ns_add(&state,safe_aml,sizeof(safe_aml)));
 assert(pn_ns_sleep(&state,&a,&b)&&a==5&&b==6);
 assert(!pn_ns_add(&state,hook_aml,sizeof(hook_aml)));
 assert(!pn_ns_add(&state,noop,sizeof(noop))&&!pn_ns_sleep(&state,&a,&b));
 pn_ns_begin(&state);assert(!pn_ns_add(&state,0,0));assert(!pn_ns_sleep(&state,&a,&b));
#if UINT_MAX > 65535U
 pn_ns_begin(&state);assert(!pn_ns_add(&state,ram,sizeof(ram)));assert(!pn_ns_sleep(&state,&a,&b));
#endif
 assert(!pn_ns_add(0,noop,1)&&!pn_ns_sleep(0,&a,&b));
 pn_ns_begin(&state);for(i=0;i<PN_NS_MAX_TABLES;i++)assert(pn_ns_add(&state,noop,0));
 assert(!pn_ns_add(&state,noop,0));assert(!pn_ns_sleep(&state,&a,&b));
 pn_ns_begin(&state);assert(pn_ns_add(&state,sleep_aml,sizeof(sleep_aml)));
 assert(!pn_ns_add(&state,sleep_aml,sizeof(sleep_aml))&&!pn_ns_sleep(&state,&a,&b));
 /* The 65535-byte bound is per table, not the aggregate namespace. */
 memset(ram,0xa3,65535U);memcpy(ram,sleep_aml,sizeof(sleep_aml));
 pn_ns_begin(&state);assert(pn_ns_add(&state,ram,65535U));
 memset(ram,0xa3,sizeof(sleep_aml));
 for(i=1;i<PN_NS_MAX_TABLES;i++)assert(pn_ns_add(&state,ram,65535U));
 assert(pn_ns_sleep(&state,&a,&b)&&a==5&&b==6);
 assert(!pn_ns_add(&state,noop,0)&&!pn_ns_sleep(&state,&a,&b));
 /* Root methods are rejected even when a later table provides sleep. */
 pn_ns_begin(&state);assert(!pn_ns_add(&state,hook_aml,sizeof(hook_aml)));
 assert(!pn_ns_add(&state,sleep_aml,sizeof(sleep_aml))&&!pn_ns_sleep(&state,&a,&b));
 /* Every truncation of the sole sleep definition fails eligibility. */
 for(i=0;i<sizeof(sleep_aml);i++){
  setup(1,0);aml_table(8192,"SSDT",sleep_aml,i);check(0);
 }
 setup(1,1);aml_table(8192,"SSDT",safe_aml,sizeof(safe_aml));check(1);
 setup(1,0);aml_table(8192,"SSDT",sleep_aml,sizeof(sleep_aml));check(1);
 setup(1,0);aml_table(8192,"PSDT",sleep_aml,sizeof(sleep_aml));check(1);
 setup(2,0);aml_table(8320,"SSDT",sleep_aml,sizeof(sleep_aml));check(1);
 /* Discovery preserves non-AML entries while compacting AML references. */
 setup(2,0);put(ram+164,8192);put(ram+168,1024);put(ram+172,8320);checksum(ram+128,48,9);
 aml_table(8320,"SSDT",sleep_aml,sizeof(sleep_aml));check(1);
 setup(1,1);aml_table(8192,"SSDT",sleep_aml,sizeof(sleep_aml));check(0);
 setup(2,0);aml_table(8192,"SSDT",sleep_aml,sizeof(sleep_aml));aml_table(8320,"SSDT",sleep_aml,sizeof(sleep_aml));check(0);
 setup(1,1);aml_table(8192,"SSDT",hook_aml,sizeof(hook_aml));check(0);
 setup(2,0);aml_table(8192,"SSDT",hook_aml,sizeof(hook_aml));aml_table(8320,"SSDT",sleep_aml,sizeof(sleep_aml));check(0);
 setup(2,0);aml_table(8192,"SSDT",sleep_aml,sizeof(sleep_aml));aml_table(8320,"SSDT",hook_aml,sizeof(hook_aml));check(0);
 setup(1,1);ram[8192+36]^=1;check(0); /* checksum failure */
 setup(1,1);put(ram+8196,32769);check(0); /* reader workspace bound */
 setup(2,1);put(ram+172,8192);checksum(ram+128,48,9);check(0); /* duplicate address */
 setup(127,0);aml_table(8192+126*128,"SSDT",sleep_aml,sizeof(sleep_aml));check(1);
 setup(128,1);{struct pn_acpi p;assert(!pn_tables(readram,0,16,&p,work,sizeof(work)));}
 puts("PASS: combined DSDT/SSDT/PSDT namespace, ordering, checksums, duplicate definitions/references, preparation methods, truncation and table bounds");
#else
 setup(0,1);check(1);
 setup(1,1);aml_table(8192,"SSDT",safe_aml,sizeof(safe_aml));check(0);
 setup(1,1);aml_table(8192,"PSDT",hook_aml,sizeof(hook_aml));check(0);
 puts("PASS: default compilation retains single-table sleep admission and rejects added AML tables");
#endif
 return 0;
}
