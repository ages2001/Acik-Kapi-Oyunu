/* Disposable NT4 regression fixtures. Never install this test helper. */
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include "SHA256.H"
void *memset(void *p,int c,size_t n){unsigned char *q=p;while(n--)*q++=(unsigned char)c;return p;}
static char desktop[MAX_PATH],linkpath[MAX_PATH],text[2300],digest[65];
static const char sentinel[]="WINPOWER unrelated-file regression sentinel\r\n";
static const char change[]="WINPOWER modified shortcut fixture\r\n";
static BYTE buf[1024],hash[32];
static int equal(const void *a,const void *b,unsigned n){const BYTE *x=a,*y=b;while(n--)if(*x++!=*y++)return 0;return 1;}
static DWORD write_new(const char *path,const char *data,DWORD bytes){
 HANDLE f;DWORD n,error=0;f=CreateFileA(path,GENERIC_WRITE,0,0,CREATE_NEW,FILE_ATTRIBUTE_NORMAL,0);
 if(f==INVALID_HANDLE_VALUE)return GetLastError();
 if(!WriteFile(f,data,bytes,&n,0)||n!=bytes)error=ERROR_WRITE_FAULT;
 if(!error&&!FlushFileBuffers(f))error=GetLastError();CloseHandle(f);return error;
}
static DWORD link_hash(void){
 struct wp_sha256 s;HANDLE f;DWORD n,error=0;unsigned i;
 lstrcpyA(digest,"N/A");f=CreateFileA(linkpath,GENERIC_READ,FILE_SHARE_READ,0,OPEN_EXISTING,0,0);
 if(f==INVALID_HANDLE_VALUE)return GetLastError();
 wp_sha_init(&s);
 for(;;){if(!ReadFile(f,buf,sizeof(buf),&n,0)){error=GetLastError();break;}if(!n)break;wp_sha_add(&s,buf,n);}
 CloseHandle(f);if(error)return error;wp_sha_end(&s,hash);
 for(i=0;i<32;i++)wsprintfA(digest+2*i,"%02x",hash[i]);return 0;
}
void WINAPI WinMainCRTStartup(void){
 OSVERSIONINFOA os;HKEY k;DWORD n,type,error=0,kept=0,record,linkerr,wrote;HANDLE f;const char *args=GetCommandLineA();
 memset(&os,0,sizeof(os));os.dwOSVersionInfoSize=sizeof(os);GetVersionExA(&os);
 if(os.dwPlatformId!=VER_PLATFORM_WIN32_NT||os.dwMajorVersion!=4){MessageBoxA(0,"This disposable test fixture requires NT4.","NTCASE",MB_OK);ExitProcess(1);}
 n=sizeof(desktop);error=RegOpenKeyExA(HKEY_CURRENT_USER,"Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Shell Folders",0,KEY_READ,&k);
 if(!error){error=RegQueryValueExA(k,"Desktop",0,&type,(BYTE*)desktop,&n);RegCloseKey(k);if(!error&&(type!=REG_SZ||n>=sizeof(desktop)))error=ERROR_INVALID_DATA;}
 if(error){MessageBoxA(0,"Cannot read the Desktop test path.","NTCASE",MB_OK);ExitProcess(error);}
 wsprintfA(linkpath,"%s\\WINPWRNT.LNK",desktop);
 while(*args&&*args!='/')args++;
 if(!lstrcmpiA(args,"/INI")){
  error=write_new("C:\\KEEP12.TXT",sentinel,sizeof(sentinel)-1);
  if(!error&&!WritePrivateProfileStringA("Setup","Shortcut","C:\\KEEP12.TXT","C:\\WINPWRNT\\WINPOWER.INI"))error=GetLastError();
  WritePrivateProfileStringA(0,0,0,"C:\\WINPWRNT\\WINPOWER.INI");
 }else if(!lstrcmpiA(args,"/LINK")){
  f=CreateFileA(linkpath,GENERIC_WRITE,0,0,OPEN_EXISTING,0,0);
  if(f==INVALID_HANDLE_VALUE)error=GetLastError();
  else{SetFilePointer(f,0,0,FILE_END);if(!WriteFile(f,change,sizeof(change)-1,&n,0)||n!=sizeof(change)-1)error=ERROR_WRITE_FAULT;FlushFileBuffers(f);CloseHandle(f);}
 }else if(!lstrcmpiA(args,"/RO")){
  const char *files[]={"C:\\WINPWRNT\\WINPWRNT.EXE","C:\\WINPWRNT\\UNINST.EXE","C:\\WINPWRNT\\WINPSVC.EXE","C:\\WINPWRNT\\PN4HOOK.SYS"};unsigned i;
  for(i=0;i<4;i++)if(!SetFileAttributesA(files[i],FILE_ATTRIBUTE_READONLY))error=GetLastError();
 }else if(lstrcmpiA(args,"/CHECK")){MessageBoxA(0,"Usage: NTCASE /INI | /LINK | /RO | /CHECK","NTCASE",MB_OK);ExitProcess(1);}
 f=CreateFileA("C:\\KEEP12.TXT",GENERIC_READ,FILE_SHARE_READ,0,OPEN_EXISTING,0,0);
 if(f!=INVALID_HANDLE_VALUE){if(ReadFile(f,buf,sizeof(buf),&n,0)&&n==sizeof(sentinel)-1&&equal(buf,sentinel,n))kept=1;CloseHandle(f);}
 record=RegOpenKeyExA(HKEY_LOCAL_MACHINE,"Software\\WINPOWER\\NTSTART",0,KEY_READ,&k);if(!record)RegCloseKey(k);
 linkerr=link_hash();
 wsprintfA(text,"WINPOWER NT4 disposable regression\r\nAction: %s\r\nAction error: %lu\r\nSentinel unchanged: %lu\r\nShortcut hash error: %lu\r\nShortcut SHA256: %s\r\nNTSTART open error: %lu\r\nGUI attributes: %08lX\r\nUninstaller attributes: %08lX\r\nService attributes: %08lX\r\nDriver attributes: %08lX\r\n",args,error,kept,linkerr,digest,record,
  GetFileAttributesA("C:\\WINPWRNT\\WINPWRNT.EXE"),GetFileAttributesA("C:\\WINPWRNT\\UNINST.EXE"),GetFileAttributesA("C:\\WINPWRNT\\WINPSVC.EXE"),GetFileAttributesA("C:\\WINPWRNT\\PN4HOOK.SYS"));
 f=CreateFileA("C:\\NTCASE.TXT",GENERIC_WRITE,FILE_SHARE_READ,0,OPEN_ALWAYS,FILE_ATTRIBUTE_NORMAL,0);
 if(f!=INVALID_HANDLE_VALUE){SetFilePointer(f,0,0,FILE_END);WriteFile(f,text,lstrlenA(text),&wrote,0);FlushFileBuffers(f);CloseHandle(f);}
 MessageBoxA(0,text,"WINPOWER NT4 test fixture",MB_OK);ExitProcess(error);
}
