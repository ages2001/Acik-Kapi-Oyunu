/* Upgrade and verify the installed power components on an isolated NT5
   test copy. Each native transition requires the selected driver owner. */
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include "../src/SHA256.H"
static char driver[MAX_PATH],app[MAX_PATH],tmp[MAX_PATH],logline[256],arg[32];
static void line(const char *s){
 DWORD n;HANDLE h=CreateFileA("A:\\UPGRADE.TXT",GENERIC_WRITE,FILE_SHARE_READ,0,OPEN_ALWAYS,0,0);
 if(h==INVALID_HANDLE_VALUE)ExitProcess(90);
 SetFilePointer(h,0,0,FILE_END);WriteFile(h,s,lstrlenA(s),&n,0);WriteFile(h,"\r\n",2,&n,0);
 FlushFileBuffers(h);CloseHandle(h);
}
static void die(const char *s){wsprintfA(logline,"FAIL %s %lu",s,GetLastError());line(logline);ExitProcess(2);}
static void install(const char *from,const char *to){
 char *ext;
 lstrcpyA(tmp,to);ext=tmp+lstrlenA(tmp);while(ext>tmp&&*ext!='.')--ext;
 if(*ext!='.')die("temporary file name");lstrcpyA(ext,".TMP");
 if(!CopyFileA(from,tmp,FALSE))die("stage file");
 if(!MoveFileExA(tmp,to,MOVEFILE_DELAY_UNTIL_REBOOT|MOVEFILE_REPLACE_EXISTING))die("queue file replacement");
}
static void digest(const char *path,BYTE *result){
 BYTE data[2048];DWORD n;HANDLE f;struct wp_sha256 sha;
 f=CreateFileA(path,GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,0,OPEN_EXISTING,0,0);
 if(f==INVALID_HANDLE_VALUE)die("open for readback");
 wp_sha_init(&sha);
 do{if(!ReadFile(f,data,sizeof(data),&n,0))die("read");wp_sha_add(&sha,data,n);}while(n);
 wp_sha_end(&sha,result);CloseHandle(f);
}
static void match(const char *left,const char *right,const char *label){
 BYTE a[32],b[32];unsigned i,n;static const char hex[]="0123456789abcdef";digest(left,a);digest(right,b);
 for(i=0;i<32;i++)if(a[i]!=b[i])die("installed digest mismatch");
 lstrcpyA(logline,label);n=(unsigned)lstrlenA(logline);
 for(i=0;i<32;i++){logline[n++]=hex[b[i]>>4];logline[n++]=hex[b[i]&15];}
 logline[n]=0;line(logline);
}
void WINAPI WinMainCRTStartup(void){
 HANDLE token,d;TOKEN_PRIVILEGES pr;DWORD bytes,status[8];char *cmd=GetCommandLineA();
 if(*cmd=='"'){++cmd;while(*cmd&&*cmd!='"')++cmd;if(*cmd)++cmd;}else while(*cmd&&*cmd!=' ')++cmd;
 while(*cmd==' ')++cmd;lstrcpynA(arg,cmd,sizeof(arg));
 if(!*arg){
  char *last;GetModuleFileNameA(0,tmp,sizeof(tmp));last=tmp+lstrlenA(tmp);
  while(last>tmp&&last[-1]!='\\')--last;
  if(!lstrcmpiA(last,"S.EXE"))lstrcpyA(arg,"/STAGE");
  else if(!lstrcmpiA(last,"F.EXE"))lstrcpyA(arg,"/OFF");
  else if(!lstrcmpiA(last,"R.EXE"))lstrcpyA(arg,"/RESTART");
  else die("expected S.EXE, R.EXE, F.EXE or explicit action");
 }
 GetSystemDirectoryA(driver,sizeof(driver));lstrcatA(driver,"\\drivers\\WINPWR5.SYS");
 GetWindowsDirectoryA(app,sizeof(app));app[2]=0;lstrcatA(app,"\\WINPWRNT\\WINPWRNT.EXE");
 if(!lstrcmpiA(arg,"/STAGE")){
  DWORD zero=0;
  if(GetFileAttributesA("A:\\WPGUEST.ID")==INVALID_FILE_ATTRIBUTES)die("test volume marker");
  d=CreateFileA("\\\\.\\PN5LAB",GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,0,OPEN_EXISTING,0,0);
  if(d==INVALID_HANDLE_VALUE||!DeviceIoControl(d,0x226000,0,0,status,sizeof(status),&bytes,0)||
     bytes!=sizeof(status)||(status[0]!=5&&status[0]!=6))die("verify resident service before staging");
  if(!DeviceIoControl(d,0x22600c,&zero,sizeof(zero),0,0,&bytes,0)||
     !DeviceIoControl(d,0x226000,0,0,status,sizeof(status),&bytes,0)||
     bytes!=sizeof(status)||(status[5]&1))die("hand back current session to Windows");
  CloseHandle(d);
  install("A:\\UPDATE.SYS",driver);install("A:\\WINPWRNT.EXE",app);
  line("Windows owns this restart. Both replacements queued for Session Manager before service startup."); 
 }else{
  if(lstrcmpiA(arg,"/OFF")&&lstrcmpiA(arg,"/RESTART"))die("argument");
  match("A:\\UPDATE.SYS",driver,"SYS SHA-256 ");match("A:\\WINPWRNT.EXE",app,"GUI SHA-256 ");
  d=CreateFileA("\\\\.\\PN5LAB",GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,0,OPEN_EXISTING,0,0);
  if(d==INVALID_HANDLE_VALUE||!DeviceIoControl(d,0x226000,0,0,status,sizeof(status),&bytes,0)||bytes!=sizeof(status))die("query installed driver");
  CloseHandle(d);if(status[0]!=6||status[1]!=1||(status[5]&257)!=257)die("driver handoff");
  wsprintfA(logline,"Verified both SHA-256 digests. Resident owner=Driver. Action=%s FADT=%lu caps=%08lX.",arg,status[3],status[4]);line(logline);
 }
 if(!OpenProcessToken(GetCurrentProcess(),TOKEN_ADJUST_PRIVILEGES|TOKEN_QUERY,&token))die("token");
 pr.PrivilegeCount=1;pr.Privileges[0].Attributes=SE_PRIVILEGE_ENABLED;
 if(!LookupPrivilegeValueA(0,SE_SHUTDOWN_NAME,&pr.Privileges[0].Luid)||!AdjustTokenPrivileges(token,FALSE,&pr,0,0,0)||GetLastError())die("shutdown privilege");
 CloseHandle(token);
 if(!ExitWindowsEx(!lstrcmpiA(arg,"/OFF")?EWX_POWEROFF:EWX_REBOOT,0))die("native transition");
 ExitProcess(0);
}
