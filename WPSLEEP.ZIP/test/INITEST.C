#include <assert.h>
#include <stdio.h>
#include <string.h>
#include "PN9INI.H"
int main(void){
 const char *base="; test\r\n[boot]\r\nshell=explorer.exe\r\n[386Enh]\r\ndevice=one.vxd\r\n device = two.vxd\r\n[other]\r\ndevice=PN9HOOK.VXD\r\n";
 const char *driver="C:\\WINPWR9X\\PN9HOOK.VXD";
 char out[2048],back[2048];unsigned n=0,m=0,i;
 assert(pn9_ini(base,(unsigned)strlen(base),out,sizeof(out),driver,0,&n)==1);
 assert(pn9_ini(out,n,back,sizeof(back),driver,0,&m)==-2);
 assert(pn9_ini(out,n,back,sizeof(back),driver,1,&m)==1);
 assert(m==strlen(base)&&!memcmp(back,base,m));
 assert(pn9_ini(base,(unsigned)strlen(base),out,sizeof(out),driver,1,&n)==2);
 assert(n==strlen(base)&&!memcmp(out,base,n));
 {const char *s="[386enh]\ndevice = \"c:\\winpwr9x\\pn9hook.vxd\"\n; retained\n";
  assert(pn9_ini(s,(unsigned)strlen(s),out,sizeof(out),driver,1,&n)==1);
  assert(n==strlen("[386enh]\n; retained\n")&&!memcmp(out,"[386enh]\n; retained\n",n));}
 {const char *s="[386enh]\ndevice=C:\\OTHER\\PN9HOOK.VXD\n";
  assert(pn9_ini(s,(unsigned)strlen(s),out,sizeof(out),driver,0,&n)==-2);}
 assert(pn9_ini("[386enh]\n[386enh]\n",18,out,sizeof(out),driver,0,&n)<0);
 assert(pn9_ini("[boot]\n",7,out,sizeof(out),driver,0,&n)==-3);
 assert(pn9_ini("[386enh]",8,out,sizeof(out),driver,0,&n)==1);
 assert(!memcmp(out,"[386enh]\r\ndevice=",17));
 assert(pn9_ini(base,(unsigned)strlen(base),out,8,driver,0,&n)==-5);
 assert(pn9_ini(base,(unsigned)strlen(base),out,sizeof(out),"bad\npath",0,&n)==-1);
 for(i=0;i<strlen(base);i++)(void)pn9_ini(base,i,out,sizeof(out),driver,0,&n);
 puts("PASS: SYSTEM.INI insertion/removal, unrelated bytes, duplicate drivers, bounds, quotes, case and malformed sections");return 0;
}
