/* WINPOWER QEMU-only VxD observer. Debug bytes go to I/O port E9.
 * No firmware power writes. See VXREF.TXT for API layout provenance. */
typedef unsigned long U32;
typedef unsigned short U16;
typedef unsigned char U8;
struct diop { U32 internal1,vm,internal2,code,in,insize,out,outsize,returned,overlapped,handle,process; };
static U32 sequence,last,apm,vmm,previous4,previous5,previous93,previousbd;
static void hook4(void);
static void hook5(void);
static void hook93(void);
static void hookbd(void);
static void byteout(U8 value);
#pragma aux byteout = "out 0e9h,al" parm [al] modify exact [];
static void hex(U32 x) {
 int i; for(i=28;i>=0;i-=4) { unsigned n=(unsigned)((x>>i)&15);byteout((U8)(n<10?'0'+n:'A'+n-10)); }
}
static void __stdcall observe(U32 eax,U32 ebx,U32 ecx,U32 edx,U32 esi,U32 edi,U32 ebp) {
 if(eax==0x21||eax==0x1e||eax==0x20||eax==0x1f)return;
 byteout('C');byteout(' ');hex(eax);byteout(' ');hex(ebx);byteout(' ');hex(ecx);byteout(' ');hex(edx);
 byteout(' ');hex(esi);byteout(' ');hex(edi);byteout(' ');hex(ebp);byteout(10);
 sequence++;last=eax;
}
static U32 __stdcall query(struct diop *p) {
 U32 *o;
 if(p->code==0 || p->code==0xffffffffUL)return 0;
 if(p->code!=1)return 50;
 if(!p->out||p->outsize<20||!p->returned)return 87;
 o=(U32 *)p->out;o[0]=1;o[1]=sequence;o[2]=last;o[3]=vmm;o[4]=apm;
 *(U32 *)p->returned=20;return 0;
}
static void __stdcall service(U32 which,U32 *saved) {
 unsigned i;byteout('S');byteout(' ');hex(which);
 for(i=0;i<8;i++){byteout(' ');hex(saved[i]);}
 byteout(' ');hex(saved[10]);byteout(' ');hex(saved[11]);byteout(10);
}
static void __declspec(naked) hook4(void) {
 _asm { pushfd
  pushad
  push esp
  push 4
  call service
  popad
  popfd
  jmp dword ptr previous4
 }
}
static void __declspec(naked) hook5(void) {
 _asm { pushfd
  pushad
  push esp
  push 5
  call service
  popad
  popfd
  jmp dword ptr previous5
 }
}
static void __declspec(naked) hook93(void) {
 _asm { pushfd
  pushad
  push esp
  push 93h
  call service
  popad
  popfd
  jmp dword ptr previous93
 }
}
static void __declspec(naked) hookbd(void) {
 _asm { pushfd
  pushad
  push esp
  push 0bdh
  call service
  popad
  popfd
  jmp dword ptr previousbd
 }
}
static void initialize(void) {
 _asm { int 20h
  dw 0
  dw 1
  mov vmm,eax
  int 20h
  dw 1
  dw 26h
  mov apm,eax
  mov eax,260004h
  mov esi,offset hook4
  int 20h
  dw 90h
  dw 1
  mov previous4,esi
  mov eax,260005h
  mov esi,offset hook5
  int 20h
  dw 90h
  dw 1
  mov previous5,esi
  mov eax,10093h
  mov esi,offset hook93
  int 20h
  dw 90h
  dw 1
  mov previous93,esi
  mov eax,100bdh
  mov esi,offset hookbd
  int 20h
  dw 90h
  dw 1
  mov previousbd,esi
 }
 byteout('H');byteout(' ');hex(previous4);byteout(' ');hex(previous5);byteout(10);
}
void __declspec(naked) control(void) {
 _asm {
  pushad
  push ebp
  push edi
  push esi
  push edx
  push ecx
  push ebx
  push eax
  call observe
  popad
  cmp eax,1bh
  je init
  cmp eax,1
  je init
  cmp eax,1ch
  je busy
  cmp eax,23h
  jne done
  push esi
  call query
  clc
  ret
 init:
  pushad
  call initialize
  popad
 done:
  clc
  ret
 busy:
  stc
  ret
 }
}
