/* Native shutdown regression helper for disposable Windows 95/98/Me and NT 3/4 guests. */
#define WIN32_LEAN_AND_MEAN
#include <windows.h>

static char path[MAX_PATH];
static char text[256], audit_path[MAX_PATH];
static const char *audit_folder = "A:\\";
static const char *record_path(const char *name)
{
    lstrcpyA(audit_path, audit_folder);
    lstrcatA(audit_path, name);
    return audit_path;
}

static void failure(DWORD code, const char *operation)
{
    DWORD written, error = GetLastError();
    HANDLE log;
    wsprintfA(text, "%s failed. Windows error %lu. Test step %lu.", operation, error, code);
    log = CreateFileA(record_path("QAERR.TXT"), GENERIC_WRITE, FILE_SHARE_READ,
                      NULL, CREATE_ALWAYS, 0, NULL);
    if (log != INVALID_HANDLE_VALUE) {
        WriteFile(log, text, lstrlenA(text), &written, NULL);
        FlushFileBuffers(log);
        CloseHandle(log);
    }
    MessageBoxA(NULL, text, "WINPOWER test report", MB_OK);
    ExitProcess(code);
}

static BOOL driver_owns(BOOL win9x, BYTE major)
{
    const char *name = win9x ? "\\\\.\\PN9HOOK" : major == 3 ? "\\\\.\\PN3LAB" : "\\\\.\\PN4LAB";
    DWORD owner = 0, size = 0;
    HANDLE device = CreateFileA(name, win9x ? 0 : GENERIC_READ,
                                 win9x ? 0 : FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, OPEN_EXISTING, 0, NULL);
    BOOL ok;
    if (device == INVALID_HANDLE_VALUE) { failure(4, "Open resident driver"); return FALSE; }
    ok = DeviceIoControl(device, win9x ? 5 : 0x226014, NULL, 0, &owner, sizeof(owner), &size, NULL);
    CloseHandle(device);
    if (!ok || size != sizeof(owner)) { failure(4, "Read resident owner"); return FALSE; }
    if (owner != (win9x ? 1UL : 257UL)) { failure(4, "Verify restored Driver selection"); return FALSE; }
    return TRUE;
}

static BOOL shutdown_privilege(void)
{
    HANDLE token;
    TOKEN_PRIVILEGES privileges;
    BOOL ok;
    if (!OpenProcessToken(GetCurrentProcess(), TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY, &token)) return FALSE;
    privileges.PrivilegeCount = 1;
    privileges.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;
    ok = LookupPrivilegeValueA(NULL, "SeShutdownPrivilege", &privileges.Privileges[0].Luid);
    if (ok) {
        SetLastError(0);
        ok = AdjustTokenPrivileges(token, FALSE, &privileges, 0, NULL, NULL) &&
             GetLastError() == ERROR_SUCCESS;
    }
    CloseHandle(token);
    return ok;
}

void WINAPI WinMainCRTStartup(void)
{
    DWORD version = GetVersion(), bytes = 0;
    BYTE major = LOBYTE(LOWORD(version)), minor = HIBYTE(LOWORD(version));
    BOOL win9x = (version & 0x80000000UL) != 0, restart, automatic;
    unsigned tries;
    const char *name;
    UINT flags;
    HANDLE log;
    int length;
    if (GetFileAttributesA("C:\\WPQA10\\AUTO9X.ID") != INVALID_FILE_ATTRIBUTES) audit_folder = "C:\\WPQA10\\";
    if (GetFileAttributesA(record_path("WPGUEST.ID")) == INVALID_FILE_ATTRIBUTES) { MessageBoxA(NULL, "Test disk identifier is unavailable.", "WINPOWER test report", MB_OK); ExitProcess(1); }
    if (!(win9x ? major == 4 : (major == 3 || major == 4))) failure(2, "Identify Windows family");
    if (!GetModuleFileNameA(NULL, path, sizeof(path))) ExitProcess(3);
    name = path + lstrlenA(path);
    while (name > path && name[-1] != '\\') --name;
    automatic = !lstrcmpiA(name, "AUTOPWR.EXE");
    if (automatic) {
        if (!win9x || GetFileAttributesA(record_path("AUTO9X.ID")) == INVALID_FILE_ATTRIBUTES) ExitProcess(2);
        for (tries = 0; tries < 240 && !FindWindowA("Shell_TrayWnd", NULL); ++tries) Sleep(500);
        if (!FindWindowA("Shell_TrayWnd", NULL)) failure(3, "Find running Explorer desktop");
        Sleep(10000);
        if (GetFileAttributesA(record_path("READF.TXT")) != INVALID_FILE_ATTRIBUTES) ExitProcess(0);
        restart = GetFileAttributesA(record_path("READR.TXT")) == INVALID_FILE_ATTRIBUTES;
    } else restart = !lstrcmpiA(name, "R.EXE");
    if ((!automatic && !restart && lstrcmpiA(name, "F.EXE")) || !driver_owns(win9x, major)) failure(4, "Identify native request");
    if (!win9x && !shutdown_privilege()) failure(5, "Enable shutdown privilege");
    length = wsprintfA(text, "Windows %s %u.%u. Resident owner=Driver. Native action=%s.\r\n",
                       win9x ? "9x" : "NT", (unsigned)major, (unsigned)minor, restart ? "Restart" : "Power off");
    log = CreateFileA(restart ? record_path("READR.TXT") : record_path("READF.TXT"), GENERIC_WRITE,
                      FILE_SHARE_READ, NULL, CREATE_NEW, 0, NULL);
    if (log == INVALID_HANDLE_VALUE) failure(6, "Create action record");
    if (!WriteFile(log, text, (DWORD)length, &bytes, NULL) || bytes != (DWORD)length || !FlushFileBuffers(log))
        ExitProcess(7);
    CloseHandle(log);
    if (!automatic && MessageBoxA(NULL, text, "WINPOWER native request", MB_OKCANCEL | MB_DEFBUTTON2) != IDOK) ExitProcess(8);
    if (automatic) Sleep(7000);
    if (restart) flags = EWX_REBOOT;
    else if (major == 3 || (win9x && minor == 0)) flags = EWX_SHUTDOWN;
    else if (win9x) flags = EWX_SHUTDOWN | EWX_POWEROFF;
    else flags = EWX_POWEROFF;
    ExitProcess(ExitWindowsEx(flags, 0) ? 0 : 9);
}
