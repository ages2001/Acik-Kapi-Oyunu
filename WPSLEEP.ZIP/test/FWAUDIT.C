/* Read-only firmware query audit. Writes FWAUDIT.TXT beside this EXE. */
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include "FWAPI.H"
void *memset(void *p,int value,size_t n){unsigned char *q=p;while(n--)*q++=(unsigned char)value;return p;}
static char path[MAX_PATH],report[1800],dialog[2400],revision[64],flags[96];
static OSVERSIONINFOA os;
static struct wp_fwtable firmware;
void WINAPI WinMainCRTStartup(void){
 HMODULE kernel;HANDLE file;DWORD n,error=0,written=0;int i,os_ok,api,ok;
 os.dwOSVersionInfoSize=sizeof(os);os_ok=GetVersionExA(&os)!=0;
 kernel=GetModuleHandleA("KERNEL32.DLL");
 api=kernel&&GetProcAddress(kernel,"GetSystemFirmwareTable")!=0;
 ok=wp_fw_query(&firmware);wp_fw_text(&firmware,revision);
 if(firmware.flags_valid)wsprintfA(flags,"0x%08lX (advertised)",firmware.flags);
 else lstrcpyA(flags,"N/A");
 wsprintfA(report,"WINPOWER firmware API audit\r\n"
  "GetVersionEx success: %d\r\nOS platform: %lu\r\nOS reported version: %lu.%lu build %lu\r\n"
  "GetSystemFirmwareTable available: %d\r\nValidated FADT query: %d\r\n"
  "Revision display: %s\r\nTable length: %lu\r\nFADT revision: %u\r\n"
  "Minor available: %u\r\nMinor revision: %u\r\nFlags: %s\r\n"
  "Capability interpretation available: %u\r\nReset register advertised: %u\r\n"
  "Hardware-reduced advertised: %u\r\nLow-power S0 advertised: %u\r\n"
  "No physical-memory access, driver load or firmware write was performed.\r\n",
  os_ok,os.dwPlatformId,os.dwMajorVersion,os.dwMinorVersion,os.dwBuildNumber,
  api,ok,revision,firmware.table_length,firmware.revision,firmware.minor_valid,
  firmware.minor_revision,flags,firmware.capabilities_valid,firmware.reset_register,
  firmware.hardware_reduced,firmware.low_power_s0);
 n=GetModuleFileNameA(0,path,MAX_PATH);
 if(!n||n>=MAX_PATH){error=ERROR_INVALID_NAME;lstrcpyA(path,"N/A");}
 else {
  for(i=(int)n-1;i>=0&&path[i]!='\\';i--){}
  if(i<0||i>MAX_PATH-13){error=ERROR_FILENAME_EXCED_RANGE;lstrcpyA(path,"N/A");}
  else {
   lstrcpyA(path+i+1,"FWAUDIT.TXT");
   file=CreateFileA(path,GENERIC_WRITE,FILE_SHARE_READ,0,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,0);
   if(file==INVALID_HANDLE_VALUE)error=GetLastError();
   else {
    n=(DWORD)lstrlenA(report);
    if(!WriteFile(file,report,n,&written,0))error=GetLastError();
    else if(written!=n)error=ERROR_WRITE_FAULT;
    if(!error&&!FlushFileBuffers(file))error=GetLastError();
    CloseHandle(file);
   }
  }
 }
 wsprintfA(dialog,"%s\r\nReport: %s\r\nReport write error: %lu (0 = success)",report,path,error);
 MessageBoxA(0,dialog,"WINPOWER firmware audit",MB_OK|MB_ICONINFORMATION);
 ExitProcess(error?1:(ok?0:2));
}
