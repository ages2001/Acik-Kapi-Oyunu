/* Read-only enumeration of the NT hardware resource map for lab transport. */
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
static char output[4096];
static void walk(const char *path,unsigned depth) {
 HKEY key;char name[128],child[512];DWORD i;LONG e;
 if(lstrlenA(output)>3000)return;
 e=RegOpenKeyExA(HKEY_LOCAL_MACHINE,path,0,KEY_READ,&key);
 wsprintfA(output+lstrlenA(output),"%s : %ld\r\n",path,e);
 if(e)return;
 if(depth)for(i=0;i<64;i++) {
  if(RegEnumKeyA(key,i,name,sizeof(name)))break;
  if(lstrlenA(path)+lstrlenA(name)>500)break;
  wsprintfA(child,"%s\\%s",path,name);walk(child,depth-1);
 }
 RegCloseKey(key);
}
void WINAPI WinMainCRTStartup(void) {
 walk("HARDWARE\\RESOURCEMAP",3);
 MessageBoxA(0,output,"WINPOWER resource-map probe",MB_OK);
 ExitProcess(0);
}
