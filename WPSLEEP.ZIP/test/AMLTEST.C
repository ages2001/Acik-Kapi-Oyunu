/* Host tests for the bounded AML interpreter (AML.C). Run from SRC:
   cc -std=c89 -fsanitize=address,undefined -I. AML.C ../test/AMLTEST.C */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "AML.H"

static int failures;
#define CHECK(c,m) do{if(!(c)){printf("FAIL: %s (line %d)\n",m,__LINE__);failures++;}}while(0)

struct log {unsigned n;unsigned long addr[64],val[64];unsigned width[64];char kind[64];};
static struct log iolog;
static unsigned char memory[0x20];
static unsigned char pci[256];
static unsigned long stalled;

static void put(char k,unsigned long a,unsigned w,unsigned long v){
 if(iolog.n<64){iolog.kind[iolog.n]=k;iolog.addr[iolog.n]=a;iolog.width[iolog.n]=w;iolog.val[iolog.n]=v;iolog.n++;}
}
static int ior(void *g,pn_u32 p,unsigned w,pn_u32 *v){(void)g;(void)w;*v=(p==0x403)?0x0f:0;put('i',p,w,*v);return p>=0x400&&p<0x410;}
static int iow(void *g,pn_u32 p,unsigned w,pn_u32 v){(void)g;put('o',p,w,v);return p>=0x400&&p<0x410;}
static int memr(void *g,pn_u32 a,unsigned w,pn_u32 *v){
 unsigned i;(void)g;if(a<0xf1000UL||a+w/8>0xf1000UL+sizeof(memory))return 0;
 *v=0;for(i=0;i<w/8;i++)*v|=(pn_u32)memory[a-0xf1000UL+i]<<(8*i);return 1;}
static int memw(void *g,pn_u32 a,unsigned w,pn_u32 v){
 unsigned i;(void)g;if(a<0xf1000UL||a+w/8>0xf1000UL+sizeof(memory))return 0;
 for(i=0;i<w/8;i++)memory[a-0xf1000UL+i]=(unsigned char)(v>>(8*i));put('m',a,w,v);return 1;}
static int pcir(void *g,unsigned b,unsigned d,unsigned f,unsigned r,unsigned w,pn_u32 *v){
 unsigned i;(void)g;if(b||d!=31||f||r+w/8>256)return 0;*v=0;for(i=0;i<w/8;i++)*v|=(pn_u32)pci[r+i]<<(8*i);return 1;}
static int pciw(void *g,unsigned b,unsigned d,unsigned f,unsigned r,unsigned w,pn_u32 v){
 unsigned i;(void)g;if(b||d!=31||f||r+w/8>256)return 0;for(i=0;i<w/8;i++)pci[r+i]=(unsigned char)(v>>(8*i));put('p',r,w,v);return 1;}
static void stall(void *g,pn_u32 us){(void)g;stalled+=us;}
static const struct pn_aml_env env={0,ior,iow,memr,memw,pcir,pciw,stall};

static unsigned char *readfile(const char *dir,const char *name,unsigned long *len){
 char path[512];FILE *f;unsigned char *b;long n;
 sprintf(path,"%s/%s",dir,name);f=fopen(path,"rb");if(!f){printf("missing %s\n",path);exit(2);}
 fseek(f,0,SEEK_END);n=ftell(f);fseek(f,0,SEEK_SET);b=malloc((size_t)n);
 if(!b||fread(b,1,(size_t)n,f)!=(size_t)n){printf("read %s\n",path);exit(2);}
 fclose(f);*len=(unsigned long)n;return b;
}
static struct pn_aml_node nodes[2048];
static int loadone(struct pn_aml *a,const unsigned char *t,unsigned long n){
 if(n<36)return 0;
 if(!pn_aml_init(a,nodes,2048,t[8]))return 0;
 return pn_aml_load(a,t+36,n-36);
}
int main(int argc,char **argv){
 const char *dir=argc>1?argv[1]:"../test/AML";
 struct pn_aml a;unsigned long n;unsigned char *t;unsigned sa,sb;unsigned cases=0;

 /* Real QEMU i440fx DSDT: full namespace load, static _S5, no prepare. */
 t=readfile(dir,"QEMUPC.AML",&n);
 CHECK(loadone(&a,t,n),"QEMU DSDT loads");cases++;
 CHECK(pn_aml_sleep_type(&a,&env,5,&sa,&sb)&&sa==0&&sb==0,"QEMU _S5 0/0");cases++;
 CHECK(pn_aml_sleep_type(&a,0,5,&sa,&sb)&&sa==0&&sb==0,"static sleep type without hardware services");cases++;
 CHECK(!pn_aml_has_prepare(&a),"QEMU has no _PTS");cases++;
 printf("QEMU DSDT nodes: %u\n",a.nodes);
 /* Truncation and single-byte mutation must fail closed without faults. */
 {unsigned long cut;unsigned char *c=malloc(n);unsigned long i;
  for(cut=36;cut<n;cut+=(n>4000?7:1)){memcpy(c,t,cut);if(loadone(&a,c,cut)){pn_aml_sleep_type(&a,&env,5,&sa,&sb);pn_aml_verify_prepare(&a,5);}}
  srand(12345);
  for(i=0;i<3000;i++){
   memcpy(c,t,n);c[36+(unsigned long)rand()%(n-36)]^=(unsigned char)(1u<<(rand()%8));
   if(loadone(&a,c,n)){pn_aml_sleep_type(&a,&env,5,&sa,&sb);if(pn_aml_verify_prepare(&a,5)){iolog.n=0;pn_aml_prepare(&a,&env,5);}}
  }
  free(c);cases+=2;}
 free(t);

 t=readfile(dir,"S5DYN.AML",&n);
 CHECK(loadone(&a,t,n),"S5DYN loads");
 CHECK(pn_aml_sleep_type(&a,&env,5,&sa,&sb)&&sa==5&&sb==5,"dynamic _S5 method");cases++;
 CHECK(!pn_aml_sleep_type(&a,&env,3,&sa,&sb),"absent _S3");cases++;
 free(t);

 t=readfile(dir,"S5NAME.AML",&n);
 CHECK(loadone(&a,t,n),"S5NAME loads");
 CHECK(pn_aml_sleep_type(&a,&env,5,&sa,&sb)&&sa==6&&sb==3,"_S5 with name element");cases++;
 CHECK(pn_aml_sleep_type(&a,&env,4,&sa,&sb)&&sa==4&&sb==4,"single-element _S4");cases++;
 free(t);

 t=readfile(dir,"S5WRITE.AML",&n);
 CHECK(loadone(&a,t,n),"S5WRITE loads");
 iolog.n=0;
 CHECK(!pn_aml_sleep_type(&a,&env,5,&sa,&sb)&&iolog.n==0,"_S5 with side effect refused");cases++;
 free(t);

 t=readfile(dir,"PTSIO.AML",&n);
 CHECK(loadone(&a,t,n),"PTSIO loads");
 CHECK(pn_aml_has_prepare(&a),"PTSIO has _PTS");
 CHECK(pn_aml_verify_prepare(&a,5),"PTSIO verifies");cases++;
 iolog.n=0;
 CHECK(pn_aml_prepare(&a,&env,5),"PTSIO executes");cases++;
 {
  /* Expected: DBG8=5; HIGN RMW: read 0x403, write 0xAF; LOWN RMW: read 0x403
     (mock returns 0x0F), write 0x03; DBG8=(3+5)<<1=16; _OSI is 0; DBG8=0x50. */
  static const char kinds[]="oioioo";static const unsigned long addrs[]={0x402,0x403,0x403,0x403,0x403,0x402,0x402};
  static const unsigned long vals[]={5,0x0f,0xaf,0x0f,0x03,16,0x50};
  unsigned i,ok=iolog.n==7;
  for(i=0;ok&&i<7;i++)if(iolog.addr[i]!=addrs[i]||iolog.val[i]!=vals[i]||(i<6&&iolog.kind[i]!=kinds[i]))ok=0;
  if(!ok)for(i=0;i<iolog.n;i++)printf("  %c %lx w%u = %lx\n",iolog.kind[i],iolog.addr[i],iolog.width[i],iolog.val[i]);
  CHECK(ok,"PTSIO port sequence");cases++;
 }
 free(t);

 t=readfile(dir,"PTSMEM.AML",&n);
 CHECK(loadone(&a,t,n),"PTSMEM loads");
 CHECK(pn_aml_verify_prepare(&a,5),"PTSMEM verifies");cases++;
 memset(memory,0,sizeof(memory));memset(pci,0,sizeof(pci));iolog.n=0;stalled=0;
 CHECK(pn_aml_prepare(&a,&env,5),"PTSMEM executes");cases++;
 CHECK(memory[0]==0x15,"_GTS after _PTS updates SLPS");cases++;
 CHECK(memory[7]==0x80,"FLAG high bit set");cases++;
 CHECK(memory[8]==0x02,"BITB set alone");cases++;
 CHECK(memory[9]==0x34&&memory[10]==0x12,"WRD written");cases++;
 {unsigned i,seen=0;for(i=0;i<iolog.n;i++)if(iolog.kind[i]=='p'&&iolog.addr[i]==0xa0&&iolog.val[i]==0x55&&iolog.width[i]==32)seen=1;
  CHECK(seen&&pci[0xa0]==0x02,"PCI config dev 31 write, then IndexField index 2");cases++;}
 CHECK(pci[0xa4]==0x22,"IndexField data write");cases++;
 CHECK(stalled==1005,"Sleep/Stall delays");cases++;
 {struct pn_aml_env no_timer=env;
  no_timer.stall=0;
  CHECK(loadone(&a,t,n)&&!pn_aml_prepare(&a,&no_timer,5),"preparation requires its firmware delays");cases++;}
 free(t);

 t=readfile(dir,"PTSEC.AML",&n);
 CHECK(loadone(&a,t,n),"PTSEC loads");
 CHECK(!pn_aml_verify_prepare(&a,5),"EmbeddedControl _PTS rejected");cases++;
 free(t);

 t=readfile(dir,"PTSLOOP.AML",&n);
 CHECK(loadone(&a,t,n),"PTSLOOP loads");
 CHECK(pn_aml_verify_prepare(&a,5),"loop verifies statically");
 CHECK(!pn_aml_prepare(&a,&env,5),"unbounded loop stops at limit");cases++;
 free(t);

 /* DSDT plus SSDT: _PTS defined in a secondary table. */
 {unsigned long n2;unsigned char *d=readfile(dir,"S5NAME.AML",&n),*s=readfile(dir,"SSDTPTS.AML",&n2);
  CHECK(pn_aml_init(&a,nodes,2048,2)&&pn_aml_load(&a,d+36,n-36)&&pn_aml_load(&a,s+36,n2-36),"DSDT+SSDT load");
  CHECK(pn_aml_verify_prepare(&a,5),"SSDT _PTS verifies");iolog.n=0;
  CHECK(pn_aml_prepare(&a,&env,5)&&iolog.n==4&&iolog.val[1]==5,"SSDT _PTS writes");cases++;
  free(d);free(s);}
 printf("AML: %u cases, %d failures\n",cases,failures);
 return failures!=0;
}
