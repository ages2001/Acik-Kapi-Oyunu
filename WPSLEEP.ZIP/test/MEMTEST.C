#include <assert.h>
#include <stdio.h>
#include <string.h>
#include "MEMMAP.H"
static void put(unsigned char *p,unsigned long n) {
 unsigned i;for(i=0;i<4;i++){p[i]=(unsigned char)n;n>>=8;}
}
int main(void) {
 unsigned char data[68],bad[68];unsigned i;struct pn_memmap m;
 memset(data,0,sizeof(data));put(data,1);put(data+16,3);
 data[20]=data[36]=data[52]=3;
 put(data+24,0);put(data+32,0xa0000);
 put(data+40,0x100000);put(data+48,0x1f00000);
 put(data+56,0x3000000);put(data+64,0xffe000);
 assert(pn_memmap(data,68,&m));assert(m.count==3&&m.top==0x3ffe000&&m.limit==0x4000000);
 assert(pn_memread(&m,0x3fff000,4096));assert(!pn_memread(&m,0x4000000,1));
 assert(pn_memread(&m,0xe0000,0x20000));assert(!pn_memread(&m,0x2000000,4096));
 assert(!pn_memread(&m,0x1fffff0,32));assert(!pn_memread(&m,0xfffffff0,32));
 assert(!pn_memread(&m,0x100000,0));
 for(i=0;i<68;i++)assert(!pn_memmap(data,i,&m));
 memcpy(bad,data,68);put(bad+16,0xffffffffUL);assert(!pn_memmap(bad,68,&m));
 memcpy(bad,data,68);put(bad+28,1);assert(!pn_memmap(bad,68,&m));
 memcpy(bad,data,68);put(bad+64,0);assert(!pn_memmap(bad,68,&m));
 memcpy(bad,data,68);put(bad+56,0xbff00000UL);assert(!pn_memmap(bad,68,&m));
 memcpy(bad,data,68);bad[20]=5;assert(!pn_memmap(bad,68,&m));
 puts("PASS: NT physical-memory descriptors, holes, BIOS/tail bounds, truncation and overflow rejection");
 return 0;
}
