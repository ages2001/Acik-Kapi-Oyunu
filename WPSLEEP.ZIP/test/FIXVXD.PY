"""Normalize Watcom LE object bases/execute flags for the flat VxD loader.

The required normalization is documented by J. Hensl's fixlink -vxd32.
Only LE VxDs with bounded object tables are accepted here.
"""
from pathlib import Path
import struct,sys
p=Path(sys.argv[1]);b=bytearray(p.read_bytes())
assert b[:2]==b'MZ' and len(b)>=64
h=struct.unpack_from('<I',b,60)[0]
assert h+196<=len(b) and b[h:h+2]==b'LE'
# Win95 RTM rejects Watcom's 0x400 LE SDK stamp as an old beta DDK.
struct.pack_into('<H',b,h+0xc2,0x030a)
t,n=struct.unpack_from('<II',b,h+64)
assert 0<n<=32 and h+t+n*24<=len(b)
for i in range(n):
    off=h+t+24*i
    size,base,flags=struct.unpack_from('<III',b,off)
    assert size and flags&0x2000, 'Expected 32-bit VxD object'
    struct.pack_into('<II',b,off+4,0,flags|4)
p.write_bytes(b)
print('PASS: flat VxD object bases and executable flags:',n)
