/* Give the original QA process the foreground for physical keyboard testing. */
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
static unsigned long wanted;
static BOOL CALLBACK select_marker(HWND w,LPARAM unused){char c[40];DWORD id;(void)unused;
 GetWindowThreadProcessId(w,&id);
 if(id!=wanted||!GetClassNameA(w,c,sizeof(c))||lstrcmpA(c,"WpSleepMarker"))return TRUE;
 ShowWindow(w,SW_SHOW);SetForegroundWindow(w);BringWindowToTop(w);return FALSE;
}
void WINAPI WinMainCRTStartup(void){HANDLE f;char buf[2048];DWORD n;char *at;
 if(GetFileAttributesA("A:\\SLEEPQA.ID")==INVALID_FILE_ATTRIBUTES)ExitProcess(2);
 f=CreateFileA("A:\\S4TEST.TXT",GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,NULL,OPEN_EXISTING,0,NULL);
 if(f==INVALID_HANDLE_VALUE)f=CreateFileA("A:\\S3TEST.TXT",GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,NULL,OPEN_EXISTING,0,NULL);
 if(f==INVALID_HANDLE_VALUE)ExitProcess(3);
 if(!ReadFile(f,buf,sizeof(buf)-1,&n,NULL))ExitProcess(4);CloseHandle(f);buf[n]=0;
 for(at=buf;at+8<=buf+n;++at){if( at[0]=='P' && at[1]=='r' && at[2]=='o' && at[3]=='c' && at[4]=='e' && at[5]=='s' && at[6]=='s' && at[7]==' ')break;}
 if(at+8>buf+n)ExitProcess(5);at+=8;while(*at>='0'&&*at<='9')wanted=wanted*10+(unsigned)(*at++-'0');
 if(wanted)EnumWindows(select_marker,0);ExitProcess(0);
}
