"""Read the hibernation header through a bounded FAT32 chain on the QA disk."""
import struct


def header(part, length):
    def at(offset, count):
        if offset < 0 or offset + count > length:
            raise ValueError('FAT32 read exceeds the partition')
        part.seek(offset)
        data = part.read(count)
        if len(data) != count:
            raise ValueError('Short FAT32 read')
        return data

    boot = at(0, 512)
    sector = struct.unpack_from('<H', boot, 11)[0]
    spc = boot[13]
    reserved, fats = struct.unpack_from('<HB', boot, 14)
    fatlen, flags = struct.unpack_from('<IH', boot, 36)
    root = struct.unpack_from('<I', boot, 44)[0]
    if boot[82:90] != b'FAT32   ' or sector not in (512,1024,2048,4096) or not spc or spc & (spc-1) or not fats or not fatlen:
        raise ValueError('Invalid FAT32 dimensions')
    size = sector * spc
    data_offset = (reserved + fats * fatlen) * sector
    active = flags & 15 if flags & 0x80 else 0
    assert active < fats
    fat_offset = (reserved + active * fatlen) * sector
    maximum = min((length-data_offset)//size+1, fatlen*sector//4-1)

    def clusters(start):
        seen = set()
        while start < 0x0ffffff8:
            if start < 2 or start > maximum or start in seen:
                raise ValueError('Invalid or circular FAT32 allocation chain')
            seen.add(start)
            yield at(data_offset + (start-2)*size, size)
            start = struct.unpack('<I', at(fat_offset+4*start, 4))[0] & 0x0fffffff

    for page in clusters(root):
        for i in range(0, len(page), 32):
            row = page[i:i+32]
            if row[0] == 0: return None
            if row[:11] != b'HIBERFILSYS' or row[11] & 0x18: continue
            start = (struct.unpack_from('<H', row, 20)[0]<<16) | struct.unpack_from('<H', row, 26)[0]
            if struct.unpack_from('<I', row, 28)[0] < 4096: raise ValueError('Short hibernation file')
            data = bytearray()
            for block in clusters(start):
                data.extend(block[:4096-len(data)])
                if len(data) == 4096: return bytes(data)
            raise ValueError('Truncated hibernation header')
    return None
