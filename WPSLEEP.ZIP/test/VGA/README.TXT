WINPOWER v1.0 sleep verification

SEPASS.TXT records the Windows 98 SE session and its F8 check. SEFACS.JSN
records the sleeping machine's 32-bit wake vector. Two device-setup
resets precede the suspend and wake events in SEEVENT.JSN. The hardware
was QEMU pc-i440fx-5.2 with standard VGA. The guest reported the active
Microsoft generic driver as well as an older Cirrus registry entry.

F98S3.TXT, F98S3R2.TXT, F98VBIO.TXT and the corresponding event logs
are Windows 98 FE runs. F98RET.TXT records the independent live marker
count after wake. F98BIOS.LOG is the relevant excerpt from SeaBIOS, with
VGA initialization disabled. The two final characters shown as literal
backslash escape sequences in F98RET.TXT came from the test reporter.

W7S4.TXT, VISTAS4.TXT and X64S4.TXT record the guest display service,
power broadcasts and in-memory checksum. The cold-start records identify
the on-disk HIBR header, its hash and a new QEMU PID. The Win7 and Vista
headers were read through NTFS, the XP x64 header through FAT32. W7PWR.TXT
contains Windows' own standby diagnosis. XP32PWR.TXT records the native
XP x86 result. S2KBLOCK.TXT and 2KS4.TXT are the two separate Windows
2000 requests. MESLP.TXT and MEVETO.PNG record the WinMe response.
The archive uses cropped views of the application's witness windows.

The QA program in ../VGASLEEP.C runs from marked disposable media with
Explorer running. It starts the distributed executable beside it and
operates the actual confirmation control. The marker is generated in
process memory. It is never recreated from the checksum stored on disk.
F8 is delivered via a physical keyboard emulated by QEMU. Where needed,
FOCUS.C gives the original marker window the foreground before that key.
Medium records ending in MED, MEDIA, MEDC or MEDD pair the exact tested
GUI digest with the QA binary. Legacy QA files are test tools only.
QAW7.EXE was used on XP x86, Vista and Win7. QA9X.EXE was used on 9x.
QA2K.EXE and QAX64.EXE are the newer readers for Windows 2000 and XP x64.
The current QA source waits for complete controls and supports the older
Windows 2000 random-byte API fallback. The current source reproduces
QA2K.EXE and QAX64.EXE byte for byte. QAW7.EXE and QA9X.EXE preserve the
actual earlier witness builds. See ../SLPQA.SH to build the current reader.

DOSSTDBY.TXT and DOSSUS.TXT contain both real-mode DOS results from the
shipping WPSLEEP.EXE. The supplied SeaBIOS 1.16.3 APM 1.2 implementation
does not advertise either global sleep state. The utility consequently
returned the explicit capability result for both commands. Host tests
exercise APM 1.0, 1.1 and 1.2 firmware calls and partial-failure cleanup.

All 65 file digests in BUILD.JSN refer to this distribution. Older native
shutdown and restart results identify their own exact binary revisions in
the separate first-phase project archive WPROJ10.ZIP.
