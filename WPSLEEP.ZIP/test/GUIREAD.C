/* Launch the distributed GUI and capture the text displayed by its native
   status control. A marker identifies the test volume used for the log. */
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
static char app[MAX_PATH], report[3600], body[2200], path[MAX_PATH], cls[24];
static OSVERSIONINFOEXW ver;
static SYSTEM_INFO arch;
static SYSTEMTIME utc;
static SYSTEM_POWER_STATUS power_state;
static STARTUPINFOA startup;
static PROCESS_INFORMATION child;
typedef LONG (WINAPI *rtlver)(OSVERSIONINFOEXW *);
static int contains(const char *s,const char *sub){int n=lstrlenA(sub);while(*s){int i=0;while(i<n&&s[i]&&s[i]==sub[i])i++;if(i==n)return 1;s++;}return 0;}
static BOOL CALLBACK read_text(HWND control,LPARAM unused){DWORD_PTR size=0;(void)unused;
 if(!GetClassNameA(control,cls,sizeof(cls))||lstrcmpiA(cls,"STATIC"))return TRUE;
 if(!SendMessageTimeoutA(control,WM_GETTEXT,(WPARAM)sizeof(body),(LPARAM)body,SMTO_ABORTIFHUNG,2000,&size)||!size)return TRUE;
 if(contains(body,"Shutdown owner:"))return FALSE;
 body[0]=0;return TRUE;
}
static int save_report(void){char c;HANDLE log;DWORD n;int ok;
 for(c='A';c<='Z';++c){wsprintfA(path,"%c:\\WPGUEST.ID",c);if(GetFileAttributesA(path)==INVALID_FILE_ATTRIBUTES)continue;
  wsprintfA(path,"%c:\\GUIREAD.TXT",c);log=CreateFileA(path,GENERIC_WRITE,FILE_SHARE_READ,NULL,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,NULL);
  if(log==INVALID_HANDLE_VALUE)continue;
  ok=WriteFile(log,report,lstrlenA(report),&n,NULL)&&n==(DWORD)lstrlenA(report)&&FlushFileBuffers(log);CloseHandle(log);if(ok)return 1;
 }return 0;
}
void WINAPI WinMainCRTStartup(void){HWND gui=0;DWORD i,err=0;HKEY mini;BOOL pe,have=FALSE;rtlver getver;
 SetErrorMode(SEM_FAILCRITICALERRORS|SEM_NOOPENFILEERRORBOX);
 pe=RegOpenKeyExA(HKEY_LOCAL_MACHINE,"SYSTEM\\CurrentControlSet\\Control\\MiniNT",0,KEY_QUERY_VALUE,&mini)==ERROR_SUCCESS;
 if(pe)RegCloseKey(mini);
 if(!GetModuleFileNameA(NULL,app,sizeof(app)))ExitProcess(1);
 i=lstrlenA(app);while(i&&app[i-1]!='\\')--i;app[i]=0;lstrcatA(app,"WINPWRNT.EXE");startup.cb=sizeof(startup);
 if(!CreateProcessA(app,NULL,NULL,NULL,FALSE,0,NULL,NULL,&startup,&child))err=GetLastError();
 if(!err)for(i=0;i<150;++i){Sleep(150);gui=FindWindowA("WINPOWER","WINPOWER - Power Center");if(gui){body[0]=0;EnumChildWindows(gui,read_text,0);if(contains(body,"Shutdown owner:"))break;}}
 getver=(rtlver)(void*)GetProcAddress(GetModuleHandleA("NTDLL.DLL"),"RtlGetVersion");ver.dwOSVersionInfoSize=sizeof(ver);if(getver)getver(&ver);GetNativeSystemInfo(&arch);
 if(gui){Sleep(6200);EnumChildWindows(gui,read_text,0);have=GetSystemPowerStatus(&power_state);}
 GetSystemTime(&utc);
 wsprintfA(report,"Observed UTC=%04u-%02u-%02u %02u:%02u:%02u.%03u.\r\nNative version=%lu.%lu.%lu. ProductType=%u. ProcessorArchitecture=%u. Application bits=%u. MiniNT=%u.\r\nGetSystemPowerStatus=%u AC=%u flags=%u percent=%u life=%lu.\r\nGUI launch error=%lu.\r\n--- Published GUI status ---\r\n%s\r\n",(UINT)utc.wYear,(UINT)utc.wMonth,(UINT)utc.wDay,(UINT)utc.wHour,(UINT)utc.wMinute,(UINT)utc.wSecond,(UINT)utc.wMilliseconds,ver.dwMajorVersion,ver.dwMinorVersion,ver.dwBuildNumber,(UINT)ver.wProductType,(UINT)arch.wProcessorArchitecture,(UINT)(8*sizeof(void*)),(UINT)pe,(UINT)have,(UINT)power_state.ACLineStatus,(UINT)power_state.BatteryFlag,(UINT)power_state.BatteryLifePercent,power_state.BatteryLifeTime,err,body);
 if(!save_report()||!gui||!contains(body,"Shutdown owner:"))MessageBoxA(NULL,report,"WINPOWER observation",MB_OK);
 if(!err){CloseHandle(child.hThread);WaitForSingleObject(child.hProcess,INFINITE);CloseHandle(child.hProcess);}
 ExitProcess(err?1:0);
}
