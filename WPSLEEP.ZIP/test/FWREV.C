/* Published firmware editions and display behavior at the legacy GUI/driver boundary. */
#include <assert.h>
#include <stdio.h>
#include <string.h>
#include "FWTABLE.H"
#include "FWVER.H"
#include "OSNAME.H"
struct edition {unsigned revision,minor,length;const char *text;};
static void test_table(const struct edition *e){
 unsigned char fadt[280];unsigned char sum=0;unsigned i;struct wp_fwtable info;
 char text[24];unsigned long caps;
 memset(fadt,0,sizeof(fadt));memcpy(fadt,"FACP",4);fadt[4]=(unsigned char)e->length;
 fadt[5]=(unsigned char)(e->length>>8);fadt[8]=(unsigned char)e->revision;
 if(e->length>131)fadt[131]=(unsigned char)e->minor;
 for(i=0;i<e->length;i++)sum=(unsigned char)(sum+fadt[i]);
 fadt[9]=(unsigned char)(0-sum);
 assert(wp_fadt(fadt,e->length,&info));
 pn_acpitext(0xffff,info.revision,info.minor_valid?info.minor_revision:0xffff,text);
 assert(!strcmp(text,e->text));
 caps=WP_FW_MINOR(info.revision,info.minor_valid?info.minor_revision:0xffff)|0x291UL;
 assert((caps&65535)==0x291UL);
 pn_acpitext(0,info.revision,wp_minor(caps),text);assert(!strcmp(text,e->text));
}
int main(void){
 static const struct edition e[]={
  {1,0,116,"1.0"},{2,0,132,"FADT 2"},{3,0x55,244,"2.0"},{4,0x55,244,"3.0/4.0"},
  {5,0,268,"5.0"},{5,1,268,"5.1"},{6,0,276,"6.0"},{6,1,276,"6.1"},
  {6,2,276,"6.2"},{6,3,276,"6.3"},{6,4,276,"6.4"},{6,5,276,"6.5"},
  {6,6,276,"6.6"},{6,7,276,"FADT 6/7"},{6,0x21,276,"FADT 6/33"},
  {6,255,276,"FADT 6/255"},{7,255,36,"FADT 7"},{255,0,36,"FADT 255"}
 };
 static const struct {unsigned v;const char *text;} apm[]={
  {0,"N/A"},{0x100,"1.0"},{0x101,"1.1"},{0x102,"1.2"},
  {0x110,"1.10"},{0x112,"1.12"},{0x12a,"N/A"},{0xabcd,"N/A"}
 };
 unsigned i;char text[24];
 for(i=0;i<sizeof(e)/sizeof(e[0]);i++)test_table(e+i);
 for(i=0;i<sizeof(apm)/sizeof(apm[0]);i++){pn_apmtext(apm[i].v,text);assert(!strcmp(text,apm[i].text));}
 pn_acpitext(0xffff,0,0xffff,text);assert(!strcmp(text,"N/A"));
 pn_acpitext(2,0,0xffff,text);assert(!strcmp(text,"2.0+"));
 pn_acpitext(0xffff,6,wp_minor(0x291UL),text);assert(!strcmp(text,"FADT 6"));
 puts("PASS: 18 FADT layouts/editions, 8 APM BCD values, old driver replies and missing firmware.");
 return 0;
}
