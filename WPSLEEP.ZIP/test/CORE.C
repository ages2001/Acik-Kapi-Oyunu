#include <assert.h>
#include <stdio.h>
#include <string.h>
#include "POLICY.H"
#include "ACPI.H"
static void fix(unsigned char *b,int n,int off) {
 int i; unsigned char s=0; b[off]=0;
 for(i=0;i<n;i++) s=(unsigned char)(s+b[i]);
 b[off]=(unsigned char)(0-s);
}
int main(void) {
 unsigned char b[36]; unsigned n;
 assert(pn_eligible(0,4,0,1)); assert(pn_eligible(0,4,10,1));
 assert(pn_eligible(0,4,90,1)); assert(pn_eligible(1,4,0,1));
 assert(pn_eligible(1,5,0,1)); assert(pn_eligible(1,5,1,1));
 assert(pn_eligible(1,5,2,1)); assert(pn_eligible(1,5,1,0));
 assert(pn_eligible(1,6,0,1)); assert(pn_eligible(1,6,1,1));
 assert(pn_eligible(1,6,3,1)); assert(pn_eligible(1,10,0,1));
 assert(!pn_eligible(1,10,0,0)); assert(!pn_eligible(1,11,0,1));
 for(n=1;n<=3;n++)assert(pn_eligible(0,n,0,0));
 assert(pn_eligible(1,3,10,0)&&pn_eligible(1,3,50,0)&&pn_eligible(1,3,51,0));
 assert(!pn_eligible(1,3,52,0)&&!pn_eligible(0,4,80,1));
 for(n=0;n<8;n++) assert(pn_owner(n&1,n&2,n&4)==(n==7));
 memset(b,0,sizeof b); memcpy(b,"RSD PTR ",8); fix(b,20,8);
 assert(pn_rsdp(b,20)==0);
 for(n=0;n<20;n++) assert(pn_rsdp(b,n)==-1);
 b[15]=2;b[20]=36;fix(b,20,8);fix(b,36,32);assert(pn_rsdp(b,36)==2);
 for(n=20;n<36;n++) assert(pn_rsdp(b,n)==-1);
 for(n=0;n<36;n++){b[n]^=1;assert(pn_rsdp(b,36)==-1);b[n]^=1;}
 b[20]=255;fix(b,36,32);assert(pn_rsdp(b,36)==-1);
 assert(pn_rsdp(0,36)==-1);
 puts("PASS: owner eligibility, default/fallback policy, RSDP checksums and bounds");
 return 0;
}
