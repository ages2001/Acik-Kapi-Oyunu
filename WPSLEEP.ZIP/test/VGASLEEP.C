/* Run from marked removable media inside a disposable installed Windows desktop.
   S.EXE exercises suspend and H.EXE hibernate through the visible WINPOWER GUI.
   The marker lives in this process. Only its checksum is stored on the test disk. */
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <setupapi.h>
#include "../src/SLPVIDEO.H"

void *memset(void *ptr,int value,size_t count)
{
    BYTE *b=ptr;while(count--)*b++=(BYTE)value;return ptr;
}

#ifndef WP_9XQA
static const GUID display_class = {0x4d36e968,0xe325,0x11ce,{0xbf,0xc1,0x08,0x00,0x2b,0xe1,0x03,0x18}};
#endif
static BYTE secret[32];
static char base[MAX_PATH], logpath[MAX_PATH], line[2048], shown[180];
static BOOL hibernating, asleep, awake, submitted;
static HWND marker, panel, ask, mainwin;
static DWORD product_pid, digest_before;
static unsigned stage, ticks;
static STARTUPINFOA start;
static PROCESS_INFORMATION process;

static void record(const char *str)
{
    DWORD n;
    HANDLE f=CreateFileA(logpath,GENERIC_WRITE,FILE_SHARE_READ,NULL,OPEN_ALWAYS,0,NULL);
    if(f==INVALID_HANDLE_VALUE)ExitProcess(11);
    SetFilePointer(f,0,NULL,FILE_END);
    if(!WriteFile(f,str,lstrlenA(str),&n,NULL)||n!=(DWORD)lstrlenA(str)||!FlushFileBuffers(f))ExitProcess(12);
    CloseHandle(f);
}
static DWORD digest(void)
{
    DWORD h=2166136261UL;unsigned i;
    for(i=0;i<sizeof(secret);i++)h=(h^secret[i])*16777619UL;
    return h;
}
static void textfile(const char *prefix, const char *msg)
{
    wsprintfA(line,"%s%s\r\n",prefix,msg);record(line);
}
#ifdef WP_9XQA
static void video_drivers(void)
{
    char primary[200],ini[160],adapter[80],path[245],label[140],driver[128];
    HKEY root,key;DWORD i,n,type;
    wp_sleep_video(primary,sizeof(primary));textfile("Primary display: ",primary);
    GetPrivateProfileStringA("boot","display.drv","N/A",ini,sizeof(ini),"SYSTEM.INI");
    textfile("SYSTEM.INI display.drv: ",ini);
    GetPrivateProfileStringA("boot.description","display.drv","N/A",ini,sizeof(ini),"SYSTEM.INI");
    textfile("SYSTEM.INI display description: ",ini);
    if(RegOpenKeyExA(HKEY_LOCAL_MACHINE,"System\\CurrentControlSet\\Services\\Class\\Display",0,KEY_READ,&root)!=ERROR_SUCCESS)return;
    for(i=0;RegEnumKeyA(root,i,adapter,sizeof(adapter))==ERROR_SUCCESS;i++){
        if(RegOpenKeyExA(root,adapter,0,KEY_READ,&key)!=ERROR_SUCCESS)continue;
        n=sizeof(label)-1;label[0]=0;RegQueryValueExA(key,"DriverDesc",NULL,&type,(BYTE*)label,&n);label[sizeof(label)-1]=0;
        n=sizeof(driver)-1;driver[0]=0;RegQueryValueExA(key,"InfPath",NULL,&type,(BYTE*)driver,&n);driver[sizeof(driver)-1]=0;
        wsprintfA(path,"Display class %.30s: %.110s. INF %.80s.",adapter,label,driver);
        textfile("Installed display binding: ",path);RegCloseKey(key);
    }
    RegCloseKey(root);
}
#else
static void video_drivers(void)
{
    HDEVINFO set;
    SP_DEVINFO_DATA d;
    HKEY key;
    SC_HANDLE manager,svc;
    SERVICE_STATUS status;
    char label[220],name[220],service[120],ver[100],file[280],svcpath[240];
    DWORD type,n,i,len,err;
    wp_sleep_video(label,sizeof(label));textfile("Primary display: ",label);
    set=SetupDiGetClassDevsA(&display_class,NULL,NULL,DIGCF_PRESENT);
    if(set==INVALID_HANDLE_VALUE){textfile("Display device list: ","Unavailable");return;}
    manager=OpenSCManagerA(NULL,NULL,SC_MANAGER_CONNECT);
    d.cbSize=sizeof(d);
    for(i=0;SetupDiEnumDeviceInfo(set,i,&d);i++){
        name[0]=service[0]=ver[0]=file[0]=0;
        SetupDiGetDeviceRegistryPropertyA(set,&d,SPDRP_DEVICEDESC,&type,(BYTE*)name,sizeof(name)-1,&len);
        SetupDiGetDeviceRegistryPropertyA(set,&d,SPDRP_SERVICE,&type,(BYTE*)service,sizeof(service)-1,&len);
        key=SetupDiOpenDevRegKey(set,&d,DICS_FLAG_GLOBAL,0,DIREG_DRV,KEY_QUERY_VALUE);
        if(key!=INVALID_HANDLE_VALUE){n=sizeof(ver)-1;RegQueryValueExA(key,"DriverVersion",NULL,&type,(BYTE*)ver,&n);RegCloseKey(key);}
        svc=manager&&*service?OpenServiceA(manager,service,SERVICE_QUERY_STATUS):NULL;
        err=svc&&QueryServiceStatus(svc,&status)?status.dwCurrentState:0;
        if(svc)CloseServiceHandle(svc);
        if(*service){
            wsprintfA(svcpath,"SYSTEM\\CurrentControlSet\\Services\\%s",service);
            if(RegOpenKeyExA(HKEY_LOCAL_MACHINE,svcpath,0,KEY_QUERY_VALUE,&key)==ERROR_SUCCESS){
                n=sizeof(file)-1;RegQueryValueExA(key,"ImagePath",NULL,&type,(BYTE*)file,&n);RegCloseKey(key);
            }
        }
        name[sizeof(name)-1]=service[sizeof(service)-1]=ver[sizeof(ver)-1]=file[sizeof(file)-1]=0;
        wsprintfA(line,"Present display adapter: %s. Service=%s. State=%lu. Version=%s. Image=%s.\r\n",name,service,err,ver,file);record(line);
    }
    if(manager)CloseServiceHandle(manager);
    SetupDiDestroyDeviceInfoList(set);
}
#endif
static BOOL CALLBACK windows(HWND h, LPARAM unused)
{
    char cls[48],title[130];DWORD pid;
    (void)unused;GetWindowThreadProcessId(h,&pid);
    if(pid!=product_pid||!GetClassNameA(h,cls,sizeof(cls))||!GetWindowTextA(h,title,sizeof(title)))return TRUE;
    if(!lstrcmpA(cls,"WINPOWER"))mainwin=h;
    if(lstrcmpA(cls,"#32770"))return TRUE;
    if(!lstrcmpA(title,"WINPOWER - Sleep states"))panel=h;
    if(!lstrcmpA(title,"WINPOWER") && GetDlgItem(h,IDYES) && panel&&GetWindow(h,GW_OWNER)==panel)ask=h;
    return TRUE;
}
static void step(void)
{
    char val[700];
    HWND button;
    if(++ticks>360){KillTimer(marker,1);record("TIMEOUT while waiting for a visible GUI control.\r\n");return;}
    EnumWindows(windows,0);
    if(stage==0 && mainwin){
        PostMessageA(mainwin,WM_COMMAND,106,0);stage=1;
    }else if(stage==1 && panel){
        if(!GetDlgItemTextA(panel,151,val,sizeof(val)) || !GetWindowTextLengthA(GetDlgItem(panel,156)))return;
        textfile("Reported sleep states:\r\n",val);
        GetDlgItemTextA(panel,156,val,sizeof(val));textfile("Display on sleep panel: ",val);
        button=GetDlgItem(panel,hibernating?155:154);
        if(!button||!IsWindowEnabled(button)){
            record("BLOCKED: Windows did not expose the requested operation in the WINPOWER GUI.\r\n");
            KillTimer(marker,1);return;
        }
        PostMessageA(button,BM_CLICK,0,0);stage=2;
    }else if(stage==2 && ask){
        KillTimer(marker,1);submitted=TRUE;
        wsprintfA(line,"GUI confirmation reached for %s. PID=%lu. RAM checksum=%08lX.\r\n",
                  hibernating?"S4 hibernation":"suspend",GetCurrentProcessId(),digest_before);
        record(line);
        PostMessageA(GetDlgItem(ask,IDYES),BM_CLICK,0,0);
    }
}
static LRESULT CALLBACK proc(HWND w,UINT m,WPARAM wp,LPARAM lp)
{
    PAINTSTRUCT paint;HDC dc;
    switch(m){
    case WM_PAINT:
        dc=BeginPaint(w,&paint);TextOutA(dc,10,14,shown,lstrlenA(shown));EndPaint(w,&paint);return 0;
    case WM_TIMER:step();return 0;
    case WM_POWERBROADCAST:
        if(wp==PBT_APMSUSPEND && submitted){asleep=TRUE;record("Windows broadcast suspend.\r\n");}
        if((wp==PBT_APMRESUMESUSPEND||wp==0x12) && submitted && asleep && !awake){
            awake=TRUE;
            wsprintfA(shown,"Resumed session %08lX. Press F8 to verify input.",digest());record("Windows broadcast resume.\r\n");
            ShowWindow(w,SW_SHOW);SetForegroundWindow(w);InvalidateRect(w,NULL,TRUE);
        }
        return TRUE;
    case WM_KEYDOWN:
        if(wp==VK_F8 && awake && digest_before==digest()){
            dc=GetDC(w);wsprintfA(line,"PASS: same running process %lu, RAM checksum %08lX, display %dx%d, F8 received after resume.\r\n",
                GetCurrentProcessId(),digest(),GetDeviceCaps(dc,HORZRES),GetDeviceCaps(dc,VERTRES));ReleaseDC(w,dc);record(line);
            lstrcpyA(shown,"Resume verified. The original in-memory marker and keyboard are available.");InvalidateRect(w,NULL,TRUE);
        }
        return 0;
    case WM_DESTROY:PostQuitMessage(0);return 0;
    }
    return DefWindowProcA(w,m,wp,lp);
}
void WINAPI WinMainCRTStartup(void)
{
    typedef BOOLEAN (WINAPI *random_bytes)(PVOID,ULONG);
    random_bytes random;
    WNDCLASSA cls={0};MSG msg;DWORD pid;HANDLE log;char *leaf,markerfile[MAX_PATH],app[MAX_PATH];
    if(!GetModuleFileNameA(NULL,base,sizeof(base)))ExitProcess(1);
    leaf=base+lstrlenA(base);while(leaf>base&&leaf[-1]!='\\')--leaf;
    hibernating=!lstrcmpiA(leaf,"H.EXE");
    if(!hibernating&&lstrcmpiA(leaf,"S.EXE"))ExitProcess(2);
    *leaf=0;lstrcpyA(markerfile,base);lstrcatA(markerfile,"SLEEPQA.ID");
    if(GetFileAttributesA(markerfile)==INVALID_FILE_ATTRIBUTES||!FindWindowA("Shell_TrayWnd",NULL))ExitProcess(3);
    lstrcpyA(logpath,base);lstrcatA(logpath,hibernating?"S4TEST.TXT":"S3TEST.TXT");
    log=CreateFileA(logpath,GENERIC_WRITE,FILE_SHARE_READ,NULL,CREATE_NEW,0,NULL);
    if(log==INVALID_HANDLE_VALUE)ExitProcess(4);
    CloseHandle(log);
    random=(random_bytes)GetProcAddress(GetModuleHandleA("ADVAPI32.DLL"),"SystemFunction036");
    /* Early Windows versions can lack the random-byte API. This challenge
       distinguishes a new test process from the original suspended session. */
    if(!random||!random(secret,sizeof(secret))){
        LARGE_INTEGER counter;DWORD seed=GetTickCount()^GetCurrentProcessId();unsigned i;
        for(i=0;i<sizeof(secret);i++){
            if(QueryPerformanceCounter(&counter))seed^=(DWORD)counter.LowPart;
            seed=seed*1664525UL+1013904223UL;
            secret[i]=(BYTE)(seed>>24);
        }
    }
    digest_before=digest();pid=GetCurrentProcessId();wsprintfA(shown,"Unsaved session %08lX. Process %lu.",digest_before,pid);
    textfile("Session: ",shown);video_drivers();
    cls.lpfnWndProc=proc;cls.hInstance=GetModuleHandleA(NULL);cls.hbrBackground=(HBRUSH)(COLOR_WINDOW+1);cls.lpszClassName="WpSleepMarker";
    if(!RegisterClassA(&cls))ExitProcess(6);
    marker=CreateWindowA(cls.lpszClassName,"WINPOWER - Resume test",WS_OVERLAPPEDWINDOW|WS_VISIBLE,6,6,570,110,NULL,NULL,cls.hInstance,NULL);
    if(!marker)ExitProcess(7);
    lstrcpyA(app,base);
#ifdef WP_9XQA
    lstrcatA(app,"WINPWR9X.EXE");
#else
    lstrcatA(app,"WINPWRNT.EXE");
#endif
    start.cb=sizeof(start);
    if(!CreateProcessA(app,NULL,NULL,NULL,FALSE,0,NULL,base,&start,&process)){record("Cannot launch release GUI.\r\n");ExitProcess(8);}
    product_pid=process.dwProcessId;CloseHandle(process.hThread);CloseHandle(process.hProcess);
    SetTimer(marker,1,250,NULL);
    while(GetMessageA(&msg,NULL,0,0)>0){TranslateMessage(&msg);DispatchMessageA(&msg);}
    ExitProcess(0);
}
