/* Hardware-reduced register admission and exact fixed-byte transfers. */
#include <assert.h>
#include <stdio.h>
#include <string.h>
#include "S5.H"
#include "PWRSEQ.H"
static unsigned char ram[3072],work[1024];
static unsigned count,prepare_ok,mem_ok,ports[8],values[8],wide_seen;
static void put(unsigned char *p,unsigned long v){unsigned i;for(i=0;i<4;i++){p[i]=(unsigned char)v;v>>=8;}}
static void seal(unsigned char *p,unsigned n,unsigned field){unsigned i;unsigned char sum=0;p[field]=0;for(i=0;i<n;i++)sum=(unsigned char)(sum+p[i]);p[field]=(unsigned char)(0-sum);}
static void header(unsigned at,const char *name,unsigned n,unsigned rev){memcpy(ram+at,name,4);put(ram+at+4,n);ram[at+8]=(unsigned char)rev;}
static void reg(unsigned at,unsigned space,unsigned long lo,unsigned long hi){ram[256+at]=(unsigned char)space;ram[257+at]=8;put(ram+260+at,lo);put(ram+264+at,hi);}
static void tables(unsigned rev,unsigned minor,unsigned space){
 static const unsigned char s5[]={8,'_','S','5','_',0x12,6,2,0x0a,5,0x0a,2};
 memset(ram,0,sizeof(ram));memcpy(ram+16,"RSD PTR ",8);put(ram+32,128);seal(ram+16,20,8);
 header(128,"RSDT",40,1);put(ram+164,256);seal(ram+128,40,9);
 header(256,"FACP",276,rev);put(ram+296,1100);put(ram+368,0x100400UL);ram[387]=(unsigned char)minor;
 reg(116,space,0x606,0);ram[384]=0x42;reg(244,space,0x600,0);reg(256,space,0x601,0);
 header(1100,"DSDT",36+sizeof(s5),2);memcpy(ram+1136,s5,sizeof(s5));seal(ram+1100,36+sizeof(s5),9);
}
static int read_ram(void *g,unsigned long at,unsigned char *p,unsigned n){(void)g;if(at>sizeof(ram)||n>sizeof(ram)-at)return 0;memcpy(p,ram+at,n);return 1;}
static struct pn_acpi fw;
static int probe(void){seal(ram+256,276,9);return pn_tables(read_ram,0,16,&fw,work,sizeof(work));}
static int bind(struct pn_reg *r){if(r->high)wide_seen++;return mem_ok;}
static int write_mem(const struct pn_reg *r,unsigned val){assert(count<8);ports[count]=(unsigned)r->low;values[count++]=val;return mem_ok;}
static void write_port(void *g,unsigned port,unsigned val){(void)g;assert(count<8);ports[count]=port;values[count++]=val;}
static void wait(void *g,unsigned ticks){(void)g;(void)ticks;}
static int prepare(void *g){(void)g;return prepare_ok;}
/* Classic two-word controls can be independently memory or I/O mapped. */
static unsigned words[2],rd_ok;
static int get_word(const struct pn_reg *r,unsigned *v){
 assert(r->bytes==2);if(!rd_ok)return 0;*v=words[r==&fw.pm1b_reg];return 1;
}
static int put_word(const struct pn_reg *r,unsigned v){
 assert(r->bytes==2);words[r==&fw.pm1b_reg]=v;return write_mem(r,v);
}
static void classic(void){
 struct pn_io io;unsigned i;
 tables(6,6,0);put(ram+368,0);reg(172,0,0x2000,1);reg(184,0,0x2002,1);
 ram[256+173]=ram[256+185]=16;ram[256+175]=ram[256+187]=2;
 assert(probe()&&!fw.reduced&&fw.off_ok&&fw.pm1a_reg.bytes==2&&fw.pm1b_reg.bytes==2);
 wide_seen=0;mem_ok=1;pn_bindregs(&fw,bind);assert(fw.off_ok&&wide_seen==2);
 memset(&io,0,sizeof(io));io.read_mmio16=get_word;io.write_mmio=put_word;io.wait=wait;
 words[0]=words[1]=1;count=0;rd_ok=1;assert(pn_s5off(&fw,&io)<0&&count==6);
 for(i=0;i<6;i++)assert(ports[i]==0x2000+(i%2)*2);
 assert(values[0]==0x1401&&values[1]==0x0801&&values[2]==0x3401&&values[3]==0x2801&&values[4]==1&&values[5]==1);
 count=0;rd_ok=0;assert(pn_s5off(&fw,&io)<0&&!count);
 assert(probe());mem_ok=0;pn_bindregs(&fw,bind);assert(!fw.off_ok);
 reg(184,0,0x2000,1);ram[256+185]=16;assert(probe()&&!fw.off_ok);
 reg(184,0,0x2003,1);ram[256+185]=16;assert(probe()&&!fw.off_ok);
 reg(184,1,0x608,0);ram[256+185]=16;assert(probe()&&fw.off_ok&&fw.pm1b==0x608);
 reg(116,0,0x2001,1);put(ram+368,0x400);assert(probe()&&!fw.off_ok&&!fw.reset_ok);
}
static void pci(void){
 tables(6,6,0);reg(116,2,(3UL<<16)+0x4a0,17);put(ram+132,44);put(ram+168,1700);seal(ram+128,44,9);
 header(1700,"MCFG",60,1);put(ram+1744,0xe0000000UL);ram[1755]=255;seal(ram+1700,60,9);
 assert(probe()&&fw.reset_ok&&fw.reset_pci&&fw.reset_reg.space==0&&fw.reset_reg.bytes==1&&fw.reset_reg.low==0xe008b4a0UL);
 put(ram+1748,1);seal(ram+1700,60,9);assert(probe()&&fw.reset_ok&&fw.reset_reg.high==1);
 ram[1754]=1;seal(ram+1700,60,9);assert(probe()&&!fw.reset_ok);ram[1754]=0;
 put(ram+1744,0xe0000100UL);seal(ram+1700,60,9);assert(probe()&&!fw.reset_ok);
 put(ram+1744,0xe0000000UL);seal(ram+1700,60,9);reg(116,2,8UL<<16,17);assert(probe()&&!fw.reset_ok);
 reg(116,2,0x1000,17);assert(probe()&&!fw.reset_ok);reg(116,2,0x100,32);assert(probe()&&!fw.reset_ok);
}
int main(void){
 struct pn_io io;unsigned rev,minor;memset(&io,0,sizeof(io));io.wait=wait;io.put8=write_port;io.write_mmio=write_mem;io.prepare=prepare;
 for(rev=5;rev<=6;rev++)for(minor=0;minor<=(rev==5?1U:6U);minor++){
  tables(rev,minor,1);assert(probe()&&fw.reduced&&fw.off_ok&&fw.reset_ok);pn_bindregs(&fw,0);
  count=0;prepare_ok=1;assert(pn_s5off(&fw,&io)<0&&count==2);
  assert(ports[0]==0x601&&values[0]==0x80&&ports[1]==0x600&&values[1]==0x34);
  count=0;pn_reset(&fw,&io);assert(count==1&&ports[0]==0x606&&values[0]==0x42);
 }
 tables(6,6,0);reg(244,0,0x600,1);reg(256,0,0x601,1);assert(probe()&&fw.off_ok);mem_ok=1;pn_bindregs(&fw,bind);assert(wide_seen==2);
 count=0;assert(pn_s5off(&fw,&io)<0&&count==2&&values[1]==0x34);
 count=0;prepare_ok=0;assert(pn_s5off(&fw,&io)<0&&count==0);prepare_ok=1;
 assert(probe());mem_ok=0;pn_bindregs(&fw,bind);assert(!fw.off_ok&&!fw.reset_ok);
 count=0;assert(pn_s5off(&fw,&io)<0);pn_reset(&fw,&io);assert(!count);
 tables(5,0,1);reg(256,1,0x600,0);assert(probe()&&!fw.off_ok);
 tables(5,0,1);reg(116,1,0x601,0);assert(probe()&&!fw.off_ok&&!fw.reset_ok);
 tables(6,1,1);ram[256+245]=16;assert(probe()&&!fw.off_ok);
 tables(6,2,1);ram[256+246]=1;assert(probe()&&!fw.off_ok);
 tables(6,3,1);ram[256+247]=2;assert(probe()&&!fw.off_ok);
 tables(6,4,1);reg(256,1,0x10000,0);assert(probe()&&!fw.off_ok);
 tables(6,5,1);reg(244,1,0x602,1);assert(probe()&&!fw.off_ok);
 tables(6,6,1);reg(244,2,0x600,0);assert(probe()&&!fw.off_ok);
 tables(6,6,1);reg(256,1,0,0);assert(probe()&&!fw.off_ok);
 tables(4,0,1);assert(probe()&&fw.reduced&&!fw.off_ok);
 tables(7,1,1);assert(probe()&&!fw.off_ok&&!fw.reset_ok);
 classic();pci();
 puts("PASS: classic PM1 MMIO widths, ordered sleep types/enables, read failure and alias checks; PCI RESET_REG/MCFG validation.");
 puts("PASS: ACPI 5.0 through 6.6 reduced S5/RESET, 64-bit GAS, failed mappings/preparation, invalid/aliased registers.");
 return 0;
}
