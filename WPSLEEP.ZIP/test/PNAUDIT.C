/* Read-only Win9x installation audit used by the QEMU tests. */
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include "PN9INI.H"
static char input[65536],output[65536];
void *memset(void *p,int c,size_t n){unsigned char *s=p;while(n--)*s++=(unsigned char)c;return p;}
static int present(const char *p){return GetFileAttributesA(p)!=INVALID_FILE_ATTRIBUTES;}
void WINAPI WinMainCRTStartup(void){
 char windir[MAX_PATH],folder[MAX_PATH],path[MAX_PATH],driver[MAX_PATH],desktop[MAX_PATH],message[1024];
 DWORD got=0,n=0,kind=0,bytes;HKEY key;HANDLE file;int startup=-1,arp=0,link=0,once=0,dir,app,vxd,temp,recovery;
 unsigned written;GetWindowsDirectoryA(windir,sizeof(windir));folder[0]=windir[0];folder[1]=':';folder[2]=0;lstrcatA(folder,"\\WINPWR9X");
 wsprintfA(driver,"%s\\PN9HOOK.VXD",folder);vxd=present(driver);dir=present(folder);
 wsprintfA(path,"%s\\WINPWR9X.EXE",folder);app=present(path);
 wsprintfA(path,"%s\\SYSOLD.INI",folder);recovery=present(path);
 wsprintfA(path,"%s\\PN9NEW.INI",windir);temp=present(path);
 wsprintfA(path,"%s\\SYSTEM.INI",windir);file=CreateFileA(path,GENERIC_READ,FILE_SHARE_READ,0,OPEN_EXISTING,0,0);
 if(file!=INVALID_HANDLE_VALUE){n=GetFileSize(file,0);if(n<sizeof(input)&&ReadFile(file,input,n,&got,0)&&got==n){int r=pn9_ini(input,n,output,sizeof(output),driver,1,&written);startup=r==1?1:(r==2?0:-1);}CloseHandle(file);}
 if(RegOpenKeyExA(HKEY_LOCAL_MACHINE,"Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\WINPWR9X",0,KEY_READ,&key)==ERROR_SUCCESS){arp=1;RegCloseKey(key);}
 if(RegOpenKeyExA(HKEY_LOCAL_MACHINE,"Software\\Microsoft\\Windows\\CurrentVersion\\RunOnce",0,KEY_READ,&key)==ERROR_SUCCESS){bytes=0;once=RegQueryValueExA(key,"WINPWR9X",0,&kind,0,&bytes)==ERROR_SUCCESS;RegCloseKey(key);}
 if(RegOpenKeyExA(HKEY_CURRENT_USER,"Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Shell Folders",0,KEY_READ,&key)==ERROR_SUCCESS){bytes=sizeof(desktop);if(RegQueryValueExA(key,"Desktop",0,&kind,(BYTE*)desktop,&bytes)==ERROR_SUCCESS&&kind==REG_SZ&&bytes<sizeof(desktop)){desktop[bytes]=0;wsprintfA(path,"%s\\WINPWR9X.LNK",desktop);link=present(path);}RegCloseKey(key);}
 wsprintfA(message,"WINPWR9X installation audit (read only)\r\n\r\nFolder: %d  GUI: %d  Driver file: %d\r\nSYSTEM.INI startup entry: %d\r\nDesktop shortcut: %d\r\nAdd/Remove Programs registration: %d\r\nRunOnce cleanup: %d\r\nTemporary INI: %d  Recovery INI: %d\r\n\r\n1 = present, 0 = absent, -1 = query failed.\r\nNo files, settings or power hooks were changed.",dir,app,vxd,startup,link,arp,once,temp,recovery);
 MessageBoxA(0,message,"WINPOWER installation audit",MB_OK);ExitProcess(startup<0?1:0);
}
