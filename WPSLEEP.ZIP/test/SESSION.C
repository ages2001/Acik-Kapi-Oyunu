#include <assert.h>
#include <stdio.h>
#include <string.h>
#include "PNLINK.H"
#include "OWN16.H"
int main(void){
 struct pn_state state;struct wp_pref16 pref;unsigned i;
 for(i=0;i<2;i++){wp_pref16(&pref,i);assert(wp_pref_ok(&pref));}
 pref.tag[0]='X';assert(!wp_pref_ok(&pref));
 wp_pref16(&pref,1);pref.inverse++;assert(!wp_pref_ok(&pref));
 wp_pref16(&pref,2);assert(!wp_pref_ok(&pref));
 memset(&state,0,sizeof(state));memcpy(state.magic,PN_MAGIC,8);
 assert(sizeof(state)==22);assert(pn_valid(&state));assert(pn_action(&state,0)==0);
 state.ready=1;assert(pn_action(&state,0)==4);
 state.action=1;assert(pn_action(&state,0)==4);
 state.action=2;assert(pn_action(&state,0)==4);
 state.action=3;assert(pn_action(&state,0)==3);
 state.owner=2;assert(!pn_valid(&state));state.owner=1;state.action=0;
 assert(pn_action(&state,0)==1);
 state.action=1;assert(pn_action(&state,0)==1);
 state.action=2;assert(pn_action(&state,0)==2);
 assert(pn_action(&state,-1)==0);assert(pn_action(&state,1)==0);
 for(i=0;i<8;i++){state.magic[i]^=0x40;assert(!pn_valid(&state));assert(pn_action(&state,0)==0);state.magic[i]^=0x40;}
 state.action=3;assert(pn_action(&state,0)==3);
 state.action=4;assert(pn_action(&state,0)==0);state.action=0;
 state.ready=2;assert(pn_action(&state,0)==0);
 state.ready=1;state.cap_flags=4;assert(!pn_valid(&state));state.cap_flags=0;
 state.acpi_rev=256;assert(!pn_valid(&state));state.acpi_rev=0xffff;assert(pn_valid(&state));
 /* Keep the handshake usable for an ACPI 1.0 FADT with no minor field
    and for a session which reports no ACPI metadata. */
 state.acpi_rev=0;state.fadt_rev=1;state.fadt_minor=0xffff;
 state.cap_flags=1;state.owner=1;state.action=0;
 assert(pn_valid(&state)&&pn_action(&state,0)==1);
 state.acpi_rev=0xffff;state.fadt_rev=0;state.cap_flags=0;state.action=2;
 assert(pn_valid(&state)&&pn_action(&state,0)==2);
 state.fadt_minor=0xfffe;assert(!pn_valid(&state));
 state.fadt_minor=256;assert(!pn_valid(&state));state.fadt_minor=255;assert(pn_valid(&state));
 puts("PASS: session owner, handback, handshake, native exit, restart, failed child and corrupt state");return 0;
}
