/* Read-only observation of the released Win9x status and owner interfaces. */
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
void WINAPI WinMainCRTStartup(void) {
    static OSVERSIONINFOA ver; static DWORD info[16]; DWORD owner=2,got=0,count=0,first,err=0;
    HANDLE dev,log; BOOL ok=FALSE,known=FALSE; char text[768];
    ver.dwOSVersionInfoSize=sizeof(ver);GetVersionExA(&ver);
    dev=CreateFileA("\\\\.\\PN9HOOK",0,0,NULL,OPEN_EXISTING,0,NULL);
    if(dev!=INVALID_HANDLE_VALUE){
        ok=DeviceIoControl(dev,1,NULL,0,info,sizeof(info),&got,NULL)&&got==sizeof(info);
        first=GetLastError();known=DeviceIoControl(dev,5,NULL,0,&owner,sizeof(owner),&count,NULL)&&count==sizeof(owner);
        err=!ok?first:!known?GetLastError():0;CloseHandle(dev);
    }else err=GetLastError();
    wsprintfA(text,"Windows %lu.%lu build %lu. Status query=%u, error=%lu, ABI=%lu, VMM=%04lX, ready=%lu, stage=%lu, OS ACPI=%lu, firmware=0x%lX, owner query=%u, owner=%lu.\r\n",ver.dwMajorVersion,ver.dwMinorVersion,ver.dwBuildNumber&0xffff,(UINT)ok,err,info[0],info[2],info[1],info[8],info[9],info[6],(UINT)known,owner);
    log=CreateFileA("C:\\V9STATE.TXT",GENERIC_WRITE,FILE_SHARE_READ,NULL,OPEN_ALWAYS,0,NULL);
    if(log!=INVALID_HANDLE_VALUE){SetFilePointer(log,0,NULL,FILE_END);WriteFile(log,text,lstrlenA(text),&count,NULL);FlushFileBuffers(log);CloseHandle(log);}
    MessageBoxA(NULL,text,"WINPOWER resident status",MB_OK);ExitProcess(ok&&known?0:1);
}
