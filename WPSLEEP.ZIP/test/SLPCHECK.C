#include <assert.h>
#include <stdio.h>
#include <string.h>
#include "SLPCAPS.H"
int main(void){
 unsigned char raw[76];struct wp_sleep_caps caps;unsigned i;
 memset(raw,0,sizeof(raw));wp_sleep_decode(&caps,0,4,0,1,WP_UNKNOWN,1,WP_UNKNOWN,0);
 assert(!caps.hibernate && !caps.suspend && caps.state[0]==WP_YES && caps.state[3]==WP_UNKNOWN);
 for(i=1;i<=3;i++){
  memset(raw,0,sizeof(raw));raw[i+2]=1;
  wp_sleep_decode(&caps,raw,6,1,1,WP_YES,1,WP_YES,0);assert(caps.suspend && caps.state[i]==WP_YES && !caps.hibernate);
  wp_sleep_decode(&caps,raw,6,1,1,WP_NO,1,WP_YES,0);assert(!caps.suspend);
 }
 memset(raw,0,sizeof(raw));raw[6]=1;wp_sleep_decode(&caps,raw,6,1,1,WP_YES,1,WP_YES,0);assert(!caps.hibernate);
 raw[8]=1;wp_sleep_decode(&caps,raw,6,1,1,WP_YES,1,WP_YES,0);assert(caps.hibernate);
 raw[22]=1;wp_sleep_decode(&caps,raw,10,0,1,WP_YES,1,WP_YES,0);assert(!caps.hibernate);
 raw[22]=2;wp_sleep_decode(&caps,raw,10,0,1,WP_YES,1,WP_YES,0);assert(caps.hibernate);
 memset(raw,0,sizeof(raw));raw[20]=1;wp_sleep_decode(&caps,raw,6,1,1,WP_YES,1,WP_YES,0);assert(!caps.suspend && caps.low_idle==WP_UNKNOWN);
 wp_sleep_decode(&caps,raw,6,2,1,WP_YES,1,WP_YES,0);assert(caps.suspend && caps.low_idle==WP_YES);
 wp_sleep_decode(&caps,raw,10,0,1,WP_YES,1,WP_YES,1);assert(!caps.suspend && !caps.hibernate);
 wp_sleep_decode(&caps,0,4,0,1,WP_YES,0,WP_NO,0);assert(caps.suspend && !caps.hibernate);
 puts("PASS: sleep capability, policy, legacy API and hibernation-file cases.");return 0;
}
