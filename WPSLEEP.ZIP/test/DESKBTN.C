/* Exercise the visible controls of the released GUI in a private desktop
   guest. The helper never calls a power API. R.EXE requests Restart and
   F.EXE requests Power off. A marker must identify the test volume. */
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
static char base[MAX_PATH], path[MAX_PATH], data[4096];
static HWND target, confirmation;
static DWORD target_pid;
static const char *relative(const char *tail) {
    lstrcpyA(path,base);
    lstrcatA(path,tail);
    return path;
}
static BOOL CALLBACK find_confirmation(HWND w, LPARAM p) {
    char cls[32], title[64]; DWORD pid=0;
    (void)p;
    GetWindowThreadProcessId(w,&pid);
    if(pid==target_pid && GetWindow(w,GW_OWNER)==target &&
       GetClassNameA(w,cls,sizeof(cls)) && !lstrcmpA(cls,"#32770") &&
       GetWindowTextA(w,title,sizeof(title)) && !lstrcmpA(title,"WINPOWER") && GetDlgItem(w,IDYES)){
        confirmation=w;
        return FALSE;
    }
    return TRUE;
}
static int includes(const char *s,const char *item) {
    while(*s){const char *a=s,*b=item;while(*b&&*a==*b){++a;++b;}if(!*b)return 1;++s;}return 0;
}
static void note(const char *message) {
    DWORD n;
    HANDLE out=CreateFileA(relative("BUTTON.TXT"),FILE_APPEND_DATA,FILE_SHARE_READ,NULL,OPEN_ALWAYS,0,NULL);
    if(out==INVALID_HANDLE_VALUE)ExitProcess(12);
    if(!WriteFile(out,message,lstrlenA(message),&n,NULL)||!FlushFileBuffers(out))ExitProcess(13);
    CloseHandle(out);
}
void WINAPI WinMainCRTStartup(void) {
    BOOL restart; unsigned i; DWORD n; char *leaf; HANDLE report; HWND button;
    PROCESS_INFORMATION process; static STARTUPINFOA start;
    if(!GetModuleFileNameA(NULL,base,sizeof(base)))ExitProcess(1);
    leaf=base+lstrlenA(base);while(leaf>base&&leaf[-1]!='\\')--leaf;
    restart=!lstrcmpiA(leaf,"R.EXE");
    if(!restart && lstrcmpiA(leaf,"F.EXE"))ExitProcess(2);
    *leaf=0;
    if(GetFileAttributesA(relative("WPGUEST.ID"))==INVALID_FILE_ATTRIBUTES)ExitProcess(3);
    DeleteFileA(relative("GUIREAD.TXT"));
    start.cb=sizeof(start);
    if(!CreateProcessA(relative("GUIREAD.EXE"),NULL,NULL,NULL,FALSE,0,NULL,base,&start,&process))ExitProcess(4);
    CloseHandle(process.hThread);
    for(i=0;i<360;++i){
        Sleep(250);target=FindWindowA("WINPOWER","WINPOWER - Power Center");
        if(!target)continue;
        report=CreateFileA(relative("GUIREAD.TXT"),GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,NULL,OPEN_EXISTING,0,NULL);
        if(report==INVALID_HANDLE_VALUE)continue;
        n=0;if(!ReadFile(report,data,sizeof(data)-1,&n,NULL))n=0;
        CloseHandle(report);data[n]=0;
        if(includes(data,"MiniNT=0.")&&includes(data,"GUI launch error=0.")&&includes(data,"Shutdown owner:"))break;
    }
    if(i==360){note("FAIL: desktop status readback timed out.\r\n");ExitProcess(5);}
    lstrcpyA(data,relative("GUIREAD.TXT"));
    if(!CopyFileA(data,relative(restart?"READR.TXT":"READF.TXT"),FALSE))ExitProcess(6);
    GetWindowThreadProcessId(target,&target_pid);
    button=GetDlgItem(target,restart?102:101);
    if(!button||!IsWindowEnabled(button)||!PostMessageA(button,BM_CLICK,0,0))ExitProcess(7);
    for(i=0;i<100&&!confirmation;++i){Sleep(100);EnumWindows(find_confirmation,0);}
    if(!confirmation)ExitProcess(8);
    note(restart?"Restart: desktop status saved; selected GUI Restart and confirmed Yes.\r\n":
                 "Power off: desktop status saved; selected GUI Power off and confirmed Yes.\r\n");
    if(!PostMessageA(GetDlgItem(confirmation,IDYES),BM_CLICK,0,0))ExitProcess(9);
    CloseHandle(process.hProcess);
    ExitProcess(0);
}
