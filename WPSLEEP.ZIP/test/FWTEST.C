#include <assert.h>
#include <stdio.h>
#include <string.h>
#include "FWTABLE.H"
static unsigned char table[WP_FADT_MAX+1];
static void put32(unsigned off,unsigned long value){unsigned i;for(i=0;i<4;i++)table[off+i]=(unsigned char)(value>>(8*i));}
static void checksum(unsigned n){unsigned i,sum=0;table[9]=0;for(i=0;i<n;i++)sum=(sum+table[i])&255;table[9]=(unsigned char)(0U-sum);}
static void make(unsigned revision,unsigned n){memset(table,0,sizeof(table));memcpy(table,"FACP",4);put32(4,n);table[8]=(unsigned char)revision;checksum(n);}
static int zero(const struct wp_fwtable *p){const unsigned char *b=(const unsigned char*)p;unsigned i;for(i=0;i<sizeof(*p);i++)if(b[i])return 0;return 1;}
int main(void){
 struct wp_fwtable info;unsigned i,n,revision;unsigned lengths[]={0,116,132,244,244,268,276};
 for(revision=1;revision<=6;revision++){
  n=lengths[revision];make(revision,n);assert(wp_fadt(table,n,&info));assert(info.revision==revision&&info.table_length==n);
  for(i=0;i<n;i++){assert(!wp_fadt(table,i,&info));assert(zero(&info));}
  make(revision,n-1);assert(!wp_fadt(table,n-1,&info));
 }
 make(6,276);table[131]=6;put32(112,0x00300400UL);checksum(276);
 assert(wp_fadt(table,276,&info));assert(info.flags==0x00300400UL&&info.flags_valid&&info.capabilities_valid);
 assert(info.minor_valid&&info.minor_revision==6&&info.reset_register&&info.hardware_reduced&&info.low_power_s0);
 for(i=0;i<276;i++){table[i]^=1;assert(!wp_fadt(table,276,&info));assert(zero(&info));table[i]^=1;}
 make(1,116);put32(112,0x00300400UL);checksum(116);assert(wp_fadt(table,116,&info));
 assert(info.flags_valid&&info.capabilities_valid&&!info.minor_valid&&!info.reset_register&&!info.hardware_reduced&&!info.low_power_s0);
 make(4,244);table[131]=99;put32(112,0x00300400UL);checksum(244);assert(wp_fadt(table,244,&info));
 assert(!info.minor_valid&&info.reset_register&&!info.hardware_reduced&&!info.low_power_s0);
 make(7,36);assert(wp_fadt(table,36,&info));assert(info.revision==7&&!info.flags_valid&&!info.capabilities_valid&&!info.minor_valid);
 make(0,116);assert(!wp_fadt(table,116,&info));assert(zero(&info));
 make(6,276);table[0]='X';checksum(276);assert(!wp_fadt(table,276,&info));
 make(6,276);assert(!wp_fadt(table,277,&info));assert(!wp_fadt(table,275,&info));
 make(6,276);put32(4,0xffffffffUL);checksum(276);assert(!wp_fadt(table,276,&info));
 make(6,WP_FADT_MAX);assert(wp_fadt(table,WP_FADT_MAX,&info));
 make(6,WP_FADT_MAX+1);assert(!wp_fadt(table,WP_FADT_MAX+1,&info));assert(zero(&info));
 assert(!wp_fadt(0,276,&info));assert(zero(&info));assert(!wp_fadt(table,276,0));
 puts("PASS: FADT signatures, exact lengths, truncation, checksum mutation, revision layouts, minor fields and advertised capability bounds");return 0;
}
