/* Exercise the NT3/4 owner protocol separately from the firmware backend. */
#include <assert.h>
#include <stdio.h>
#include <stdint.h>
typedef uint32_t ULONG;
typedef unsigned char BOOLEAN, KIRQL;
typedef int NTSTATUS, KSPIN_LOCK;
typedef void *PVOID;
typedef KSPIN_LOCK *PKSPIN_LOCK;
typedef KIRQL *PKIRQL;
#define TRUE 1
#define VOID void
#define NTAPI
#define __declspec(attribute)
#define STATUS_SUCCESS 0
#define STATUS_BUFFER_TOO_SMALL 1
#define STATUS_INVALID_PARAMETER 2
#define STATUS_INVALID_DEVICE_REQUEST 3
#define STATUS_SHUTDOWN_IN_PROGRESS 4
#include "LEGCTRL.H"
void KeAcquireSpinLock(PKSPIN_LOCK lock,PKIRQL irql){
 assert(*lock==0);*lock=1;*irql=0;
}
void KeReleaseSpinLock(PKSPIN_LOCK lock,KIRQL irql){
 assert(*lock==1&&irql==0);*lock=0;
}
static ULONG read_owner(void){
 ULONG value=0,written=0;
 assert(leg_control(WP_LEG_QUERY,&value,0,4,&written)==STATUS_SUCCESS);
 assert(written==4&&(value&~1U)==0x100);
 return value&1U;
}
static NTSTATUS choose(ULONG value){
 ULONG written=9;
 NTSTATUS rc=leg_control(WP_LEG_SET,&value,4,0,&written);
 assert(written==0);return rc;
}
int main(void){
 ULONG mode,word=0,count=0;
 for(mode=0;mode<2;mode++){
  leg_owner=leg_at_shutdown=0;leg_closing=0;
  assert(read_owner()==0);assert(choose(1)==STATUS_SUCCESS);assert(read_owner()==1);
  assert(choose(0)==STATUS_SUCCESS);assert(read_owner()==0);
  assert(choose(2)==STATUS_INVALID_PARAMETER);
  assert(leg_control(WP_LEG_QUERY,&word,0,3,&count)==STATUS_BUFFER_TOO_SMALL);
  assert(leg_control(WP_LEG_SET,&word,3,0,&count)==STATUS_INVALID_PARAMETER);
  assert(leg_control(0x226004,&word,4,4,&count)==STATUS_INVALID_DEVICE_REQUEST);
  assert(leg_control(0x226008,&word,4,4,&count)==STATUS_INVALID_DEVICE_REQUEST);
  assert(choose(mode)==STATUS_SUCCESS);leg_latch();assert(leg_at_shutdown==mode);
  assert(choose(1-mode)==STATUS_SHUTDOWN_IN_PROGRESS);assert(read_owner()==mode);
 }
 puts("PASS: NT3/4 default owner, round trip, final latch, length checks and removed immediate power requests");
 return 0;
}
