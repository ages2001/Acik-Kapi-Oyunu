/* Dynamically load and query the WINPOWER read-only VxD observer. */
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
void WINAPI WinMainCRTStartup(void) {
 char path[300],name[MAX_PATH],msg[512];DWORD i,size=0,error=0,info[5]={0};HANDLE h;
 DWORD version=GetVersion();
 if(!(version&0x80000000UL) || LOBYTE(LOWORD(version))!=4) {
  MessageBoxA(0,"This observer requires Windows 95, 98 or Me.","WINPOWER VxD observer",MB_OK);ExitProcess(50);
 }
 GetModuleFileNameA(0,name,sizeof(name));i=lstrlenA(name);
 while(i && name[i-1]!='\\')i--;
 name[i]=0;SetCurrentDirectoryA(name);lstrcatA(name,"PN9TRACE.VXD");
 lstrcpyA(path,"\\\\.\\PN9TRACE.VXD");
 h=CreateFileA(path,0,0,0,CREATE_NEW,FILE_FLAG_DELETE_ON_CLOSE,0);
 if(h==INVALID_HANDLE_VALUE)error=GetLastError();
 else {
  if(!DeviceIoControl(h,1,0,0,info,sizeof(info),&size,0))error=GetLastError();
  else if(size!=sizeof(info)||info[0]!=1)error=13;
 }
 wsprintfA(msg,"QEMU VxD observer\r\nError: %lu  Bytes: %lu\r\nProtocol: %lu  Controls seen: %lu  Last: %08lX\r\nVMM: %08lX  APM BIOS: %08lX\r\n%s\r\nFile attributes: %08lX\r\n\r\nDebug tracing uses QEMU I/O port E9.\r\nPower services are traced and forwarded unchanged.\r\nThe observer remains loaded until Windows exits.",error,size,info[0],info[1],info[2],info[3],info[4],name,GetFileAttributesA(name));
 MessageBoxA(0,msg,"WINPOWER VxD observer",MB_OK);
 if(h!=INVALID_HANDLE_VALUE)CloseHandle(h);
 ExitProcess(error);
}
