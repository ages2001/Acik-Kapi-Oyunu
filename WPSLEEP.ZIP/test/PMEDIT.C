/* Isolated NT3 test fixture: retarget one owned item to NOTEPAD.EXE. */
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <ddeml.h>
#include "NTITEM.H"
static char data[32768],report[66000],message[300];
static const char app[]="C:\\WINPWRNT\\WINPWRNT.EXE";
static const char uninst[]="C:\\WINPWRNT\\UNINST.EXE";
static HDDEDATA CALLBACK callback(UINT a,UINT b,HCONV c,HSZ d,HSZ e,HDDEDATA f,ULONG_PTR g,ULONG_PTR h){(void)a;(void)b;(void)c;(void)d;(void)e;(void)f;(void)g;(void)h;return 0;}
static int query(HCONV conv,HSZ item){
 HDDEDATA response;DWORD size,got,reply,i;
 response=DdeClientTransaction(0,0,conv,item,CF_TEXT,XTYP_REQUEST,10000,&reply);
 if(!response)return 0;
 size=DdeGetData(response,0,0,0);
 if(!size||size>sizeof(data)){DdeFreeDataHandle(response);return 0;}
 got=DdeGetData(response,(BYTE*)data,size,0);DdeFreeDataHandle(response);
 if(got!=size)return 0;
 for(i=0;i<size;i++)if(!data[i])return 1;
 return 0;
}
void WINAPI WinMainCRTStartup(void){
 DWORD id=0,reply,error=0,bytes,got=0;HSZ name=0,item=0;HCONV conv=0;HANDLE file;
 struct nt_itemstat state;int ok=0;
 static const char command[]="[ShowGroup(WINPOWER,1)][ReplaceItem(WINPOWER)][AddItem(NOTEPAD.EXE,WINPOWER)]";
 lstrcpyA(report,"WINPOWER Program Manager edited-item fixture\r\n");
 if(DdeInitializeA(&id,callback,APPCMD_CLIENTONLY,0)!=DMLERR_NO_ERROR)goto done;
 name=DdeCreateStringHandleA(id,"PROGMAN",CP_WINANSI);item=DdeCreateStringHandleA(id,"WINPOWER",CP_WINANSI);
 conv=DdeConnect(id,name,name,0);if(!conv||!query(conv,item))goto done;
 lstrcatA(report,"BEFORE\r\n");lstrcatA(report,data);
 ni_scan(data,app,uninst,&state);
 if(state.count!=2||state.owned!=3||state.preserved)goto done;
 if(!DdeClientTransaction((BYTE*)command,sizeof(command),conv,0,0,XTYP_EXECUTE,10000,&reply))goto done;
 if(!query(conv,item))goto done;
 lstrcatA(report,"\r\nAFTER\r\n");lstrcatA(report,data);
 ni_scan(data,"NOTEPAD.EXE",uninst,&state);
 ok=state.count==2&&state.owned==3&&!state.preserved;
 done:
 if(conv)DdeDisconnect(conv);if(item)DdeFreeStringHandle(id,item);if(name)DdeFreeStringHandle(id,name);if(id)DdeUninitialize(id);
 lstrcatA(report,ok?"\r\nPASS: WINPOWER command is NOTEPAD.EXE; uninstaller is unchanged.\r\n":"\r\nFAIL: expected fixture identity was not established.\r\n");
 file=CreateFileA("C:\\PMEDIT.TXT",GENERIC_WRITE,FILE_SHARE_READ,0,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,0);
 if(file==INVALID_HANDLE_VALUE)error=GetLastError();
 else {bytes=(DWORD)lstrlenA(report);if(!WriteFile(file,report,bytes,&got,0))error=GetLastError();else if(got!=bytes)error=ERROR_WRITE_FAULT;
  if(!error&&!FlushFileBuffers(file))error=GetLastError();CloseHandle(file);}
 wsprintfA(message,"%s\r\nReport: C:\\PMEDIT.TXT\r\nReport write error: %lu",ok?"PASS: WINPOWER now opens NOTEPAD.EXE. Uninstall and verify this edited item is preserved.":"FAIL: inspect the recorded DDE data.",error);
 MessageBoxA(0,message,"WINPOWER edited-item fixture",MB_OK|MB_ICONINFORMATION);ExitProcess(error?2:(ok?0:1));
}
