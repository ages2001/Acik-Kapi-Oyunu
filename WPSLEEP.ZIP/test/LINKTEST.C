/* Exercise real link-ownership decisions with deterministic API faults. */
#include <stdio.h>
#include <string.h>
#include <strings.h>
#include <stdarg.h>
#include "../src/LINKOWN.C"
static const char path[]="C:\\DESKTOP\\WINPWRNT.LNK";
static BYTE saved[sizeof(struct lo_record)],bytes[20];
static DWORD last_error,attrs,record_type,record_size,write_error,open_error;
static unsigned exists,record_exists,position,deletes,writes,attr_writes,read_failure,delete_failure,cases,failures;
static unsigned batch_exists,run_exists;
static char saved_batch[1024],saved_run[308],windows_path[260];
static const char batch_path[]="C:\\WINDOWS\\WPGCLN.BAT";
int wsprintfA(char *out,const char *format,...){va_list v;int n;va_start(v,format);n=vsprintf(out,format,v);va_end(v);return n;}
DWORD GetLastError(void){return last_error;}
BOOL SetFileAttributesA(const char *p,DWORD a){if(strcmp(p,path))return FALSE;attrs=a;attr_writes++;return TRUE;}
DWORD GetFileAttributesA(const char *p){if(strcmp(p,path)||!exists){last_error=ERROR_FILE_NOT_FOUND;return INVALID_FILE_ATTRIBUTES;}return attrs;}
int lstrlenA(const char *p){return (int)strlen(p);}
int lstrcmpiA(const char *a,const char *b){return strcasecmp(a,b);}
char *lstrcpyA(char *a,const char *b){return strcpy(a,b);}
HANDLE CreateFileA(const char *p,DWORD a,DWORD b,void *c,DWORD d,DWORD e,HANDLE f){
 (void)a;(void)b;(void)c;(void)d;(void)e;(void)f;
 if(!strcmp(p,batch_path)&&d==CREATE_NEW){if(batch_exists){last_error=ERROR_ALREADY_EXISTS;return INVALID_HANDLE_VALUE;}batch_exists=1;return 2;}
 if(strcmp(p,path)||!exists){last_error=ERROR_FILE_NOT_FOUND;return INVALID_HANDLE_VALUE;}
 if(read_failure){last_error=ERROR_SHARING_VIOLATION;return INVALID_HANDLE_VALUE;}
 position=0;return 1;
}
BOOL ReadFile(HANDLE h,void *out,DWORD n,DWORD *got,void *overlap){
 unsigned size=(unsigned)sizeof(bytes)-position;(void)h;(void)overlap;if(size>n)size=n;
 memcpy(out,bytes+position,size);position+=size;*got=size;return TRUE;
}
BOOL CloseHandle(HANDLE h){(void)h;return TRUE;}
BOOL WriteFile(HANDLE h,const void *data,DWORD size,DWORD *got,void *overlap){
 (void)overlap;if(h!=2||size>=sizeof(saved_batch))return FALSE;memcpy(saved_batch,data,size);saved_batch[size]=0;*got=size;return TRUE;
}
BOOL FlushFileBuffers(HANDLE h){(void)h;return TRUE;}
BOOL DeleteFileA(const char *p){
 if(!strcmp(p,batch_path)){batch_exists=0;return TRUE;}
 if(strcmp(p,path)){failures++;return FALSE;}
 if(delete_failure){last_error=ERROR_ACCESS_DENIED;return FALSE;}
 exists=0;deletes++;return TRUE;
}
DWORD RegOpenKeyExA(HKEY a,const char *p,DWORD b,DWORD access,HKEY *out){
 (void)a;(void)p;(void)b;(void)access;if(open_error)return open_error;*out=1;return 0;
}
DWORD RegSetValueExA(HKEY a,const char *name,DWORD b,DWORD type,const BYTE *data,DWORD size){
 (void)a;(void)b;if(write_error)return write_error;
 if(a==2&&!strcmp(name,"WINPWR9XGUI")&&type==REG_SZ&&size<sizeof(saved_run)){memcpy(saved_run,data,size);run_exists=1;return 0;}
 if(strcmp(name,"Shortcut")||type!=REG_BINARY||size!=sizeof(saved)){failures++;return ERROR_ACCESS_DENIED;}
 memcpy(saved,data,size);record_exists=1;record_type=type;record_size=size;writes++;return 0;
}
DWORD RegFlushKey(HKEY h){(void)h;return 0;}
DWORD RegCloseKey(HKEY h){(void)h;return 0;}
DWORD RegQueryValueExA(HKEY a,const char *name,void *reserved,DWORD *type,BYTE *out,DWORD *size){
 (void)a;(void)reserved;
 if(a==2&&!strcmp(name,"WINPWR9XGUI")){if(!run_exists)return ERROR_FILE_NOT_FOUND;*type=REG_SZ;*size=(DWORD)strlen(saved_run)+1;return 0;}
 if(strcmp(name,"Shortcut")){failures++;return ERROR_FILE_NOT_FOUND;}
 if(!record_exists)return ERROR_FILE_NOT_FOUND;
 if(*size<record_size)return ERROR_MORE_DATA;
 memcpy(out,saved,record_size);*type=record_type;*size=record_size;return 0;
}
DWORD RegCreateKeyExA(HKEY a,const char *p,DWORD b,void *c,DWORD d,DWORD e,void *f,HKEY *out,DWORD *disp){
 (void)a;(void)p;(void)b;(void)c;(void)d;(void)e;(void)f;*out=2;*disp=1;return 0;
}
DWORD GetWindowsDirectoryA(char *out,DWORD size){if(strlen(windows_path)>=size)return (DWORD)strlen(windows_path)+1;strcpy(out,windows_path);return (DWORD)strlen(out);}
HMODULE GetModuleHandleA(const char *name){(void)name;return 1;}
static DWORD short_name(const char *path,char *out,DWORD size){if(strlen(path)>=size)return 0;strcpy(out,path);return (DWORD)strlen(out);}
void (*GetProcAddress(HMODULE module,const char *name))(void){(void)module;(void)name;return (void(*)(void))short_name;}
static void reset(void){
 memset(&staged,0,sizeof(staged));memset(saved,0,sizeof(saved));memset(bytes,0x5a,sizeof(bytes));
 have_staged=FALSE;notice=0;reason[0]=0;last_error=attrs=write_error=open_error=0;
 exists=1;record_exists=position=deletes=writes=attr_writes=read_failure=delete_failure=0;
 record_type=REG_BINARY;record_size=sizeof(saved);
 batch_exists=run_exists=0;saved_batch[0]=saved_run[0]=0;strcpy(windows_path,"C:\\WINDOWS");
}
static void check(const char *name,int passed){cases++;if(!passed){fprintf(stderr,"FAIL %s\n",name);failures++;}}
static int save(void){return lo_save("ARP",path,"WINPWRNT.LNK");}
int main(void){
 struct lo_record *record=(void*)saved;
 reset();check("atomic full ownership record",save()&&writes==1&&record->magic==LO_LINK_MAGIC&&!strcmp(record->path,path));
 check("exact matching link removed",lo_remove("ARP","WINPWRNT.LNK")&&deletes==1&&!exists&&!notice);
 reset();save();bytes[2]^=1;check("edited bytes preserved",lo_remove("ARP","WINPWRNT.LNK")&&!deletes&&exists&&notice==1);
 reset();check("old missing record preserved",lo_remove("ARP","WINPWRNT.LNK")&&!deletes&&exists&&notice==2);
 reset();save();record->magic=0;check("bad magic preserved",lo_remove("ARP","WINPWRNT.LNK")&&!deletes&&notice==2);
 reset();save();strcpy(record->path,"C:\\KEEP.TXT");check("unrelated record path preserved",lo_remove("ARP","WINPWRNT.LNK")&&!deletes&&notice==2);
 reset();save();record_size--;check("truncated record preserved",lo_remove("ARP","WINPWRNT.LNK")&&!deletes&&notice==2);
 reset();save();read_failure=1;check("unreadable link preserved",lo_remove("ARP","WINPWRNT.LNK")&&!deletes&&notice==2);
 reset();save();exists=0;check("already missing link accepted",lo_remove("ARP","WINPWRNT.LNK")&&!deletes&&!notice);
 reset();save();attrs=FILE_ATTRIBUTE_READONLY;check("verified readonly link removed",lo_remove("ARP","WINPWRNT.LNK")&&deletes==1&&attr_writes==1&&attrs==FILE_ATTRIBUTE_NORMAL);
 reset();save();delete_failure=1;check("failed deletion remains retryable",!lo_remove("ARP","WINPWRNT.LNK")&&record_exists&&exists);
 delete_failure=0;check("failed deletion retry",lo_remove("ARP","WINPWRNT.LNK")&&deletes==1);
 reset();write_error=ERROR_ACCESS_DENIED;check("failed atomic write retains staged identity",!save()&&!writes&&have_staged&&lo_undo()&&deletes==1);
 reset();read_failure=1;check("unverified partial save preserved",!save()&&!have_staged&&lo_undo()&&!deletes&&notice==2);
 reset();save();bytes[0]^=1;check("edited rollback link preserved",lo_undo()&&!deletes&&notice==1);
 reset();open_error=ERROR_ACCESS_DENIED;check("ownership access failure stops removal",!lo_remove("ARP","WINPWRNT.LNK")&&!deletes);
 reset();check("fixed folder cleanup scheduled",lo_finish9("C:\\WINPWR9X")&&batch_exists&&run_exists&&strstr(saved_batch,"\r\nRD C:\\WINPWR9X\r\n")&&!strstr(saved_batch,"/S")&&!strstr(saved_batch,"*"));
 check("cleanup uses exact owned batch",!strcmp(saved_run,"C:\\WINDOWS\\COMMAND.COM /C C:\\WINDOWS\\WPGCLN.BAT"));
 reset();check("arbitrary folder rejected",!lo_finish9("C:\\OTHER")&&!batch_exists&&!run_exists);
 reset();check("shell metacharacters rejected",!lo_finish9("C:\\WINPWR9X&DEL")&&!batch_exists&&!run_exists);
 reset();strcpy(windows_path,"C:\\WIN&DOWS");check("unsafe short Windows directory rejected",!lo_finish9("C:\\WINPWR9X")&&!batch_exists&&!run_exists);
 reset();run_exists=1;strcpy(saved_run,"prior command");check("existing RunOnce preserved",!lo_finish9("C:\\WINPWR9X")&&!batch_exists&&!strcmp(saved_run,"prior command"));
 reset();batch_exists=1;strcpy(saved_batch,"prior batch");check("existing batch preserved",!lo_finish9("C:\\WINPWR9X")&&!run_exists&&!strcmp(saved_batch,"prior batch"));
 reset();write_error=ERROR_ACCESS_DENIED;check("failed schedule removes only new batch",!lo_finish9("C:\\WINPWR9X")&&!batch_exists&&!run_exists);
 printf("LINKTEST: %u cases, %u failures\n",cases,failures);return failures?1:0;
}
