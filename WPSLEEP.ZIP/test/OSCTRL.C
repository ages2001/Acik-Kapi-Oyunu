/* Native Windows 2000 restart control for a disposable AHCI guest.
   Abort unless the product driver file and device are both absent. */
#define WIN32_LEAN_AND_MEAN
#include <windows.h>

void WINAPI WinMainCRTStartup(void)
{
    char file[MAX_PATH];
    const char message[] = "Driver file and device absent. Calling ExitWindowsEx(EWX_REBOOT).\r\n";
    DWORD bytes, error;
    HANDLE device, token, log;
    TOKEN_PRIVILEGES privileges;
    GetSystemDirectoryA(file, sizeof(file));
    lstrcatA(file, "\\drivers\\WINPWR5.SYS");
    if (GetFileAttributesA(file) != INVALID_FILE_ATTRIBUTES) ExitProcess(1);
    error = GetLastError();
    if (error != ERROR_FILE_NOT_FOUND && error != ERROR_PATH_NOT_FOUND) ExitProcess(2);
    device = CreateFileA("\\\\.\\PN5LAB", GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE,
                         NULL, OPEN_EXISTING, 0, NULL);
    if (device != INVALID_HANDLE_VALUE) { CloseHandle(device); ExitProcess(3); }
    error = GetLastError();
    if (error != ERROR_FILE_NOT_FOUND && error != ERROR_PATH_NOT_FOUND) ExitProcess(4);
    if (!OpenProcessToken(GetCurrentProcess(), TOKEN_QUERY | TOKEN_ADJUST_PRIVILEGES, &token)) ExitProcess(5);
    privileges.PrivilegeCount = 1;
    privileges.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;
    if (!LookupPrivilegeValueA(NULL, SE_SHUTDOWN_NAME, &privileges.Privileges[0].Luid)) ExitProcess(6);
    SetLastError(ERROR_SUCCESS);
    if (!AdjustTokenPrivileges(token, FALSE, &privileges, 0, NULL, NULL) || GetLastError()) ExitProcess(7);
    CloseHandle(token);
    log = CreateFileA("A:\\OSCTRL.TXT", GENERIC_WRITE, FILE_SHARE_READ, NULL, OPEN_ALWAYS, 0, NULL);
    if (log == INVALID_HANDLE_VALUE) ExitProcess(8);
    SetFilePointer(log, 0, NULL, FILE_END);
    if (!WriteFile(log, message, sizeof(message)-1, &bytes, NULL) || bytes != sizeof(message)-1 || !FlushFileBuffers(log)) ExitProcess(9);
    CloseHandle(log);
    ExitProcess(ExitWindowsEx(EWX_REBOOT, 0) ? 0 : 10);
}
