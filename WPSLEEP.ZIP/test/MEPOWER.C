/* Guest-only comparison. Both owners start with the same Windows API request. */
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
static DWORD read_owner(void)
{
    DWORD value=2, count=0;
    HANDLE driver=CreateFileA("\\\\.\\PN9HOOK",0,0,NULL,OPEN_EXISTING,0,NULL);
    if(driver!=INVALID_HANDLE_VALUE){
        if(!DeviceIoControl(driver,5,NULL,0,&value,sizeof(value),&count,NULL)
            ||count!=sizeof(value))value=2;
        CloseHandle(driver);
    }
    return value;
}
void WINAPI WinMainCRTStartup(void)
{
    char cmd[128],text[180]; DWORD owner=read_owner();
    BOOL reboot;
    lstrcpynA(cmd,GetCommandLineA(),sizeof(cmd));CharUpperBuffA(cmd,lstrlenA(cmd));
    reboot=lstrlenA(cmd)>=2&&cmd[lstrlenA(cmd)-1]=='R';
    wsprintfA(text,"Measured resident owner = %lu. Confirm a native Windows %s.",owner,reboot?"restart":"power off");
    if(owner<=1&&MessageBoxA(NULL,text,"WINPOWER native comparison",MB_OKCANCEL|MB_DEFBUTTON2)==IDOK)
        ExitProcess(!ExitWindowsEx(reboot?EWX_REBOOT:EWX_SHUTDOWN|EWX_POWEROFF,0));
    ExitProcess(2);
}
