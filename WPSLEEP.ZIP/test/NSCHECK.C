#include <stdio.h>
#include <assert.h>
#include "S5.H"
static const unsigned char base[]={
 8,'_','S','5','_',0x12,6,2,0x0a,5,0x0a,6,
 0x5b,0x82,5,'P','W','R','0',
 0x5b,0x82,5,'D','E','V','0'
};
/* Scope(\DEV0) { Scope(PWR0) { Method(^_PTS,1) {} } } */
static const unsigned char hidden[]={0x10,20,'\\','D','E','V','0',0x10,13,'P','W','R','0',0x14,7,'^','_','P','T','S',1};
static const unsigned char device[]={0x5b,0x82,5,'_','S','5','_'};
static const unsigned char mutex[]={0x5b,1,'_','S','5','_',0};
static const unsigned char event[]={0x5b,2,'_','S','5','_'};
static const unsigned char region[]={0x5b,0x80,'_','S','5','_',1,0,1};
static const unsigned char thermal[]={0x5b,0x85,5,'_','S','5','_'};
static const unsigned char resource[]={0x5b,0x84,8,'_','S','5','_',0,0,0};
static const unsigned char processor[]={0x5b,0x83,11,'_','S','5','_',0,0,0,0,0,0};
static const unsigned char pts_name[]={8,'_','P','T','S',0};
static const unsigned char s5_method[]={0x14,6,'_','S','5','_',0};
static const unsigned char reserved_scope[]={0x10,6,'_','S','5','_',0xa3};
/* OperationRegion(REG0,SystemIO,0x604,2); Field(REG0,WordAcc,NoLock,Preserve){_S5_,16} */
static const unsigned char field[]={0x5b,0x80,'R','E','G','0',1,0x0b,4,6,0x0a,2,0x5b,0x81,11,'R','E','G','0',2,'_','S','5','_',16};
/* Method(MTHD,0) {Return(One)}; Name(BUF0,Buffer(MTHD()){0}) */
static const unsigned char dynamic_buffer[]={0x14,8,'M','T','H','D',0,0xa4,1,8,'B','U','F','0',0x11,6,'M','T','H','D',0};
/* Scope(\_SB_) {Scope(\) {Method(_PTS,1) {}}} */
static const unsigned char root_scope[]={0x10,17,'\\','_','S','B','_',0x10,10,'\\',0,0x14,6,'_','P','T','S',1};
static const unsigned char parent_method[]={0x10,14,'\\','D','E','V','0',0x14,7,'^','_','P','T','S',1};
static const unsigned char conditional[]={0xa0,3,1,0xa3,0xa1,2,0xa3};
static const unsigned char alias[]={6,'D','E','V','0','_','S','5','_'};
/* The inner relative Scope can resolve at depth one or two. */
static const unsigned char ambig_s5[]={0x10,24,'D','E','V','0',0x10,18,'P','W','R','0',8,'^','_','S','5','_',0x12,6,2,0x0a,5,0x0a,6};
static const unsigned char nested_ok[]={0x10,17,'D','E','V','0',0x10,11,'P','W','R','0',8,'V','A','L','0',0};
/* Scope(DEV0){Scope(PWR0){Scope(^){Method(_PTS,1){}}}} */
static const unsigned char null_hook[]={0x10,22,'D','E','V','0',0x10,16,'P','W','R','0',0x10,10,'^',0,0x14,6,'_','P','T','S',1};
/* Reserved continuation bits would otherwise encode a valid Buffer length. */
static const unsigned char bad_pkg[]={8,'B','U','F','0',0x11,0x54,0,1,0};
static const unsigned char short_pkg[]={0x10,63,'D','E','V','0',0xa3};
static const unsigned char short_count[]={8,'B','U','F','0',0x11,4,0x0c,0,0};
static const unsigned char dynamic_count[]={8,'P','K','G','0',0x13,6,'M','T','H','D',0};
static const unsigned char bad_field[]={0x5b,0x81,12,'R','E','G','0',2,'B','I','T','S',0x54,0};
static const unsigned char literal_data[]={8,'B','U','F','0',0x11,3,1,0,
 8,'P','K','G','0',0x12,4,2,0,1,
 0x5b,0x80,'R','E','G','0',1,0x0b,4,6,0x0a,2,
 0x5b,0x81,11,'R','E','G','0',2,'B','I','T','S',16};
static void probe(const char *label,const unsigned char *p,unsigned n){struct pn_s5ns s;unsigned a=0,b=0;int first,second,ready;pn_ns_begin(&s);first=pn_ns_add(&s,base,sizeof(base));second=pn_ns_add(&s,p,n);ready=pn_ns_sleep(&s,&a,&b);printf("%s: base %d add %d eligible %d (expected 0)\n",label,first,second,ready);assert(first&&!second&&!ready);}
static void interval(void){struct pn_s5ns s;unsigned a=0,b=0;pn_ns_begin(&s);assert(pn_ns_add(&s,base+12,sizeof(base)-12));assert(!pn_ns_add(&s,ambig_s5,sizeof(ambig_s5)));assert(!pn_ns_sleep(&s,&a,&b));pn_ns_begin(&s);assert(pn_ns_add(&s,base,sizeof(base)));assert(pn_ns_add(&s,nested_ok,sizeof(nested_ok)));assert(pn_ns_sleep(&s,&a,&b)&&a==5&&b==6);puts("PASS: ambiguous sleep definition rejected without an existing sleep object; harmless nested relative scopes accepted");}
#define CHECK(n) probe(#n,n,sizeof(n))
int main(void){CHECK(hidden);CHECK(device);CHECK(mutex);CHECK(event);CHECK(region);CHECK(thermal);CHECK(resource);CHECK(processor);CHECK(pts_name);CHECK(s5_method);CHECK(reserved_scope);CHECK(field);CHECK(dynamic_buffer);CHECK(root_scope);CHECK(parent_method);CHECK(conditional);CHECK(alias);CHECK(ambig_s5);CHECK(null_hook);CHECK(bad_pkg);CHECK(short_pkg);CHECK(short_count);CHECK(dynamic_count);CHECK(bad_field);interval();
 {struct pn_s5ns s;unsigned a,b;pn_ns_begin(&s);assert(pn_ns_add(&s,base,sizeof(base)));assert(pn_ns_add(&s,literal_data,sizeof(literal_data)));assert(pn_ns_sleep(&s,&a,&b));}
 puts("PASS: literal Buffer/Package/Field data accepted; malformed lengths and dynamic operands rejected");return 0;}
