/* Test fixture only: add one unrelated user item to the existing group. */
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <ddeml.h>
static HDDEDATA CALLBACK callback(UINT a,UINT b,HCONV c,HSZ d,HSZ e,HDDEDATA f,ULONG_PTR g,ULONG_PTR h){(void)a;(void)b;(void)c;(void)d;(void)e;(void)f;(void)g;(void)h;return 0;}
void WINAPI WinMainCRTStartup(void){
 DWORD id=0,result;HSZ name;HCONV conv;BOOL ok=FALSE;
 static const char command[]="[ShowGroup(WINPOWER,1)][AddItem(notepad.exe,Keep Note,notepad.exe,0)]";
 if(DdeInitializeA(&id,callback,APPCMD_CLIENTONLY,0)!=DMLERR_NO_ERROR)ExitProcess(1);
 name=DdeCreateStringHandleA(id,"PROGMAN",CP_WINANSI);conv=DdeConnect(id,name,name,0);
 if(conv){ok=DdeClientTransaction((BYTE*)command,sizeof(command),conv,0,0,XTYP_EXECUTE,10000,&result)!=0;DdeDisconnect(conv);}
 DdeFreeStringHandle(id,name);DdeUninitialize(id);
 MessageBoxA(0,ok?"Test fixture added: Keep Note. Removal must preserve this user item.":"Cannot add the test fixture.","WINPOWER group test",MB_OK);ExitProcess(ok?0:1);
}
