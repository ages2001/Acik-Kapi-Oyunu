/* pn_tables with the PN_AML backend over a captured QEMU i440fx table set
   (RSDP at 0xF52A0, tables at 0x1FE0000), plus a synthetic added SSDT with
   _PTS. Build from SRC with -DPN_AML S5.C ACPI.C AML.C. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "S5.H"
static int failures;
#define CHECK(c,m) do{if(!(c)){printf("FAIL: %s\n",m);failures++;}}while(0)
static unsigned char rsdp[36],tab[0x3000];static unsigned long rsdpat=0xf52a0UL,base=0x1fe0000UL,tabsize;
static int rd(void *g,unsigned long a,unsigned char *o,unsigned n){
 (void)g;
 if(a>=rsdpat&&a+n<=rsdpat+36){memcpy(o,rsdp+(a-rsdpat),n);return 1;}
 if(a>=base&&a+n<=base+tabsize){memcpy(o,tab+(a-base),n);return 1;}
 return 0;
}
static unsigned long load(const char *dir,const char *name,unsigned char *dst,unsigned long cap){
 char p[512];FILE *f;unsigned long n;sprintf(p,"%s/%s",dir,name);f=fopen(p,"rb");
 if(!f){printf("missing %s\n",p);exit(2);}n=(unsigned long)fread(dst,1,cap,f);fclose(f);return n;
}
static void sum(unsigned char *t,unsigned long n,unsigned at){unsigned long i;unsigned char s=0;t[at]=0;for(i=0;i<n;i++)s=(unsigned char)(s+t[i]);t[at]=(unsigned char)(0-s);}
static struct pn_aml_node nodes[2048];static unsigned char arena[65536],work[65536];
int main(int argc,char **argv){
 const char *dir=argc>1?argv[1]:"../test/AML";struct pn_acpi p;struct pn_amlctx c;unsigned long rsdt;
 load(dir,"QEMURSDP.BIN",rsdp,20);tabsize=load(dir,"QEMUTAB.BIN",tab,0x2400);
 memset(&c,0,sizeof(c));c.nodes=nodes;c.capacity=2048;c.arena=arena;c.arena_size=sizeof(arena);
 pn_amlctx=0;
 CHECK(pn_tables(rd,0,rsdpat,&p,work,32768)&&p.off_ok&&p.sleepa==0,"static path without context");
 pn_amlctx=&c;
 CHECK(pn_tables(rd,0,rsdpat,&p,work,32768)&&p.off_ok&&p.sleepa==0&&p.sleepb==0&&!c.prepare&&c.tables==1,"AML path on QEMU DSDT");
 /* Append SSDTPTS after the existing tables and add it to the RSDT. */
 rsdt=(unsigned long)rsdp[16]|((unsigned long)rsdp[17]<<8)|((unsigned long)rsdp[18]<<16)|((unsigned long)rsdp[19]<<24);
 {unsigned long ro=rsdt-base,len=(unsigned long)tab[ro+4]|((unsigned long)tab[ro+5]<<8),ss=0x2400,newr=0x2800,i;
  (void)load(dir,"SSDTPTS.AML",tab+ss,0x400);
  memcpy(tab+newr,tab+ro,len);tab[newr+4]=(unsigned char)(len+4);
  for(i=0;i<4;i++)tab[newr+len+i]=(unsigned char)((base+ss)>>(8*i));
  sum(tab+newr,len+4,9);tabsize=0x3000;
  for(i=0;i<4;i++)rsdp[16+i]=(unsigned char)((base+newr)>>(8*i));sum(rsdp,20,8);
 }
 pn_amlctx=0;
 CHECK(pn_tables(rd,0,rsdpat,&p,work,32768)&&!p.off_ok,"SSDT present: static path fails closed");
 pn_amlctx=&c;
 {int r=pn_tables(rd,0,rsdpat,&p,work,32768);
 CHECK(r&&p.off_ok&&c.prepare&&c.tables==2,"AML path admits SSDT _PTS");}
 printf("AMLTAB: 4 cases, %d failures\n",failures);
 return failures!=0;
}
