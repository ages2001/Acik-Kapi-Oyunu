/* Host regression checks for Program Manager ownership decisions. */
#include <stdio.h>
#include <string.h>
#include "../src/NTITEM.H"
#define HEADER "\"WINPOWER\",WINPOWER,2,1,1\r\n"
#define APP "C:\\WINPWRNT\\WINPWRNT.EXE"
#define UNINST "C:\\WINPWRNT\\UNINST.EXE"
#define APPROW "\"WINPOWER\",\"" APP "\",," APP ",0,0,0,0,0,0\r\n"
#define UNROW "\"Uninstall WINPOWER\",\"" UNINST "\",," UNINST ",1,0,0,0,0,0\r\n"
static unsigned failures,cases;
static void check(const char *name,const char *data,unsigned count,unsigned owned,unsigned preserved){
 struct nt_itemstat state;cases++;ni_scan(data,APP,UNINST,&state);
 if(state.count!=count||state.owned!=owned||state.preserved!=preserved){
  fprintf(stderr,"FAIL %s: count=%u owned=%u preserved=%u\n",name,state.count,state.owned,state.preserved);failures++;
 }
}
int main(void){
 char longrow[1024];
 check("unchanged pair",HEADER APPROW UNROW,2,3,0);
 check("preserve ordinary user item",HEADER APPROW UNROW "\"Keep Note\",\"notepad.exe\",,notepad.exe,21,0,0,0,0,0\r\n",3,3,0);
 check("changed same title",HEADER "\"WINPOWER\",\"notepad.exe\",,notepad.exe,21,0,0,0,0,0\r\n" UNROW,2,2,1);
 check("command with added argument",HEADER "\"WINPOWER\",\"" APP " /EDIT\",," APP ",0,0,0,0,0,0\r\n" UNROW,2,2,1);
 check("same path different letter case",HEADER "\"winpower\",\"c:\\winpwrnt\\winpwrnt.exe\",,x,0\r\n" UNROW,2,3,0);
 check("duplicate owned title",HEADER APPROW APPROW UNROW,3,2,1);
 check("duplicate edited title",HEADER APPROW "\"WINPOWER\",\"notepad.exe\",,x,0\r\n" UNROW,3,2,1);
 check("duplicate uninstall title",HEADER APPROW UNROW UNROW,3,1,1);
 check("malformed command",HEADER "\"WINPOWER\",\"unterminated\r\n" UNROW,2,2,1);
 check("malformed title hides duplicate",HEADER APPROW "\"WINPOWER\r\n" UNROW,3,0,1);
 check("comma inside changed command",HEADER "\"WINPOWER\",\"notepad.exe a,b\",,x,0\r\n" UNROW,2,2,1);
 check("escaped quotes in changed command",HEADER "\"WINPOWER\",\"\"\"" APP "\"\"\",,x,0\r\n" UNROW,2,2,1);
 check("empty group",HEADER,0,0,0);
 check("user item only",HEADER "\"Keep Note\",\"notepad.exe\",,notepad.exe,21,0,0,0,0,0\r\n",1,0,0);
 check("final row without newline",HEADER APPROW "\"Uninstall WINPOWER\",\"" UNINST "\",,x,1",2,3,0);
 strcpy(longrow,HEADER "\"WINPOWER\",\"");memset(longrow+strlen(longrow),'A',500);longrow[strlen(HEADER "\"WINPOWER\",\"")+500]=0;strcat(longrow,"\",,x,0\r\n" UNROW);
 check("overlong command",longrow,2,2,1);
 printf("NTITEM: %u cases, %u failures\n",cases,failures);return failures?1:0;
}
