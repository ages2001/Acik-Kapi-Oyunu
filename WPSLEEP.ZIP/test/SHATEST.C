#include <assert.h>
#include <stdio.h>
#include <string.h>
#include "SHA256.H"
static void check(const char *message,unsigned repeats,unsigned chunk,const char *want){
 struct wp_sha256 s;unsigned char digest[32];char text[65];unsigned i,j,n=(unsigned)strlen(message);
 wp_sha_init(&s);
 for(i=0;i<repeats;i++)for(j=0;j<n;){unsigned k=n-j;if(k>chunk)k=chunk;wp_sha_add(&s,(const unsigned char*)message+j,k);j+=k;}
 wp_sha_end(&s,digest);for(i=0;i<32;i++)sprintf(text+i*2,"%02x",digest[i]);assert(!strcmp(text,want));
}
int main(void){
 unsigned n;
 check("",1,1,"e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855");
 for(n=1;n<70;n++){
  check("abc",1,n,"ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad");
  check("abcdbcdecdefdefgefghfghighijhijkijkljklmklmnlmnomnopnopq",1,n,"248d6a61d20638b8e5c026930c3e6039a33ce45964ff2167f6ecedd419db06c1");
 }
 check("aaaaaaaaaa",100000,7,"cdc76e5c9914fb9281a1c7e284d73e67f1809a48a497200e046d39ccc7112cd0");
 puts("PASS: SHA-256 NIST vectors, padding boundaries, streaming and million-byte input");return 0;
}
