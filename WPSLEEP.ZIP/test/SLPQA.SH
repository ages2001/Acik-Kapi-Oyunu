#!/bin/sh
# Build the separate guest witness used for an unsaved-session resume test.
set -eu
cd "$(dirname "$0")"
: "${1:?Usage: sh test/SLPQA.SH OUTPUT_DIRECTORY}"
mkdir -p "$1"
export SOURCE_DATE_EPOCH=1795046400
for variant in nt32 nt64 win9x; do
    arch=i686; cpu='-march=i386 -mno-sse -mno-mmx'; entry='_WinMainCRTStartup@0'; version=4.0
    extra=; setup=-lsetupapi; name=QA2K
    case "$variant" in
        nt64) arch=x86_64; cpu=; entry=WinMainCRTStartup; version=5.2; name=QAX64 ;;
        win9x) extra=-DWP_9XQA; setup=; name=QA9X ;;
    esac
    "$arch-w64-mingw32-gcc" $cpu -x c -Os -Wall -Wextra -Werror -Wno-cast-function-type \
        -Wno-misleading-indentation -fno-builtin -fno-stack-protector -nostdlib -mwindows $extra \
        VGASLEEP.C "-Wl,--entry,$entry,--subsystem,windows:$version" \
        -o "$1/$name.EXE" $setup -luser32 -lkernel32 -lgdi32 -ladvapi32
done
