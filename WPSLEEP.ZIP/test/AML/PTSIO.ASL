DefinitionBlock ("", "DSDT", 2, "WINPWR", "PTSIO", 1)
{
    Name (_S5, Package (0x04) { 0x00, 0x00, 0x00, 0x00 })
    OperationRegion (DBGP, SystemIO, 0x0402, 0x02)
    Field (DBGP, ByteAcc, NoLock, Preserve)
    {
        DBG8, 8,
        LOWN, 4,
        HIGN, 4
    }
    Name (CNT, 0)
    Method (HELP, 2, Serialized)
    {
        Store (Add (Arg0, Arg1), Local0)
        Return (ShiftLeft (Local0, 1))
    }
    Method (_PTS, 1, NotSerialized)
    {
        Store (Arg0, DBG8)
        Store (0x0A, HIGN)
        Store (0x03, LOWN)
        While (LLess (CNT, 3))
        {
            Increment (CNT)
        }
        Store (HELP (CNT, Arg0), Local1)
        Store (Local1, DBG8)
        If (CondRefOf (\_OSI))
        {
            If (\_OSI ("Windows 2001"))
            {
                Store (0xEE, DBG8)
            }
        }
        Store (0x50, DBG8)
    }
}
