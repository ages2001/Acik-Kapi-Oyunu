DefinitionBlock ("", "DSDT", 2, "WINPWR", "PTSEC", 1)
{
    Name (_S5, Package (0x04) { 0x05, 0x05, 0x00, 0x00 })
    OperationRegion (ECOR, EmbeddedControl, 0x00, 0xFF)
    Field (ECOR, ByteAcc, Lock, Preserve)
    {
        ECSL, 8
    }
    Method (_PTS, 1, NotSerialized)
    {
        Store (Arg0, ECSL)
    }
}
