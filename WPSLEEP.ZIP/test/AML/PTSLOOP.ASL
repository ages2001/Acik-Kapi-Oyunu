DefinitionBlock ("", "DSDT", 2, "WINPWR", "PTSLOOP", 1)
{
    Name (_S5, Package (0x04) { 0x05, 0x05, 0x00, 0x00 })
    Name (XX, 0)
    Method (_PTS, 1, NotSerialized)
    {
        While (One)
        {
            Increment (XX)
        }
    }
}
