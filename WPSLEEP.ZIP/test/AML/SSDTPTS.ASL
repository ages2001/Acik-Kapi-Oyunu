DefinitionBlock ("", "SSDT", 2, "WINPWR", "SSDTPTS", 1)
{
    External (\_SB.PCI0, DeviceObj)
    OperationRegion (DBGP, SystemIO, 0x0402, 0x01)
    Field (DBGP, ByteAcc, NoLock, Preserve)
    {
        DBG8, 8
    }
    Method (_PTS, 1, NotSerialized)
    {
        Store (0x50, DBG8)
        Store (Arg0, DBG8)
        Store (0x54, DBG8)
        Store (0x53, DBG8)
    }
}
