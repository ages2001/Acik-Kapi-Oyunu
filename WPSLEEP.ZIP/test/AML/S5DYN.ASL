DefinitionBlock ("", "DSDT", 2, "WINPWR", "S5DYN", 1)
{
    Name (OSFL, 1)
    Name (SLPB, 0x05)
    Method (_S5, 0, NotSerialized)
    {
        If (LEqual (OSFL, 1))
        {
            Return (Package (0x04) { 0x05, SLPB, 0x00, 0x00 })
        }
        Else
        {
            Return (Package (0x04) { 0x07, 0x07, 0x00, 0x00 })
        }
    }
}
