DefinitionBlock ("", "SSDT", 2, "WINPWR", "QEMUPTS", 1)
{
    OperationRegion (WPDB, SystemIO, 0x0599, 0x01)
    Field (WPDB, ByteAcc, NoLock, Preserve)
    {
        WPDC, 8
    }
    Method (_PTS, 1, Serialized)
    {
        Store (0x50, WPDC)
        Store (0x54, WPDC)
        Store (0x53, WPDC)
        Store (Add (Arg0, 0x30), WPDC)
    }
    Method (_GTS, 1, NotSerialized)
    {
        Store (0x47, WPDC)
        Store (Add (Arg0, 0x30), WPDC)
    }
}
