DefinitionBlock ("", "DSDT", 1, "WINPWR", "S5NAME", 1)
{
    Name (SLPA, 0x06)
    Name (_S5, Package (0x04) { SLPA, 0x03, 0x00, 0x00 })
    Name (_S4, Package (0x01) { 0x0404 })
}
