DefinitionBlock ("", "DSDT", 2, "WINPWR", "PTSMEM", 1)
{
    Name (_S5, Package (0x04) { 0x05, 0x05, 0x00, 0x00 })
    Name (NVSA, 0x000F1000)
    OperationRegion (GNVS, SystemMemory, NVSA, 0x10)
    Field (GNVS, AnyAcc, Lock, Preserve)
    {
        SLPS, 8,
        Offset (0x04),
        FLAG, 32,
        BITA, 1,
        BITB, 1,
        , 6,
        WRD, 16
    }
    Scope (\_SB)
    {
        Device (PCI0)
        {
            Name (_HID, EisaId ("PNP0A03"))
            Name (_ADR, 0x00)
            Name (_BBN, 0x00)
            Device (LPCB)
            {
                Name (_ADR, 0x001F0000)
                OperationRegion (LPCR, PCI_Config, 0xA0, 0x10)
                Field (LPCR, DWordAcc, NoLock, Preserve)
                {
                    GEN1, 32,
                    Offset (0x04),
                    PMBS, 16
                }
            }
        }
    }
    IndexField (\_SB.PCI0.LPCB.GEN1, \_SB.PCI0.LPCB.PMBS, ByteAcc, NoLock, Preserve)
    {
        Offset (0x02),
        IDX2, 8
    }
    Method (_PTS, 1, Serialized)
    {
        Store (Arg0, SLPS)
        Or (FLAG, 0x80000000, FLAG)
        Store (One, BITB)
        Store (0x1234, WRD)
        Store (0x55, \_SB.PCI0.LPCB.GEN1)
        Store (Divide (100, 7, Local2), Local3)
        Store (Local2, Local4)
        Store (Package (0x02) { 0x11, 0x22 }, Local5)
        Store (DerefOf (Index (Local5, 1)), Local6)
        If (LAnd (LEqual (Local3, 14), LEqual (Local4, 2)))
        {
            Store (Local6, IDX2)
        }
        Sleep (1)
        Stall (5)
    }
    Method (_GTS, 1, NotSerialized)
    {
        Store (Add (Arg0, 0x10), SLPS)
    }
}
