DefinitionBlock ("", "DSDT", 2, "WINPWR", "S5WRITE", 1)
{
    OperationRegion (DBGP, SystemIO, 0x0402, 0x01)
    Field (DBGP, ByteAcc, NoLock, Preserve)
    {
        DBG8, 8
    }
    Method (_S5, 0, NotSerialized)
    {
        Store (0x01, DBG8)
        Return (Package (0x04) { 0x05, 0x05, 0x00, 0x00 })
    }
}
