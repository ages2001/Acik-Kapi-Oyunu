/* Modern legacy-boot _PTS using only interpreter-supported operations:
   SystemIO read-modify-write on a scratch register, bit ops, a bounded
   poll loop and branching - no out-of-policy memory write. Proves the
   bounded interpreter runs realistic modern control flow end to end. */
DefinitionBlock ("", "SSDT", 2, "WINPWR", "PNMODR2", 0x00001000)
{
    OperationRegion (WPDB, SystemIO, 0x0599, 0x01)
    Field (WPDB, ByteAcc, NoLock, Preserve) { WPDC, 8 }
    OperationRegion (GPES, SystemIO, 0x0594, 0x04)
    Field (GPES, ByteAcc, NoLock, Preserve) { GPS0, 8, GPS1, 8, GPS2, 8, GPS3, 8 }
    Name (PCNT, 0)
    Method (_PTS, 1, Serialized)
    {
        Store (0x50, WPDC)                          /* 'P' */
        If (LEqual (And (Arg0, 0x07), 5))
        {
            Store (0x35, WPDC)                      /* '5' */
            Store (GPS0, Local0)
            Store (Or (Local0, 0xFF), GPS0)         /* IO read-modify-write */
            Store (0x49, WPDC)                      /* 'I' after IO RMW */
            Store (0, PCNT)
            While (LLess (PCNT, 4)) { Increment (PCNT) }
            If (LEqual (PCNT, 4)) { Store (0x4C, WPDC) }  /* 'L' loop done */
        }
        Store (0x54, WPDC)                          /* 'T' */
    }
    Method (_GTS, 1, Serialized) { Store (0x47, WPDC) Store (Add (And (Arg0,0x07),0x30), WPDC) }
}
