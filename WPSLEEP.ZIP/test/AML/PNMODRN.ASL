/*
 * PNMODRN - a modern legacy-boot desktop's sleep methods, for testing the
 * WINPOWER bounded AML interpreter against realistic firmware density.
 * Fixed-hardware ACPI (PM1 soft-off kept from the platform's own \_S5), but
 * modern-style _PTS/_GTS/_WAK: branching on sleep type, bit operations on a
 * PM/GPE register, a bounded poll loop, a scratch NVS (SystemMemory) store,
 * and named context - the shapes a real ACPI 5/6 DSDT uses. Every stage
 * traces one byte to port 599h so a live run can be followed.
 * ACPI 2.0 definition block (revision 2) to exercise the 64-bit path.
 */
DefinitionBlock ("", "SSDT", 2, "WINPWR", "PNMODRN", 0x00001000)
{
    /* Debug trace port (isa-debugcon at 599h). */
    OperationRegion (WPDB, SystemIO, 0x0599, 0x01)
    Field (WPDB, ByteAcc, NoLock, Preserve) { WPDC, 8 }

    /* A PM1/GPE-style status register in I/O space (read + write-1-to-clear,
       as modern _PTS does to acknowledge wake events). Uses a benign scratch
       port so a live run cannot disturb the platform. */
    OperationRegion (GPES, SystemIO, 0x0594, 0x04)
    Field (GPES, ByteAcc, NoLock, Preserve) { GPS0, 8, GPS1, 8, GPS2, 8, GPS3, 8 }

    /* Scratch "ACPI NVS" in low memory (BIOS data area is safe to read). */
    OperationRegion (NVSR, SystemMemory, 0x00000400, 0x10)
    Field (NVSR, AnyAcc, NoLock, Preserve) { NVSA, 8, NVSB, 8, NVSW, 16 }

    Name (SLPT, 0)        /* last requested sleep type   */
    Name (PCNT, 0)        /* poll counter                */

    Method (_PTS, 1, Serialized)
    {
        Store (0x50, WPDC)                      /* 'P' - entered           */
        Store (Arg0, SLPT)
        Store (And (Arg0, 0x07), Local0)        /* bit op on the argument  */

        If (LEqual (Local0, 5))                 /* branch on S5            */
        {
            Store (0x35, WPDC)                  /* '5'                     */
            /* Acknowledge/clear a wake status register (write-1-to-clear). */
            Store (GPS0, Local1)
            Store (Or (Local1, 0xFF), GPS0)
            /* Save context to scratch NVS, read it back, verify.          */
            Store (Arg0, NVSA)
            If (LEqual (NVSA, Arg0)) { Store (0x4D, WPDC) }  /* 'M' memok  */
            /* Bounded poll loop, as modern firmware waits on a ready bit.  */
            Store (0, PCNT)
            While (LLess (PCNT, 4))
            {
                Increment (PCNT)
            }
            If (LEqual (PCNT, 4)) { Store (0x4C, WPDC) }     /* 'L' loopok */
        }
        Else
        {
            Store (0x3F, WPDC)                  /* '?' - non-S5            */
        }
        Store (0x54, WPDC)                      /* 'T' - done              */
    }

    Method (_GTS, 1, Serialized)
    {
        Store (0x47, WPDC)                      /* 'G'                     */
        Store (Add (And (Arg0, 0x07), 0x30), WPDC)
    }

    Method (_WAK, 1, Serialized)               /* present on real systems  */
    {
        Store (0x57, WPDC)                      /* 'W'                     */
        Return (Package (2) { 0, 0 })
    }
}
