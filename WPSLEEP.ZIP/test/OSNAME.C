#include <assert.h>
#include <string.h>
#include <stdio.h>
#include "OSNAME.H"
int main(void){
 struct T{unsigned p,a,b;unsigned long n;unsigned t;const char*s;} cases[]={
 {0,1,0,0,0,"Windows 1.0"},{0,1,1,0,0,"Windows 1.01"},{0,1,4,0,0,"Windows 1.04"},
 {0,2,3,0,0,"Windows 2.03"},{0,2,10,0,0,"Windows 2.10"},{0,2,11,0,0,"Windows 2.11"},
 {0,2,0x10,0,0,"Windows 2.10"},{0,2,0x11,0,0,"Windows 2.11"},
 {0,3,0,0,0,"Windows 3.0"},{0,3,10,0,0,"Windows 3.1"},{0,3,11,0,0,"Windows 3.11"},
 {1,4,0,950,0,"Windows 95"},{1,4,10,1998,0,"Windows 98"},{1,4,10,2222,0,"Windows 98 Second Edition"},{1,4,90,3000,0,"Windows Me"},
 {2,3,10,511,0,"Windows NT 3.1"},{2,3,50,807,0,"Windows NT 3.5"},{2,3,51,1057,0,"Windows NT 3.51"},{2,4,0,1381,0,"Windows NT 4.0"},
 {2,5,0,2195,1,"Windows 2000"},{2,5,1,2600,1,"Windows XP"},{2,5,2,3790,1,"Windows XP Professional x64"},{2,5,2,3790,3,"Windows Server 2003 family"},
 {2,6,0,6002,1,"Windows Vista"},{2,6,1,7601,1,"Windows 7"},{2,6,2,9200,1,"Windows 8"},{2,6,3,9600,1,"Windows 8.1"},
 {2,10,0,19045,1,"Windows 10"},{2,10,0,22000,1,"Windows 11"},{2,10,0,26100,1,"Windows 11"},{2,10,0,26100,3,"Windows Server 2025"},
 {2,12,0,30000,1,"Windows NT (unidentified release)"}};
 unsigned i;for(i=0;i<sizeof(cases)/sizeof(cases[0]);i++){struct T*t=&cases[i];assert(strcmp(pn_osname(t->p,t->a,t->b,t->n,t->t),t->s)==0);}
 puts("PASS: 32 OS naming cases, Win2 BCD, Windows 1.0 through 11, Server separation, unknown version");return 0;
}
