#include <assert.h>
#include <stdio.h>
#include "APMSLEEP.H"
static unsigned ver, flags, supported, fail_call, enables, disables, engages, disengages;
static unsigned requested, disconnected, connections, expected_device, fail_enable_off, bad_version;
static int firmware(unsigned ax, unsigned bx, unsigned cx, struct wp_apm_result *r)
{
    r->ax = r->bx = r->cx = 0;
    if (ax == fail_call) return 0;
    switch (ax) {
    case 0x5300: r->ax = ver; r->bx = 0x504d; r->cx = flags; break;
    case 0x5301: ++connections; break;
    case 0x530e: r->ax = bad_version ? 0x105 : cx; break;
    case 0x5310: assert(!bx); r->cx = supported; break;
    case 0x5308: assert(bx == expected_device); if (cx) ++enables; else { ++disables; if(fail_enable_off) return 0; } break;
    case 0x530f: assert(bx == 1 && ver >= 0x101); if (cx) ++engages; else ++disengages; break;
    case 0x5307: assert(bx == 1 && (cx == 1 || cx == 2)); requested = cx; break;
    case 0x5304: ++disconnected; break;
    default: assert(0);
    }
    return 1;
}
static void reset(unsigned v)
{
    ver=v; flags=24; supported=3; fail_call=0; enables=disables=engages=disengages=0;
    requested=disconnected=connections=fail_enable_off=bad_version=0; expected_device=v==0x100?0xffff:1;
}
int main(void)
{
    unsigned v, s;
    for(v=0x100;v<=0x102;++v) for(s=1;s<=2;++s) {
        reset(v); assert(wp_apm_sleep(s,firmware)==WP_RETURNED);
        assert(requested==s && connections==1 && disconnected==1 && enables==1 && disables==1);
        assert(engages==(v>0x100) && disengages==engages);
    }
    reset(0x102); supported=1; assert(wp_apm_sleep(2,firmware)==WP_UNAVAILABLE && !requested && disconnected);
    reset(0x102); fail_call=0x5301; assert(wp_apm_sleep(1,firmware)==WP_BUSY && !requested && !disconnected);
    reset(0x102); fail_call=0x530f; assert(wp_apm_sleep(2,firmware)==WP_DECLINED && enables && disables && disconnected);
    reset(0x102); fail_call=0x5307; assert(wp_apm_sleep(1,firmware)==WP_DECLINED && disengages && disables && disconnected);
    reset(0x102); fail_enable_off=1; assert(wp_apm_sleep(1,firmware)==WP_RESTORE && disconnected);
    reset(0x102); fail_call=0x530e; expected_device=0xffff; assert(wp_apm_sleep(2,firmware)==WP_RETURNED && !engages);
    reset(0x102); bad_version=1; assert(wp_apm_sleep(2,firmware)==WP_VERSION && disconnected && !requested);
    reset(0x103); assert(wp_apm_sleep(1,firmware)==WP_VERSION && !connections);
    reset(0x100); assert(wp_apm_sleep(4,firmware)==WP_UNAVAILABLE && !connections);
    puts("PASS: APM firmware standby and suspend, version negotiation, capability checks, refusal and restoration.");
    return 0;
}
