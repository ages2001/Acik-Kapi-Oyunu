#include <assert.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "S5.H"
static unsigned char ram[65536],work[32768];
static unsigned char aml[]={0x08,'_','S','5','_',0x12,6,4,0,0,0,0};
static void put(unsigned char *p,unsigned long v){unsigned i;for(i=0;i<4;i++){p[i]=(unsigned char)v;v>>=8;}}
static void checksum(unsigned char *p,unsigned n,unsigned offset){unsigned i;unsigned char sum=0;p[offset]=0;for(i=0;i<n;i++)sum=(unsigned char)(sum+p[i]);p[offset]=(unsigned char)(0-sum);}
static void header(unsigned char *p,const char *sig,unsigned n){memset(p,0,n);memcpy(p,sig,4);put(p+4,n);p[8]=1;}
static int readram(void *unused,unsigned long addr,unsigned char *out,unsigned n){(void)unused;if(addr>sizeof(ram)||n>sizeof(ram)-addr)return 0;memcpy(out,ram+addr,n);return 1;}
static void setup(void){
 memset(ram,0,sizeof(ram));memcpy(ram+16,"RSD PTR ",8);put(ram+32,128);checksum(ram+16,20,8);
 header(ram+128,"RSDT",40);put(ram+164,256);checksum(ram+128,40,9);
 header(ram+256,"FACP",276);put(ram+296,1024);put(ram+320,0x604);ram[345]=2;checksum(ram+256,276,9);
 header(ram+1024,"DSDT",36+sizeof(aml));memcpy(ram+1060,aml,sizeof(aml));checksum(ram+1024,36+sizeof(aml),9);
}
static void check(void){struct pn_acpi p;assert(pn_tables(readram,0,16,&p,work,sizeof(work)));assert(p.off_ok&&p.pm1a==0x604&&p.sleepa==0&&p.sleepb==0);}
int main(int argc,char **argv){
 struct pn_acpi p;unsigned a,b,i,j;unsigned char buf[128];unsigned long random=1;
 assert(pn_s5(aml,sizeof(aml),&a,&b)&&a==0&&b==0);
 for(i=0;i<sizeof(aml);i++)assert(!pn_s5(aml,i,&a,&b));
 memcpy(buf,aml,sizeof(aml));buf[8]=8;assert(!pn_s5(buf,sizeof(aml),&a,&b));
 memcpy(buf,aml,sizeof(aml));memcpy(buf+sizeof(aml),aml,sizeof(aml));assert(!pn_s5(buf,2*sizeof(aml),&a,&b));
 /* Same bytes inside a Buffer or Method body are not namespace definitions. */
 buf[0]=8;memcpy(buf+1,"BUFF",4);buf[5]=0x11;buf[6]=2+sizeof(aml);buf[7]=sizeof(aml);memcpy(buf+8,aml,sizeof(aml));assert(!pn_s5(buf,8+sizeof(aml),&a,&b));
 buf[0]=0x14;buf[1]=6+sizeof(aml);memcpy(buf+2,"TEST",4);buf[6]=0;memcpy(buf+7,aml,sizeof(aml));assert(!pn_s5(buf,7+sizeof(aml),&a,&b));
 /* A root preparation method makes the static backend ineligible. */
 memcpy(buf,aml,sizeof(aml));i=sizeof(aml);buf[i++]=0x14;buf[i++]=6;memcpy(buf+i,"_PTS",4);i+=4;buf[i++]=1;assert(!pn_s5(buf,i,&a,&b));
 memcpy(buf+i-5,"_TTS",4);assert(!pn_s5(buf,i,&a,&b));
 setup();check();
#ifdef PN_TIMER_INFO
 /* Optional PM timer must be a bounded DWORD System I/O register. */
 put(ram+332,0x608);ram[347]=4;checksum(ram+256,276,9);
 assert(pn_tables(readram,0,16,&p,work,sizeof(work))&&p.timer_port==0x608&&p.timer_bits==24);
 put(ram+368,0x100);checksum(ram+256,276,9);
 assert(pn_tables(readram,0,16,&p,work,sizeof(work))&&p.timer_bits==32);
 put(ram+332,65533);checksum(ram+256,276,9);
 assert(pn_tables(readram,0,16,&p,work,sizeof(work))&&!p.timer_port);
 setup();put(ram+332,0x608);ram[347]=4;ram[464]=1;ram[465]=24;ram[467]=3;put(ram+468,0x708);checksum(ram+256,276,9);
 assert(pn_tables(readram,0,16,&p,work,sizeof(work))&&p.timer_port==0x708&&p.timer_bits==24);
 ram[464]=0;checksum(ram+256,276,9);
 assert(pn_tables(readram,0,16,&p,work,sizeof(work))&&!p.timer_port);
 setup();check();
#endif
 /* XSDT discovery uses 64-bit entries, bounded to this reader's address space. */
 ram[31]=2;put(ram+36,36);put(ram+40,128);checksum(ram+16,20,8);checksum(ram+16,36,32);
 header(ram+128,"XSDT",44);put(ram+164,256);checksum(ram+128,44,9);check();
 ram[168]=1;checksum(ram+128,44,9);assert(!pn_tables(readram,0,16,&p,work,sizeof(work)));
 setup();ram[1068]^=1;assert(pn_tables(readram,0,16,&p,work,sizeof(work))&&!p.off_ok);
 setup();put(ram+320,65535);checksum(ram+256,276,9);assert(pn_tables(readram,0,16,&p,work,sizeof(work))&&!p.off_ok);
 setup();put(ram+368,0x100000UL);checksum(ram+256,276,9);assert(pn_tables(readram,0,16,&p,work,sizeof(work))&&!p.off_ok);
 setup();ram[264]=6;put(ram+368,0x400);ram[372]=1;ram[373]=8;ram[375]=1;put(ram+376,0xcf9);ram[384]=6;checksum(ram+256,276,9);assert(pn_tables(readram,0,16,&p,work,sizeof(work))&&p.reset_ok&&p.reset_port==0xcf9);
 ram[374]=1;checksum(ram+256,276,9);assert(pn_tables(readram,0,16,&p,work,sizeof(work))&&!p.reset_ok);
 setup();put(ram+260,0xffffffffUL);assert(!pn_tables(readram,0,16,&p,work,sizeof(work)));
 /* Extended GAS must not silently fall back to a legacy port. */
 setup();put(ram+432,0x604);ram[428]=0;ram[429]=16;checksum(ram+256,276,9);assert(pn_tables(readram,0,16,&p,work,sizeof(work))&&!p.off_ok);
 for(i=0;i<20000;i++){
  unsigned n=i%sizeof(buf);for(j=0;j<n;j++){random=(random*1664525UL+1013904223UL)&0xffffffffUL;buf[j]=(unsigned char)(random>>24);}
  pn_s5(buf,n,&a,&b);
 }
 if(argc==2){FILE *f=fopen(argv[1],"rb");long n;assert(f);fseek(f,0,SEEK_END);n=ftell(f);rewind(f);assert(n>36&&(unsigned long)n<sizeof(work));assert(fread(work,1,n,f)==(unsigned long)n);fclose(f);assert(pn_s5(work+36,(unsigned)n-36,&a,&b));printf("Fixture S5: %u/%u\n",a,b);}
 puts("PASS: static AML grammar, truncation, duplicate/decoy/hook rejection, checksums, GAS, reset and bounded fuzz");return 0;
}
