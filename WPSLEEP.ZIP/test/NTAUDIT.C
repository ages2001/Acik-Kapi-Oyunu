#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include "NTPWR.H"
#include "NTDDE.H"
void *memset(void *p,int c,size_t n){BYTE *q=p;while(n--)*q++=(BYTE)c;return p;}
static int keyexists(const char *path){HKEY key;LONG e=RegOpenKeyExA(HKEY_LOCAL_MACHINE,path,0,KEY_QUERY_VALUE,&key);if(!e){RegCloseKey(key);return 1;}return e==ERROR_FILE_NOT_FOUND?0:-1;}
static int fileexists(const char *path){DWORD e;if(GetFileAttributesA(path)!=INVALID_FILE_ATTRIBUTES)return 1;e=GetLastError();return e==ERROR_FILE_NOT_FOUND||e==ERROR_PATH_NOT_FOUND?0:-1;}
static int serviceexists(SC_HANDLE manager,const char *name){SC_HANDLE s;DWORD e;if(!manager)return -1;s=OpenServiceA(manager,name,SERVICE_QUERY_STATUS);if(s){CloseServiceHandle(s);return 1;}e=GetLastError();return e==ERROR_SERVICE_DOES_NOT_EXIST?0:(e==ERROR_SERVICE_MARKED_FOR_DELETE?2:-1);}
void WINAPI WinMainCRTStartup(void){
 char folder[MAX_PATH],path[MAX_PATH],text[1600],power[100];struct wp_config cfg;struct wp_regvalue value;
 HKEY key;SC_HANDLE manager;DWORD e;unsigned i,owned=0,other=0;int files[6],services[3],group=-2,record,arp;
 static const char *names[]={"WINPWRNT.EXE","UNINST.EXE","WINPSVC.EXE","PN3HOOK.SYS","PN4HOOK.SYS","WINPOWER.INI"};
 GetWindowsDirectoryA(folder,MAX_PATH);folder[3]=0;lstrcatA(folder,"WINPWRNT");
 record=keyexists(WP_META);
 if(!RegOpenKeyExA(HKEY_LOCAL_MACHINE,WP_META,0,KEY_QUERY_VALUE,&key)){if(!wp_config(key,&cfg))lstrcpyA(folder,cfg.folder);RegCloseKey(key);}
 for(i=0;i<6;i++){wp_path(path,folder,names[i]);files[i]=fileexists(path);}
 manager=OpenSCManagerA(0,0,SC_MANAGER_CONNECT);services[0]=serviceexists(manager,WP_SERVICE);services[1]=serviceexists(manager,"PN3LAB");services[2]=serviceexists(manager,"PN4LAB");if(manager)CloseServiceHandle(manager);
 arp=keyexists("Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\WINPWRNT");
 if(wp_kind()==3)group=nt_group_status(&owned,&other);
 lstrcpyA(power,"N/A");
 e=RegOpenKeyExA(HKEY_LOCAL_MACHINE,"Software\\Microsoft\\Windows NT\\CurrentVersion\\Winlogon",0,KEY_QUERY_VALUE,&key);
 if(!e){e=wp_regread(key,&value);RegCloseKey(key);if(!e){
  wsprintfA(power,"Present %u / type %u / bytes %u / first bytes %02X %02X %02X %02X",value.present,value.type,value.size,value.data[0],value.data[1],value.data[2],value.data[3]);
 }}
 wsprintfA(text,"WINPOWER NT installation audit (read only)\r\n\r\nFolder: %d   GUI: %d   Uninstaller: %d\r\nStartup EXE: %d   NT3 driver: %d   NT4 driver: %d   INI: %d\r\nServices: WINPOWER %d / NT3 %d / NT4 %d\r\nInstallation record: %d   Add/Remove Programs: %d\r\nProgram Manager group: %d   Owned items: %u   Other items: %u\r\n\r\nPowerdownAfterShutdown: %s\r\n\r\n1 = present; 0 = absent; -1 = query failed.\r\nService 2 = deletion pending. Group -2 = not applicable.\r\nNo files, services, settings or hooks were changed.",
 fileexists(folder),files[0],files[1],files[2],files[3],files[4],files[5],services[0],services[1],services[2],record,arp,group,owned,other,power);
 MessageBoxA(0,text,"WINPOWER installation audit",MB_OK|MB_ICONINFORMATION);ExitProcess(0);
}
