/* Exercise the normal NT 3/4 installer and shipped owner controls on marked QA media. */
#define WIN32_LEAN_AND_MEAN
#include <windows.h>

static STARTUPINFOA startup;
static PROCESS_INFORMATION process;
static char message[820], reason[820], application[MAX_PATH];
static HWND dialog;
static int action;
static DWORD child_pid;

static BOOL contains(const char *s, const char *part)
{
    while (*s) {
        const char *a=s, *b=part;
        while (*b && *a==*b) { ++a; ++b; }
        if (!*b) return TRUE;
        ++s;
    }
    return FALSE;
}

static void notes(const char *file, const char *line)
{
    DWORD size;
    HANDLE h=CreateFileA(file,GENERIC_WRITE,FILE_SHARE_READ,NULL,OPEN_ALWAYS,0,NULL);
    if (h==INVALID_HANDLE_VALUE) ExitProcess(12);
    SetFilePointer(h,0,0,FILE_END);
    if (!WriteFile(h,line,lstrlenA(line),&size,NULL) || !FlushFileBuffers(h)) ExitProcess(13);
    CloseHandle(h);
}

static void failed(const char *s)
{
    notes("A:\\QAERR.TXT",s);
    MessageBoxA(NULL,s,"WINPOWER installation test",MB_OK);
    ExitProcess(1);
}

static BOOL CALLBACK content(HWND h, LPARAM l)
{
    char cls[24]; (void)l;
    if (GetClassNameA(h,cls,sizeof(cls)) && !lstrcmpiA(cls,"Static") &&
        GetWindowTextA(h,message,sizeof(message)) && lstrlenA(message)>6) {
        lstrcpyA(reason,message);
    }
    return TRUE;
}

static BOOL CALLBACK window(HWND h, LPARAM l)
{
    DWORD pid; char cls[24], title[64]; (void)l;
    GetWindowThreadProcessId(h,&pid);
    if (pid!=child_pid || !GetClassNameA(h,cls,sizeof(cls)) || lstrcmpA(cls,"#32770")) return TRUE;
    if (!GetWindowTextA(h,title,sizeof(title))) return TRUE;
    reason[0]=0;
    EnumChildWindows(h,content,0);
    if (action==0 && !lstrcmpA(title,"WINPOWER Setup")) {
        if (contains(reason,"Install WINPOWER")) dialog=h;
        else if (contains(reason,"WINPOWER is installed")) dialog=h;
        else if (*reason && (contains(reason,"failed") || contains(reason,"error") || contains(reason,"Cannot") || contains(reason,"already"))) failed(reason);
    } else if (action!=0 && !lstrcmpA(title,"WINPOWER installed test")) {
        if (contains(reason,action==1?"default OS to Driver":"restored Driver ownership")) dialog=h;
    } else if (contains(title,"test error")) failed(reason);
    return !dialog;
}

static void child(const char *app,char *cmd)
{
    startup.cb=sizeof(startup);
    if (!CreateProcessA(app,cmd,NULL,NULL,FALSE,0,NULL,NULL,&startup,&process))
        failed("Could not start the standard installer or regression helper.\r\n");
    CloseHandle(process.hThread);
    child_pid=process.dwProcessId;
}

void WINAPI WinMainCRTStartup(void)
{
    DWORD v=GetVersion(),exit_code; unsigned i; BOOL confirmed=FALSE;
    char command[96]; HWND button;
    if (GetFileAttributesA("A:\\WPGUEST.ID")==INVALID_FILE_ATTRIBUTES ||
        GetFileAttributesA("A:\\NTCASE.ID")==INVALID_FILE_ATTRIBUTES) ExitProcess(2);
    if ((v&0x80000000UL) || (LOBYTE(LOWORD(v))!=3 && LOBYTE(LOWORD(v))!=4)) ExitProcess(2);
    if (GetFileAttributesA("A:\\READF.TXT")!=INVALID_FILE_ATTRIBUTES) ExitProcess(0);
    if (!CreateMutexA(NULL,FALSE,"WINPOWER QA install session") || GetLastError()==ERROR_ALREADY_EXISTS) ExitProcess(0);
    GetWindowsDirectoryA(application,sizeof(application));application[2]=0;
    lstrcatA(application,"\\WINPWRNT\\WINPWRNT.EXE");
    if (GetFileAttributesA(application)==INVALID_FILE_ATTRIBUTES) {
        lstrcpyA(command,"A:\\SETUP.EXE");child(command,NULL);
        for (i=0;i<1800;i++) {
            if (WaitForSingleObject(process.hProcess,250)==WAIT_OBJECT_0) break;
            dialog=NULL;EnumWindows(window,0);
            if (!dialog) continue;
            button=GetDlgItem(dialog,IDYES);
            if (!button) button=GetDlgItem(dialog,IDOK);
            if (IsWindowEnabled(dialog)) {
                notes("A:\\INSTALL.TXT",reason);notes("A:\\INSTALL.TXT","\r\n");
                PostMessageA(dialog,WM_COMMAND,contains(reason,"Install WINPOWER") ? IDYES : IDOK,(LPARAM)button);
                Sleep(400);
            }
        }
        if (i==1800 || !GetExitCodeProcess(process.hProcess,&exit_code) || exit_code ||
            GetFileAttributesA(application)==INVALID_FILE_ATTRIBUTES) failed("The normal WINPOWER setup did not complete.\r\n");
        CloseHandle(process.hProcess);
    }
    action=GetFileAttributesA("A:\\READR.TXT")==INVALID_FILE_ATTRIBUTES?1:2;
    lstrcpyA(command,action==1?"A:\\OWNLEG.EXE /DRIVER":"A:\\OWNLEG.EXE /OFF");
    child("A:\\OWNLEG.EXE",command);
    for (i=0;i<1800;i++) {
        if (WaitForSingleObject(process.hProcess,250)==WAIT_OBJECT_0) break;
        dialog=NULL;EnumWindows(window,0);
        if (!dialog || confirmed) continue;
        notes(action==1?"A:\\READR.TXT":"A:\\READF.TXT",reason);
        notes(action==1?"A:\\READR.TXT":"A:\\READF.TXT","\r\n");
        confirmed=TRUE;
        Sleep(5500);
        PostMessageA(dialog,WM_COMMAND,IDOK,(LPARAM)GetDlgItem(dialog,IDOK));
    }
    CloseHandle(process.hProcess);
    if (!confirmed) failed("The resident Driver confirmation did not arrive.\r\n");
    ExitProcess(0);
}
