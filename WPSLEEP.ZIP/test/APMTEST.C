#include <assert.h>
#include <stdio.h>
#include <string.h>
#include "../src/APMDATA.H"
static wp_apm_u32 desc_base(const unsigned char *d){return (wp_apm_u32)d[2]|((wp_apm_u32)d[3]<<8)|((wp_apm_u32)d[4]<<16)|((wp_apm_u32)d[7]<<24);}
static unsigned desc_length(const unsigned char *d){return ((unsigned)d[0]|((unsigned)d[1]<<8))+1;}
int main(void){
 struct wp_apm_raw raw={0xf000,0x1234,0xf000,0xf000,0xfff0fff0U,0xfff0,0};
 struct wp_apm_map m,saved;unsigned i;
 assert(wp_apm_decode(0x102,3,32,&raw,&m));assert(m.count==3&&m.mode==32&&m.entry==0x1234);
 for(i=0;i<3;i++){assert(m.base[i]==0xf0000&&m.length[i]==0xfff0);assert(desc_base(m.descriptor+i*8)==m.base[i]);assert(desc_length(m.descriptor+i*8)==m.length[i]);}
 assert(m.descriptor[5]==0x9a&&m.descriptor[6]==0x40&&m.descriptor[13]==0x9a&&m.descriptor[14]==0&&m.descriptor[21]==0x92&&m.descriptor[22]==0);
 assert(wp_apm_decode(0x100,3,32,&raw,&m));for(i=0;i<3;i++)assert(m.length[i]==65536);
 assert(wp_apm_decode(0x101,3,32,&raw,&m));assert(m.length[0]==0xfff0&&m.length[1]==65536&&m.length[2]==0xfff0);
 assert(wp_apm_decode(0x102,3,16,&raw,&m));assert(m.count==2&&m.descriptor[5]==0x9a&&m.descriptor[6]==0&&m.descriptor[13]==0x92&&m.length[2]==0);
 raw.si=raw.di=0;assert(wp_apm_decode(0x102,3,32,&raw,&m));for(i=0;i<3;i++)assert(m.length[i]==65536);
 raw.bx=65535;assert(wp_apm_decode(0x102,3,32,&raw,&m));raw.bx=65536;
 memset(&m,0xa5,sizeof(m));saved=m;assert(!wp_apm_decode(0x102,3,32,&raw,&m));assert(!memcmp(&m,&saved,sizeof(m)));
 raw.bx=0;raw.ax=0xffff;assert(!wp_apm_decode(0x102,3,32,&raw,&m));raw.ax=0xf000;
 raw.cx=0xffff;assert(!wp_apm_decode(0x102,3,32,&raw,&m));raw.cx=0xf000;
 raw.dx=0xffff;assert(!wp_apm_decode(0x102,3,32,&raw,&m));raw.dx=0xf000;
 raw.flags=1;assert(!wp_apm_decode(0x102,3,32,&raw,&m));raw.flags=0;
 assert(!wp_apm_decode(0x99,3,32,&raw,&m));assert(!wp_apm_decode(0x103,3,32,&raw,&m));
 assert(!wp_apm_decode(0x102,1,32,&raw,&m));assert(!wp_apm_decode(0x102,2,16,&raw,&m));
 assert(!wp_apm_decode(0x102,0x23,32,&raw,&m));assert(!wp_apm_decode(0x102,3,64,&raw,&m));
 raw.si=0x00010001;raw.di=1;assert(wp_apm_decode(0x102,3,32,&raw,&m));
 assert(m.length[0]==1&&m.length[1]==1&&m.length[2]==1);
 raw.bx=1;assert(!wp_apm_decode(0x102,3,32,&raw,&m));
 assert(!wp_apm_decode(0x102,3,32,0,&m));assert(!wp_apm_decode(0x102,3,32,&raw,0));
 puts("PASS: APM 1.0/1.1/1.2 descriptor lengths, 16/32-bit layouts, entry bounds, physical bounds, carry/flags/version rejection and unchanged output on failure");return 0;
}
