/* Read-only proof that the retargeted WINPOWER item survived removal. */
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <ddeml.h>
#include "NTITEM.H"
static char data[32768],report[33500],message[250];
static HDDEDATA CALLBACK callback(UINT a,UINT b,HCONV c,HSZ d,HSZ e,HDDEDATA f,ULONG_PTR g,ULONG_PTR h){(void)a;(void)b;(void)c;(void)d;(void)e;(void)f;(void)g;(void)h;return 0;}
void WINAPI WinMainCRTStartup(void){
 DWORD id=0,reply,size,got=0,i,error=0;HSZ name=0,item=0;HCONV conv=0;HDDEDATA response=0;HANDLE file;
 struct nt_itemstat state;int ok=0;
 lstrcpyA(report,"WINPOWER retained Program Manager item verification\r\n");
 if(DdeInitializeA(&id,callback,APPCMD_CLIENTONLY,0)!=DMLERR_NO_ERROR)goto done;
 name=DdeCreateStringHandleA(id,"PROGMAN",CP_WINANSI);item=DdeCreateStringHandleA(id,"WINPOWER",CP_WINANSI);
 conv=DdeConnect(id,name,name,0);if(!conv)goto done;
 response=DdeClientTransaction(0,0,conv,item,CF_TEXT,XTYP_REQUEST,10000,&reply);if(!response)goto done;
 size=DdeGetData(response,0,0,0);if(!size||size>sizeof(data))goto done;
 got=DdeGetData(response,(BYTE*)data,size,0);if(got!=size)goto done;
 for(i=0;i<size&&data[i];i++){}if(i==size)goto done;
 lstrcatA(report,data);
 ni_scan(data,"NOTEPAD.EXE","C:\\WINPWRNT\\UNINST.EXE",&state);
 ok=state.count==1&&state.owned==1&&!state.preserved;
 done:
 if(response)DdeFreeDataHandle(response);if(conv)DdeDisconnect(conv);
 if(item)DdeFreeStringHandle(id,item);if(name)DdeFreeStringHandle(id,name);if(id)DdeUninitialize(id);
 lstrcatA(report,ok?"\r\nPASS: one WINPOWER item still targets NOTEPAD.EXE; owned uninstaller item is absent.\r\n":"\r\nFAIL: expected retained item identity was not found.\r\n");
 file=CreateFileA("C:\\PMPOST.TXT",GENERIC_WRITE,FILE_SHARE_READ,0,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,0);
 if(file==INVALID_HANDLE_VALUE)error=GetLastError();
 else {size=(DWORD)lstrlenA(report);if(!WriteFile(file,report,size,&got,0))error=GetLastError();else if(got!=size)error=ERROR_WRITE_FAULT;
  if(!error&&!FlushFileBuffers(file))error=GetLastError();CloseHandle(file);}
 wsprintfA(message,"%s\r\nReport: C:\\PMPOST.TXT\r\nReport write error: %lu",ok?"PASS: edited item preserved exactly; owned uninstaller item absent.":"FAIL: inspect the recorded DDE data.",error);
 MessageBoxA(0,message,"WINPOWER preserved-item audit",MB_OK|MB_ICONINFORMATION);ExitProcess(error?2:(ok?0:1));
}
