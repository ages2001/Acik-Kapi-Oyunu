/* Deterministic failed-install rollback test. Never ship in BIN.
   Requires an isolated NT3 VM and a deliberately invalid driver fixture
   beside this executable on A:. Writes C:\\NTROLL.TXT before displaying
   results. The normal SETUP /REMOVE command must perform the recovery. */
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include "NTSET.H"
#include "NTPWR.H"
void *memset(void *p,int c,size_t n){BYTE *q=p;while(n--)*q++=(BYTE)c;return p;}
static char logtext[7000],line[1000],path[MAX_PATH],self[MAX_PATH];
static char before[400],after[400],hashtext[65],dialog[1200];
static const char folder[]="C:\\WINPWRNT";
static const char invalid[]="WINPOWER INVALID DRIVER FIXTURE\r\n";
static struct wp_config cfg;
static void logline(const char *text){
 int n=lstrlenA(logtext),more=lstrlenA(text);
 if(n+more+3<(int)sizeof(logtext)){lstrcatA(logtext,text);lstrcatA(logtext,"\r\n");}
}
static void result(const char *name,DWORD value){wsprintfA(line,"%s: %lu",name,value);logline(line);}
static DWORD record(HKEY *key,DWORD *removing){
 DWORD e=RegOpenKeyExA(HKEY_LOCAL_MACHINE,WP_META,0,KEY_QUERY_VALUE,key);
 if(!e)e=wp_config(*key,&cfg);
 if(!e)e=wp_getnum(*key,"Removing",removing);
 return e;
}
static int fixture(void){
 HANDLE f;DWORD got,size;char bytes[sizeof(invalid)];int good=0;
 f=CreateFileA("A:\\PN3HOOK.SYS",GENERIC_READ,FILE_SHARE_READ,0,OPEN_EXISTING,0,0);
 if(f==INVALID_HANDLE_VALUE)return 0;
 size=GetFileSize(f,0);
 if(size==sizeof(invalid)-1&&ReadFile(f,bytes,sizeof(bytes),&got,0)&&
    got==sizeof(invalid)-1&&!memcmp(bytes,invalid,sizeof(invalid)-1))good=1;
 CloseHandle(f);return good;
}
static int copy_new(const char *source,const char *name){
 wp_path(path,folder,name);
 if(!CopyFileA(source,path,TRUE)){result("Copy error",GetLastError());return 0;}
 if(!nt_newfile(path)){logline(nt_reason());return 0;}
 return 1;
}
static int hashline(unsigned index){
 static const char digits[]="0123456789ABCDEF";
 BYTE digest[32];DWORD e;unsigned j;
 wp_path(path,folder,wp_file(3,index));e=wp_hash(path,digest,0);
 wsprintfA(line,"Retained %s hash error: %lu",wp_file(3,index),e);logline(line);
 if(e)return 0;
 for(j=0;j<32;j++){hashtext[j*2]=digits[digest[j]>>4];hashtext[j*2+1]=digits[digest[j]&15];}
 hashtext[64]=0;logline(hashtext);
 wsprintfA(line,"Matches saved Config[%u]: %u",index,!memcmp(digest,cfg.hashes[index],32));logline(line);
 return !memcmp(digest,cfg.hashes[index],32);
}
void WINAPI WinMainCRTStartup(void){
 HANDLE lock=INVALID_HANDLE_VALUE,file;HKEY key=0;DWORD n,e,removing=99,got=0;
 DWORD write_error=0,words[12],version=GetVersion(),stage=0,last=0,armed=99;
 unsigned j;int installed=0,aborted=0,pass=0,hashes=1;
 logline("WINPOWER deterministic rollback regression");
 result("OS major",LOBYTE(LOWORD(version)));result("OS minor",HIBYTE(LOWORD(version)));
 result("OS build",HIWORD(version));
 n=GetModuleFileNameA(0,self,MAX_PATH);
 if(!n||n>=MAX_PATH||lstrcmpiA(self,"A:\\NTROLL.EXE")){
  logline("STOP: run this isolated test only as A:\\NTROLL.EXE.");goto done;
 }
 if(wp_kind()!=3){logline("STOP: this fixture is restricted to Windows NT 3.x.");goto done;}
 if(!fixture()){logline("STOP: A:\\PN3HOOK.SYS is not the exact invalid ASCII fixture.");goto done;}
 logline("Invalid driver fixture identity: verified before staging");
 if(!nt_preflight()){logline("Preflight failed:");logline(nt_reason());goto done;}
 logline("Preflight: passed (no existing installation or active backend)");
 if(GetFileAttributesA(folder)!=INVALID_FILE_ATTRIBUTES){logline("STOP: destination already exists.");goto done;}
 e=GetLastError();if(e!=ERROR_FILE_NOT_FOUND&&e!=ERROR_PATH_NOT_FOUND){result("Destination query error",e);goto done;}
 if(!CreateDirectoryA(folder,0)){result("Create directory error",GetLastError());goto done;}
 if(!copy_new("A:\\WINPWRNT.EXE","WINPWRNT.EXE")||!copy_new("A:\\SETUP.EXE","UNINST.EXE"))goto done;
 if(!nt_stage(self,folder)){logline("Staging failed:");logline(nt_reason());goto done;}
 logline("Staging: actual GUI, SETUP, service and invalid driver copied");
 installed=nt_install(folder);result("nt_install returned",installed);
 lstrcpyA(before,nt_reason());logline(before);
 if(installed){logline("FAIL: invalid driver unexpectedly activated. Preserve VM evidence.");goto done;}
 e=record(&key,&removing);result("Pre-abort Config read error",e);result("Pre-abort Removing",removing);
 if(!e)e=wp_getnum(key,"Stage",&stage);
 if(!e)e=wp_getnum(key,"LastError",&last);
 if(!e)e=wp_getnum(key,"Armed",&armed);
 result("Pre-abort stage",stage);result("Pre-abort last error",last);result("Pre-abort armed",armed);
 if(key){RegCloseKey(key);key=0;}if(e)goto done;
 if(stage!=4||!last||armed){logline("STOP: failure was not an unarmed kernel-load failure at stage 4.");goto done;}
 wp_path(path,folder,"PN3HOOK.SYS");
 lock=CreateFileA(path,GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,0,OPEN_EXISTING,0,0);
 if(lock==INVALID_HANDLE_VALUE){result("Driver lock error",GetLastError());goto done;}
 logline("Staged driver opened after load failure, without delete sharing");
 aborted=nt_abort(folder);result("nt_abort returned",aborted);
 lstrcpyA(after,nt_reason());logline(after);
 removing=99;e=record(&key,&removing);
 result("Post-abort Config read error",e);result("Post-abort Removing",removing);
 if(!e){result("Post-abort Config kind",cfg.kind);logline(cfg.folder);for(j=0;j<4;j++)if(!hashline(j))hashes=0;}
 if(key){RegCloseKey(key);key=0;}
 pass=!aborted&&!e&&removing==1&&cfg.kind==3&&!lstrcmpiA(cfg.folder,folder)&&hashes;
 CloseHandle(lock);lock=INVALID_HANDLE_VALUE;
 logline("Blocking driver handle: closed after state checks");
 e=wp_backend(3,words);result("Backend open error (2 or 3 = absent)",e);
 if(e!=ERROR_FILE_NOT_FOUND&&e!=ERROR_PATH_NOT_FOUND)pass=0;
 logline(pass?"PASS: failed deletion retained valid Config and Removing=1.":"FAIL: expected recoverable rollback state was not established.");
 logline("Next: run real A:\\SETUP.EXE /REMOVE, restart, then audit clean state.");
 logline("nt_abortfinish was deliberately not called after failed nt_abort.");
 done:
 if(lock!=INVALID_HANDLE_VALUE)CloseHandle(lock);if(key)RegCloseKey(key);
 result("Regression result (1 = pass)",pass);
 file=CreateFileA("C:\\NTROLL.TXT",GENERIC_WRITE,FILE_SHARE_READ,0,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,0);
 if(file==INVALID_HANDLE_VALUE)write_error=GetLastError();
 else {
  n=(DWORD)lstrlenA(logtext);
  if(!WriteFile(file,logtext,n,&got,0))write_error=GetLastError();
  else if(got!=n)write_error=ERROR_WRITE_FAULT;
  if(!write_error&&!FlushFileBuffers(file))write_error=GetLastError();
  CloseHandle(file);
 }
 result("C:\\NTROLL.TXT write error",write_error);
 wsprintfA(dialog,"%s\r\n\r\nnt_install: %d; stage: %lu; load error: %lu; armed: %lu\r\n"
  "nt_abort: %d; retained Removing: %lu; saved file hashes: %d\r\n\r\n%s\r\n\r\n"
  "Full report: C:\\NTROLL.TXT\r\nReport write error: %lu\r\n\r\n"
  "Recovery: real A:\\SETUP.EXE /REMOVE, then restart and audit.",
  pass?"PASS: recovery record retained after blocked rollback.":"FAIL: inspect the report before changing this VM.",
  installed,stage,last,armed,aborted,removing,hashes,after,write_error);
 MessageBoxA(0,dialog,"WINPOWER rollback regression",MB_OK|(pass?MB_ICONINFORMATION:MB_ICONEXCLAMATION));
 ExitProcess(write_error?2:(pass?0:1));
}
