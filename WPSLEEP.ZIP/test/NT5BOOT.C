/* Launch a marked native NT5 test at the installed Explorer desktop. */
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
static char body[25000], cmd[64], report[MAX_PATH];
static STARTUPINFOA start;
static PROCESS_INFORMATION proc;
static DWORD read_text(const char *file)
{
    DWORD n=0;HANDLE f=CreateFileA(file,GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,0,OPEN_EXISTING,0,0);
    if(f!=INVALID_HANDLE_VALUE){if(!ReadFile(f,body,sizeof(body)-1,&n,0))n=0;CloseHandle(f);}
    body[n]=0;return n;
}
static unsigned occurrences(const char *part)
{
    unsigned n=0;const char *q=body;
    while(*q){const char *s=q,*p=part;while(*p && *p==*s){++s;++p;}if(!*p){++n;q=s;}else ++q;}
    return n;
}
static void record(const char *path,const char *msg)
{
    HANDLE h;DWORD n;
    h=CreateFileA(path,GENERIC_WRITE,FILE_SHARE_READ,0,CREATE_NEW,0,0);
    if(h==INVALID_HANDLE_VALUE)ExitProcess(4);
    if(!WriteFile(h,msg,lstrlenA(msg),&n,0)||!FlushFileBuffers(h))ExitProcess(5);
    CloseHandle(h);
}
void WINAPI WinMainCRTStartup(void)
{
    DWORD v=GetVersion();unsigned i,done,count=0;BOOL control;const char *next;
    if((v&0x80000000UL)||LOBYTE(LOWORD(v))!=5||!read_text("A:\\WPGUEST.ID"))ExitProcess(1);
    if(!read_text("A:\\QAUTO.ID")||(body[0]!='C'&&body[0]!='D'))ExitProcess(1);
    control=body[0]=='C';for(i=1;body[i]>='0'&&body[i]<='9';i++)count=count*10+body[i]-'0';
    if(!count||count>20)ExitProcess(1);
    for(i=0;i<240&&!FindWindowA("Shell_TrayWnd",0);++i)Sleep(500);
    if(!FindWindowA("Shell_TrayWnd",0))ExitProcess(2);
    Sleep(8000);
    read_text(control?"A:\\OSCTRL.TXT":"A:\\UPGRADE.TXT");
    done=occurrences(control?"Calling ExitWindowsEx(EWX_REBOOT).":"Action=/RESTART ");
    if(done>count||(!control&&occurrences("Action=/OFF ")))ExitProcess(2);
    wsprintfA(report,"A:\\BOOT%02u.TXT",done);
    record(report,"Explorer desktop is running after this number of confirmed native restart requests.\r\n");
    if(control&&done==count)ExitProcess(0);
    next=done<count?"A:\\R.EXE":"A:\\F.EXE";
    lstrcpyA(cmd,next);Sleep(6000);
    start.cb=sizeof(start);if(!CreateProcessA(next,cmd,0,0,FALSE,0,0,0,&start,&proc))ExitProcess(3);
    CloseHandle(proc.hThread);CloseHandle(proc.hProcess);ExitProcess(0);
}
