#include <assert.h>
#include <stdio.h>
#include <string.h>
#include "PWRSEQ.H"
struct bus {unsigned a,b,n,sleep[2],enabled,disabled,ticks,fail_enable,fail_disable,reset,cf9,kbd;};
static unsigned get(void *ctx,unsigned port){struct bus *b=ctx;assert(port==0x604||port==0x608);return port==0x604?b->a:b->b;}
static void put16(void *ctx,unsigned port,unsigned val){struct bus *b=ctx;assert(port==0x604||port==0x608);b->n++;if(val&0x2000)b->sleep[port==0x604?0:1]=val;if(port==0x604)b->a=val;else b->b=val;}
static void put8(void *ctx,unsigned port,unsigned val){struct bus *b=ctx;b->n++;
 if(port==0xcf9){assert(val==0x02||val==0x0e);b->cf9++;return;}   /* PCI reset control */
 if(port==0x64){assert(val==0xfe);b->kbd++;return;}               /* keyboard controller reset */
 if(port==0x600){assert(val==6);b->reset++;return;}               /* ACPI RESET_REG */
 assert(port==0xb2);if(val==0xf1){b->enabled++;if(!b->fail_enable){b->a|=1;b->b|=1;}}else {assert(val==0xf0);b->disabled++;if(!b->fail_disable){b->a&=~1U;b->b&=~1U;}}}
static void waitio(void *ctx,unsigned ticks){struct bus *b=ctx;b->ticks+=ticks;}
int main(void){
 struct pn_acpi p;struct bus b;struct pn_io io;memset(&p,0,sizeof(p));memset(&b,0,sizeof(b));memset(&io,0,sizeof(io));
 io.arg=&b;io.get16=get;io.put16=put16;io.put8=put8;io.wait=waitio;
 assert(pn_s5off(&p,&io)==0&&b.n==0);
 assert(pn_apm_permitted(&p,&io));
 p.reduced=1;assert(!pn_apm_permitted(&p,&io));p.reduced=0;
 p.fadt_rev=6;assert(!pn_apm_permitted(&p,&io));p.pm1a=0x604;
 b.a=1;assert(!pn_apm_permitted(&p,&io));b.a=0x2000;assert(!pn_apm_permitted(&p,&io));
 b.a=0;assert(pn_apm_permitted(&p,&io));
 p.pm1b=0x608;b.b=1;assert(!pn_apm_permitted(&p,&io));b.b=0;
 p.fadt_rev=7;assert(!pn_apm_permitted(&p,&io));p.fadt_rev=6;

 p.off_ok=1;p.pm1a=0x604;p.pm1b=0x608;p.smi=0xb2;p.enable=0xf1;p.disable=0xf0;p.sleepa=5;p.sleepb=6;
 b.a=0x100;b.b=0x200;assert(pn_s5off(&p,&io)==0);
 assert(b.sleep[0]==0x3501&&b.sleep[1]==0x3a01);assert(b.a==0x100&&b.b==0x200);assert(b.enabled==1&&b.disabled==1);
 memset(&b,0,sizeof(b));b.a=b.b=1;assert(pn_s5off(&p,&io)==-1&&b.disabled==0&&b.enabled==0);
 memset(&b,0,sizeof(b));b.a=1;assert(pn_s5off(&p,&io)==-1&&b.n==0);
 memset(&b,0,sizeof(b));b.a=0x2000;assert(pn_s5off(&p,&io)==-1&&b.n==0);
 memset(&b,0,sizeof(b));b.fail_enable=1;assert(pn_s5off(&p,&io)==0&&b.sleep[0]==0&&b.sleep[1]==0&&b.disabled==1);
 memset(&b,0,sizeof(b));b.fail_disable=1;assert(pn_s5off(&p,&io)==-1&&b.disabled==1);
 memset(&b,0,sizeof(b));p.disable=0;assert(pn_s5off(&p,&io)==0&&b.n==0);
 /* Reset tries PCI 0CF9h and the keyboard controller even with no ACPI reset
    register, and adds the ACPI reset register when the FADT provides one. */
 memset(&b,0,sizeof(b));
 assert(pn_reset(&p,&io)==0&&b.reset==0&&b.cf9>=2&&b.kbd>=1);
 memset(&b,0,sizeof(b));p.reset_ok=1;p.reset_reg.space=1;p.reset_reg.low=p.reset_port=0x600;p.reset_value=6;
 assert(pn_reset(&p,&io)==0&&b.reset>=1&&b.cf9>=2&&b.kbd>=1);
#ifdef WP_2000
 memset(&b,0,sizeof(b));pn_reset_fixed(&p,&io);
 assert(b.reset==1&&!b.cf9&&!b.kbd&&b.ticks==4);
 memset(&b,0,sizeof(b));p.reset_ok=0;pn_reset_fixed(&p,&io);
 assert(!b.n&&!b.ticks);
 puts("PASS: Windows 2000 uses one validated firmware reset or returns to its platform handler.");
#endif
 puts("PASS: PM1 fields, mode handshake, restoration, mixed-state rejection, failure fallback block, multi-method reset");return 0;
}
