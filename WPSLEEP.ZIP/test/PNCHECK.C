#define WIN32_LEAN_AND_MEAN
#include <windows.h>
void *memset(void *p,int c,size_t n){unsigned char*q=p;while(n--)*q++=(unsigned char)c;return p;}
void WINAPI WinMainCRTStartup(void){
 char path[MAX_PATH],result[512];SC_HANDLE manager=0,svc=0;SERVICE_STATUS state;HANDLE d;DWORD got,err=0,step=0;LONG rev=-1;int i;
 GetModuleFileNameA(0,path,sizeof(path));for(i=lstrlenA(path)-1;i>=0&&path[i]!='\\';--i){}path[i+1]=0;lstrcatA(path,"PNINFO.SYS");
 manager=OpenSCManagerA(0,0,SC_MANAGER_CREATE_SERVICE);if(!manager){err=GetLastError();step=1;goto done;}
 svc=CreateServiceA(manager,"PNTEST","WINPOWER diagnostic test",SERVICE_START|SERVICE_STOP|DELETE|SERVICE_QUERY_STATUS,SERVICE_KERNEL_DRIVER,SERVICE_DEMAND_START,SERVICE_ERROR_NORMAL,path,0,0,0,0,0);
 if(!svc){err=GetLastError();step=2;goto done;}
 if(!StartServiceA(svc,0,0)){err=GetLastError();step=3;goto done;}
 d=CreateFileA("\\\\.\\WINPOWER",GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,0,OPEN_EXISTING,0,0);
 if(d==INVALID_HANDLE_VALUE){err=GetLastError();step=4;goto done;}
 if(!DeviceIoControl(d,0x00226000,0,0,&rev,sizeof(rev),&got,0)||got!=sizeof(rev)){err=GetLastError();step=5;}
 CloseHandle(d);
 /* Verify the GUI while the test driver is still loaded. */
 wsprintfA(result,"WINPOWER driver test\r\nStep: %lu\r\nError: %lu\r\nRSDP revision: %ld\r\n\r\nThe driver will be unloaded when this dialog closes.",step,err,rev);
 MessageBoxA(0,result,"WINPOWER driver test",MB_OK);
 done:
 if(svc){
  if(step!=3 && step!=2 && !ControlService(svc,SERVICE_CONTROL_STOP,&state)){err=GetLastError();step=6;}
  if(!DeleteService(svc)){err=GetLastError();step=7;}CloseServiceHandle(svc);
 }
 if(manager)CloseServiceHandle(manager);
 wsprintfA(result,"Test complete\r\nStep: %lu\r\nError: %lu\r\nRSDP revision: %ld",step,err,rev);
 MessageBoxA(0,result,"WINPOWER driver result",MB_OK|(err?MB_ICONEXCLAMATION:MB_ICONINFORMATION));ExitProcess(err?1:0);
}
