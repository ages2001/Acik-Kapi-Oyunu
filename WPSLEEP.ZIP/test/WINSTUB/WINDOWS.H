/* Small API surface for host tests of LINKOWN.C, never a release header. */
#ifndef WINPOWER_LINK_STUB_H
#define WINPOWER_LINK_STUB_H
#include <stdint.h>
#include <stddef.h>
#define MAX_PATH 260
typedef uint32_t DWORD;
typedef unsigned char BYTE;
typedef int BOOL;
typedef int HKEY;
typedef int HANDLE;
typedef int HMODULE;
#define WINAPI
#define TRUE 1
#define FALSE 0
#define HKEY_LOCAL_MACHINE 1
#define INVALID_HANDLE_VALUE (-1)
#define INVALID_FILE_ATTRIBUTES 0xffffffffUL
#define FILE_ATTRIBUTE_NORMAL 0x80
#define FILE_ATTRIBUTE_DIRECTORY 0x10
#define FILE_ATTRIBUTE_READONLY 1
#define GENERIC_READ 1
#define GENERIC_WRITE 2
#define FILE_SHARE_READ 1
#define OPEN_EXISTING 1
#define CREATE_NEW 2
#define KEY_SET_VALUE 1
#define KEY_QUERY_VALUE 2
#define REG_BINARY 3
#define REG_SZ 1
#define ERROR_FILE_NOT_FOUND 2
#define ERROR_PATH_NOT_FOUND 3
#define ERROR_ACCESS_DENIED 5
#define ERROR_SHARING_VIOLATION 32
#define ERROR_INVALID_NAME 123
#define ERROR_FILENAME_EXCED_RANGE 206
#define ERROR_MORE_DATA 234
#define ERROR_ALREADY_EXISTS 183
#define ERROR_WRITE_FAULT 29
int wsprintfA(char *,const char *,...);
DWORD GetLastError(void);
BOOL SetFileAttributesA(const char *,DWORD);
DWORD GetFileAttributesA(const char *);
int lstrlenA(const char *);
int lstrcmpiA(const char *,const char *);
char *lstrcpyA(char *,const char *);
HANDLE CreateFileA(const char *,DWORD,DWORD,void *,DWORD,DWORD,HANDLE);
BOOL ReadFile(HANDLE,void *,DWORD,DWORD *,void *);
BOOL WriteFile(HANDLE,const void *,DWORD,DWORD *,void *);
BOOL FlushFileBuffers(HANDLE);
BOOL CloseHandle(HANDLE);
BOOL DeleteFileA(const char *);
DWORD RegOpenKeyExA(HKEY,const char *,DWORD,DWORD,HKEY *);
DWORD RegSetValueExA(HKEY,const char *,DWORD,DWORD,const BYTE *,DWORD);
DWORD RegFlushKey(HKEY);
DWORD RegCloseKey(HKEY);
DWORD RegQueryValueExA(HKEY,const char *,void *,DWORD *,BYTE *,DWORD *);
DWORD RegCreateKeyExA(HKEY,const char *,DWORD,void *,DWORD,DWORD,void *,HKEY *,DWORD *);
DWORD GetWindowsDirectoryA(char *,DWORD);
HMODULE GetModuleHandleA(const char *);
void (*GetProcAddress(HMODULE,const char *))(void);
#endif
