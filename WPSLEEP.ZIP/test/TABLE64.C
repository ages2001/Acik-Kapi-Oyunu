/* Reader contract for 64-bit physical table pointers and rejected overflows. */
#include <assert.h>
#include <stdio.h>
#include <string.h>
#include "S5.H"
#include "REGMEM.H"
static unsigned char rdptr[36],root[44],fixed[276],dsdt[64],work[512];
static pn_address rp,xs,fa,ds;
static unsigned seen;
static void put32(unsigned char *p,unsigned long v){
 unsigned i;for(i=0;i<4;i++){p[i]=(unsigned char)v;v>>=8;}
}
static void put64(unsigned char *p,pn_address v){put32(p,(unsigned long)v);put32(p+4,(unsigned long)(v>>32));}
static void seal(unsigned char *p,unsigned n,unsigned at){
 unsigned i;unsigned char v=0;p[at]=0;for(i=0;i<n;i++)v=(unsigned char)(v+p[i]);p[at]=(unsigned char)(0-v);
}
static int rd(void *arg,pn_address at,unsigned char *to,unsigned n){
 const unsigned char *from;unsigned size;(void)arg;
 if(at==rp){from=rdptr;size=sizeof(rdptr);seen|=1;}
 else if(at==xs){from=root;size=sizeof(root);seen|=2;}
 else if(at==fa){from=fixed;size=sizeof(fixed);seen|=4;}
 else if(at==ds){from=dsdt;size=sizeof(dsdt);seen|=8;}
 else return 0;
 if(n>size)return 0;
 memcpy(to,from,n);return 1;
}
static void build(void){
 static const unsigned char s5[]={8,'_','S','5','_',0x12,6,2,0x0a,5,0x0a,2};
 rp=((pn_address)4<<32)|0x80;xs=(pn_address)1<<32;fa=((pn_address)2<<32)|0x100;ds=((pn_address)3<<32)|0x180;
 memset(rdptr,0,sizeof(rdptr));memcpy(rdptr,"RSD PTR ",8);rdptr[15]=2;put32(rdptr+20,36);
 put64(rdptr+24,xs);seal(rdptr,20,8);seal(rdptr,36,32);
 memset(root,0,sizeof(root));memcpy(root,"XSDT",4);put32(root+4,sizeof(root));root[8]=1;put64(root+36,fa);seal(root,sizeof(root),9);
 memset(fixed,0,sizeof(fixed));memcpy(fixed,"FACP",4);put32(fixed+4,sizeof(fixed));fixed[8]=6;fixed[131]=6;
 put64(fixed+140,ds);put32(fixed+64,0x604);fixed[89]=2;seal(fixed,sizeof(fixed),9);
 memset(dsdt,0,sizeof(dsdt));memcpy(dsdt,"DSDT",4);put32(dsdt+4,36+sizeof(s5));dsdt[8]=2;memcpy(dsdt+36,s5,sizeof(s5));seal(dsdt,36+sizeof(s5),9);
}
int main(void){
 struct pn_acpi f;build();seen=0;
 assert(pn_tables(rd,0,rp,&f,work,sizeof(work))&&seen==15&&f.off_ok&&f.sleepa==5&&f.fadt_minor==6);
 seen=0;assert(!pn_tables(rd,0,~(pn_address)0-16,&f,work,sizeof(work))&&!seen);
 put64(root+36,~(pn_address)0-16);seal(root,sizeof(root),9);seen=0;
 assert(!pn_tables(rd,0,rp,&f,work,sizeof(work))&&seen==3);
 /* Simulated XP memory map: low RAM, a PCI window, then high RAM. */
 assert(wp_ram_disjoint(0xe0000010UL,1,0,0xc0000000UL));
 assert(wp_ram_disjoint(0xe0000010UL,1,(uint64_t)1<<32,0x40000000UL));
 assert(!wp_ram_disjoint(0xbfffffffUL,2,0,0xc0000000UL));
 assert(!wp_ram_disjoint(0xffffffffUL,2,(uint64_t)1<<32,0x40000000UL));
 assert(!wp_ram_disjoint(0xe0000000UL,1,(uint64_t)-2,3));
 assert(!wp_ram_disjoint((uint64_t)-1,2,0,4096));
 assert(!wp_ram_disjoint(0xe0000000UL,1,0,0));
 puts("PASS: NT5 fixed-register MMIO gaps, RAM overlap, range overflow and page boundaries.");
 puts("PASS: 64-bit RSDP, XSDT, FADT and DSDT including a zero low DWORD and overflow rejection.");
 return 0;
}
