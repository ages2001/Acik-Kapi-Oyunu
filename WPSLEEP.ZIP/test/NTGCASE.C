/* Disposable Windows 2000 / XP x64 GUI-package regression fixtures. Do not install. */
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include "SHA256.H"
#include "LINKOWN.H"
void *memset(void *p,int c,size_t n){unsigned char *q=p;while(n--)*q++=(unsigned char)c;return p;}
static char desktop[MAX_PATH],linkpath[MAX_PATH],text[2000],digest[65],marker[40],shortcut[MAX_PATH];
static const char sentinel[]="WINPOWER unrelated NT generic regression sentinel\r\n";
static const char change[]="WINPOWER changed NT generic shortcut fixture\r\n";
static const char ini[]="C:\\WINPWRNT\\WINPOWER.INI";
static BYTE buffer[1024],hash[32];
static int equal(const void *a,const void *b,unsigned n){const BYTE *x=a,*y=b;while(n--)if(*x++!=*y++)return 0;return 1;}
static DWORD write_new(const char *path,const char *data,DWORD bytes){
 HANDLE f;DWORD n,error=0;f=CreateFileA(path,GENERIC_WRITE,0,0,CREATE_NEW,FILE_ATTRIBUTE_NORMAL,0);
 if(f==INVALID_HANDLE_VALUE)return GetLastError();
 if(!WriteFile(f,data,bytes,&n,0)||n!=bytes)error=ERROR_WRITE_FAULT;
 if(!error&&!FlushFileBuffers(f))error=GetLastError();CloseHandle(f);return error;
}
static DWORD link_hash(void){
 struct wp_sha256 s;HANDLE f;DWORD n,error=0;unsigned i;
 lstrcpyA(digest,"N/A");f=CreateFileA(linkpath,GENERIC_READ,FILE_SHARE_READ,0,OPEN_EXISTING,0,0);
 if(f==INVALID_HANDLE_VALUE)return GetLastError();
 wp_sha_init(&s);
 for(;;){if(!ReadFile(f,buffer,sizeof(buffer),&n,0)){error=GetLastError();break;}if(!n)break;wp_sha_add(&s,buffer,n);}
 CloseHandle(f);if(error)return error;wp_sha_end(&s,hash);
 for(i=0;i<32;i++)wsprintfA(digest+2*i,"%02x",hash[i]);return 0;
}
void WINAPI WinMainCRTStartup(void){
 OSVERSIONINFOA os;HKEY k;DWORD n,type,error=0,kept=0,arp,linkerr,wrote,record=ERROR_FILE_NOT_FOUND,record_type=0,record_size=0,matched=0;struct lo_record rec;HANDLE f;const char *args=GetCommandLineA();
 memset(&os,0,sizeof(os));os.dwOSVersionInfoSize=sizeof(os);
 if(!GetVersionExA(&os)||os.dwPlatformId!=VER_PLATFORM_WIN32_NT||os.dwMajorVersion!=5||(os.dwMinorVersion!=0&&os.dwMinorVersion!=2)){MessageBoxA(0,"This disposable fixture requires Windows 2000 or XP x64 on a disposable test disk.","NTGCASE",MB_OK);ExitProcess(1);}
 n=sizeof(desktop);error=RegOpenKeyExA(HKEY_CURRENT_USER,"Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Shell Folders",0,KEY_READ,&k);
 if(!error){error=RegQueryValueExA(k,"Desktop",0,&type,(BYTE*)desktop,&n);RegCloseKey(k);if(!error&&(type!=REG_SZ||!n||n>=sizeof(desktop)))error=ERROR_INVALID_DATA;}
 if(error){MessageBoxA(0,"Cannot read the Desktop test path.","NTGCASE",MB_OK);ExitProcess(error);}
 desktop[n]=0;if(lstrlenA(desktop)>MAX_PATH-14)ExitProcess(ERROR_FILENAME_EXCED_RANGE);
 wsprintfA(linkpath,"%s\\WINPWRNT.LNK",desktop);
 while(*args&&*args!='/')args++;
 GetPrivateProfileStringA("Setup","Product","",marker,sizeof(marker),ini);
 if(lstrcmpiA(args,"/CHECK")&&lstrcmpA(marker,"WINPWRNT")){MessageBoxA(0,"Install the disposable WINPWRNT package before changing a fixture.","NTGCASE",MB_OK);ExitProcess(1);}
 if(!lstrcmpiA(args,"/INI")){
  error=write_new("C:\\KEEPG12.TXT",sentinel,sizeof(sentinel)-1);
  if(!error&&!WritePrivateProfileStringA("Setup","Shortcut","C:\\KEEPG12.TXT",ini))error=GetLastError();
  WritePrivateProfileStringA(0,0,0,ini);
 }else if(!lstrcmpiA(args,"/LINK")){
  f=CreateFileA(linkpath,GENERIC_WRITE,0,0,OPEN_EXISTING,0,0);
  if(f==INVALID_HANDLE_VALUE)error=GetLastError();
  else{SetFilePointer(f,0,0,FILE_END);if(!WriteFile(f,change,sizeof(change)-1,&n,0)||n!=sizeof(change)-1)error=ERROR_WRITE_FAULT;FlushFileBuffers(f);CloseHandle(f);}
 }else if(lstrcmpiA(args,"/CHECK")){MessageBoxA(0,"Usage: NTGCASE /INI | /LINK | /CHECK","NTGCASE",MB_OK);ExitProcess(1);}
 f=CreateFileA("C:\\KEEPG12.TXT",GENERIC_READ,FILE_SHARE_READ,0,OPEN_EXISTING,0,0);
 if(f!=INVALID_HANDLE_VALUE){if(ReadFile(f,buffer,sizeof(buffer),&n,0)&&n==sizeof(sentinel)-1&&equal(buffer,sentinel,n))kept=1;CloseHandle(f);}
 arp=RegOpenKeyExA(HKEY_LOCAL_MACHINE,"Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\WINPWRNT",0,KEY_READ,&k);
 if(!arp){record_size=sizeof(rec);record=RegQueryValueExA(k,"Shortcut",0,&record_type,(BYTE*)&rec,&record_size);RegCloseKey(k);}
 linkerr=link_hash();
 if(!record&&record_type==REG_BINARY&&record_size==sizeof(rec)&&rec.magic==LO_LINK_MAGIC&&!rec.path[MAX_PATH-1]&&!lstrcmpiA(rec.path,linkpath)&&!linkerr&&equal(rec.hash,hash,32))matched=1;
 GetPrivateProfileStringA("Setup","Shortcut","N/A",shortcut,sizeof(shortcut),ini);
 wsprintfA(text,"WINPOWER NT generic GUI regression\r\nAction: %s / error: %lu\r\nSentinel unchanged: %lu\r\nShortcut hash error: %lu\r\nShortcut SHA256:\r\n%s\r\nINI Shortcut: %s\r\nARP open error: %lu\r\nLink record error/type/bytes: %lu / %lu / %lu\r\nRecord matches current link: %lu\r\nFolder attributes: %08lX\r\nGUI attributes: %08lX\r\nUninstaller attributes: %08lX\r\nINI attributes: %08lX\r\n",
  args,error,kept,linkerr,digest,shortcut,arp,record,record_type,record_size,matched,GetFileAttributesA("C:\\WINPWRNT"),GetFileAttributesA("C:\\WINPWRNT\\WINPWRNT.EXE"),GetFileAttributesA("C:\\WINPWRNT\\UNINST.EXE"),GetFileAttributesA(ini));
 f=CreateFileA("C:\\NTGCASE.TXT",GENERIC_WRITE,FILE_SHARE_READ,0,OPEN_ALWAYS,FILE_ATTRIBUTE_NORMAL,0);
 if(f!=INVALID_HANDLE_VALUE){SetFilePointer(f,0,0,FILE_END);WriteFile(f,text,lstrlenA(text),&wrote,0);FlushFileBuffers(f);CloseHandle(f);}
 MessageBoxA(0,text,"WINPOWER NT generic test fixture",MB_OK);ExitProcess(error);
}
