#include <assert.h>
#include <stdio.h>
#include <string.h>
#include "NTREG.H"
int main(void){
 struct wp_regvalue saved,current;unsigned i;
 memset(&saved,0,sizeof(saved));saved.magic=WP_REG_MAGIC;current=saved;
 assert(wp_reg_restore(&saved,&current)==0);
 current.present=1;current.type=1;current.size=2;current.data[0]='1';
 assert(wp_reg_restore(&saved,&current)==1);
 for(i=0;i<256;i++){saved.data[i]=(unsigned char)i;}
 saved.present=1;saved.type=3;saved.size=256;
 assert(wp_reg_restore(&saved,&current)==1);
 current=saved;assert(wp_reg_restore(&saved,&current)==0);
 current.data[255]^=1;assert(wp_reg_restore(&saved,&current)==2);
 current=saved;current.type=4;assert(wp_reg_restore(&saved,&current)==2);
 current.size=257;assert(wp_reg_restore(&saved,&current)==-1);
 current=saved;current.present=2;assert(wp_reg_restore(&saved,&current)==-1);
 current=saved;saved.magic=0;assert(wp_reg_restore(&saved,&current)==-1);
 puts("PASS: exact NT registry backup, absent values, binary types, later-edit preservation and malformed record rejection");return 0;
}
