#!/bin/sh
# Stage the lowercase SDK include alias outside the uppercase 8.3 package.
set -eu
cd "$(dirname "$0")"
stub=$(mktemp -d "${TMPDIR:-/tmp}/WPLINK.XXXXXX")
trap 'rm -rf "$stub"; rm -f LINKTEST' EXIT HUP INT TERM
cp WINSTUB/WINDOWS.H "$stub/windows.h"
cc -x c -std=c89 -Wall -Wextra -Werror -Wno-misleading-indentation \
 -Wno-cast-function-type -pedantic -fsanitize=address,undefined \
 -I"$stub" LINKTEST.C ../src/SHA256.C -o LINKTEST
./LINKTEST
