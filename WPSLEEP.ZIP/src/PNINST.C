/* Standalone DOS installation. The original loader is preserved as PNWIN.COM. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dos.h>
#include <fcntl.h>
#include <errno.h>
#include <i86.h>
#include <direct.h>
#include "DOSINFO.H"
#include "OWN16.H"
#include "ENTRY16.H"
static char srcdir[144],windir[144],source[160],target[160];
static unsigned char buffer[4096];
struct install { char magic[8]; unsigned long hash[5]; };
typedef char install_record_must_be_28_bytes[(sizeof(struct install)==28)?1:-1];
static const char *owned[]={WP_ENTRY_FILE,"WINPWR16.EXE","UNINST.EXE","PNUNINST.EXE"};
static const char *inputs[]={"WPWRDOS.EXE","WINPWR16.EXE","UNINST.EXE","PNINST.EXE"};
static void path(char *out,const char *dir,const char *name){strcpy(out,dir);strcat(out,"\\");strcat(out,name);}
static int exists(const char *p){unsigned attr;return _dos_getfileattr(p,&attr)==0;}
static int inwindows(void){return pn_inwindows();}
/* AH=5Bh (create new) exists from DOS 3.0. DOS 2.x gets an explicit
   existence check followed by AH=3Ch on the absent name. */
static int createnew(const char *p,int *fd){
 union REGS in,out;
 memset(&in,0,sizeof(in));in.h.ah=0x30;intdos(&in,&out);
 if(out.h.al>=3)return _dos_creatnew(p,0,fd);
 if(exists(p))return 1;
 return _dos_creat(p,0,fd);
}
static void flush(void){union REGS in,out;memset(&in,0,sizeof(in));in.h.ah=0x0d;intdos(&in,&out);}
static int hashfile(const char *p,unsigned long *hash){
 int fd;unsigned n,i;unsigned long h=2166136261UL;
 if(_dos_open(p,O_RDONLY,&fd))return 0;
 for(;;){if(_dos_read(fd,buffer,sizeof(buffer),&n)){_dos_close(fd);return 0;}if(!n)break;
  for(i=0;i<n;i++){h^=buffer[i];h*=16777619UL;}
 }
 if(_dos_close(fd))return 0;*hash=h;return 1;
}
static int copynew(const char *from,const char *to){
 int a,b;unsigned n,w;int ok=1;
 if(_dos_open(from,O_RDONLY,&a))return 0;
 if(createnew(to,&b)){_dos_close(a);return 0;}
 for(;;){if(_dos_read(a,buffer,sizeof(buffer),&n)){ok=0;break;}if(!n)break;
  if(_dos_write(b,buffer,n,&w)||w!=n){ok=0;break;}}
 if(_dos_close(a))ok=0;if(_dos_close(b))ok=0;
 if(!ok)remove(to);return ok;
}
static int writeid(const char *p,struct install *id){
 struct wp_pref16 pref;int fd;unsigned n;int ok;
 wp_pref16(&pref,0);
 if(createnew(p,&fd))return 0;
 ok=!_dos_write(fd,id,sizeof(*id),&n)&&n==sizeof(*id);
 if(ok)ok=!_dos_write(fd,&pref,sizeof(pref),&n)&&n==sizeof(pref);
 if(_dos_close(fd))ok=0;if(!ok)remove(p);return ok;
}
static int readid(struct install *id){
 int fd;unsigned n;int ok;path(target,windir,"WINPWR16.ID");
 if(_dos_open(target,O_RDONLY,&fd))return 0;
 ok=!_dos_read(fd,id,sizeof(*id),&n)&&n==sizeof(*id)&&!memcmp(id->magic,"WPINST10",8);
 _dos_close(fd);return ok;
}
static int install(void){
 struct install id;unsigned i,copied=0;int renamed=0;
 char original[160],backup[160],marker[160];
 path(original,windir,WP_ENTRY_FILE);path(backup,windir,"PNWIN.COM");path(marker,windir,"WINPWR16.ID");
 if(!exists(original)){puts(WP_ENTRY_FILE " was not found in that directory.");return 1;}
 if(exists(backup)||exists(marker)){puts("An installation or backup already exists. Nothing changed.");return 1;}
 {const char *reserved[]={"PNSTATE.DAT","PNICONS.ID","PNOLD.COM","PNPOWER.LOG"};
  for(i=0;i<4;i++){path(target,windir,reserved[i]);if(exists(target)){puts("A reserved file already exists. Nothing changed.");return 1;}}}
 for(i=1;i<4;i++){path(target,windir,owned[i]);if(exists(target)){puts("A destination file already exists. Nothing changed.");return 1;}}
 for(i=0;i<4;i++){path(source,srcdir,inputs[i]);if(!hashfile(source,&id.hash[i+1])){puts("A distribution file is missing or unreadable.");return 1;}}
 if(!hashfile(original,&id.hash[0]))return 1;
 memcpy(id.magic,"WPINST10",8);
 puts("Install WINPOWER into this Windows directory? Type Y to continue:");puts(windir);
 {int answer=getchar();if(answer!='Y'&&answer!='y'){puts("Cancelled.");return 1;}}
 if(rename(original,backup)){puts("Cannot preserve " WP_ENTRY_FILE ". Nothing changed.");return 1;}renamed=1;
 for(i=0;i<4;i++){
  path(source,srcdir,inputs[i]);path(target,windir,owned[i]);
  if(!copynew(source,target))goto rollback;copied++;
 }
 if(!writeid(marker,&id))goto rollback;
 flush();puts("Installed. Start Windows with its normal " WP_ENTRY_CMD " command.");
 puts("Original loader: PNWIN.COM. To uninstall from DOS: PNUNINST /U.");return 0;
 rollback:
 puts("Install failed. Restoring the original loader.");
 for(i=0;i<copied;i++){path(target,windir,owned[i]);if(remove(target))puts("A copied file could not be removed.");}
 if(renamed&&rename(backup,original))puts("Restore failed: rename PNWIN.COM to " WP_ENTRY_FILE " before starting Windows.");
 flush();return 1;
}
static int uninstall(int confirmed){
 struct install id;unsigned i;unsigned long h;int rc=0;
 char original[160],backup[160],temp[160];
 if(!readid(&id)){puts("A valid WINPOWER installation record was not found.");return 1;}
 path(backup,windir,"PNWIN.COM");path(original,windir,WP_ENTRY_FILE);path(temp,windir,"PNOLD.COM");
 if(exists(temp)){puts("PNOLD.COM already exists. Nothing changed.");return 1;}
 if(!hashfile(backup,&h)||h!=id.hash[0]){puts("Original " WP_ENTRY_FILE " backup changed or is missing. Nothing changed.");return 1;}
 for(i=0;i<4;i++){path(target,windir,owned[i]);if(!hashfile(target,&h)||h!=id.hash[i+1]){puts("An installed file changed or is missing. Nothing changed.");return 1;}}
 if(!confirmed){int answer;puts("Uninstall WINPOWER and restore original " WP_ENTRY_FILE "? Type Y:");answer=getchar();if(answer!='Y'&&answer!='y'){puts("Cancelled.");return 1;}}
 if(rename(original,temp)){puts("Cannot move the supervisor. Nothing changed.");return 1;}
 if(rename(backup,original)){rename(temp,original);puts("Cannot restore the original loader.");return 1;}
 if(remove(temp))rc=1;
 for(i=1;i<4;i++){path(target,windir,owned[i]);if(remove(target))rc=1;}
 path(target,windir,"PNICONS.ID");if(exists(target)&&remove(target))rc=1;
 path(target,windir,"PNPOWER.LOG");if(exists(target)&&remove(target))rc=1;
 if(!rc){path(target,windir,"WINPWR16.ID");if(remove(target))rc=1;}
 flush();puts(rc?"Original loader restored; some owned files need cleanup.":"Uninstalled. Original " WP_ENTRY_FILE " restored.");return rc;
}
/* DOS 2.x passes no program path: accept the current directory when it
   holds the distribution or an installed uninstaller. */
static int findself(char *out){
 char dir[144];
 if(!getcwd(dir,sizeof(dir))||strlen(dir)>120)return 0;
 if(dir[strlen(dir)-1]=='\\')dir[strlen(dir)-1]=0;
 path(out,dir,"PNINST.EXE");if(exists(out))return 1;
 path(out,dir,"PNUNINST.EXE");return exists(out);
}
int main(int argc,char **argv){
 char *slash;int remove_mode=0,confirmed=0;
 puts("WINPOWER DOS Setup 1.0 - run only after leaving Windows");
 if(inwindows()){puts("Exit Windows completely before running DOS Setup.");return 1;}
 if(argv[0][0]){if(!_fullpath(srcdir,argv[0],sizeof(srcdir)))return 1;}
 else if(!findself(srcdir)){puts("Run PNINST from its own directory on this DOS version.");return 1;}
 slash=strrchr(srcdir,'\\');if(!slash)return 1;*slash=0;
 if(argc>=2&&(!stricmp(argv[1],"/U")||!stricmp(argv[1],"/CLEAN"))){remove_mode=1;confirmed=!stricmp(argv[1],"/CLEAN");}
 else if(argc!=3||stricmp(argv[1],"/I")){puts("Usage: PNINST /I C:\\WINDOWS or PNUNINST /U");return 1;}
 if(remove_mode){strcpy(windir,srcdir);return uninstall(confirmed);}
 if(!_fullpath(windir,argv[2],sizeof(windir))||strlen(windir)>120)return 1;
 if(windir[strlen(windir)-1]=='\\')windir[strlen(windir)-1]=0;
 return install();
}
