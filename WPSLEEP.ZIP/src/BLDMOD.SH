#!/bin/sh
# Desktop front end for Vista and newer, using ordinary Windows power APIs.
set -eu
cd "$(dirname "$0")"
mkdir -p ../TEST ../bin/NT6X86 ../bin/NT6AMD64
for arch in i686 x86_64; do
 if [ "$arch" = i686 ]; then out=NT6X86; entry=_WinMainCRTStartup@0; else out=NT6AMD64; entry=WinMainCRTStartup; fi
 "$arch-w64-mingw32-windres" SLEEPUI.RC -O coff -o ../TEST/MODGUI.O
 "$arch-w64-mingw32-windres" ADMIN.RC -O coff -o ../TEST/MODSET.O
 flags="-x c -Os -Wall -Wextra -Werror -Wno-cast-function-type -Wno-misleading-indentation -fno-builtin -fno-stack-protector -nostdlib -mwindows"
 "$arch-w64-mingw32-gcc" $flags -DWP_MODERN WINPOWER.C OSINFO.C OSNAME.C ICONUI.C FWAPI.C FWTABLE.C P9PREF.C -x none ../TEST/MODGUI.O -Wl,--entry,"$entry",--subsystem,windows:6.0 -o ../bin/$out/WINPWRNT.EXE -luser32 -lkernel32 -lgdi32 -ladvapi32
 "$arch-w64-mingw32-gcc" $flags SETUP.C LINKOWN.C SHA256.C NTDDE.C -x none ../TEST/MODSET.O -Wl,--entry,"$entry",--subsystem,windows:6.0 -o ../bin/$out/SETUP.EXE -luser32 -lkernel32 -ladvapi32 -luuid
done
