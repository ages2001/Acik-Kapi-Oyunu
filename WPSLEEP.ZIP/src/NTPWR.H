#ifndef WINPOWER_NTPWR_H
#define WINPOWER_NTPWR_H
#include <windows.h>
#include <string.h>
#include "NTREG.H"
#define WP_META "Software\\WINPOWER\\NTSTART"
#define WP_SERVICE "WINPOWER"
#define WP_OWNER_MUTEX "WINPOWER.LegacyOwner"
#define WP_CONFIG_MAGIC 0x57505331UL
struct wp_config { DWORD magic,kind;char folder[MAX_PATH];BYTE hashes[4][32]; };
DWORD wp_kind(void);
BOOL wp_folder(const char *folder);
BOOL wp_ownfolder(char *folder);
const char *wp_kernel(DWORD kind);
const char *wp_driver(DWORD kind);
const char *wp_file(DWORD kind,unsigned index);
void wp_path(char *path,const char *folder,const char *file);
DWORD wp_setnum(HKEY key,const char *name,DWORD number);
DWORD wp_getnum(HKEY key,const char *name,DWORD *number);
DWORD wp_config(HKEY key,struct wp_config *cfg);
DWORD wp_hash(const char *path,BYTE digest[32],HANDLE *lock);
DWORD wp_checkfiles(const struct wp_config *cfg,HANDLE locks[4]);
void wp_unlock(HANDLE locks[4]);
DWORD wp_regread(HKEY key,struct wp_regvalue *value);
DWORD wp_saved(HKEY meta,struct wp_regvalue *value);
DWORD wp_winlogon(HKEY meta,BOOL restore);
DWORD wp_owned(SC_HANDLE manager,const char *name,const char *path,DWORD type,SC_HANDLE *service);
DWORD wp_legacy_owner(DWORD kind,DWORD mode);
DWORD wp_backend(DWORD kind,DWORD *words);
DWORD wp_start(const char *folder);
#endif
