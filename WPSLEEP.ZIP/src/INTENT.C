/* NT3 Winlogon first calls NtShutdownSystem(NoReboot) for BOTH off and
   restart. The Boolean passed to IoShutdownSystem does not encode intent.
   Read only the known caller's saved context; never change user memory. */
#include "INTENT.H"
static unsigned long dword(const unsigned char *p) {
 return (unsigned long)p[0]|((unsigned long)p[1]<<8)|
        ((unsigned long)p[2]<<16)|((unsigned long)p[3]<<24);
}
static int same(const unsigned char *a,const unsigned char *b,unsigned n) {
 unsigned i;for(i=0;i<n;i++)if(a[i]!=b[i])return 0;return 1;
}
/* Wildcard pattern: 0x100 matches any byte. */
static int match(const unsigned char *a,const unsigned short *p,unsigned n){
 unsigned i;for(i=0;i<n;i++)if(p[i]<0x100&&a[i]!=p[i])return 0;return 1;
}
/* Locate the calling executable dynamically: images are 64 KiB aligned. */
static int imagebase(unsigned long ret,pn_usread read,void *arg,unsigned long *base,unsigned long *size){
 unsigned char b[96];unsigned long at=ret&~0xffffUL,pe;unsigned i;
 for(i=0;i<64&&at;i++,at-=0x10000UL){
  if(!read(arg,at,b,64)||b[0]!='M'||b[1]!='Z')continue;
  pe=dword(b+60);if(pe<64||pe>2048)return 0;
  if(!read(arg,at+pe,b,96)||dword(b)!=0x4550||b[4]!=0x4c||b[5]!=1)return 0;
  /* Executable (not DLL) whose image contains the return address. */
  if((b[22]&0x20)||!(b[22]&2))return 0;
  *size=dword(b+80);if(*size<0x1000||*size>0x1000000UL||ret-at>=*size)return 0;
  *base=at;return 1;
 }
 return 0;
}
static int inside(unsigned long v,unsigned long base,unsigned long size){return v>=base&&v-base<size;}
unsigned pn_intent(unsigned kernel,const struct pn_userregs *r,pn_usread read,void *arg) {
 unsigned char b[96];unsigned long base,size,ret,flags,target;
 static const unsigned char syscall[]={0x8d,0x54,0x24,4,0xcd,0x2e,0xc2,4,0};
 /* push 0; call rel32 (NtShutdownSystem thunk); push esi; call rel32; and ebx,2 */
 static const unsigned short call31[]={0x6a,0,0xe8,0x100,0x100,0x100,0x100,0x56,0xe8,0x100,0x100,0x100,0x100,0x83,0xe3,2};
 /* push 0; call [IAT]; push ebx; call rel32 (3.50 and 3.51 main caller) */
 static const unsigned short call35[]={0x6a,0,0xff,0x15,0x100,0x100,0x100,0x100,0x53,0xe8,0x100,0x100,0x100,0x100};
 /* push 0; call [IAT]; push 0; push 13h (3.51 alternate caller) */
 static const unsigned short alternate[]={0x6a,0,0xff,0x15,0x100,0x100,0x100,0x100,0x6a,0,0x6a,0x13};
 unsigned long number;
 /* Kernel-mode caller context: the user-mode NtShutdownSystem stub. Its
    service number identifies the NT 3.5x release (3.50: A5h, 3.51: ADh). */
 if(kernel!=31&&kernel!=35&&kernel!=350&&kernel!=351)return 0;
 if(r->eip<11||!read(arg,r->eip-11,b,14)||b[0]!=0xb8||!same(b+5,syscall,sizeof(syscall)))return 0;
 number=dword(b+1);
 if(kernel==31){if(number!=0x9cUL)return 0;}
 else if(number==0xa5UL&&kernel!=351)kernel=350;
 else if(number==0xadUL&&kernel!=350)kernel=351;
 else return 0;
 if(!read(arg,r->esp,b,8)||dword(b+4)!=0)return 0;
 ret=dword(b);
 if(!imagebase(ret,read,arg,&base,&size))return 0;
 if(kernel==31) {
  if(ret-base<7||!read(arg,ret-7,b,16)||!match(b,call31,16))return 0;
  target=(ret+dword(b+3))&0xffffffffUL;
  if(!inside(target,base,size)||!inside((ret+6+dword(b+9))&0xffffffffUL,base,size))return 0;
  flags=r->ebx;
 } else {
  if(ret-base<8||!read(arg,ret-8,b,14))return 0;
  if(kernel==351&&match(b,alternate,12)) {
   if(!inside(dword(b+4),base,size))return 0;
   return r->ebx==11?2:((r->ebx==5||r->ebx==10)?1:0);
  }
  if(!match(b,call35,14)||!inside(dword(b+4),base,size)||!inside((ret+6+dword(b+10))&0xffffffffUL,base,size))return 0;
  if(kernel==350)flags=r->edi;
  else {
   if(r->edi>0x7ffeffabUL||!read(arg,r->edi+0x54,b,4))return 0;
   flags=dword(b);
  }
 }
 if(flags&2)return 2;
 return (flags&(kernel==31?1:9))?1:0;
}
