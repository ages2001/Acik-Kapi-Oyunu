#ifndef WP_OWNER16_H
#define WP_OWNER16_H
/* Extension to the original 28-byte WINPWR16.ID installation record. */
#define WP_PREF_POS 28
struct wp_pref16 { char tag[4]; unsigned short value, inverse; };
typedef char wp_pref_width[(sizeof(struct wp_pref16)==8)?1:-1];
static void wp_pref16(struct wp_pref16 *p,unsigned mode){
 p->tag[0]='O';p->tag[1]='W';p->tag[2]='N';p->tag[3]='1';
 p->value=(unsigned short)mode;p->inverse=(unsigned short)(mode^0xffffU);
}
static int wp_pref_ok(const struct wp_pref16 *p){
 return p->tag[0]=='O'&&p->tag[1]=='W'&&p->tag[2]=='N'&&p->tag[3]=='1'&&
        p->value<=1&&(unsigned short)(p->value^p->inverse)==0xffffU;
}
#endif
