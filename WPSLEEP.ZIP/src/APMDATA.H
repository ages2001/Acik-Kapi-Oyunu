#ifndef WINPOWER_APMDATA_H
#define WINPOWER_APMDATA_H
#include <limits.h>
#if UINT_MAX == 0xffffffffU
typedef unsigned int wp_apm_u32;
#else
typedef unsigned long wp_apm_u32;
#endif
typedef char wp_apm_u32_is_four[(sizeof(wp_apm_u32)==4)?1:-1];
struct wp_apm_raw { wp_apm_u32 ax,bx,cx,dx,si,di; unsigned short flags; };
struct wp_apm_map {
 unsigned mode,count;
 wp_apm_u32 entry,base[3],length[3];
 unsigned char descriptor[24];
};
/* Structural decoding only. Physical bases are not kernel virtual addresses.
   Never install these diagnostic templates directly in an OS GDT. */
int wp_apm_decode(unsigned version,unsigned flags,unsigned mode,
                  const struct wp_apm_raw *raw,struct wp_apm_map *out);
#endif
