/* WINPOWER bounded AML interpreter for sleep-state preparation.
   Freestanding C89, usable in 16-bit DOS, VxD and NT kernel builds.
   Scope: load DSDT/SSDT/PSDT definition blocks, resolve names, evaluate
   \_Sx (Name or Method) and execute \_TTS/\_PTS/\_GTS for a sleep state.
   Supported region spaces: SystemIO, SystemMemory and PCI_Config, each
   through caller hooks that decide what is admissible. Unsupported
   opcodes, spaces or limits fail closed; nothing is guessed. */
#ifndef PN_AML_H
#define PN_AML_H
typedef unsigned long pn_u32;

struct pn_aml_env {
 void *arg;
 /* Return nonzero on success. width is 8, 16 or 32. */
 int (*io_read)(void *arg,pn_u32 port,unsigned width,pn_u32 *value);
 int (*io_write)(void *arg,pn_u32 port,unsigned width,pn_u32 value);
 int (*mem_read)(void *arg,pn_u32 address,unsigned width,pn_u32 *value);
 int (*mem_write)(void *arg,pn_u32 address,unsigned width,pn_u32 value);
 int (*pci_read)(void *arg,unsigned bus,unsigned dev,unsigned fn,unsigned reg,unsigned width,pn_u32 *value);
 int (*pci_write)(void *arg,unsigned bus,unsigned dev,unsigned fn,unsigned reg,unsigned width,pn_u32 value);
 void (*stall)(void *arg,pn_u32 microseconds);
};

#define PN_AML_MAX_TABLES 16
#define PN_AML_NAMELEN 4

struct pn_aml_node;

struct pn_aml_obj {
 unsigned char type;      /* PN_OBJ_* */
 unsigned char table;     /* AML source table for strings/buffers/packages */
 unsigned short node;     /* Referenced/owning node index (0 = none) */
 pn_u32 value;            /* Integer value, or AML offset of data */
 pn_u32 length;           /* String/buffer length or package extent end */
 unsigned short count;    /* Package element count */
 unsigned short index;    /* Index reference element */
};
#define PN_OBJ_NONE    0
#define PN_OBJ_INT     1
#define PN_OBJ_STRING  2
#define PN_OBJ_BUFFER  3
#define PN_OBJ_PACKAGE 4
#define PN_OBJ_REF     5   /* Reference to a named node */
#define PN_OBJ_INDEX   6   /* Reference to a package element */
#define PN_OBJ_UNKNOWN 7   /* Verification placeholder value */
#define PN_OBJ_DEBUG   8   /* Debug object target */

struct pn_aml_node {
 char name[PN_AML_NAMELEN];
 unsigned short parent;
 unsigned char type;      /* PN_NODE_* */
 unsigned char flags;     /* Method: argument count (bits 0-2) */
 unsigned char table;
 unsigned char space;     /* Region: address space; field: access/update */
 unsigned short link;     /* Field: region node; IndexField: index node */
 unsigned short link2;    /* IndexField: data node; BankField: bank node */
 pn_u32 start,end;        /* AML extent (method body, region args, etc.) */
 pn_u32 bit,bits;         /* Field position/size; region cached offset/len */
 pn_u32 bank;             /* BankField value */
 struct pn_aml_obj value; /* Name objects */
};
#define PN_NODE_FREE      0
#define PN_NODE_SCOPE     1   /* Scope, Device, Processor, ThermalZone, PowerResource */
#define PN_NODE_NAME      2
#define PN_NODE_METHOD    3
#define PN_NODE_REGION    4
#define PN_NODE_FIELD     5
#define PN_NODE_INDEXFLD  6
#define PN_NODE_BANKFLD   7
#define PN_NODE_MUTEX     8
#define PN_NODE_EVENT     9
#define PN_NODE_ALIAS    10
#define PN_NODE_BUILTIN  11   /* \_OSI */
#define PN_NODE_EXTERNAL 12

struct pn_aml {
 const unsigned char *aml[PN_AML_MAX_TABLES];
 pn_u32 size[PN_AML_MAX_TABLES];
 unsigned tables;
 struct pn_aml_node *node;
 unsigned nodes,capacity;
 unsigned revision;       /* DSDT revision: 2+ means 64-bit integers */
 unsigned failed;
 /* Diagnostics: last failing opcode and AML offset. */
 unsigned last_op;
 pn_u32 last_at;
 unsigned last_table;
};

/* nodes: caller-provided array; capacity >= 64. */
int pn_aml_init(struct pn_aml *a,struct pn_aml_node *nodes,unsigned capacity,unsigned revision);
/* Load one definition block body (table bytes after the 36-byte header).
   The memory must remain valid while the interpreter is used. */
int pn_aml_load(struct pn_aml *a,const unsigned char *body,pn_u32 length);
/* Evaluate \_Sx: returns 1 with SLP_TYPa/SLP_TYPb, 0 when absent or invalid.
   Side effects are refused during this evaluation. */
int pn_aml_sleep_type(struct pn_aml *a,const struct pn_aml_env *env,unsigned state,unsigned *typa,unsigned *typb);
/* Verify, without hardware access, that every preparation method present
   (\_TTS, \_PTS, \_GTS) uses only supported operations. 1 = executable. */
int pn_aml_verify_prepare(struct pn_aml *a,unsigned state);
/* Execute \_TTS(state), \_PTS(state), \_GTS(state) when present.
   Returns 1 when all present methods completed, 0 on a runtime failure. */
int pn_aml_prepare(struct pn_aml *a,const struct pn_aml_env *env,unsigned state);
/* 1 when any preparation method exists. */
int pn_aml_has_prepare(struct pn_aml *a);
#endif
