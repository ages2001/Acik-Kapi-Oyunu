#!/bin/sh
set -eu
: "${WATCOM:?Set WATCOM to the Open Watcom 1.9 directory}"
cd "$(dirname "$0")"
export PATH="$WATCOM/binl:$PATH"
export INCLUDE="$WATCOM/h"
run() { if [ -n "${WIN16_RUN:-}" ]; then "$WIN16_RUN" "$@"; else "$@"; fi; }
mkdir -p ../BIN/WINPWR9X/LAB
for unit in PN9HOOK PN9MIN S5 ACPI PWRSEQ AML; do
 run "$WATCOM/binl/wcc386" -q -3s -mf -s -zl -os -wx -dPN_TIMER_INFO -dPN_AML -fo=../TEST/$unit.OBJ $unit.C
done
run "$WATCOM/binl/wasm" -q -fo=../TEST/PN9DDB.OBJ PN9DDB.ASM
run "$WATCOM/binl/wlink" @PN9LINK.LNK
python3 ../TEST/FIXVXD.PY ../BIN/WINPWR9X/LAB/PN9HOOK.VXD
i686-w64-mingw32-gcc -x c -march=i386 -Os -Wall -Wextra -Werror -fno-builtin -fno-stack-protector -nostdlib -mwindows PN9TEST.C -Wl,--entry,_WinMainCRTStartup@0,--subsystem,windows:4.0 -o ../BIN/WINPWR9X/LAB/PN9TEST.EXE -lkernel32 -luser32
rm ../TEST/PN9DDB.OBJ ../TEST/PN9HOOK.OBJ ../TEST/PN9MIN.OBJ ../TEST/S5.OBJ ../TEST/ACPI.OBJ ../TEST/PWRSEQ.OBJ ../TEST/AML.OBJ
