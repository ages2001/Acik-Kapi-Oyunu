; Physical memory reads above 1 MiB from real-mode DOS without INT 15h AH=87h.
; Some DOS kernels (for example the MS-DOS 8.0 built-in XMS manager) halt
; when a program issues INT 15h AH=87h. In real mode (not V86), a 4 GiB FS
; limit is loaded through a brief protected-mode switch with interrupts
; disabled. Callers must use pn_v86 first and must not use these in V86 mode.
.model large,c
.386p
.data
pn_gdt    dw 0,0,0,0
          dw 0ffffh,0,9200h,008fh
pn_gdtr   dw 15
          dd 0
.code
public pn_v86, pn_a20, pn_bigread, pn_bigwrite, pn_in32, pn_out32
; Returns 1 when the CPU is in protected or V86 mode (MSW.PE set).
pn_v86 proc far
 smsw ax
 and ax,1
 ret
pn_v86 endp
; Returns 1 when address line 20 is enabled. Memory is restored.
pn_a20 proc far
 push ds
 push es
 pushf
 cli
 xor ax,ax
 mov ds,ax
 not ax
 mov es,ax
 mov cl,ds:[0500h]
 mov ch,es:[0510h]
 mov byte ptr ds:[0500h],0
 mov byte ptr es:[0510h],0ffh
 xor ax,ax
 cmp byte ptr ds:[0500h],0ffh
 je short aliased
 mov ax,1
aliased:
 mov es:[0510h],ch
 mov ds:[0500h],cl
 popf
 pop es
 pop ds
 ret
pn_a20 endp
; cdecl: unsigned long physical, void far *destination, unsigned count.
; Returns 1 after copying; 0 when called in V86/protected mode.
pn_bigread proc far
 push bp
 mov bp,sp
 push ds
 push es
 push fs
 push esi
 push edi
 push ebx
 smsw ax
 test ax,1
 jnz short refused
 mov ax,seg pn_gdt
 mov ds,ax
 movzx ebx,ax
 shl ebx,4
 add ebx,offset pn_gdt
 mov dword ptr ds:[pn_gdtr+2],ebx
 pushf
 cli
 lgdt fword ptr ds:[pn_gdtr]
 mov eax,cr0
 or al,1
 mov cr0,eax
 jmp short pmode
pmode:
 mov bx,8
 mov fs,bx
 and al,0feh
 mov cr0,eax
 jmp short rmode
rmode:
 xor bx,bx
 mov fs,bx
 mov esi,dword ptr [bp+6]
 les di,dword ptr [bp+10]
 mov cx,word ptr [bp+14]
 jcxz short copied
 cmp cx,2
 jne short copy
 test esi,1
 jnz short copy
 mov ax,fs:[esi]
 mov es:[di],ax
 jmp short copied
copy:
 mov al,fs:[esi]
 mov es:[di],al
 inc esi
 inc di
 loop copy
copied:
 popf
 mov ax,1
 jmp short done
refused:
 xor ax,ax
done:
 pop ebx
 pop edi
 pop esi
 pop fs
 pop es
 pop ds
 pop bp
 ret
pn_bigread endp
; cdecl: unsigned port -> 32-bit value in DX:AX.
pn_in32 proc far
 push bp
 mov bp,sp
 mov dx,word ptr [bp+6]
 in eax,dx
 mov edx,eax
 shr edx,16
 pop bp
 ret
pn_in32 endp
; cdecl: unsigned port, unsigned long value.
pn_out32 proc far
 push bp
 mov bp,sp
 mov dx,word ptr [bp+6]
 mov eax,dword ptr [bp+8]
 out dx,eax
 pop bp
 ret
pn_out32 endp
; cdecl: unsigned long physical, void far *source, unsigned count.
; Same real-mode-only rule as pn_bigread.
pn_bigwrite proc far
 push bp
 mov bp,sp
 push ds
 push es
 push fs
 push esi
 push edi
 push ebx
 smsw ax
 test ax,1
 jnz short wrefused
 mov ax,seg pn_gdt
 mov ds,ax
 movzx ebx,ax
 shl ebx,4
 add ebx,offset pn_gdt
 mov dword ptr ds:[pn_gdtr+2],ebx
 pushf
 cli
 lgdt fword ptr ds:[pn_gdtr]
 mov eax,cr0
 or al,1
 mov cr0,eax
 jmp short wpmode
wpmode:
 mov bx,8
 mov fs,bx
 and al,0feh
 mov cr0,eax
 jmp short wrmode
wrmode:
 xor bx,bx
 mov fs,bx
 mov edi,dword ptr [bp+6]
 lds si,dword ptr [bp+10]
 mov cx,word ptr [bp+14]
 jcxz short wcopied
 cmp cx,2
 jne short wcopy
 test edi,1
 jnz short wcopy
 mov ax,ds:[si]
 mov fs:[edi],ax
 jmp short wcopied
wcopy:
 mov al,ds:[si]
 mov fs:[edi],al
 inc edi
 inc si
 loop wcopy
wcopied:
 popf
 mov ax,1
 jmp short wdone
wrefused:
 xor ax,ax
wdone:
 pop ebx
 pop edi
 pop esi
 pop fs
 pop es
 pop ds
 pop bp
 ret
pn_bigwrite endp
end
