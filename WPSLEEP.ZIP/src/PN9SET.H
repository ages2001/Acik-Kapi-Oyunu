#ifndef PN9_SET_H
#define PN9_SET_H
BOOL pn9_stage(const char *self,const char *folder);
BOOL pn9_install(const char *folder);
BOOL pn9_remove(const char *folder);
BOOL pn9_release(void);
BOOL pn9_cleanup(const char *folder);
BOOL pn9_finish(const char *folder);
BOOL pn9_recovery(void);
const char *pn9_reason(void);
#endif
