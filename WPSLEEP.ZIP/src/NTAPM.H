#ifndef PN_NTAPM_H
#define PN_NTAPM_H
/* NT real-mode APM power-off fallback. ACPI stays preferred; this is used
   only when no ACPI S5 is available (or an ACPI S5 attempt returned).
   pn_apm_init runs at PASSIVE_LEVEL (driver load): it allocates a <1 MiB
   real-mode trampoline and an identity page table, confirms the x86 page-
   directory self-map, and checks that a BIOS INT 15h vector is present.
   Returns 1 when APM power-off is available. pn_apm_off runs at any IRQL
   at final shutdown and does not return on success. */
int pn_apm_init(void);
int pn_apm_available(void);
/* APM version BCD (e.g. 0x0102) discovered at init, or 0 if unknown. */
unsigned pn_apm_version(void);
void pn_apm_off(void);       /* One-way: powers the machine off via APM. */
void pn_apm_cleanup(void);   /* Frees the trampoline (driver unload only). */
#endif
