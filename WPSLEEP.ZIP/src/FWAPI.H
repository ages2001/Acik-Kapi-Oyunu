#ifndef WINPOWER_FWAPI_H
#define WINPOWER_FWAPI_H
#include "FWTABLE.H"
/* Returns validated metadata without physical reads or driver loading.
   Call once during GUI initialization; firmware tables are boot data. */
int wp_fw_query(struct wp_fwtable *info);
/* The destination must hold at least 64 bytes. */
void wp_fw_text(const struct wp_fwtable *info,char text[64]);
#endif
