#include "FWVER.H"
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include "OSINFO.H"
#include "ICONUI.H"
#include "OSNAME.H"
#include "FWAPI.H"
#include "P9PREF.H"
#ifdef WP_NT34CFG
#include "NTPWR.H"
#endif
#ifdef WP_NT5CFG
#include "P5SCM.H"
#endif
#define ID_OFF 101
#define ID_BOOT 102
#define ID_INFO 103
#define ID_SLEEP 106
#define ID_OWNER_OS 104
#define ID_OWNER_DRV 105
void *memset(void *p, int c, size_t n) { unsigned char *q=p; while(n--) *q++=(unsigned char)c; return p; }
static HINSTANCE inst;
static HWND statusbox,ownerOS,ownerDriver;
static unsigned powerlab;
static int showowner;       /* owner selector is shown only where the OS can also power itself off (Win9x, NT5) */
static BOOL oldhandoff;
static BOOL ownerselectable;/* the loaded driver can take over the native Windows shutdown (owner handoff) */
static unsigned batteryicon=8, acicon=10, amlprep;
static BOOL compact;
static int status_y;
static char displayed[1024],ownerlabel[64];

static HFONT titlefont, bodyfont;
static HBRUSH headerbrush, bodybrush;
static COLORREF headercolor, accentcolor;
static OSVERSIONINFOA os;
static char osname[160], architecture[80];
static struct wp_fwtable firmware;
#ifdef WP_MODERN
static BOOL pe_mode;
static HANDLE pe_command;
#endif
/* The legacy shared GUI is the binary supplied in bin/WIN9X. */
#if !defined(WP_MODERN) && !defined(WP_NT34CFG) && !defined(WP_NT5CFG)
#define WP_WIN9X_STATUS
static BOOL early9;
static BOOL early_restart(const DWORD *report) {
 return report[0]==10 && report[1]==1 && report[2]>=0x40a && !(report[6]&0x40);
}
static DWORD restore9(void) {
 DWORD report[16],bytes,mode=0,actual=2,err;
 HANDLE dev=CreateFileA("\\\\.\\PN9HOOK",0,0,NULL,OPEN_EXISTING,0,NULL);
 if(dev!=INVALID_HANDLE_VALUE){
  if(DeviceIoControl(dev,1,NULL,0,report,sizeof(report),&bytes,NULL) &&
     bytes==sizeof(report) && early_restart(report)){
   if(!DeviceIoControl(dev,4,&mode,sizeof(mode),NULL,0,&bytes,NULL) ||
      !DeviceIoControl(dev,5,NULL,0,&actual,sizeof(actual),&bytes,NULL))err=GetLastError();
   else err=bytes==sizeof(actual)&&actual==0?ERROR_REVISION_MISMATCH:ERROR_INVALID_DATA;
   CloseHandle(dev);return err;
  }
  CloseHandle(dev);
 }
 return wp9_restore();
}
#endif
typedef BOOL (WINAPI *POWERFN)(LPSYSTEM_POWER_STATUS);
static void refresh(void) {
 SYSTEM_POWER_STATUS p; char text[1024], bat[64], charge[48], ac[64], life[64], rev[64],apm[32];
 unsigned oldbattery=batteryicon,oldac=acicon;
#ifdef WP_WIN9X_STATUS
 BOOL windows_restart=FALSE;
 early9=FALSE;
#endif
 HANDLE d; LONG v; DWORD got,lab[16],mode=0;BOOL modeknown=FALSE,acpioff=FALSE;const char *owner="Operating system",*driver="WINPOWER driver (unavailable)";
 POWERFN fn=(POWERFN)GetProcAddress(GetModuleHandleA("KERNEL32.DLL"),"GetSystemPowerStatus");
 wp_fw_text(&firmware,rev);
 lstrcpyA(apm,"N/A");
 d=CreateFileA("\\\\.\\WINPOWER",GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,0,OPEN_EXISTING,0,0);
 if(d!=INVALID_HANDLE_VALUE){
  if(DeviceIoControl(d,0x00226000UL,0,0,&v,sizeof(v),&got,0)&&got==sizeof(v)&&v>=0&&!firmware.revision)
   pn_acpitext((unsigned)v,0,0,rev);
  CloseHandle(d);
 }
 powerlab=0;amlprep=0;ownerselectable=FALSE;oldhandoff=FALSE;
 if(os.dwPlatformId==VER_PLATFORM_WIN32_NT&&(os.dwMajorVersion==3||os.dwMajorVersion==4)){
  unsigned old3=os.dwMajorVersion==3;DWORD size=old3?48:32;
  d=CreateFileA(old3?"\\\\.\\PN3LAB":"\\\\.\\PN4LAB",GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,0,OPEN_EXISTING,0,0);
  if(d!=INVALID_HANDLE_VALUE){
   if(DeviceIoControl(d,0x00226000UL,0,0,lab,size,&got,0)&&got==size&&lab[0]==(old3?9UL:7UL)&&lab[1]==1&&(lab[4]&17)&&(!old3||lab[11]==1)){
    powerlab=old3?3:4;acpioff=(lab[4]&1)!=0;if(lab[3]&&(!firmware.revision||(lab[4]&0x80000000UL)))pn_acpitext(lab[2],lab[3],wp_minor(lab[4]),rev);amlprep=(lab[4]&8)!=0;
#ifdef WP_NT34CFG
    if(DeviceIoControl(d,0x226014,0,0,&mode,sizeof(mode),&got,0)&&got==sizeof(mode)&&(mode&~1UL)==0x100){
     ownerselectable=TRUE;modeknown=TRUE;mode&=1;
    }
#endif
    if(lab[6+!old3])pn_apmtext(lab[6+!old3],apm);   /* NT3: lab[6], NT4: lab[7] */
   }CloseHandle(d);
  }
 }
 if(os.dwPlatformId==VER_PLATFORM_WIN32_NT&&os.dwMajorVersion==5){
  /* Windows 2000/XP: query the loaded driver and its current owner. */
  d=CreateFileA("\\\\.\\PN5LAB",GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,0,OPEN_EXISTING,0,0);
  if(d!=INVALID_HANDLE_VALUE){
   if(DeviceIoControl(d,0x00226000UL,0,0,lab,32,&got,0)&&got==32&&lab[1]==1){
    if(lab[0]==5)oldhandoff=TRUE;
    if(lab[0]==6&&(lab[4]&0x11)){
    powerlab=5;ownerselectable=(lab[5]&0x100)!=0;mode=lab[5]&1;modeknown=TRUE;acpioff=(lab[4]&1)!=0;if(lab[3]&&(!firmware.revision||(lab[4]&0x80000000UL)))pn_acpitext(lab[2],lab[3],wp_minor(lab[4]),rev);amlprep=(lab[4]&8)!=0;
    if(lab[7])pn_apmtext(lab[7],apm);
    }
   }CloseHandle(d);
  }
 }
 if(os.dwPlatformId==VER_PLATFORM_WIN32_WINDOWS&&os.dwMajorVersion==4){
  /* No extension: query a resident VxD without loading a driver or hook. */
  d=CreateFileA("\\\\.\\PN9HOOK",0,0,0,OPEN_EXISTING,0,0);
  if(d!=INVALID_HANDLE_VALUE){
   if(DeviceIoControl(d,1,0,0,lab,sizeof(lab),&got,0)&&got==sizeof(lab)&&lab[0]==10){
    if(lab[3]&&lab[3]<=0xffff)pn_apmtext((unsigned)lab[3],apm);
    if(lab[4]!=0xffff&&lab[5])pn_acpitext(lab[4],lab[5],wp_minor(lab[6]),rev);
#ifdef WP_WIN9X_STATUS
    windows_restart=(lab[6]&0x40)!=0;
    early9=early_restart(lab);
#endif
    /* An armed native handoff keeps the OS/Driver selector available. */
    if(lab[1]==1&&(lab[6]&1)){powerlab=9;ownerselectable=TRUE;acpioff=TRUE;}
   }
   if(powerlab==9&&DeviceIoControl(d,5,0,0,&mode,sizeof(mode),&got,0)&&got==sizeof(mode)&&mode<=1)
    modeknown=TRUE;
   CloseHandle(d);
  }
 }
 if(powerlab==3){owner="WINPOWER NT3 driver";driver="WINPOWER NT3 driver (active)";}
 if(powerlab==4){owner="WINPOWER NT4 driver";driver="WINPOWER NT4 driver (active)";}
#ifdef WP_NT34CFG
 if(powerlab==3||powerlab==4){
  if(modeknown){owner="Operating system";driver="WINPOWER driver (final power transition)";}
  else{owner="Earlier fixed-owner driver loaded";driver="WINPOWER driver (requires update)";}
 }
#endif
 if(oldhandoff){owner="Legacy driver loaded; update requires restart";driver="Legacy driver - run HNDLOAD, then restart";}
 if(powerlab==5||powerlab==9)driver="WINPOWER driver (final power transition)";
#ifdef WP_WIN9X_STATUS
 if(powerlab==9 && windows_restart)driver="WINPOWER power off / Windows restart";
 if(early9)driver="Earlier driver (update required)";
#endif
 /* Read the actual owner on every refresh, including after reopening the GUI.
    Unknown state is displayed with neither radio selected. */
 if(showowner){
  if(!powerlab&&!oldhandoff){mode=0;modeknown=TRUE;driver="WINPOWER driver";}
  if(ownerselectable&&!modeknown)owner="Unknown (driver state query failed)";
  SendMessageA(ownerOS,BM_SETCHECK,modeknown&&mode==0?BST_CHECKED:BST_UNCHECKED,0);
  SendMessageA(ownerDriver,BM_SETCHECK,modeknown&&mode==1?BST_CHECKED:BST_UNCHECKED,0);
  /* Keep the requested Win9x/NT5 settings accessible. A failed Driver
     selection reports the reason and restores the confirmed radio state. */
  EnableWindow(ownerOS,TRUE);
#ifdef WP_MODERN
  if(os.dwPlatformId==VER_PLATFORM_WIN32_NT && os.dwMajorVersion>=6){
   driver="WINPOWER driver (final transition unavailable)";
   EnableWindow(ownerDriver,FALSE);
  }else
#endif
  EnableWindow(ownerDriver,TRUE);
  if(lstrcmpA(ownerlabel,driver)){SetWindowTextA(ownerDriver,driver);lstrcpyA(ownerlabel,driver);}
  if(ownerselectable&&SendMessageA(ownerDriver,BM_GETCHECK,0,0)==BST_CHECKED)
   owner="WINPOWER driver (native shutdown handoff)";
#ifdef WP_WIN9X_STATUS
  if(windows_restart&&modeknown&&mode==1)owner="WINPOWER power off / Windows restart";
  if(early9&&modeknown&&mode==1)owner="Earlier driver active - select Windows";
#endif
 }
 batteryicon=8;acicon=10;
 lstrcpyA(charge,"");
 lstrcpyA(bat,"N/A");lstrcpyA(ac,"N/A");lstrcpyA(life,"N/A");
 if(fn && fn(&p)) {
  if(p.ACLineStatus==0)lstrcpyA(ac,"Offline");
  if(p.ACLineStatus==1){lstrcpyA(ac,"Online");acicon=6;}
  if(p.BatteryFlag!=255 && (p.BatteryFlag&128))lstrcpyA(bat,"Not present");
  else if(p.BatteryLifePercent<=100) wsprintfA(bat,"%u%%",p.BatteryLifePercent);
  if(p.BatteryFlag!=255 && !(p.BatteryFlag&128)) {
   batteryicon=(p.BatteryFlag&8)?9:5;
   if(p.BatteryFlag&8)lstrcpyA(charge," / Charging");
   else if(p.BatteryFlag&4)lstrcpyA(charge," / Critical");
   else if(p.BatteryFlag&2)lstrcpyA(charge," / Low");
  }
  if(p.BatteryLifeTime!=0xffffffffUL)wsprintfA(life,"%lu seconds",p.BatteryLifeTime);
 }
 wsprintfA(text,compact?
 "%s\r\n%s\r\nACPI version: %s\r\nAPM version: %s\r\nAC power: %s\r\nBattery: %s%s\r\nBattery time remaining: %s\r\nShutdown owner: %s\r\nFirmware control: %s":
 "%s\r\n%s\r\n\r\nACPI version: %s\r\nAPM version: %s\r\n\r\nAC power: %s\r\nBattery: %s%s\r\nBattery time remaining: %s\r\n\r\nShutdown owner: %s\r\nFirmware control: %s",
 osname,architecture,rev,apm,ac,bat,charge,life,owner,powerlab?(acpioff?(amlprep?"ACPI S5 with sleep preparation":"ACPI S5 available"):"APM power off available"):"Windows power management");
 if(lstrcmpA(displayed,text)){SetWindowTextA(statusbox,text);lstrcpyA(displayed,text);}
 /* Only the status icons need a parent repaint when their values change.
    Repainting the entire header every timer tick causes visible flicker
    on slow legacy display drivers. Static controls repaint themselves. */
 if(oldbattery!=batteryicon||oldac!=acicon){
  HWND h=GetParent(statusbox);HDC dc=GetDC(h);TEXTMETRICA tm;RECT r;
  HFONT old=(HFONT)SelectObject(dc,bodyfont);GetTextMetricsA(dc,&tm);
  SelectObject(dc,old);ReleaseDC(h,dc);
  r.left=22;r.right=38;r.top=status_y+(compact?4:6)*tm.tmHeight;
  r.bottom=r.top+tm.tmHeight+16;InvalidateRect(h,&r,FALSE);
 }
}
static void error(HWND h, const char *what) {
 char b[384];wsprintfA(b,"%s\r\nWindows error: %lu",what,GetLastError());
 MessageBoxA(h,b,"WINPOWER",MB_OK|MB_ICONEXCLAMATION);
}
#ifdef WP_MODERN
/* WinPE uses its own power utility to finish the session. */
static void pe_power(HWND window, BOOL restart) {
 char exe[MAX_PATH],command[MAX_PATH+18];
 DWORD length;
 STARTUPINFOA startup;
 PROCESS_INFORMATION child;
 if(pe_command)return;
 length=GetSystemDirectoryA(exe,sizeof(exe));
 if(!length || length+sizeof("\\wpeutil.exe")>sizeof(exe)){
  MessageBoxA(window,"The Windows PE system directory is unavailable.","WINPOWER",MB_OK|MB_ICONERROR);
  return;
 }
 lstrcatA(exe,"\\wpeutil.exe");
 wsprintfA(command,"\"%s\" %s",exe,restart?"Reboot":"Shutdown");
 ZeroMemory(&startup,sizeof(startup));startup.cb=sizeof(startup);
 if(!CreateProcessA(exe,command,NULL,NULL,FALSE,CREATE_NO_WINDOW,NULL,NULL,&startup,&child)){
  error(window,"Windows PE could not start its power utility.");return;
 }
 CloseHandle(child.hThread);
 pe_command=child.hProcess;
}
static void pe_poll(HWND window) {
 DWORD code=0;
 if(!pe_command || WaitForSingleObject(pe_command,0)!=WAIT_OBJECT_0)return;
 if(!GetExitCodeProcess(pe_command,&code))code=GetLastError();
 CloseHandle(pe_command);pe_command=NULL;
 if(code){SetLastError(code);error(window,"Windows PE rejected the power request.");}
}
#endif
static DWORD owner_query(HANDLE dev, BOOL nt, DWORD *mode) {
 DWORD bytes, status[8];
 if(nt){
  if(!DeviceIoControl(dev,0x226000,0,0,status,sizeof(status),&bytes,0))return GetLastError();
  if(bytes!=sizeof(status)||status[0]!=6||!(status[5]&0x100))return ERROR_NOT_SUPPORTED;
  *mode=status[5]&1;
 }else{
  if(!DeviceIoControl(dev,5,0,0,mode,sizeof(*mode),&bytes,0))return GetLastError();
  if(bytes!=sizeof(*mode)||*mode>1)return ERROR_INVALID_DATA;
 }
 return 0;
}
static void setmode(HWND h,int driverowns) {
 BOOL nt=os.dwPlatformId==VER_PLATFORM_WIN32_NT,changed=FALSE;
 DWORD mode=driverowns?1:0,previous=0,actual=0,bytes,err=0,code=nt?0x22600c:4;
 HANDLE dev;
#ifdef WP_WIN9X_STATUS
 if(driverowns&&early9){
  MessageBoxA(h,"Select Windows, update the installed VxD, then restart to enable Driver control.","WINPOWER",MB_OK|MB_ICONEXCLAMATION);
  refresh();return;
 }
#endif
#ifdef WP_NT34CFG
 if(nt&&(os.dwMajorVersion==3||os.dwMajorVersion==4)){
  if(!ownerselectable&&powerlab){
   SetLastError(ERROR_NOT_SUPPORTED);error(h,"Remove the older fixed-owner driver and restart to install this package.");
  }else{
   err=wp_legacy_owner(os.dwMajorVersion,mode);
   if(err){SetLastError(err);error(h,"Could not confirm or save the legacy shutdown owner.");}
  }
  refresh();return;
 }
#endif
 if(oldhandoff){
  MessageBoxA(h,"Run HNDLOAD.EXE to return the older driver to OS control, then restart.","WINPOWER",MB_OK|MB_ICONEXCLAMATION);
  refresh();return;
 }
 if(!ownerselectable){
  if(!mode){
#ifdef WP_NT5CFG
   if(nt)err=wp5_remember(0);
#endif
   if(!nt)err=wp9_remember(0);
   if(err){SetLastError(err);error(h,"Could not save OS control for the next boot.");}
   refresh();return;
  }
#ifdef WP_NT5CFG
  if(nt){err=wp5_start();refresh();}
#endif
  if(!ownerselectable){
   SetLastError(err?err:ERROR_NOT_SUPPORTED);
   error(h,"Driver control is unavailable. Install the matching package. Win9x needs a restart. The driver must recognize the firmware and Windows version.");refresh();return;
  }
 }
 dev=CreateFileA(nt?"\\\\.\\PN5LAB":"\\\\.\\PN9HOOK",nt?GENERIC_READ:0,
                  nt?FILE_SHARE_READ|FILE_SHARE_WRITE:0,0,OPEN_EXISTING,0,0);
 if(dev==INVALID_HANDLE_VALUE)err=GetLastError();
 else{
  err=owner_query(dev,nt,&previous);
  if(!err){
   if(!DeviceIoControl(dev,code,&mode,sizeof(mode),0,0,&bytes,0))err=GetLastError();
   else{changed=TRUE;err=owner_query(dev,nt,&actual);if(!err&&actual!=mode)err=ERROR_INVALID_DATA;}
  }
  if(!err){
#ifdef WP_NT5CFG
   if(nt)err=wp5_remember(mode);
#endif
   if(!nt)err=wp9_remember(mode);
  }
  if(err&&changed)DeviceIoControl(dev,code,&previous,sizeof(previous),0,0,&bytes,0);
  CloseHandle(dev);
 }
 if(err){SetLastError(err);error(h,"Windows could not confirm or save the chosen owner. The current state will be read again.");}
 refresh();
}
static void power(HWND h,int reboot) {
 HANDLE token=0; TOKEN_PRIVILEGES tp,old; DWORD sz=sizeof(old); BOOL adjusted=FALSE;
#ifdef WP_WIN9X_STATUS
 refresh();
 if(early9&&SendMessageA(ownerOS,BM_GETCHECK,0,0)!=BST_CHECKED){
  MessageBoxA(h,"Select Windows before requesting power with the older driver loaded.","WINPOWER",MB_OK|MB_ICONEXCLAMATION);return;
 }
#endif
 if(oldhandoff){MessageBoxA(h,"An older NT5 driver is still loaded. Run HNDLOAD.EXE to return it to OS control, then restart Windows to load this build.","WINPOWER",MB_OK|MB_ICONEXCLAMATION);return;}
 BOOL plain_shutdown=os.dwPlatformId==VER_PLATFORM_WIN32_NT&&os.dwMajorVersion<4;
#ifndef _WIN64
 /* NT4 without the final-power backend can reboot for EWX_POWEROFF.
    Ordinary shutdown reaches its safe-to-turn-off screen instead. */
 if(os.dwPlatformId==VER_PLATFORM_WIN32_NT&&os.dwMajorVersion==4&&(powerlab!=4
#ifdef WP_NT34CFG
 ||SendMessageA(ownerDriver,BM_GETCHECK,0,0)!=BST_CHECKED
#endif
 ))
  plain_shutdown=TRUE;
#endif
 if(MessageBoxA(h,reboot?"Restart Windows now? Save your work first.":
 "Request Windows power off now? Save your work first.\r\nPhysical power off requires support from Windows and firmware.",
 "WINPOWER",MB_YESNO|MB_ICONQUESTION|MB_DEFBUTTON2)!=IDYES)return;
#ifdef WP_MODERN
 if(pe_mode){pe_power(h,reboot);return;}
#endif
 /* Both owner modes begin with normal Windows shutdown. Applications may
    veto it; the driver acts only at its native final-power handoff. */
 if(os.dwPlatformId==VER_PLATFORM_WIN32_NT) {
  if(!OpenProcessToken(GetCurrentProcess(),TOKEN_ADJUST_PRIVILEGES|TOKEN_QUERY,&token)){error(h,"Cannot open process token.");return;}
  tp.PrivilegeCount=1;tp.Privileges[0].Attributes=SE_PRIVILEGE_ENABLED;
  if(!LookupPrivilegeValueA(0,"SeShutdownPrivilege",&tp.Privileges[0].Luid)){error(h,"Cannot find shutdown privilege.");CloseHandle(token);return;}
  SetLastError(0);
  if(!AdjustTokenPrivileges(token,FALSE,&tp,sizeof(old),&old,&sz)||GetLastError()!=ERROR_SUCCESS){error(h,"Shutdown privilege is unavailable.");CloseHandle(token);return;}
  adjusted=TRUE;
 }
 /* NT3.1 has no EWX_POWEROFF contract. The final-shutdown driver supplies
    power off after an ordinary EWX_SHUTDOWN has completed. Win9x also needs
    the SHUTDOWN bit: POWEROFF alone can log off the user. */
 if(!ExitWindowsEx(reboot?EWX_REBOOT:
    (plain_shutdown?EWX_SHUTDOWN:
    (EWX_POWEROFF|(os.dwPlatformId==VER_PLATFORM_WIN32_WINDOWS?EWX_SHUTDOWN:0))),0))
  error(h,"Windows rejected the power request.");
 if(adjusted)AdjustTokenPrivileges(token,FALSE,&old,0,0,0);
 if(token)CloseHandle(token);
}
#include "SLPWIN.H"
static HWND child(HWND h,const char *cls,const char *s,DWORD style,int x,int y,int w,int ht,int id) {
 HWND c=CreateWindowA(cls,s,WS_CHILD|WS_VISIBLE|style,x,y,w,ht,h,(HMENU)(INT_PTR)id,inst,0);
 SendMessageA(c,WM_SETFONT,(WPARAM)bodyfont,TRUE);return c;
}
static LRESULT CALLBACK proc(HWND h,UINT m,WPARAM w,LPARAM l) {
 switch(m) {
 case WM_CREATE: {
  HWND c;HDC screen=GetDC(h);int colors=GetDeviceCaps(screen,BITSPIXEL)*GetDeviceCaps(screen,PLANES);
  int group_y=compact?222:274,button_y=showowner?(compact?304:360):(compact?232:284);ReleaseDC(h,screen);
  headercolor=colors<=8?RGB(0,0,128):RGB(18,41,67);
  accentcolor=colors<=8?RGB(0,128,128):RGB(33,178,181);
  headerbrush=CreateSolidBrush(headercolor);bodybrush=CreateSolidBrush(GetSysColor(COLOR_BTNFACE));
  bodyfont=CreateFontA(-14,0,0,0,FW_NORMAL,0,0,0,ANSI_CHARSET,OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,DEFAULT_QUALITY,DEFAULT_PITCH,"MS Sans Serif");
  titlefont=CreateFontA(-24,0,0,0,FW_BOLD,0,0,0,ANSI_CHARSET,OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,DEFAULT_QUALITY,DEFAULT_PITCH,"Arial");
  status_y=compact?66:78;statusbox=child(h,"STATIC","",0,46,status_y,466,compact?150:190,0);
  if(showowner){
   child(h,"BUTTON","Final shutdown / restart control",BS_GROUPBOX,16,group_y,500,72,0);
   ownerOS=c=child(h,"BUTTON","The operating system (default)",BS_AUTORADIOBUTTON|WS_GROUP,30,group_y+18,440,22,ID_OWNER_OS);
   SendMessageA(c,BM_SETCHECK,BST_CHECKED,0);
   ownerDriver=c=child(h,"BUTTON","The WINPOWER driver (unavailable)",BS_AUTORADIOBUTTON,30,group_y+44,440,22,ID_OWNER_DRV);EnableWindow(c,FALSE);
  }
  child(h,"BUTTON","&Power off",WS_TABSTOP|BS_OWNERDRAW,18,button_y,118,32,ID_OFF);
  child(h,"BUTTON","&Restart",WS_TABSTOP|BS_OWNERDRAW,143,button_y,118,32,ID_BOOT);
  child(h,"BUTTON","&Sleep...",WS_TABSTOP|BS_OWNERDRAW,268,button_y,118,32,ID_SLEEP);
  child(h,"BUTTON","&About",WS_TABSTOP|BS_OWNERDRAW,393,button_y,118,32,ID_INFO);
  refresh();SetTimer(h,1,5000,0);return 0;
 }
 case WM_DRAWITEM: {
  LPDRAWITEMSTRUCT d=(LPDRAWITEMSTRUCT)l;
  if(d->CtlType==ODT_BUTTON&&(d->CtlID==ID_OFF||d->CtlID==ID_BOOT||d->CtlID==ID_SLEEP||d->CtlID==ID_INFO)){
   pn_button(d,inst,d->CtlID==ID_OFF?3:(d->CtlID==ID_BOOT?4:d->CtlID==ID_SLEEP?12:7),bodyfont,bodybrush);return TRUE;
  }break;
 }
 case WM_PAINT: {
  PAINTSTRUCT ps;HDC dc=BeginPaint(h,&ps);RECT r;HBRUSH b;
  GetClientRect(h,&r);r.bottom=compact?58:68;FillRect(dc,&r,headerbrush);
  r.top=r.bottom;r.bottom+=3;b=CreateSolidBrush(accentcolor);FillRect(dc,&r,b);DeleteObject(b);
  /* Paint header text in the same pass as its background. Older USER
     versions do not repaint unchanged static children on parent refresh. */
  {const char *subtitle="Power status and system controls  /  Release 1.0";
   HFONT old=(HFONT)SelectObject(dc,titlefont);
   SetBkMode(dc,TRANSPARENT);SetTextColor(dc,RGB(255,255,255));
   TextOutA(dc,64,10,"WINPOWER",8);SelectObject(dc,bodyfont);
   TextOutA(dc,64,compact?34:42,subtitle,lstrlenA(subtitle));SelectObject(dc,old);
  }
  DrawIcon(dc,18,compact?13:17,LoadIconA(inst,MAKEINTRESOURCEA(1)));
  {TEXTMETRICA tm;HFONT old=(HFONT)SelectObject(dc,bodyfont);GetTextMetricsA(dc,&tm);SelectObject(dc,old);
   pn_icon(dc,LoadIconA(inst,MAKEINTRESOURCEA(acicon)),22,status_y+(compact?4:6)*tm.tmHeight,16,bodybrush);
   pn_icon(dc,LoadIconA(inst,MAKEINTRESOURCEA(batteryicon)),22,status_y+(compact?5:7)*tm.tmHeight,16,bodybrush);
  }
  EndPaint(h,&ps);return 0;
 }
 case WM_CTLCOLORSTATIC:
  /* fall through */
 case WM_CTLCOLORBTN:
  SetBkColor((HDC)w,GetSysColor(COLOR_BTNFACE));
  SetTextColor((HDC)w,GetSysColor(COLOR_BTNTEXT));
  return (LRESULT)bodybrush;
 case WM_SYSCOLORCHANGE:
  DeleteObject(bodybrush);bodybrush=CreateSolidBrush(GetSysColor(COLOR_BTNFACE));InvalidateRect(h,0,TRUE);return 0;
 case WM_SYSKEYDOWN:
  if(w=='S'){SendMessageA(h,WM_COMMAND,ID_SLEEP,0);return 0;}
  if(w=='R'){power(h,1);return 0;}
  if(w=='P'){power(h,0);return 0;}
  break;
 case WM_TIMER:
#ifdef WP_MODERN
  pe_poll(h);
#endif
  refresh();return 0;
 case WM_COMMAND:
  if(LOWORD(w)==ID_OWNER_OS&&showowner)setmode(h,0);
  if(LOWORD(w)==ID_OWNER_DRV&&showowner)setmode(h,1);
  if(LOWORD(w)==ID_OFF)power(h,0);
  if(LOWORD(w)==ID_BOOT)power(h,1);
  if(LOWORD(w)==ID_SLEEP)DialogBoxParamA(inst,MAKEINTRESOURCEA(150),h,wp_sleep_dialog,0);
  if(LOWORD(w)==ID_INFO)MessageBoxA(h,"WINPOWER 1.0 - Initial release\r\n\r\nOS and independent-driver shutdown/reboot and power status.\r\nFADT is a firmware table revision, not a support guarantee.\r\nN/A means unavailable or not queried; it does not prove absence.\r\nWin9x / NT3 / NT4 / NT5 lab activity appears in the main window.\r\nSee STATUS.TXT for the complete support matrix.","About WINPOWER",MB_OK|MB_ICONINFORMATION);
  return 0;
 case WM_DESTROY:
#ifdef WP_MODERN
  if(pe_command){CloseHandle(pe_command);pe_command=NULL;}
#endif
  KillTimer(h,1);DeleteObject(titlefont);DeleteObject(bodyfont);DeleteObject(headerbrush);DeleteObject(bodybrush);PostQuitMessage(0);return 0;
 }
 return DefWindowProcA(h,m,w,l);
}
void WINAPI WinMainCRTStartup(void) {
 WNDCLASSA wc; HWND h; MSG msg; int r,x,y;RECT area,window;
 DWORD style=WS_OVERLAPPED|WS_CAPTION|WS_SYSMENU|WS_MINIMIZEBOX;
 inst=GetModuleHandleA(0);pn_osinfo(&os,osname,architecture);
#ifdef WP_MODERN
 {
  HKEY mini;
  pe_mode=RegOpenKeyExA(HKEY_LOCAL_MACHINE,"SYSTEM\\CurrentControlSet\\Control\\MiniNT",
                         0,KEY_QUERY_VALUE,&mini)==ERROR_SUCCESS;
  if(pe_mode){
   RegCloseKey(mini);
   if(lstrlenA(osname)<(int)(sizeof(osname)-sizeof(" | Windows PE")))lstrcatA(osname," | Windows PE");
  }
 }
#endif
 if(os.dwPlatformId==VER_PLATFORM_WIN32_WINDOWS){
  const char *arg=GetCommandLineA();
  if(*arg=='"'){++arg;while(*arg&&*arg!='"')++arg;if(*arg)++arg;}
  else while(*arg&&*arg!=' ')++arg;
  while(*arg==' ')++arg;
  if(!lstrcmpiA(arg,"/RESTORE")){
#ifdef WP_WIN9X_STATUS
   ExitProcess(restore9());
#else
   ExitProcess(wp9_restore());
#endif
  }
 }
 wp_fw_query(&firmware);
 ZeroMemory(&wc,sizeof(wc));wc.lpfnWndProc=proc;wc.hInstance=inst;wc.hCursor=LoadCursorA(0,IDC_ARROW);
 wc.hIcon=LoadIconA(inst,MAKEINTRESOURCEA(1));wc.hbrBackground=(HBRUSH)(COLOR_BTNFACE+1);wc.lpszClassName="WINPOWER";
 if(!RegisterClassA(&wc))ExitProcess(1);
 area.left=area.top=0;area.right=GetSystemMetrics(SM_CXSCREEN);area.bottom=GetSystemMetrics(SM_CYSCREEN);
 if(os.dwMajorVersion>=4){RECT work;if(SystemParametersInfoA(SPI_GETWORKAREA,0,&work,0))area=work;}
 compact=area.bottom-area.top<440;
 /* Size the control row for the OS family and the compiled backend.
    Runtime queries determine whether Driver ownership is available. */
 showowner=(os.dwPlatformId==VER_PLATFORM_WIN32_WINDOWS&&os.dwMajorVersion==4)||
           (os.dwPlatformId==VER_PLATFORM_WIN32_NT&&os.dwMajorVersion==5);
#ifdef WP_NT34CFG
 if(os.dwPlatformId==VER_PLATFORM_WIN32_NT && (os.dwMajorVersion==3||os.dwMajorVersion==4))showowner=TRUE;
#endif
#ifdef WP_MODERN
 if(os.dwPlatformId==VER_PLATFORM_WIN32_NT && os.dwMajorVersion>=6)showowner=TRUE;
#endif
 window.left=window.top=0;window.right=532;window.bottom=showowner?(compact?346:410):(compact?274:334);
 AdjustWindowRect(&window,style,FALSE);window.right-=window.left;window.bottom-=window.top;
 x=area.left+(area.right-area.left-window.right)/2;y=area.top+(area.bottom-area.top-window.bottom)/2;
 if(x<area.left)x=area.left;
 if(y<area.top)y=area.top;
 h=CreateWindowA("WINPOWER","WINPOWER - Power Center",style,x,y,window.right,window.bottom,0,0,inst,0);
 if(!h)ExitProcess(2);
 ShowWindow(h,SW_SHOW);UpdateWindow(h);
 while((r=GetMessageA(&msg,0,0,0))>0){if(!IsDialogMessageA(h,&msg)){TranslateMessage(&msg);DispatchMessageA(&msg);}}
 ExitProcess(r<0?3:(UINT)msg.wParam);
}
