/* Bounded Program Manager CSV parsing; no DDE or Windows dependencies. */
#ifndef WINPOWER_NTITEM_H
#define WINPOWER_NTITEM_H
struct nt_itemstat { unsigned count,owned,preserved; };
static int ni_equal(const char *a,const char *b){
 while(*a&&*b){
  unsigned x=(unsigned char)*a++,y=(unsigned char)*b++;
  if(x>='a'&&x<='z')x-='a'-'A';if(y>='a'&&y<='z')y-='a'-'A';
  if(x!=y)return 0;
 }return *a==*b;
}
static int ni_field(const char **cursor,const char *end,char *out,unsigned capacity){
 const char *p=*cursor;unsigned n=0;
 while(p<end&&(*p==' '||*p=='\t'))p++;
 if(p==end||*p++!='"')return 0;
 while(p<end){
  char c=*p++;
  if(c=='"'){
   if(p<end&&*p=='"')p++;
   else {
    while(p<end&&(*p==' '||*p=='\t'))p++;
    if(p==end||*p++!=',')return 0;
    out[n]=0;*cursor=p;return 1;
   }
  }
  if(n+1>=capacity)return 0;out[n++]=c;
 }return 0;
}
static void ni_scan(const char *data,const char *app,const char *uninst,struct nt_itemstat *result){
 const char *p=data;unsigned line=0,seen[2]={0,0},match[2]={0,0},uncertain=0,i;
 result->count=result->owned=result->preserved=0;
 while(*p){
  const char *end=p,*q;char title[64],command[260];int index=-1;
  while(*end&&*end!='\r'&&*end!='\n')end++;
  if(line&&end>p){
   result->count++;q=p;
   if(!ni_field(&q,end,title,sizeof(title)))uncertain=1;
   else {
    if(ni_equal(title,"WINPOWER"))index=0;
    else if(ni_equal(title,"Uninstall WINPOWER"))index=1;
    if(index>=0){
     seen[index]++;
     if(ni_field(&q,end,command,sizeof(command))&&ni_equal(command,index?uninst:app))match[index]++;
    }
   }
  }
  line++;p=end;while(*p=='\r'||*p=='\n')p++;
 }
 /* DeleteItem selects by title. Even one retargeted duplicate makes that
    title unsafe to delete. A malformed title can hide such a duplicate. */
 for(i=0;i<2;i++){
  if(!uncertain&&seen[i]==1&&match[i]==1)result->owned|=1U<<i;
  else if(seen[i])result->preserved=1;
 }
 if(uncertain)result->preserved=1;
}
#endif
