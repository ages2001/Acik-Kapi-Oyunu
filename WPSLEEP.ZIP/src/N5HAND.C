/* NT5 power manager registration. No kernel/HAL image is scanned or patched.
   The off notification runs inside Windows' final state dispatcher. The
   reset provider is registered only if Windows accepts that handler. */
#include <ntddk.h>
#include "N5HAND.H"

typedef NTSTATUS (NTAPI *SYSTEM_HANDLER)(PVOID);
typedef NTSTATUS (NTAPI *ENTER_HANDLER)(PVOID, SYSTEM_HANDLER, PVOID,
                                        LONG, volatile LONG *);
typedef NTSTATUS (NTAPI *NOTIFY_HANDLER)(ULONG, PVOID, BOOLEAN);
typedef struct {
    ULONG type;
    UCHAR rtc_wake, reserved[3];
    ENTER_HANDLER enter;
    PVOID context;
} STATE_REGISTRATION;
typedef struct { NOTIFY_HANDLER notify; PVOID context; } NOTIFICATION;

enum { RegisterStateHandler=6, RegisterNotification=17,
       Nt5Reset=5, Nt5Off=6 };
enum { Collecting, Performing, Delegating };
extern __declspec(dllimport) CCHAR KeNumberProcessors;
static KSPIN_LOCK owner_lock;
static ULONG owner, final_owner, closing, ready;
static volatile LONG arrived, phase;

static void trace(const char *s) {
    while (*s) __asm__ volatile("outb %0,%w1"::"a"((UCHAR)*s++),"d"((USHORT)0xe9));
}

void wp_n5_initialize(void) { KeInitializeSpinLock(&owner_lock); }

static unsigned processor(void) {
#ifdef _WIN64
    USHORT n;
    __asm__ volatile("movw %%gs:0x184,%0":"=r"(n));
#else
    UCHAR n;
    __asm__ volatile("movb %%fs:0x51,%0":"=q"(n));
#endif
    return n;
}

/* A final transition may be delivered to more than one processor. If a
   participant is missing, release all participants back to Windows. */
static void final_transition(ULONG action, LONG participants) {
    ULONG_PTR flags;
    unsigned cpu, waits=0;
    if (!ready || !closing || !final_owner || participants < 1 ||
        participants > 64 || KeGetCurrentIrql() < DISPATCH_LEVEL ||
        InterlockedCompareExchange(&phase, Collecting, Collecting) == Delegating) return;
    cpu=processor();
#ifdef _WIN64
    __asm__ volatile("pushfq; popq %0; cli; wbinvd":"=r"(flags)::"memory");
#else
    __asm__ volatile("pushfl; popl %0; cli; wbinvd":"=r"(flags)::"memory");
#endif
    InterlockedIncrement(&arrived);
    while (InterlockedCompareExchange(&phase, Collecting, Collecting) == Collecting) {
        if (cpu == 0 && InterlockedCompareExchange(&arrived, 0, 0) == participants) {
            if (InterlockedCompareExchange(&phase, Performing, Collecting) == Collecting) {
                wp_n5_power(action);
                InterlockedExchange(&phase, Delegating);
            }
        } else if (++waits >= 20000) {
            if (InterlockedCompareExchange(&phase, Delegating, Collecting) == Collecting)
                trace("WINPOWER OS fallback: processor timeout\n");
        } else KeStallExecutionProcessor(50);
    }
    while (InterlockedCompareExchange(&phase, 0, 0) == Performing)
        KeStallExecutionProcessor(1);
#ifdef _WIN64
    __asm__ volatile("pushq %0; popfq"::"r"(flags):"memory");
#else
    __asm__ volatile("pushl %0; popfl"::"r"(flags):"memory");
#endif
}

static NTSTATUS NTAPI notification(ULONG state, PVOID context, BOOLEAN entering) {
    (void)context;
    if (entering && state == Nt5Off) final_transition(1, KeNumberProcessors);
    return STATUS_SUCCESS;  /* If hardware returned, continue the OS transition. */
}

static NTSTATUS NTAPI reset(PVOID context, SYSTEM_HANDLER system, PVOID sysctx,
                            LONG cpus, volatile LONG *number) {
    (void)context; (void)sysctx; (void)number;
    if (!system) final_transition(2, cpus);
    /* This previously vacant registration leaves the Windows reset fallback
       responsible for OS mode and for any failed driver transition. */
    return STATUS_NOT_SUPPORTED;
}

int wp_n5_arm(ULONG minor) {
    STATE_REGISTRATION entry;
    NOTIFICATION note = { notification, NULL };
    NTSTATUS status;
    (void)minor;
    RtlZeroMemory(&entry, sizeof(entry));
    entry.type=Nt5Reset; entry.enter=reset;
    status=ZwPowerInformation((POWER_INFORMATION_LEVEL)RegisterNotification, &note, sizeof(note), NULL, 0);
    if (!NT_SUCCESS(status)) { trace("N5 notification registration refused\n"); return 0; }
    status=ZwPowerInformation((POWER_INFORMATION_LEVEL)RegisterStateHandler, &entry, sizeof(entry), NULL, 0);
    if (!NT_SUCCESS(status)) { trace("N5 reset registration refused\n"); return 0; }
    ready=1;
    trace("N5 power manager registered off and reset\n");
    return 1;
}

void wp_n5_latch(void) {
    KIRQL irql;
    KeAcquireSpinLock(&owner_lock, &irql);
    final_owner=owner; closing=1;
    KeReleaseSpinLock(&owner_lock, irql);
}
NTSTATUS wp_n5_set(ULONG value) {
    KIRQL irql; NTSTATUS status=STATUS_SUCCESS;
    if (value>1) return STATUS_INVALID_PARAMETER;
    KeAcquireSpinLock(&owner_lock, &irql);
    if (closing) status=STATUS_SHUTDOWN_IN_PROGRESS;
    else if (!ready && value) status=STATUS_NOT_SUPPORTED;
    else owner=value;
    KeReleaseSpinLock(&owner_lock, irql);
    return status;
}
ULONG wp_n5_state(void) { return (ready?0x100:0)|owner; }
