#include <windows.h>
#include <dos.h>
#include "OSNAME.H"
#include "ICONUI.H"
#include "PNLINK.H"
#include "OWN16.H"
#include "DOSINFO.H"
UINT pn_exec(LPCSTR command);
BOOL pn_icons(HWND,HINSTANCE,LPCSTR,BOOL);
#if defined(PN_WIN1) || defined(PN_WIN2)
/* Win1/2 export the original four-byte ExitWindows entry at USER ordinal 2. */
BOOL FAR PASCAL OldExitWindows(UINT,UINT);
#define ExitWindows OldExitWindows
#endif
static HINSTANCE instance;
static HWND panel;
static HBRUSH face;
static char status[400];
static unsigned api_ver;
static unsigned pending;
static unsigned batteryicon=5,acicon=6;
static HWND buttons[4],osradio,drvradio,ownertext;
static unsigned owner;
static char markerpath[144];
static BOOL supervised;
static char statepath[144];
static BOOL installed;
static unsigned acpirev=0xffff,fadtrev,fadtminor,capflags;
static BOOL session(unsigned action,BOOL startup){
 HFILE f;static struct pn_state state;unsigned n;
 if(!statepath[0]){
  if(!GetModuleFileName(instance,statepath,sizeof(statepath)))return FALSE;
  n=lstrlen(statepath);while(n&&statepath[n-1]!='\\'&&statepath[n-1]!=':')n--;
  if(n>125)return FALSE;lstrcpy(statepath+n,PN_STATE);
 }
 f=_lopen(statepath,OF_READWRITE);if(f==HFILE_ERROR)return FALSE;
 if(_lread(f,(LPSTR)&state,sizeof(state))!=sizeof(state)||!pn_valid(&state)){_lclose(f);return FALSE;}
 if(!startup&&state.ready!=1){_lclose(f);return FALSE;}
 if(startup){owner=state.owner;acpirev=state.acpi_rev;fadtrev=state.fadt_rev;fadtminor=state.fadt_minor;capflags=state.cap_flags;}
 state.ready=1;state.action=action;state.owner=(unsigned short)owner;_llseek(f,0,0);
 n=_lwrite(f,(LPSTR)&state,sizeof(state));if(_lclose(f)==HFILE_ERROR)return FALSE;return n==sizeof(state);
}
/* Only a recognized installation record may be modified. A portable
   supervised session keeps its choice in this session only. */
static BOOL save_owner(unsigned mode){
 struct wp_pref16 pref;HFILE f;char prefix[8];UINT n;BOOL ok;
 if(!installed)return TRUE;
 f=_lopen(markerpath,OF_READWRITE);if(f==HFILE_ERROR)return FALSE;
 ok=_lread(f,prefix,8)==8 && prefix[0]=='W' && prefix[1]=='P' &&
    prefix[2]=='I' && prefix[3]=='N' && prefix[4]=='S' &&
    prefix[5]=='T' && prefix[6]=='1' && prefix[7]=='0';
 if(ok)ok=_llseek(f,WP_PREF_POS,0)==WP_PREF_POS &&
     _lread(f,(LPSTR)&pref,sizeof(pref))==sizeof(pref) && wp_pref_ok(&pref);
 if(ok){
  wp_pref16(&pref,mode);
  ok=_llseek(f,WP_PREF_POS,0)==WP_PREF_POS &&
     _lwrite(f,(LPSTR)&pref,sizeof(pref))==sizeof(pref);
 }
 if(_lclose(f)==HFILE_ERROR)ok=FALSE;
 if(!ok)return FALSE;
 f=_lopen(markerpath,OF_READ);if(f==HFILE_ERROR)return FALSE;
 n=0;if(_llseek(f,WP_PREF_POS,0)==WP_PREF_POS)n=_lread(f,(LPSTR)&pref,sizeof(pref));
 _lclose(f);return n==sizeof(pref)&&wp_pref_ok(&pref)&&pref.value==mode;
}
static void radios(void){
 SendMessage(osradio,BM_SETCHECK,!owner,0);SendMessage(drvradio,BM_SETCHECK,owner!=0,0);
}
static BOOL icons(HWND h,BOOL remove){
 static char directory[144],marker[160];unsigned n;HFILE f;OFSTRUCT of;
 if(LOBYTE(LOWORD(GetVersion()))<3||!installed)return FALSE;
 lstrcpy(directory,statepath);n=lstrlen(directory);while(n&&directory[n-1]!='\\')n--;
 if(!n)return FALSE;directory[n-1]=0;lstrcpy(marker,directory);lstrcat(marker,"\\PNICONS.ID");
 if(!remove){f=_lopen(marker,OF_READ);if(f!=HFILE_ERROR){_lclose(f);return TRUE;}}
 if(remove){
  BOOL ok=pn_icons(h,instance,directory,TRUE);
  /* A partial DDE removal must not suppress recreation after a veto. */
  OpenFile(marker,&of,OF_DELETE);return ok;
 }
 if(!pn_icons(h,instance,directory,FALSE))return FALSE;
 f=_lcreat(marker,0);if(f!=HFILE_ERROR){_lwrite(f,"PNICONS5",8);_lclose(f);}
 return TRUE;
}
static unsigned buttonicon(unsigned id){return id==101?(pending==3?2:(pending==2?4:3)):(id==102?(pending?2:4):(id==103?11:7));}
/* Windows 2.x has no BS_OWNERDRAW. A small window class provides the same
   keyboard/mouse behavior and shared artwork without that control style. */
long FAR PASCAL __export ButtonProc(HWND h,UINT m,WPARAM w,LPARAM l) {
 switch(m){
 case WM_PAINT:{
  PAINTSTRUCT ps;DRAWITEMSTRUCT d;unsigned id=GetWindowWord(h,GWW_ID);
  d.CtlType=ODT_BUTTON;d.CtlID=id;d.itemID=0;d.itemAction=ODA_DRAWENTIRE;
  d.itemState=(GetFocus()==h?ODS_FOCUS:0)|(GetWindowWord(h,0)?ODS_SELECTED:0)|(!IsWindowEnabled(h)?ODS_DISABLED:0);
  d.hwndItem=h;d.hDC=BeginPaint(h,&ps);GetClientRect(h,&d.rcItem);
  pn_button(&d,instance,buttonicon(id),(HFONT)GetStockObject(SYSTEM_FONT),face);
  EndPaint(h,&ps);return 0;
 }
 case WM_SETFOCUS:case WM_KILLFOCUS:InvalidateRect(h,0,TRUE);return 0;
 case WM_LBUTTONDOWN:SetFocus(h);SetCapture(h);SetWindowWord(h,0,1);InvalidateRect(h,0,TRUE);return 0;
 case WM_LBUTTONUP:{
  RECT r;POINT p;int pressed=GetWindowWord(h,0);
  SetWindowWord(h,0,0);ReleaseCapture();InvalidateRect(h,0,TRUE);
  p.x=(short)LOWORD(l);p.y=(short)HIWORD(l);GetClientRect(h,&r);
  if(pressed&&PtInRect(&r,p))SendMessage(GetParent(h),WM_COMMAND,GetWindowWord(h,GWW_ID),0);
  return 0;
 }
 case WM_KEYDOWN:
  if(w==VK_ESCAPE&&pending){SendMessage(GetParent(h),WM_COMMAND,102,0);return 0;}
  if(w==VK_SPACE){SetWindowWord(h,0,1);InvalidateRect(h,0,TRUE);return 0;}
  if(w==VK_RETURN){SendMessage(GetParent(h),WM_COMMAND,GetWindowWord(h,GWW_ID),0);return 0;}
  if(w==VK_TAB){int i=(int)GetWindowWord(h,GWW_ID)-101;do{i=(i+((GetKeyState(VK_SHIFT)<0)?3:1))%4;}while(!IsWindowEnabled(buttons[i]));SetFocus(buttons[i]);return 0;}
  break;
 case WM_KEYUP:
  if(w==VK_SPACE&&GetWindowWord(h,0)){SetWindowWord(h,0,0);InvalidateRect(h,0,TRUE);SendMessage(GetParent(h),WM_COMMAND,GetWindowWord(h,GWW_ID),0);return 0;}
  break;
 }
 return DefWindowProc(h,m,w,l);
}
/* GetVersion on Windows 1.01 returns 1.0. The installed Executive's
   version text in WIN100.OVL distinguishes these early maintenance releases.
   OpenFile searches the Windows directory. Reject conflicting version texts. */
static unsigned win1minor(void) {
 OFSTRUCT info;HFILE f;char block[512];unsigned got,i,match=0,minor=0;
 static char prefix[]="Version 1.0";
 f=OpenFile("WIN100.OVL",&info,OF_READ);
 if(f==HFILE_ERROR)return 0;
 while((got=_lread(f,block,sizeof(block)))!=0 && got!=(unsigned)-1){
  for(i=0;i<got;i++){
   char c=block[i];
   if(match<11){if(c==prefix[match])match++;else match=(c=='V');}
   else {
    if(c>='1'&&c<='4'){
     unsigned value=(unsigned)(c-'0');
     if(minor&&minor!=value){_lclose(f);return 0;}
     minor=value;
    }
    match=(c=='V');
   }
  }
 }
 _lclose(f);return minor;
}
/* Windows 3.x installers can share a version number. Read the resources of
   the installed user interface to distinguish the products. */
static BOOL scanfile(LPCSTR name,LPCSTR text,char *after,unsigned aftersize){
 OFSTRUCT info;HFILE f;static char block[512];unsigned got,i,match=0,len=lstrlen(text),kept=0,state=0;char c;
 f=OpenFile(name,&info,OF_READ);if(f==HFILE_ERROR)return FALSE;
 while((got=_lread(f,block,sizeof(block)))!=0&&got!=(unsigned)-1){
  for(i=0;i<got;i++){
   c=block[i];
   if(state==0){
    if(c==text[match]){if(++match==len){state=1;if(!after)goto done;}}
    else match=(c==text[0]);
   }else if(state==1){if(c){if(kept+1>=aftersize)goto done;after[kept++]=c;state=2;}}
   else{if(!c||kept+1>=aftersize)goto done;after[kept++]=c;}
  }
 }
 done:
 _lclose(f);if(after)after[kept]=0;return state!=0;
}
#if !defined(PN_WIN1) && !defined(PN_WIN2)
/* Simplified Chinese Windows 3.2 reports 3.10. Its installed SETUP.INF
   names the release. A minimal installation can also be identified by
   the language/code-page key and fixed file/product versions of SHELL.DLL. */
static BOOL chinese32(void){
 static const unsigned char version[]={0xbd,0x04,0xef,0xfe,0,0,1,0,
  10,0,3,0,153,0,0,0,10,0,3,0,153,0,0,0};
 char path[144],title[32];unsigned char block[512];
 UINT base=GetSystemDirectory(path,sizeof(path));unsigned got,i,matched=0;HFILE f;
 if(!base||base>=sizeof(path)-12)return FALSE;
 if(path[base-1]!='\\')path[base++]='\\';
 lstrcpy(path+base,"SHELL.DLL");
 if(!scanfile(path,"080403A8",0,0))return FALSE;
 lstrcpy(path+base,"SETUP.INF");
 if(GetPrivateProfileString("data","welcome","",title,sizeof(title),path)&&
    !lstrcmpi(title,"Windows 3.2"))return TRUE;
 lstrcpy(path+base,"SHELL.DLL");f=_lopen(path,OF_READ);if(f==HFILE_ERROR)return FALSE;
 while((got=_lread(f,block,sizeof(block)))!=0 && got!=(unsigned)-1){
  for(i=0;i<got;i++){
   if(block[i]==version[matched]){if(++matched==sizeof(version)){_lclose(f);return TRUE;}}
   else matched=(block[i]==version[0]);
  }
 }
 _lclose(f);return FALSE;
}
#endif
static LPCSTR win3name(unsigned minor){
 static LPCSTR detected=0;
 char ver[8];BOOL wfw,eleven;
#if !defined(PN_WIN1) && !defined(PN_WIN2)
 static int china=-1;
 if(minor==20)return "Windows 3.2";
 if(minor==10){if(china<0)china=chinese32();if(china)return "Windows 3.2";}
#endif
 if(minor!=10)return pn_osname(0,3,minor,0,0);
 if(detected)return detected;
 eleven=scanfile("USER.EXE","FileVersion",ver,sizeof(ver))&&!lstrcmp(ver,"3.11");
 /* Retail Windows 3.11 and Workgroups 3.11 ship the same KRNL386.EXE.
    Their shell About dialogs and File Manager product descriptions differ.
    The matching Setup and File Manager exports also survive localization. */
 wfw=scanfile("SHELL.DLL","Windows for Workgroups",0,0) ||
     scanfile("WINFILE.EXE","Windows for Workgroups File Manager",0,0) ||
     (scanfile("WFWSETUP.DLL","WRKGRPSETUP",0,0) &&
      scanfile("WINFILE.EXE","FILEOPENHOOKPROC",0,0));
 if(wfw)detected=eleven?"Windows for Workgroups 3.11":"Windows for Workgroups 3.1";
 else detected=eleven?"Windows 3.11":"Windows 3.1";
 return detected;
}
static void apmtext(void) {
 union REGS in,out; char v[8]; unsigned ver=0;
 in.w.ax=0x5300;in.w.bx=0;int86(0x15,&in,&out);
 {
 DWORD version=GetVersion();unsigned major=LOBYTE(LOWORD(version)),minor=HIBYTE(LOWORD(version));
 api_ver=LOWORD(version);
 if(major==1&&minor==0)minor=win1minor();
#ifdef PN_WIN1
 /* The 1985 Premiere Edition also reports API 1.0. Its Executive is
    split between WIN100.MOD and WIN100.MID instead of the retail OVL. */
 if(major==1&&minor==0&&scanfile("WIN100.MOD","Premiere Edition",0,0)&&
    scanfile("WIN100.MID","MS-DOS Executive",0,0))
  lstrcpy(status,"Windows 1.0 Premiere Edition");
 else
#endif
 lstrcpy(status,(major==1&&minor==0)?"Windows 1.x (API 1.0)":(major==3?win3name(minor):pn_osname(0,major,minor,0,0)));
 {struct pn_dos dos;static char dosname[48];pn_dosinfo(&dos);pn_dosname(&dos,dosname);lstrcat(status," on ");lstrcat(status,dosname);}
 lstrcat(status,"\r\nOS environment: 16-bit | Application: 16-bit\r\n\r\nACPI: ");
 {char acpi[24];
  if(acpirev==0xffff)lstrcat(status,"N/A");
  else{pn_acpitext(acpirev,fadtrev,fadtminor,acpi);lstrcat(status,acpi);}}
 lstrcat(status,"\r\nAPM BIOS version: ");
 }
 if(out.w.cflag || out.w.bx!=0x504d)lstrcat(status,"N/A");
 else {ver=out.w.ax;pn_apmtext(ver,v);lstrcat(status,v);}
 lstrcat(status,"\r\n\r\nBattery: ");
 in.w.ax=0x530a;in.w.bx=1;in.w.cx=0;int86(0x15,&in,&out);batteryicon=5;acicon=6;
 if(out.w.cflag)lstrcat(status,"N/A");
 else if(out.h.bl==0x80||(ver>=0x101&&out.h.ch!=255&&(out.h.ch&0x80))){lstrcat(status,"Not present");batteryicon=8;}
 else if(out.h.cl<=100){
  unsigned pct=out.h.cl;char number[5];unsigned n=0;
  if(pct==100)number[n++]='1';
  if(pct>=10)number[n++]='0'+((pct/10)%10);
  number[n++]='0'+pct%10;number[n++]='%';number[n]=0;lstrcat(status,number);
  if(out.h.bl==3){lstrcat(status," (charging)");batteryicon=9;}
  else if(out.h.bl==2)lstrcat(status," (critical)");
  else if(out.h.bl==1)lstrcat(status," (low)");
 }else lstrcat(status,"N/A");
 lstrcat(status,"\r\nAC power: ");
 if(out.w.cflag||out.h.bh==255)lstrcat(status,"N/A");
 else if(out.h.bh==1)lstrcat(status,"Online");
 else if(out.h.bh==0){lstrcat(status,"Offline");acicon=10;}
 else if(out.h.bh==2)lstrcat(status,"Backup power");
 else lstrcat(status,"N/A");
 lstrcat(status,"\r\n\r\n");
 if(!supervised)lstrcat(status,"Start Windows using WPWRDOS for power control.");
 else if(!owner)lstrcat(status,"Shutdown owner: Operating system");
 else lstrcat(status,(capflags&1)?"Shutdown owner: WINPOWER DOS/ACPI-first":"Shutdown owner: WINPOWER DOS/APM");

}
long FAR PASCAL __export PanelProc(HWND h,UINT m,WPARAM w,LPARAM l){
 if(m==WM_PAINT){
  PAINTSTRUCT ps;TEXTMETRIC tm;HDC dc=BeginPaint(h,&ps);unsigned i=0,start=0;int y=0;
  GetTextMetrics(dc,&tm);SetBkMode(dc,TRANSPARENT);SetTextColor(dc,RGB(0,0,0));
  while(status[i]){
   if(status[i]=='\r'||status[i]=='\n'){
    TextOut(dc,0,y,status+start,i-start);y+=tm.tmHeight+tm.tmExternalLeading;
    if(status[i]=='\r'&&status[i+1]=='\n')i++;start=++i;
   }else i++;
  }
  if(i>start)TextOut(dc,0,y,status+start,i-start);
  EndPaint(h,&ps);return 0;
 }
 return DefWindowProc(h,m,w,l);
}
static void confirm(HWND h,unsigned action){
 pending=action;
 EnableWindow(osradio,supervised&&!action);EnableWindow(drvradio,supervised&&!action);
 ShowWindow(ownertext,action?SW_HIDE:SW_SHOWNORMAL);
 ShowWindow(osradio,action?SW_HIDE:SW_SHOWNORMAL);ShowWindow(drvradio,action?SW_HIDE:SW_SHOWNORMAL);
 SetWindowText(buttons[0],action==3?"Uninstall":(action==2?"Restart":"Power off"));
 SetWindowText(buttons[1],action?"Cancel":"Restart");
 EnableWindow(buttons[2],!action);EnableWindow(buttons[3],!action);
 ShowWindow(buttons[2],action?SW_HIDE:SW_SHOWNORMAL);ShowWindow(buttons[3],action?SW_HIDE:SW_SHOWNORMAL);
 if(action){
  lstrcpy(status,action==3?"Uninstall WINPOWER and end Windows?":(action==1?"Power off this computer?":"Restart this computer?"));
  lstrcat(status,"\r\n\r\nSave your work before confirming.\r\nWindows will ask applications to close.");
  if(!owner&&action!=3)lstrcat(status,"\r\n\r\nWindows controls this action and may return to DOS.");
  else lstrcat(status,"\r\n\r\nWINPOWER acts after Windows exits.");
 }else apmtext();
 InvalidateRect(panel,0,TRUE);InvalidateRect(h,0,TRUE);
 InvalidateRect(buttons[0],0,TRUE);InvalidateRect(buttons[1],0,TRUE);
 SetFocus(buttons[action?1:0]);
 if(action&&LOBYTE(LOWORD(GetVersion()))==1){
  SetActiveWindow(h);PostMessage(h,WM_SYSCOMMAND,SC_MAXIMIZE,0L);
 }
}
long FAR PASCAL __export WindowProc(HWND h,UINT m,WPARAM w,LPARAM l) {
 switch(m){
 case WM_CREATE:
  face=CreateSolidBrush(LOBYTE(LOWORD(GetVersion()))<3?RGB(255,255,255):RGB(192,192,192));
  CreateWindow("STATIC","WINPOWER - Power Center",WS_CHILD|WS_VISIBLE,58,16,340,24,h,0,instance,0);
  panel=CreateWindow("PNPANEL","",WS_CHILD|WS_VISIBLE,40,46,406,164,h,0,instance,0);
  buttons[0]=CreateWindow("PNBUTTON","Power off",WS_CHILD|WS_VISIBLE|WS_TABSTOP,12,250,116,28,h,(HMENU)101,instance,0);
  buttons[1]=CreateWindow("PNBUTTON","Restart",WS_CHILD|WS_VISIBLE|WS_TABSTOP,134,250,108,28,h,(HMENU)102,instance,0);
  buttons[2]=CreateWindow("PNBUTTON","Refresh",WS_CHILD|WS_VISIBLE|WS_TABSTOP,248,250,100,28,h,(HMENU)103,instance,0);
  buttons[3]=CreateWindow("PNBUTTON","About",WS_CHILD|WS_VISIBLE|WS_TABSTOP,354,250,78,28,h,(HMENU)104,instance,0);
  ownertext=CreateWindow("STATIC","Control",WS_CHILD|WS_VISIBLE,12,221,59,20,h,0,instance,0);
  osradio=CreateWindow("BUTTON","OS",WS_CHILD|WS_VISIBLE|WS_GROUP|WS_TABSTOP|BS_RADIOBUTTON,79,218,70,23,h,(HMENU)105,instance,0);
  drvradio=CreateWindow("BUTTON","WINPOWER driver",WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_RADIOBUTTON,162,218,192,23,h,(HMENU)106,instance,0);
  supervised=session(0,TRUE);
  {char marker[144];unsigned n=lstrlen(statepath);HFILE f;
   lstrcpy(marker,statepath);while(n&&marker[n-1]!='\\')n--;lstrcpy(marker+n,"WINPWR16.ID");
   lstrcpy(markerpath,marker);f=_lopen(marker,OF_READ);installed=f!=HFILE_ERROR;if(installed)_lclose(f);
  }
  radios();EnableWindow(osradio,supervised);EnableWindow(drvradio,supervised);
  EnableWindow(buttons[0],supervised);EnableWindow(buttons[1],supervised);
  apmtext();InvalidateRect(panel,0,TRUE);
  if(installed&&LOBYTE(LOWORD(GetVersion()))>=3)SetTimer(h,5,3000,0);return 0;
 case WM_TIMER:if(w==5){KillTimer(h,5);icons(h,FALSE);}return 0;
 case WM_DRAWITEM: {
  LPDRAWITEMSTRUCT d=(LPDRAWITEMSTRUCT)l;
  if(d->CtlType==ODT_BUTTON){pn_button(d,instance,buttonicon(d->CtlID),(HFONT)GetStockObject(SYSTEM_FONT),face);return TRUE;}
  break;
 }
 case WM_PAINT: {
  PAINTSTRUCT ps;TEXTMETRIC tm;HDC dc=BeginPaint(h,&ps);int line;
  GetTextMetrics(dc,&tm);line=tm.tmHeight+tm.tmExternalLeading;
  pn_pixel(dc,1,16,10,32);if(!pending){pn_pixel(dc,batteryicon,16,46+6*line,16);pn_pixel(dc,acicon,16,46+7*line,16);}
  EndPaint(h,&ps);return 0;
 }
 case WM_KEYDOWN:if(w==VK_TAB){SetFocus(buttons[supervised?0:2]);return 0;}break;
 case WM_COMMAND:
  if((w==105||w==106)&&supervised&&!pending){
   unsigned previous=owner,mode=w==106;
   if(save_owner(mode)){
    owner=mode;
    if(!session(0,FALSE)){owner=previous;save_owner(previous);MessageBox(h,"Could not update this Windows session.","WINPOWER",MB_OK);}
   }else MessageBox(h,"Could not verify the installed owner preference.","WINPOWER",MB_OK);
   radios();apmtext();InvalidateRect(panel,0,TRUE);return 0;
  }
  if(w==103){apmtext();InvalidateRect(panel,0,TRUE);}
  if((w==101||w==102)&&supervised){
   if(!pending)confirm(h,w==101?1:2);
   else if(w==102)confirm(h,0);
   else {
    if(!session(pending,FALSE))MessageBox(h,"Cannot update the DOS supervisor.","WINPOWER",MB_OK|MB_ICONEXCLAMATION);
    else {
     BOOL removing=pending==3;
     if(removing)icons(h,TRUE);
     /* EW_REBOOTSYSTEM is a Windows 3.1+ contract. Earlier Windows
        versions return to their host DOS when OS owns an end-session. */
     if(!ExitWindows(!owner&&pending==2&&LOBYTE(api_ver)==3&&HIBYTE(api_ver)>=10?0x43:0,0)){session(0,FALSE);confirm(h,0);if(removing)icons(h,FALSE);MessageBox(h,"Windows did not end the session.","WINPOWER",MB_OK|MB_ICONEXCLAMATION);}
    }
   }
  }
  if(w==104)MessageBox(h,"WINPOWER 1.0 - Windows and DOS power control.","About WINPOWER",MB_OK);
  return 0;
 case WM_USER+5:
  if(installed&&supervised)confirm(h,3);
  else MessageBox(h,"No supervised installation was found.","WINPOWER",MB_OK);
  return 0;
 case WM_ENDSESSION:
  if(!w&&pending){BOOL removing=pending==3;session(0,FALSE);confirm(h,0);if(removing)icons(h,FALSE);}
  else if(w&&!owner&&pending==2&&LOBYTE(api_ver)==3&&HIBYTE(api_ver)>=10){
   /* A native reboot may bypass the waiting DOS parent. Release its
      handshaken session record only after Windows commits the restart. */
   OFSTRUCT of;OpenFile(statepath,&of,OF_DELETE);
  }
  return 0;
 case WM_QUERYENDSESSION:return TRUE;
 case WM_DESTROY:DeleteObject(face);PostQuitMessage(0);return 0;
 }
 return DefWindowProc(h,m,w,l);
}
int PASCAL WinMain(HINSTANCE h,HINSTANCE prev,LPSTR cmd,int show) {
 WNDCLASS c;HWND win;MSG msg;FARPROC thunk,button_thunk,panel_thunk;
 (void)show;instance=h;
 win=0;
#ifdef PN_UNINST
 win=FindWindow(0,"WINPOWER");
#else
 if(prev)win=FindWindow(0,"WINPOWER");
#endif
 if(win){ShowWindow(win,SW_SHOWNORMAL);SetActiveWindow(win);
#ifdef PN_UNINST
  PostMessage(win,WM_USER+5,0,0);
#endif
  return 0;
 }
 thunk=MakeProcInstance((FARPROC)WindowProc,h);
 button_thunk=MakeProcInstance((FARPROC)ButtonProc,h);
 panel_thunk=MakeProcInstance((FARPROC)PanelProc,h);
 if(!prev){
  c.style=0;c.lpfnWndProc=(WNDPROC)thunk;c.cbClsExtra=0;c.cbWndExtra=0;c.hInstance=h;
  c.hIcon=LOBYTE(LOWORD(GetVersion()))<3?0:LoadIcon(h,MAKEINTRESOURCE(
#ifdef PN_UNINST
  2
#else
  1
#endif
  ));c.hCursor=LoadCursor(0,IDC_ARROW);
  /* Win1 needs a real brush handle, not the later COLOR_xxx+1 shortcut. */
  c.hbrBackground=(HBRUSH)GetStockObject(WHITE_BRUSH);c.lpszMenuName=0;c.lpszClassName="WINPOWER";
  if(!RegisterClass(&c))return 1;
  c.lpfnWndProc=(WNDPROC)button_thunk;c.cbWndExtra=2;c.hIcon=0;c.lpszClassName="PNBUTTON";
  if(!RegisterClass(&c))return 1;
  c.lpfnWndProc=(WNDPROC)panel_thunk;c.cbWndExtra=0;c.lpszClassName="PNPANEL";
  if(!RegisterClass(&c))return 1;
 }
 win=CreateWindow("WINPOWER","WINPOWER",WS_OVERLAPPEDWINDOW,20,20,460,330,0,0,h,0);
 if(!win)return 2;ShowWindow(win,SW_SHOWNORMAL);UpdateWindow(win);
#ifdef PN_UNINST
 PostMessage(win,WM_USER+5,0,0);
#else
 if(cmd[0]=='/'&&cmd[1]=='R'&&cmd[2]=='U'&&cmd[3]=='N'&&cmd[4]==' '){
  if(pn_exec(cmd+5)<32)MessageBox(win,"The requested application could not be started.","WINPOWER",MB_OK);
 }
#endif
 while(GetMessage(&msg,0,0,0)){
  if(!pending && supervised && msg.message==WM_SYSKEYDOWN && (msg.wParam=='O'||msg.wParam=='D')){
   SendMessage(win,WM_COMMAND,msg.wParam=='O'?105:106,0);continue;
  }
  if(!pending&&supervised&&msg.message==WM_KEYDOWN&&msg.wParam==VK_TAB){
   HWND tab[6];int i,back=GetKeyState(VK_SHIFT)<0;
   tab[0]=buttons[0];tab[1]=buttons[1];tab[2]=buttons[2];tab[3]=buttons[3];tab[4]=osradio;tab[5]=drvradio;
   for(i=0;i<6;i++)if(GetFocus()==tab[i])break;
   SetFocus(tab[i==6?0:(i+(back?5:1))%6]);continue;
  }
  TranslateMessage(&msg);DispatchMessage(&msg);
 }
 FreeProcInstance(panel_thunk);FreeProcInstance(button_thunk);FreeProcInstance(thunk);return msg.wParam;
}
