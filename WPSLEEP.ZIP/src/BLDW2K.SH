#!/bin/sh
set -eu
cd "$(dirname "$0")"
: "${DDK_ROOT:=/usr}"
i686-w64-mingw32-gcc -x c -march=i486 -Os -Wall -Wextra -Werror -Wno-misleading-indentation \
 -nostdlib -ffreestanding -fno-stack-protector -I. -I"$DDK_ROOT/i686-w64-mingw32/include/ddk" \
 -D_WIN32_WINNT=0x0502 -DNTDDI_VERSION=0x05020000 -DNTDDI_WINVISTA=0x06000000 \
 -DWP_2000 -DPN_AML -DPN_NT5_RANGES -shared PN5HOOK.C W2K/N5HAND.C W2K/N5SCAN.C S5.C ACPI.C PWRSEQ.C AML.C NTAML.C NTAPM.C \
 -Wl,--entry,_DriverEntry@8,--subsystem,native:5.0,--image-base,0x10000 \
 -o ../bin/2KXP/W2KHOOK.SYS -lntoskrnl -lhal
