/* Standalone DOS standby and suspend through a real-mode APM BIOS. */
#include <stdio.h>
#include <string.h>
#include <dos.h>
#include "APMSLEEP.H"

unsigned __cdecl pn_cpu(void);
unsigned __cdecl wp_apmreal(void);

static int in_windows(void)
{
    union REGS in, out;
    memset(&in, 0, sizeof(in));
    in.w.ax = 0x1600; int86(0x2f, &in, &out);
    if (out.h.al && out.h.al != 0x80) return 1;
    in.w.ax = 0x4680; int86(0x2f, &in, &out);
    if (!out.w.ax) return 1;
    in.w.ax = 0x160a; int86(0x2f, &in, &out);
    return !out.w.ax;
}
static int bios(unsigned ax, unsigned bx, unsigned cx, struct wp_apm_result *r)
{
    union REGS in, out;
    memset(&in, 0, sizeof(in));
    in.w.ax = ax; in.w.bx = bx; in.w.cx = cx;
    int86(0x15, &in, &out);
    r->ax = out.w.ax; r->bx = out.w.bx; r->cx = out.w.cx;
    return !out.w.cflag;
}
int main(int argc, char **argv)
{
    static const char *const result[] = {
        "The BIOS returned from the request. Check the display and keyboard after wake.",
        "APM BIOS unavailable.", "The BIOS declined a new APM connection.",
        "Unsupported APM version response.", "The BIOS does not advertise this power state.",
        "The BIOS declined the operation.", "The BIOS could not restore its previous configuration."
    };
    unsigned state;
    enum wp_apm_status status;
    union REGS in, out;
    puts("WINPOWER DOS standby and suspend 1.0");
    if (argc < 2 || argc > 3 || (argc == 3 && stricmp(argv[2], "/Y")) ||
        (stricmp(argv[1], "/STANDBY") && stricmp(argv[1], "/SUSPEND"))) {
        puts("Usage: WPSLEEP /STANDBY or /SUSPEND, optionally followed by /Y."); return 1;
    }
    if (in_windows() || !pn_cpu() || !wp_apmreal()) {
        puts("Run this utility from standalone real-mode DOS on a 386 or newer processor."); return 2;
    }
    if (argc == 2) {
        int c;
        printf("Put this DOS session to sleep? Type Y to confirm: "); fflush(stdout);
        c = getchar(); if (c != 'y' && c != 'Y') return 1;
    }
    state = !stricmp(argv[1], "/STANDBY") ? 1 : 2;
    fflush(stdout); memset(&in, 0, sizeof(in)); in.h.ah = 0x0d;
    int86(0x21, &in, &out);
    status = wp_apm_sleep(state, bios);
    puts(result[status]);
    return status == WP_RETURNED ? 0 : 3;
}
