#ifndef WINPOWER_NTDDE_H
#define WINPOWER_NTDDE_H
#include <windows.h>
BOOL nt_group(BOOL remove,const char *app,const char *uninst);
#ifdef PNNT_PACKAGE
void nt_group_ini(const char *path);
#endif
int nt_group_status(unsigned *owned,unsigned *other);
unsigned nt_groupnotice(void);
#endif
