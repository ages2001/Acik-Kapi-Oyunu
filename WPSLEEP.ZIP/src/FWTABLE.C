#include "FWTABLE.H"
static unsigned long word32(const unsigned char *p){
 return (unsigned long)p[0]|((unsigned long)p[1]<<8)|
        ((unsigned long)p[2]<<16)|((unsigned long)p[3]<<24);
}
void wp_fw_clear(struct wp_fwtable *info){
 unsigned i;if(!info)return;
 for(i=0;i<sizeof(*info);i++)((unsigned char*)info)[i]=0;
}
int wp_fadt(const unsigned char *data,unsigned long size,struct wp_fwtable *info){
 unsigned long length,i,minimum=36;unsigned revision,sum=0;
 wp_fw_clear(info);
 if(!info||!data||size<36||size>WP_FADT_MAX)return 0;
 if(data[0]!='F'||data[1]!='A'||data[2]!='C'||data[3]!='P')return 0;
 length=word32(data+4);revision=data[8];
 if(length!=size||!revision)return 0;
 /* Known FADT revisions have defined minimum layouts. Unknown revisions
    expose validated header metadata only, not guessed field semantics. */
 if(revision==1)minimum=116;
 else if(revision==2)minimum=132;
 else if(revision==3||revision==4)minimum=244;
 else if(revision==5)minimum=268;
 else if(revision==6)minimum=276;
 if(length<minimum)return 0;
 for(i=0;i<length;i++)sum=(sum+data[i])&255;
 if(sum)return 0;
 info->table_length=length;info->revision=revision;
 if(revision>=1&&revision<=6){
  info->flags_valid=1;info->flags=word32(data+112);
  info->capabilities_valid=1;
  if(revision>=2)info->reset_register=(info->flags&0x400UL)!=0;
  if(revision>=5){
   info->minor_valid=1;info->minor_revision=data[131];
   info->hardware_reduced=(info->flags&0x100000UL)!=0;
   info->low_power_s0=(info->flags&0x200000UL)!=0;
  }
 }
 return 1;
}
