#include "FWVER.H"
/* NT4 uniprocessor research shim. Unsupported kernel IAT interception.
   Not installed by SETUP. No port access in IRP_MJ_SHUTDOWN.
   Once armed, the shim cannot unload; a reboot restores the original IAT. */
#include <ntddk.h>
#include "LEGCTRL.H"
#include "S5.H"
#include "PWRSEQ.H"
#include "ACPI.H"
#ifdef PN_AML
#include "NTAML.H"
#include "NTAPM.H"
#endif
NTSYSAPI NTSTATUS NTAPI ZwQuerySystemInformation(ULONG,PVOID,ULONG,PULONG);
__declspec(dllimport) VOID NTAPI HalReturnToFirmware(ULONG);
extern __declspec(dllimport) CCHAR KeNumberProcessors;
typedef struct {PVOID section,mapped,base;ULONG size,flags;USHORT load,init,count,name;UCHAR path[256];} MODULE;
typedef struct {ULONG count;MODULE item[1];} MODULES;
typedef VOID (NTAPI *RETURNFN)(ULONG);
static PUNICODE_STRING servicekey;
static void mark(ULONG value){OBJECT_ATTRIBUTES a;UNICODE_STRING n;HANDLE k;
 InitializeObjectAttributes(&a,servicekey,OBJ_CASE_INSENSITIVE,0,0);
 if(NT_SUCCESS(ZwOpenKey(&k,KEY_SET_VALUE,&a))){RtlInitUnicodeString(&n,L"Stage");ZwSetValueKey(k,&n,0,REG_DWORD,&value,sizeof(value));ZwClose(k);}}
static RETURNFN original;
static struct pn_acpi firmware;
static volatile LONG shutdown_seen;
static ULONG status[8];
static ULONG *iat;
static UNICODE_STRING linkname;
static unsigned get16(void *arg,unsigned port){USHORT value;(void)arg;__asm__ volatile("inw %w1,%0":"=a"(value):"d"((USHORT)port));return value;}
static void put16(void *arg,unsigned port,unsigned value){(void)arg;__asm__ volatile("outw %0,%w1"::"a"((USHORT)value),"d"((USHORT)port));}
static void put8(void *arg,unsigned port,unsigned value){(void)arg;__asm__ volatile("outb %0,%w1"::"a"((UCHAR)value),"d"((USHORT)port));}
static void waitio(void *arg,unsigned ticks){unsigned i;(void)arg;for(i=0;i<ticks*55;i++)KeStallExecutionProcessor(1000);}
#ifdef PN_AML
static const struct pn_io ports={0,get16,put16,put8,waitio,pn_ntaml_prepare,pn_ntreg_write,pn_ntreg_read16};
#else
static const struct pn_io ports={0,get16,put16,put8,waitio,0,0,0};
#endif
static void do_power(ULONG action){
 /* HalHaltRoutine(0)/HalPowerDownRoutine(1) -> power off; ACPI S5 is the
    preferred mechanism and the APM BIOS is the fallback when the machine
    has no ACPI. HalRestart(2)/HalReboot(3) -> hardware reset. */
 if(action==0||action==1){
  if((firmware.off_ok||firmware.reduced)&&pn_s5off(&firmware,&ports)<0)return;
#ifdef PN_AML
  if(pn_apm_available()&&pn_apm_permitted(&firmware,&ports))pn_apm_off();
#endif
 }
 else if(action==2||action==3)pn_reset(&firmware,&ports);  /* reset has universal fallbacks */
}
static VOID NTAPI final_power(ULONG action){
 status[6]=action;
 if(shutdown_seen&&leg_at_shutdown)do_power(action);
 original(action);
}
static int readphys(void *arg,unsigned long address,unsigned char *out,unsigned size){
 PHYSICAL_ADDRESS a;PUCHAR mapped;(void)arg;
 /* Map firmware/ACPI physical memory on demand wherever the ACPI pointers
    lead (Linux acpi_os_map_memory model): RSDP in the low 1 MiB, tables
    wherever the structures reference - commonly a reserved region outside the
    OS RAM map. 4 GiB sanity bound only; no contiguous-RAM assumption, so
    VirtualBox/VMware hole-punched maps read like real hardware. Firmware
    writes stay policed by the NTAML firmware-area rules. */
 if(!size||address<0x400||address>=0xfffff000UL||size>0xfffff000UL-address)return 0;
 a.QuadPart=address;mapped=MmMapIoSpace(a,size,MmNonCached);if(!mapped)return 0;
 RtlCopyMemory(out,mapped,size);MmUnmapIoSpace(mapped,size);return 1;
}
static int discover(void){
 ULONG basic[11],got=0,ebda,p,found=0;UCHAR bytes[36],*work;int ok;
 if(!NT_SUCCESS(ZwQuerySystemInformation(0,basic,sizeof(basic),&got)))return 0;
 /* SYSTEM_BASIC_INFORMATION: HighestPhysicalPage is DWORD 5. */
 if(basic[2]!=4096)return 0;
 if(!readphys(0,0x40e,bytes,2))return 0;ebda=((ULONG)bytes[0]|((ULONG)bytes[1]<<8))<<4;
 if(ebda>=0x400&&ebda<=0x9ffff)for(p=ebda;p+36<=ebda+1024&&p+36<=0x100000;p+=16){
  if(readphys(0,p,bytes,36)&&pn_rsdp(bytes,36)>=0){found=p;break;}
 }
 if(!found)for(p=0xe0000;p<=0x100000-36;p+=16){if(readphys(0,p,bytes,36)&&pn_rsdp(bytes,36)>=0){found=p;break;}}
 if(!found)return 0;
#ifdef PN_AML
 /* Bounded AML: DSDT/SSDT namespace, \_S5 methods and verified
    _PTS/_GTS. Firmware memory writes are limited to areas above RAM. */
 pn_ntaml_pages(basic[5],ebda);
 work=ExAllocatePool(NonPagedPool,262144);if(!work){pn_ntaml_release();return 0;}
 ok=pn_tables(readphys,0,found,&firmware,work,262144);ExFreePool(work);
 if(ok)pn_bindregs(&firmware,pn_ntreg_bind);
 pn_ntaml_done(ok&&firmware.off_ok);
 return ok&&firmware.off_ok;
#else
 work=ExAllocatePool(NonPagedPool,32768);if(!work)return 0;
 ok=pn_tables(readphys,0,found,&firmware,work,32768);ExFreePool(work);if(ok)pn_bindregs(&firmware,0);return ok&&firmware.off_ok;
#endif
}
static int same(const UCHAR *a,const char *b){unsigned i;for(i=0;i<256;i++){unsigned c=a[i],d=(UCHAR)b[i];if(c>='a'&&c<='z')c-=32;if(d>='a'&&d<='z')d-=32;if(c!=d)return 0;if(!c)return 1;}return 0;}
static ULONG *find_iat(void){
 MODULES *mods;ULONG need=0,i,n,rva,size,matches=0,*found=0;PUCHAR base;PUCHAR pe;ULONG offset;
 need=262144;mark(21);
 mods=ExAllocatePool(NonPagedPool,need);if(!mods)return 0;
 if(!NT_SUCCESS(ZwQuerySystemInformation(11,mods,need,&need))){ExFreePool(mods);return 0;}
 mark(22);n=mods->count;if(!n||n>(262144-4)/sizeof(MODULE)||need>262144){ExFreePool(mods);return 0;}
 mark(23);base=mods->item[0].base;size=mods->item[0].size;
 for(i=0;i<n;i++){mods->item[i].path[255]=0;if(mods->item[i].name<256&&same(mods->item[i].path+mods->item[i].name,"ACPI.SYS")){ExFreePool(mods);return 0;}}
 ExFreePool(mods);mark(24);
 if(!base||size<4096||size>0x1000000||!MmIsAddressValid(base))return 0;
 mark(25);if(*(USHORT*)base!=0x5a4d)return 0;offset=*(ULONG*)(base+60);if(offset>2048)return 0;
 mark(26);pe=base+offset;
 if(*(ULONG*)pe!=0x4550||*(USHORT*)(pe+4)!=0x14c||*(USHORT*)(pe+20)<224||*(USHORT*)(pe+24)!=0x10b||*(ULONG*)(pe+116)<=12)return 0;
 mark(27);rva=*(ULONG*)(pe+216);n=*(ULONG*)(pe+220);
 if(!n||n>4096||(rva&3)||(n&3)||rva>=size||n>size-rva)return 0;
 mark(28);for(i=0;i<n;i+=4){ULONG *slot=(ULONG*)(base+rva+i);if(!MmIsAddressValid(slot)||!MmIsAddressValid((PUCHAR)slot+3))return 0;
  if(*slot==(ULONG)original){found=slot;matches++;}
 }
 mark(290+matches);return matches==1?found:0;
}
static int arm(void){
 KIRQL old;ULONG cr0;int ok=0;
 /* NT4 has no supported final-power filter API. Scope is x86 UP only.
    Interrupts are masked for this one aligned IAT pointer store. */
 KeRaiseIrql(HIGH_LEVEL,&old);
 __asm__ volatile("mov %%cr0,%0":"=r"(cr0)::"memory");
 if(*iat==(ULONG)original){
  ULONG writable=cr0&~0x10000UL;
  __asm__ volatile("mov %0,%%cr0"::"r"(writable):"memory");
  *(volatile ULONG*)iat=(ULONG)final_power;
  __asm__ volatile("mov %0,%%cr0"::"r"(cr0):"memory");ok=1;
 }
 KeLowerIrql(old);return ok;
}
static NTSTATUS NTAPI dispatch(PDEVICE_OBJECT dev,PIRP irp){
 PIO_STACK_LOCATION s=IoGetCurrentIrpStackLocation(irp);NTSTATUS st=STATUS_INVALID_DEVICE_REQUEST;ULONG bytes=0;(void)dev;
 if(s->MajorFunction==IRP_MJ_CREATE||s->MajorFunction==IRP_MJ_CLOSE)st=STATUS_SUCCESS;
 else if(s->MajorFunction==IRP_MJ_SHUTDOWN){leg_latch();InterlockedExchange(&shutdown_seen,1);st=STATUS_SUCCESS;}
 else if(s->MajorFunction==IRP_MJ_DEVICE_CONTROL&&s->Parameters.DeviceIoControl.IoControlCode==0x00226000){
  if(s->Parameters.DeviceIoControl.OutputBufferLength<sizeof(status))st=STATUS_BUFFER_TOO_SMALL;
  else{status[5]=shutdown_seen;RtlCopyMemory(irp->AssociatedIrp.SystemBuffer,status,sizeof(status));bytes=sizeof(status);st=STATUS_SUCCESS;}
 }
 else if(s->MajorFunction==IRP_MJ_DEVICE_CONTROL){
  st=leg_control(s->Parameters.DeviceIoControl.IoControlCode,irp->AssociatedIrp.SystemBuffer,
      s->Parameters.DeviceIoControl.InputBufferLength,s->Parameters.DeviceIoControl.OutputBufferLength,&bytes);
 }
 irp->IoStatus.Status=st;irp->IoStatus.Information=bytes;IoCompleteRequest(irp,IO_NO_INCREMENT);return st;
}
static NTSTATUS start_driver(PDRIVER_OBJECT driver,PUNICODE_STRING registry){
 ULONG major,minor,build,i;UNICODE_STRING name;PDEVICE_OBJECT dev;NTSTATUS st;(void)registry;
 KeInitializeSpinLock(&leg_lock);servicekey=registry;mark(10);PsGetVersion(&major,&minor,&build,0);
#ifdef PN_AML
 /* Any NT 4.0 service pack; uniprocessor or multiprocessor kernels. The
    import slot store is one aligned 32-bit write, atomic on every CPU. */
 if(major!=4||minor!=0||build!=1381||KeNumberProcessors<1)return STATUS_NOT_SUPPORTED;
#else
 if(major!=4||minor!=0||build!=1381||KeNumberProcessors!=1)return STATUS_NOT_SUPPORTED;
#endif
 mark(20);original=HalReturnToFirmware;iat=find_iat();if(!iat)return STATUS_NOT_SUPPORTED;
 mark(30);
#ifdef PN_AML
 /* discover() may fail when the machine has no ACPI; that is not fatal
    because an APM BIOS can still provide the power-off. ACPI is preferred. */
 discover();
 if(!firmware.reduced)pn_apm_init();
 if(!firmware.off_ok&&!pn_apm_available())return STATUS_NOT_SUPPORTED;
#else
 if(!discover())return STATUS_NOT_SUPPORTED;
 if(!firmware.off_ok)return STATUS_NOT_SUPPORTED;
#endif
 mark(40);RtlInitUnicodeString(&name,L"\\Device\\PN4LAB");RtlInitUnicodeString(&linkname,L"\\DosDevices\\PN4LAB");
 st=IoCreateDevice(driver,0,&name,FILE_DEVICE_UNKNOWN,FILE_DEVICE_SECURE_OPEN,FALSE,&dev);if(!NT_SUCCESS(st))return st;
 for(i=0;i<=IRP_MJ_MAXIMUM_FUNCTION;i++)driver->MajorFunction[i]=dispatch;
 st=IoCreateSymbolicLink(&linkname,&name);if(!NT_SUCCESS(st)){IoDeleteDevice(dev);return st;}
 st=IoRegisterShutdownNotification(dev);if(!NT_SUCCESS(st)){IoDeleteSymbolicLink(&linkname);IoDeleteDevice(dev);return st;}
 status[0]=7;status[2]=firmware.rsdp_rev;status[3]=firmware.fadt_rev;status[4]=WP_FW_MINOR(firmware.fadt_rev,firmware.fadt_minor)|firmware.off_ok|(firmware.reset_ok<<1);
#ifdef PN_AML
 status[4]|=(pn_ntaml_tables()?4:0)|(pn_ntaml_prepared()?8:0)|(pn_apm_available()?16:0)|((ULONG)KeNumberProcessors<<8);
 status[7]=pn_apm_version();   /* APM BIOS version BCD (0 if unknown) */
#endif
 mark(50);if(!arm()){IoUnregisterShutdownNotification(dev);IoDeleteSymbolicLink(&linkname);IoDeleteDevice(dev);return STATUS_UNSUCCESSFUL;}
 mark(60);status[1]=1;driver->DriverUnload=0;dev->Flags&=~DO_DEVICE_INITIALIZING;return STATUS_SUCCESS;
}

NTSTATUS NTAPI DriverEntry(PDRIVER_OBJECT driver,PUNICODE_STRING registry){
 NTSTATUS result=start_driver(driver,registry);
#ifdef PN_AML
 if(!NT_SUCCESS(result))pn_ntreg_release(&firmware);
#endif
 return result;
}
