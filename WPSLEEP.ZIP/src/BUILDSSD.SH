#!/bin/sh
# Isolated static DSDT/SSDT DOS qualification utility. Keeps PNACPI unchanged.
set -eu
: "${WATCOM:?Set WATCOM to the Open Watcom 1.9 directory}"
cd "$(dirname "$0")"
export INCLUDE="$WATCOM/h"
export PATH="$WATCOM/binl:$PATH"
run() { if [ -n "${WIN16_RUN:-}" ]; then "$WIN16_RUN" "$@"; else "$@"; fi; }
mkdir -p ../BIN/WPWRDOS ../TEST/TMPSSD
trap 'rm -f ../TEST/TMPSSD/*.OBJ; rmdir ../TEST/TMPSSD' EXIT HUP INT TERM
run "$WATCOM/binl/wasm" -fo=../TEST/TMPSSD/BIOREAD.OBJ BIOREAD.ASM
for name in ACPI S5 PWRSEQ ACPIDOS PNACPI; do
 run "$WATCOM/binl/wcc" -bt=dos -ml -0 -os -we -dPN_MULTI_S5 -fo=../TEST/TMPSSD/$name.OBJ $name.C
done
run "$WATCOM/binl/wlink" system dos option stack=8192 name ../BIN/WPWRDOS/WPS5DOS.EXE file ../TEST/TMPSSD/PNACPI.OBJ,../TEST/TMPSSD/ACPI.OBJ,../TEST/TMPSSD/S5.OBJ,../TEST/TMPSSD/PWRSEQ.OBJ,../TEST/TMPSSD/ACPIDOS.OBJ,../TEST/TMPSSD/BIOREAD.OBJ
