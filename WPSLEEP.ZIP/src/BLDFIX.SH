#!/bin/sh
# Rebuild the changed handoff components with MinGW-w64 and Open Watcom 1.9.
# Run on a case-sensitive Linux filesystem. DDK_ROOT defaults to /usr.
set -eu
cd "$(dirname "$0")"
mkdir -p ../TEST
cp ../test/FIXVXD.PY ../test/PNREG.C ../test/MEMTEST.C ../test/INTTEST.C ../TEST/
sh BUILDUI.SH gui
sh BLDHAND.SH
sh BUILDP9.SH
sh BUILD9S.SH setup
for arch in i686 x86_64; do
 if [ "$arch" = i686 ]; then out=X86; entry=_WinMainCRTStartup@0; ver=4.0; cpu=-march=i486;
 else out=X64; entry=WinMainCRTStartup; ver=5.2; cpu=; fi
 "$arch-w64-mingw32-gcc" -x c $cpu -Os -Wall -Wextra -Werror -Wno-misleading-indentation \
  -fno-builtin -fno-stack-protector -nostdlib -mwindows HNDLOAD.C \
  -Wl,--entry,"$entry",--subsystem,windows:$ver \
  -o ../BIN/WINPWRNT/$out/HNDLOAD.EXE -lkernel32 -luser32 -ladvapi32
done
cp ../BIN/WINPWRNT/X86/WINPWRNT.EXE ../bin/2KXP/WINPWRNT.EXE
cp ../BIN/WINPWRNT/X64/WINPWRNT.EXE ../bin/XPAMD64/WINPWRNT.EXE
cp ../BIN/WINPWRNT/X86/WINPWRNT.EXE ../bin/WIN9X/WINPWR9X.EXE
cp ../BIN/WINPWRNT/NT5LAB/PN5HOOK.SYS ../bin/2KXP/
cp ../BIN/WINPWRNT/NT5X64/PN5HOOK.SYS ../bin/XPAMD64/
cp ../BIN/WINPWRNT/X86/HNDLOAD.EXE ../bin/2KXP/
cp ../BIN/WINPWRNT/X64/HNDLOAD.EXE ../bin/XPAMD64/
cp ../BIN/WINPWR9X/LAB/PN9HOOK.VXD ../bin/WIN9X/
cp ../BIN/WINPWR9X/LAB/SETUP.EXE ../bin/WIN9X/
sh BLDLEG.SH
sh BUILD16.SH
for target in WIN1 WIN2 WIN3 WIN386; do
 mkdir -p ../bin/$target
 cp ../BIN/WINPWR16/$target/*.EXE ../bin/$target/
done
cp ../BIN/WPWRDOS/PNINST.EXE ../BIN/WPWRDOS/WPWRDOS.EXE ../bin/DOS/
sh BLDMOD.SH
sh BLDW2K.SH
sh BLDSET5.SH
echo 'Changed handoff components built. Re-run runtime qualification before distribution.'
