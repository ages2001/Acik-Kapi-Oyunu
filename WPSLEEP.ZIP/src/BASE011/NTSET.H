#ifndef WINPOWER_NTSET_H
#define WINPOWER_NTSET_H
#include <windows.h>
BOOL nt_preflight(void);
BOOL nt_stage(const char *self,const char *folder);
BOOL nt_install(const char *folder);
BOOL nt_abort(const char *folder);
BOOL nt_remove(const char *folder,BOOL external);
BOOL nt_finish(const char *folder);
BOOL nt_target(char *folder);
const char *nt_reason(void);
void nt_error(const char *step,DWORD error);
#endif
