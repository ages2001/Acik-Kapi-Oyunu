WINPOWER SOURCE AND BUILD NOTES - 0.10

All project paths use uppercase 8.3 names. Project text is English.
Run shell scripts on a Unix host; uppercase .C files are compiled as C.
The complete authored source of every supplied executable is included.
Microsoft SDKs, operating-system media and third-party compilers are not
part of the project ZIP. Initial installed OS images are delivered separately.

TOOLS

Python 3; a host C compiler with ASan/UBSan; GNU binutils; i686 and x86_64
MinGW-w64 GCC/binutils with DDK headers/import libraries; Open Watcom 1.9.
Add cross-compilers to PATH. DDK_ROOT defaults to /usr, with DDK headers
under $DDK_ROOT/i686-w64-mingw32/include/ddk and the matching x64 path.
For Watcom, set WATCOM to its directory. Set WIN16_RUN to qemu-i386 only
if the host cannot execute Watcom's 32-bit Linux tools directly.

BUILDS (run from SRC)

sh BUILD.SH    Base NT x86/x64 GUI, setup, read-only diagnostics, DOS APM.
sh BUILD3.SH   NT3 ABI read-only diagnostic driver, query and cleanup tools.
sh BUILDP3.SH  NT3 final-power experimental driver, loader and registry tool.
sh BUILD4.SH   NT4 final-power experimental driver and loader.
sh BUILDUI.SH  NT x86/x64 GUI/setup and generic Win9x GUI/setup package.
sh BUILDGUI.SH GUI-only refresh; preserves tested drivers and installers.
sh BUILDP9.SH  Win95/98 experimental VxD and query/loader helper.
sh BUILD9S.SH  Win9x VxD package installer, GUI copy and installation audit.
sh BUILD16.SH Win1, Win2, Win3 GUI/uninstaller and DOS supervisor/setup.
sh ../TEST/CHECK.SH  Host tests with address/undefined-behavior sanitizers.
python3 ../TEST/VERIFY.PY --static  Paths, branding, headers and legacy ABI.
python3 PACK.PY OUTPUT_DIR [IMAGE_DIR]  Verify and package without rebuilding.

BUILDUI precedes BUILD9S so the VxD package gets the current GUI.
BUILD16 generates ICO resources and indexed artwork using ICON.PY. BUILD.SH
also regenerates artwork. After any rebuild, previous runtime hashes must
be requalified; full VERIFY.PY intentionally rejects changed binaries.

The NT x86 GUI uses i386 instructions and subsystem 3.10; x64 uses 5.2.
It has no external C runtime DLL. Newer APIs are resolved dynamically.
The Win16 packages have distinct NE headers and exit imports: Windows 1/2
use the original USER.2 ABI, Windows 3 uses USER.7. Windows 1 additionally
uses WIN1FIX.ASM and indexed icon drawing. These compatibility measures do
not establish support on every Windows build or every firmware platform.

MAIN SOURCE MAP

WINPOWER.C   NT/Win9x ANSI GUI, status refresh and OS shutdown requests.
OSINFO.C     Dynamic version, native architecture and power-status queries.
OSNAME.C     Release-name mapping, including version and build boundaries.
ICONUI.C     Background-matched icons and custom buttons.
ICON.PY      Original icon and indexed-artwork generator.
PNW16.C      Win16 GUI/uninstaller, APM display and session-exit handshake.
WPWRDOS.C    DOS supervisor, ACPI-first power off, APM fallback and reset.
PNLINK.H     Fixed session protocol shared by the GUI, supervisor and tests.
PNINST.C     DOS install/remove, original-loader backup and file ownership.
PNDDE.C      Program Manager DDE; compatible Win1/2 stubs.
PNEXEC.C     Original KERNEL.45 application command forwarding.
ACPIDOS.C    E820, BIOS extended-memory reads and DOS port-I/O transport.
BIOREAD.ASM  Guarded real-mode BIOS calls and CPU capability detection.
PNACPI.C     Standalone DOS ACPI probe and confirmed power/reset commands.
APM.S        Standalone real-mode BIOS APM diagnostic/power-off tool.
S5.C         Bounded ACPI tables and restricted static AML namespace parser.
PWRSEQ.C     Checked ACPI mode, PM1 and reset-register sequencing.
ACPI.C       Bounded RSDP validation.
SETUP.C      NT/Win9x GUI installer, uninstall, DDE and shell links.
PN9SET.C     Persistent Win9x VxD package transaction and rollback.
PN9INI.C     Byte-preserving, bounded SYSTEM.INI entry insertion/removal.
PN9HOOK.C    Guarded Win95/98 native final-power VxD experiment.
PN9DDB.ASM   VxD entry points and control/exit forwarding.
PN3HOOK.C    Guarded NT3 dynamic final-I/O call interception experiment.
SHUTFIND.C   Bounded unique shutdown-call pattern search.
INTENT.C     Validated Winlogon caller, image and off/restart intent checks.
MEMMAP.C     Bounded NT resource descriptor / memory-span validation.
PN3TEST.C    Temporary NT3 laboratory load/status helper.
PN4HOOK.C    Dynamic NT4 kernel HAL-import interception experiment.
PN4TEST.C    Temporary NT4 helper and backed-up Winlogon setting restore.
PNINFO.C     Read-only firmware diagnostic driver; no power transition.
PNCLEAN.C    Guarded stopped diagnostic-service cleanup.
POLICY.C     Owner eligibility/default model; handoff is not implemented.

PNINFO exposes a fixed read-only IOCTL, not arbitrary memory/port writes.
NT3, generic x86 and x64 diagnostic files must not be mixed. The binaries
are unsigned. Read TEST/NT3LAB.TXT, NT4LAB.TXT and WIN9LAB.TXT before using
a power experiment. Full AML, active OS ACPI handoff and general protected
mode APM are unfinished. STATUS.TXT is the complete scope and limitations.

BUILDNT.SH builds the separate LEGACY automatic-start package and audit.
It copies the existing qualified GUI and NT3/NT4 drivers unchanged.
NTPWR/NTSET implement bounded installation state, SHA-256 checks, SCM
startup and recoverable removal. NTREG preserves exact registry values;
NTDDE preserves unrelated Program Manager items. See TEST/NTSTART.TXT.
