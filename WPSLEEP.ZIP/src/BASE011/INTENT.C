/* NT3 Winlogon first calls NtShutdownSystem(NoReboot) for BOTH off and
   restart. The Boolean passed to IoShutdownSystem does not encode intent.
   Read only the known caller's saved context; never change user memory. */
#include "INTENT.H"
static unsigned long dword(const unsigned char *p) {
 return (unsigned long)p[0]|((unsigned long)p[1]<<8)|
        ((unsigned long)p[2]<<16)|((unsigned long)p[3]<<24);
}
static int same(const unsigned char *a,const unsigned char *b,unsigned n) {
 unsigned i;for(i=0;i<n;i++)if(a[i]!=b[i])return 0;return 1;
}
unsigned pn_intent(unsigned kernel,const struct pn_userregs *r,pn_usread read,void *arg) {
 unsigned char b[96];unsigned long base,time,size,sum,pe,ret,flags;
 static const unsigned char syscall[]={0x8d,0x54,0x24,4,0xcd,0x2e,0xc2,4,0};
 static const unsigned char call31[]={0x6a,0,0xe8,0x0e,0x4b,0,0,0x56,0xe8,0x18,0x7f,0xff,0xff,0x83,0xe3,2};
 static const unsigned char call351[]={0x6a,0,0xff,0x15,0x9c,0x15,0x16,2,0x53,0xe8,0xb0,0xf7,0xff,0xff};
 static const unsigned char call350[]={0x6a,0,0xff,0x15,0x48,0xcd,0x1e,2,0x53,0xe8,0xa0,0x44,0,0};
 static const unsigned char alternate[]={0x6a,0,0xff,0x15,0x9c,0x15,0x16,2,0x6a,0,0x6a,0x13};
 if(kernel==31){base=0x2440000;time=0x2de1235c;size=0x30000;sum=0x36c2a;}
 else if(kernel==350){base=0x21c0000;time=0x2fce5340;size=0x3c000;sum=0x3d37d;}
 else if(kernel==351){base=0x2160000;time=0x3457cc1d;size=0x2c000;sum=0x30f1e;}
 else return 0;
 if(!read(arg,base,b,64)||b[0]!='M'||b[1]!='Z')return 0;
 pe=dword(b+60);if(pe<64||pe>2048)return 0;
 if(!read(arg,base+pe,b,96)||dword(b)!=0x4550||b[4]!=0x4c||b[5]!=1||
    dword(b+8)!=time||dword(b+80)!=size||dword(b+88)!=sum)return 0;
 if(r->eip<11||!read(arg,r->eip-11,b,14)||b[0]!=0xb8||
    dword(b+1)!=(kernel==31?0x9cUL:(kernel==350?0xa5UL:0xadUL))||!same(b+5,syscall,sizeof(syscall)))return 0;
 if(!read(arg,r->esp,b,8)||dword(b+4)!=0)return 0;
 ret=dword(b);
 if(kernel==31) {
  if(ret!=base+0xadf2||!read(arg,ret-7,b,sizeof(call31))||!same(b,call31,sizeof(call31)))return 0;
  flags=r->ebx;
 } else if(kernel==350) {
  if(ret!=base+0x1c5f||!read(arg,ret-8,b,sizeof(call350))||!same(b,call350,sizeof(call350)))return 0;
  flags=r->edi;
 } else if(ret==base+0x43a3) {
  if(!read(arg,ret-8,b,sizeof(call351))||!same(b,call351,sizeof(call351))||
     r->edi>0x7ffeffabUL||!read(arg,r->edi+0x54,b,4))return 0;
  flags=dword(b);
 } else if(ret==base+0x42f7) {
  if(!read(arg,ret-8,b,sizeof(alternate))||!same(b,alternate,sizeof(alternate)))return 0;
  return r->ebx==11?2:((r->ebx==5||r->ebx==10)?1:0);
 } else return 0;
 if(flags&2)return 2;
 return (flags&(kernel==31?1:9))?1:0;
}
