/* WINPOWER DOS APM power utility. GAS, real-mode .COM, 80386 or later. */
.code16
.global _start
.text
_start:
    push %cs
    pop %ds
    mov $banner,%dx
    call puts
    /* Refuse Windows standard/enhanced-mode DOS sessions. */
    mov $0x1600,%ax
    int $0x2f
    test %al,%al
    jz checkstd
    cmp $0x80,%al
    jne inwin
checkstd:
    mov $0x4680,%ax
    int $0x2f
    test %ax,%ax
    jz inwin
    mov $0x160a,%ax
    int $0x2f
    test %ax,%ax
    jz inwin
    mov $0x5300,%ax
    xor %bx,%bx
    int $0x15
    jc absent
    cmp $0x504d,%bx
    jne absent
    mov %ax,version
    mov $vermsg,%dx
    call puts
    mov version+1,%al
    call hex
    mov $'.',%dl
    call putc
    mov version,%al
    call hex
    mov $newline,%dx
    call puts
    xor %cx,%cx
    mov 0x80,%cl
    mov $0x81,%si
skip:
    test %cx,%cx
    jz done
    lodsb
    dec %cx
    cmp $' ',%al
    je skip
    cmp $'/',%al
    jne usage
    cmp $3,%cx
    jb usage
    lodsb
    and $0xdf,%al
    cmp $'O',%al
    jne usage
    lodsb
    and $0xdf,%al
    cmp $'F',%al
    jne usage
    lodsb
    and $0xdf,%al
    cmp $'F',%al
    jne usage
    sub $3,%cx
trailing:
    jcxz confirm
    lodsb
    dec %cx
    cmp $' ',%al
    jne usage
    jmp trailing
confirm:
    mov $prompt,%dx
    call puts
    mov $1,%ah
    int $0x21
    and $0xdf,%al
    cmp $'Y',%al
    jne done
    mov $0x5301,%ax
    xor %bx,%bx
    int $0x15
    jc fail
    /* Real-mode APM 1.0 connection; global power-off is a 1.0 operation. */
    mov $0x5308,%ax
    mov $1,%bx
    mov $1,%cx
    int $0x15
    jc disconnect
    mov $0x0d,%ah
    int $0x21
    mov $0x5307,%ax
    mov $1,%bx
    mov $3,%cx
    int $0x15
    /* A successful power-off never returns. */
disconnect:
    mov $0x5304,%ax
    xor %bx,%bx
    int $0x15
fail:
    mov $failed,%dx
    call puts
    mov $0x4c01,%ax
    int $0x21
absent:
    mov $noapm,%dx
    call puts
    jmp done
inwin:
    mov $winmsg,%dx
    call puts
    mov $0x4c02,%ax
    int $0x21
usage:
    mov $help,%dx
    call puts
done:
    mov $0x4c00,%ax
    int $0x21
puts:
    mov $9,%ah
    int $0x21
    ret
putc:
    mov $2,%ah
    int $0x21
    ret
hex:
    push %ax
    shr $4,%al
    call digit
    pop %ax
    and $15,%al
digit:
    and $15,%al
    add $'0',%al
    cmp $'9',%al
    jbe emit
    add $7,%al
emit:
    mov %al,%dl
    call putc
    ret
version: .word 0
banner: .asciz "WINPOWER APM utility 0.1 - Standalone DOS only\r\n$"
vermsg: .asciz "APM BIOS version: $"
newline: .asciz "\r\n$"
noapm: .asciz "APM: N/A\r\n$"
winmsg: .asciz "Refused: exit Windows completely before running this utility.\r\n$"
help: .asciz "Usage: APM (status) or APM /OFF (power off)\r\n$"
prompt: .asciz "Power off this PC? Close all programs first. Type Y to confirm: $"
failed: .asciz "\r\nAPM power off failed or returned. No reset was attempted.\r\n$"
