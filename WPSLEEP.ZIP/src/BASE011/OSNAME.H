#ifndef PN_OSNAME_H
#define PN_OSNAME_H
/* platform: 0=Win16, 1=Win9x, 2=NT. product: 1=workstation, 2/3=server. */
const char *pn_osname(unsigned platform,unsigned major,unsigned minor,unsigned long build,unsigned product);
#endif
