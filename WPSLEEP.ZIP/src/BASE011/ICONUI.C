#include "ICONUI.H"
#ifndef _WIN32
#include "ICON16.H"
void pn_pixel(HDC dc,unsigned icon,int x,int y,int size){
 int a,b;unsigned c;unsigned oldpalette=LOBYTE(LOWORD(GetVersion()))<3;
 if(icon<1||icon>10)return;
 for(b=0;b<size;b++)for(a=0;a<size;a++){
  c=pn_pixels[icon-1][(b*32/size)*32+(a*32/size)];
  if(c!=255)SetPixel(dc,x+a,y+b,(oldpalette&&c==8)?RGB(0,0,0):pn_colors[c]);
 }
}
#endif
void pn_icon(HDC dc,HICON icon,int x,int y,int size,HBRUSH background){
 HDC mem;HBITMAP bmp,old;RECT r;int previous;
 if(!icon)return;
 mem=CreateCompatibleDC(dc);if(!mem)return;
 bmp=CreateCompatibleBitmap(dc,32,32);if(!bmp){DeleteDC(mem);return;}
 old=(HBITMAP)SelectObject(mem,bmp);r.left=r.top=0;r.right=r.bottom=32;
 FillRect(mem,&r,background);DrawIcon(mem,0,0,icon);
 previous=SetStretchBltMode(dc,COLORONCOLOR);
 StretchBlt(dc,x,y,size,size,mem,0,0,32,32,SRCCOPY);SetStretchBltMode(dc,previous);
 SelectObject(mem,old);DeleteObject(bmp);DeleteDC(mem);
}
void pn_button(LPDRAWITEMSTRUCT d,HINSTANCE instance,unsigned icon,HFONT font,HBRUSH background){
 RECT r=d->rcItem,edge,text;HBRUSH light,dark;HFONT old;int shift=(d->itemState&ODS_SELECTED)?1:0;char caption[64];
#ifdef _WIN32
 light=CreateSolidBrush(GetSysColor(shift?COLOR_BTNSHADOW:COLOR_BTNHIGHLIGHT));
 dark=CreateSolidBrush(GetSysColor(shift?COLOR_BTNHIGHLIGHT:COLOR_BTNSHADOW));
#else
 /* The button color indexes were added after Windows 2.x. */
 {COLORREF shadow=LOBYTE(LOWORD(GetVersion()))<3?RGB(0,0,0):RGB(128,128,128);
 light=CreateSolidBrush(shift?shadow:RGB(255,255,255));
 dark=CreateSolidBrush(shift?RGB(255,255,255):shadow);}
#endif
 FillRect(d->hDC,&r,background);
 edge=r;edge.bottom=edge.top+2;FillRect(d->hDC,&edge,light);
 edge=r;edge.right=edge.left+2;FillRect(d->hDC,&edge,light);
 edge=r;edge.top=edge.bottom-2;FillRect(d->hDC,&edge,dark);
 edge=r;edge.left=edge.right-2;FillRect(d->hDC,&edge,dark);
 DeleteObject(light);DeleteObject(dark);
#ifdef _WIN32
 pn_icon(d->hDC,LoadIcon(instance,MAKEINTRESOURCE(icon)),r.left+7+shift,r.top+(r.bottom-r.top-20)/2+shift,20,background);
#else
 (void)instance;
 pn_pixel(d->hDC,icon,r.left+7+shift,r.top+(r.bottom-r.top-20)/2+shift,20);
#endif
 text=r;text.left+=34+shift;text.right-=4;text.top+=shift;
 GetWindowText(d->hwndItem,caption,sizeof(caption));old=(HFONT)SelectObject(d->hDC,font);
 SetBkMode(d->hDC,TRANSPARENT);
#ifdef _WIN32
 SetTextColor(d->hDC,GetSysColor((d->itemState&ODS_DISABLED)?COLOR_GRAYTEXT:COLOR_BTNTEXT));
#else
 SetTextColor(d->hDC,((d->itemState&ODS_DISABLED)&&LOBYTE(LOWORD(GetVersion()))>=3)?RGB(128,128,128):RGB(0,0,0));
#endif
 DrawText(d->hDC,caption,-1,&text,DT_CENTER|DT_VCENTER|DT_SINGLELINE);
 SelectObject(d->hDC,old);
 if(d->itemState&ODS_FOCUS){
  r.left+=4;r.top+=4;r.right-=4;r.bottom-=4;
#ifdef _WIN32
  DrawFocusRect(d->hDC,&r);
#else
  /* USER.466 (DrawFocusRect) is absent from Windows 1.x. */
  {int p;for(p=r.left;p<r.right;p+=2){SetPixel(d->hDC,p,r.top,RGB(0,0,0));SetPixel(d->hDC,p,r.bottom-1,RGB(0,0,0));}
   for(p=r.top;p<r.bottom;p+=2){SetPixel(d->hDC,r.left,p,RGB(0,0,0));SetPixel(d->hDC,r.right-1,p,RGB(0,0,0));}}
#endif
 }
}
