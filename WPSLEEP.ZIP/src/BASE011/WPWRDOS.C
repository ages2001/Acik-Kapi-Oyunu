/* DOS session supervisor. Firmware is touched only after WIN.COM returns. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <process.h>
#include <dos.h>
#include <i86.h>
#include <conio.h>
#include "PNLINK.H"
#include "ACPIDOS.H"
static struct pn_acpi firmware;
static char statepath[144],guipath[144],winpath[144],helper[144],launch[128];
static void trace(const char *message){
 char path[144],head[32];FILE *f;size_t n;static const char magic[]="WINPOWER power trace 0.10\r\n";
 strcpy(path,guipath);strcpy(strrchr(path,'\\')+1,"PNPOWER.LOG");
 f=fopen(path,"rb");if(f){n=fread(head,1,sizeof(magic)-1,f);fclose(f);if(n!=sizeof(magic)-1||memcmp(head,magic,n))return;}
 else {f=fopen(path,"wb");if(!f)return;fwrite(magic,1,sizeof(magic)-1,f);if(fclose(f))return;}
 f=fopen(path,"ab");if(!f)return;fputs(message,f);fputs("\r\n",f);fclose(f);
}
static int bios(unsigned ax,unsigned bx,unsigned cx,union REGS *out){
 union REGS in;memset(&in,0,sizeof(in));in.w.ax=ax;in.w.bx=bx;in.w.cx=cx;
 int86(0x15,&in,out);return !out->w.cflag;
}
static int inwindows(void){
 union REGS in,out;memset(&in,0,sizeof(in));in.w.ax=0x1600;int86(0x2f,&in,&out);
 if(out.h.al && out.h.al!=0x80)return 1;
 in.w.ax=0x4680;int86(0x2f,&in,&out);if(!out.w.ax)return 1;
 in.w.ax=0x160a;int86(0x2f,&in,&out);return !out.w.ax;
}
static void flushdos(void){union REGS in,out;memset(&in,0,sizeof(in));in.h.ah=0x0d;intdos(&in,&out);}
static int poweroff(void){
 union REGS out;unsigned version,negotiated=0x100;
 if(!bios(0x5300,0,0,&out)||out.w.bx!=0x504d){puts("APM is unavailable. No power registers were written.");return 1;}
 version=out.w.ax;
 if(!bios(0x5301,0,0,&out)){puts("APM connection failed. Power off was not attempted.");return 1;}
 if(version>=0x102&&bios(0x530e,0,0x102,&out))negotiated=0x102;
 else if(version>=0x101&&bios(0x530e,0,0x101,&out))negotiated=0x101;
 if(!bios(0x5308,1,1,&out))goto fail;
 if(negotiated>=0x101&&!bios(0x530f,1,1,&out))goto fail;
 flushdos();bios(0x5307,1,3,&out);
 fail: bios(0x5304,0,0,&out);puts("APM power off failed or returned. The PC remains on.");return 1;
}
static int restart(void){
 unsigned wait;void (__far *reset)(void)=(void (__far *)(void))MK_FP(0xffff,0);
 flushdos();_disable();
 *(unsigned __far *)MK_FP(0x40,0x72)=0x1234;
 for(wait=0;wait<65535U;wait++)if(!(inp(0x64)&2))break;
 outp(0x64,0xfe);
 for(wait=0;wait<65535U;wait++)inp(0x64);
 reset();_enable();puts("Firmware reset returned unexpectedly.");return 1;
}
static int command_tail(int wrapped){
 char __far *tail=(char __far *)MK_FP(_psp,0x80);char raw[128];unsigned i,n=(unsigned char)*tail;
 char *p,*start;unsigned used=0,len;
 if(n>126)return 0;for(i=0;i<n;i++)raw[i]=tail[i+1];raw[n]=0;p=raw;
 if(!wrapped){
  while(*p==' ')p++;
  if(*p=='"'){p++;while(*p&&*p!='"')p++;if(*p)p++;}
  else while(*p&&*p!=' ')p++;
 }
 while(*p==' ')p++;
 while(*p=='/'){
  start=p;while(*p&&*p!=' ')p++;len=(unsigned)(p-start);
  if(used+len+1>=sizeof(launch))return 0;
  memcpy(launch+used,start,len);used+=len;launch[used++]=' ';
  while(*p==' ')p++;
 }
 len=strlen(guipath);
 if(used+len+1>=sizeof(launch))return 0;
 memcpy(launch+used,guipath,len);used+=len;
 if(*p){
  len=strlen(p);if(used+6+len>=sizeof(launch))return 0;
  memcpy(launch+used," /RUN ",6);used+=6;memcpy(launch+used,p,len);used+=len;
 }
 launch[used]=0;return 1;
}
int main(int argc,char **argv){
 FILE *f;struct pn_state state;char *slash;int rc,wrapped;unsigned action;
 puts("WINPOWER DOS session supervisor 0.10");
 if(inwindows()){puts("Exit Windows before starting WPWRDOS.");return 1;}
 if(!_fullpath(guipath,argv[0],sizeof(guipath))){puts("Cannot locate WPWRDOS.");return 1;}
 slash=strrchr(guipath,'\\');if(!slash || (slash-guipath)>125)return 1;
 wrapped=!stricmp(slash+1,"WIN.COM");
 if(!wrapped&&argc<2){puts("Usage: WPWRDOS C:\\WINDOWS\\WIN.COM [Windows arguments]");return 1;}
 if(wrapped){strcpy(winpath,guipath);strcpy(strrchr(winpath,'\\')+1,"PNWIN.COM");}
 else if(!_fullpath(winpath,argv[1],sizeof(winpath)))return 1;
 strcpy(slash+1,"WINPWR16.EXE");strcpy(statepath,guipath);strcpy(strrchr(statepath,'\\')+1,PN_STATE);
 if(!command_tail(wrapped)){puts("Windows command line is too long. Nothing was started.");return 1;}
 f=fopen(guipath,"rb");if(!f){puts("WINPWR16.EXE is missing beside the supervisor.");return 1;}fclose(f);
 f=fopen(statepath,"rb");if(f){fclose(f);puts("PNSTATE.DAT already exists. A session may still be active.");puts("After a cold boot only, remove that file and try again.");return 1;}
 memset(&state,0,sizeof(state));memcpy(state.magic,PN_MAGIC,8);
 pn_probe(&firmware);state.acpi_rev=firmware.rsdp_rev;state.fadt_rev=firmware.fadt_rev;
 state.fadt_minor=firmware.fadt_minor;state.cap_flags=(firmware.off_ok?1:0)|(firmware.reset_ok?2:0);
 f=fopen(statepath,"wb");if(!f){puts("Cannot create the session state file.");return 1;}
 if(fwrite(&state,1,sizeof(state),f)!=sizeof(state)){fclose(f);remove(statepath);return 1;}
 if(fclose(f)){remove(statepath);return 1;}flushdos();
 puts("Starting Windows. Save work before ending the session.");
 rc=spawnlp(P_WAIT,winpath,winpath,launch,NULL);
 f=fopen(statepath,"rb");if(!f){puts("Session state is missing; no power action.");return 1;}
 if(fread(&state,1,sizeof(state),f)!=sizeof(state))state.ready=0;
 fclose(f);remove(statepath);flushdos();
 action=pn_action(&state,rc);
 if(!action){puts("Windows did not complete a confirmed session; no power action.");return 1;}
 if(inwindows()){puts("Windows is still active; no power action.");return 1;}
 if(action==3){
  if(!wrapped){puts("This session does not have an installed loader to remove.");return 1;}
  strcpy(helper,guipath);strcpy(strrchr(helper,'\\')+1,"PNUNINST.EXE");
  return spawnlp(P_WAIT,helper,helper,"/CLEAN",NULL);
 }
 pn_probe(&firmware);flushdos();
 if(action==2){
  if(firmware.reset_ok){trace("ACPI reset requested");flushdos();puts("Requesting ACPI reset.");pn_acreset(&firmware);}
  trace("Legacy reset requested");flushdos();
  return restart();
 }
 if(firmware.off_ok){
  trace("ACPI S5 requested");flushdos();puts("Requesting ACPI S5 power off.");
  if(pn_acoff(&firmware)<0){trace("ACPI returned; APM blocked");flushdos();puts("ACPI remains active; APM fallback was not attempted.");return 1;}
 }
 trace("APM power off requested");flushdos();puts("Using BIOS APM power off.");return poweroff();
}
