#ifndef PN_ACPIDOS_H
#define PN_ACPIDOS_H
#include "S5.H"
int pn_probe(struct pn_acpi *out);
/* Called only in standalone DOS after all Windows sessions have ended.
   Return 0: unavailable/failed with legacy mode restored; -1: do not fallback. */
int pn_acoff(const struct pn_acpi *info);
int pn_acreset(const struct pn_acpi *info);
#endif
