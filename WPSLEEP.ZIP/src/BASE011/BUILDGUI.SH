#!/bin/sh
# Rebuild only the native GUI; retain tested drivers and installers.
set -eu
cd "$(dirname "$0")"
mkdir -p ../BIN/WINPWRNT/X86 ../BIN/WINPWRNT/X64 ../BIN/WINPWR9X/GUI ../BIN/WINPWR9X/LAB ../TEST
for arch in i686 x86_64; do
 if [ "$arch" = i686 ]; then cpu='-march=i386 -mno-sse -mno-mmx'; out=X86; entry=_WinMainCRTStartup@0; ver=3.10; else cpu=''; out=X64; entry=WinMainCRTStartup; ver=5.2; fi
 "$arch-w64-mingw32-windres" WINPOWER.RC -O coff -o ../TEST/ICON.O
 "$arch-w64-mingw32-gcc" $cpu -x c -Os -Wall -Wextra -Werror -Wno-cast-function-type -fno-builtin -fno-stack-protector -nostdlib -mwindows WINPOWER.C OSINFO.C OSNAME.C ICONUI.C -x none ../TEST/ICON.O -Wl,--entry,"$entry",--subsystem,windows:$ver -o ../BIN/WINPWRNT/$out/WINPWRNT.EXE -luser32 -lkernel32 -lgdi32 -ladvapi32
 printf 'Built native GUI for %s\n' "$out"
done
rm ../TEST/ICON.O
for package in GUI LAB; do cp ../BIN/WINPWRNT/X86/WINPWRNT.EXE ../BIN/WINPWR9X/$package/WINPWR9X.EXE; done
