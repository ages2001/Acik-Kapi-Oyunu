/* User-mode auto-start loader. The kernel backend alone handles final power. */
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include "NTPWR.H"
void *memset(void *p,int c,size_t n){BYTE *q=p;while(n--)*q++=(BYTE)c;return p;}
static SERVICE_STATUS_HANDLE status_handle;
static SERVICE_STATUS state;
static HANDLE stop_event;
static CRITICAL_SECTION state_lock;
static void report(DWORD current,DWORD error){
 EnterCriticalSection(&state_lock);ZeroMemory(&state,sizeof(state));
 state.dwServiceType=SERVICE_WIN32_OWN_PROCESS;state.dwCurrentState=current;
 state.dwControlsAccepted=current==SERVICE_RUNNING?SERVICE_ACCEPT_STOP|SERVICE_ACCEPT_SHUTDOWN:0;
 state.dwWin32ExitCode=error;
 if(current==SERVICE_START_PENDING||current==SERVICE_STOP_PENDING){state.dwCheckPoint=1;state.dwWaitHint=30000;}
 SetServiceStatus(status_handle,&state);LeaveCriticalSection(&state_lock);
}
static void WINAPI control(DWORD code){
 if(code==SERVICE_CONTROL_STOP||code==SERVICE_CONTROL_SHUTDOWN)SetEvent(stop_event);
 else if(code==SERVICE_CONTROL_INTERROGATE){EnterCriticalSection(&state_lock);SetServiceStatus(status_handle,&state);LeaveCriticalSection(&state_lock);}
}
static void WINAPI service_main(DWORD argc,LPSTR *argv){
 char folder[MAX_PATH];DWORD error;(void)argc;(void)argv;
 stop_event=CreateEventA(0,TRUE,FALSE,0);
 status_handle=RegisterServiceCtrlHandlerA(WP_SERVICE,control);
 if(!status_handle){if(stop_event)CloseHandle(stop_event);return;}
 if(!stop_event){report(SERVICE_STOPPED,GetLastError());return;}
 report(SERVICE_START_PENDING,0);
 /* Release the old SCM's serialized automatic-start gate before opening
    its service database to prepare/load the kernel backend. RUNNING here
    describes this loader; Stage 6 and a successful device query establish
    that the power backend is ready. */
 report(SERVICE_RUNNING,0);
 error=wp_ownfolder(folder)?wp_start(folder):ERROR_INVALID_NAME;
 if(!error){
  report(SERVICE_RUNNING,0);WaitForSingleObject(stop_event,INFINITE);
  report(SERVICE_STOP_PENDING,0);
 }
 /* Stopping this loader never unloads an armed kernel shim or cuts power. */
 report(SERVICE_STOPPED,error);CloseHandle(stop_event);stop_event=0;
}
static void inspect(void){
 HKEY meta=0;SC_HANDLE manager,svc;SERVICE_STATUS ss;struct wp_config cfg;
 DWORD error,kind=wp_kind(),starts=0,stage=0,last=0,removing=0,service=0,backend[12],berror;char text[1200];
 ZeroMemory(&cfg,sizeof(cfg));error=RegOpenKeyExA(HKEY_LOCAL_MACHINE,WP_META,0,KEY_QUERY_VALUE,&meta);
 if(!error){error=wp_config(meta,&cfg);if(!error)kind=cfg.kind;
  wp_getnum(meta,"Starts",&starts);wp_getnum(meta,"Stage",&stage);wp_getnum(meta,"LastError",&last);wp_getnum(meta,"Removing",&removing);RegCloseKey(meta);}
 manager=OpenSCManagerA(0,0,SC_MANAGER_CONNECT);
 if(manager){svc=OpenServiceA(manager,WP_SERVICE,SERVICE_QUERY_STATUS);if(svc){if(QueryServiceStatus(svc,&ss))service=ss.dwCurrentState;CloseServiceHandle(svc);}CloseServiceHandle(manager);}
 berror=wp_backend(kind,backend);
 wsprintfA(text,"WINPOWER NT startup service\r\n\r\nInstallation record error: %lu\r\nFolder: %s\r\nService state: %lu (4 = running, 1 = stopped, 0 = absent/unavailable)\r\nStart count: %lu   Stage: %lu   Last error: %lu\r\nRemoval pending: %lu\r\n\r\nBackend query error: %lu\r\nArmed: %lu   RSDP: %lu   FADT: %lu\r\nShutdown seen: %lu\r\n\r\nRead-only status query. No service or setting was changed.\r\nAn armed kernel backend remains resident until restart.",
 error,error?"N/A":cfg.folder,service,starts,stage,last,removing,berror,berror?0:backend[1],berror?0:backend[2],berror?0:backend[3],berror?0:backend[5]);
 MessageBoxA(0,text,"WINPOWER service status",MB_OK|MB_ICONINFORMATION);
}
void WINAPI WinMainCRTStartup(void){
 LPSTR command=GetCommandLineA();SERVICE_TABLE_ENTRYA table[2];DWORD error;
 if(*command=='"'){command++;while(*command&&*command!='"')command++;if(*command)command++;}else while(*command&&*command!=' ')command++;
 while(*command==' ')command++;
 if(!lstrcmpiA(command,"/STATUS")){inspect();ExitProcess(0);}
 if(*command){MessageBoxA(0,"Usage: WINPSVC /STATUS. Automatic startup is managed by Windows Services.","WINPOWER",MB_OK);ExitProcess(1);}
 InitializeCriticalSection(&state_lock);ZeroMemory(table,sizeof(table));table[0].lpServiceName=WP_SERVICE;table[0].lpServiceProc=service_main;
 if(!StartServiceCtrlDispatcherA(table)){error=GetLastError();if(error==ERROR_FAILED_SERVICE_CONTROLLER_CONNECT)inspect();else ExitProcess(error);}
 DeleteCriticalSection(&state_lock);ExitProcess(0);
}
