#include "NTREG.H"
int wp_reg_valid(const struct wp_regvalue *v){
 return v&&v->magic==WP_REG_MAGIC&&v->present<=1&&v->size<=sizeof(v->data)&&
        (v->present||(v->size==0&&v->type==0));
}
int wp_reg_equal(const struct wp_regvalue *a,const struct wp_regvalue *b){
 unsigned i;if(!wp_reg_valid(a)||!wp_reg_valid(b)||a->present!=b->present)return 0;
 if(!a->present)return 1;
 if(a->type!=b->type||a->size!=b->size)return 0;
 for(i=0;i<a->size;i++)if(a->data[i]!=b->data[i])return 0;
 return 1;
}
int wp_reg_restore(const struct wp_regvalue *saved,const struct wp_regvalue *current){
 if(!wp_reg_valid(saved)||!wp_reg_valid(current))return -1;
 if(wp_reg_equal(saved,current))return 0;
 if(current->present&&current->type==1&&current->size==2&&current->data[0]=='1'&&!current->data[1])return 1;
 return 2;
}
