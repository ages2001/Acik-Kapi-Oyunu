#ifndef PN_ICONUI_H
#define PN_ICONUI_H
#include <windows.h>
void pn_icon(HDC dc,HICON icon,int x,int y,int size,HBRUSH background);
void pn_button(LPDRAWITEMSTRUCT item,HINSTANCE instance,unsigned icon,HFONT font,HBRUSH background);
#ifndef _WIN32
void pn_pixel(HDC dc,unsigned icon,int x,int y,int size);
#endif
#endif
