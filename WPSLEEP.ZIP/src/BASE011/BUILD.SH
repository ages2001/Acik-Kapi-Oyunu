#!/bin/sh
set -eu
cd "$(dirname "$0")"
python3 ICON.PY
mkdir -p ../BIN/WINPWRNT/X86 ../BIN/WINPWRNT/X64 ../BIN/WPWRDOS ../TEST
for arch in i686 x86_64; do
 cc=${arch}-w64-mingw32-gcc
 rc=${arch}-w64-mingw32-windres
 if [ "$arch" = i686 ]; then cpu="-march=i386 -mno-sse -mno-mmx"; out=X86; entry=_WinMainCRTStartup@0; ver=3.10; else cpu=""; out=X64; entry=WinMainCRTStartup; ver=5.2; fi
 "$rc" WINPOWER.RC -O coff -o ../BIN/WINPWRNT/$out/ICON.O
 "$cc" $cpu -x c -Os -Wall -Wextra -Wno-cast-function-type -fno-builtin -fno-stack-protector -nostdlib -mwindows WINPOWER.C OSINFO.C OSNAME.C ICONUI.C -x none ../BIN/WINPWRNT/$out/ICON.O -Wl,--entry,"$entry",--subsystem,windows:$ver -o ../BIN/WINPWRNT/$out/WINPWRNT.EXE -luser32 -lkernel32 -lgdi32 -ladvapi32
 "$cc" $cpu -x c -Os -Wall -Wextra -Wno-cast-function-type -fno-builtin -fno-stack-protector -nostdlib -mwindows SETUP.C -x none ../BIN/WINPWRNT/$out/ICON.O -Wl,--entry,"$entry",--subsystem,windows:$ver -o ../BIN/WINPWRNT/$out/SETUP.EXE -luser32 -lkernel32 -ladvapi32 -luuid
 rm ../BIN/WINPWRNT/$out/ICON.O
 if [ "$arch" = i686 ]; then de=_DriverEntry@8; else de=DriverEntry; fi
 "$cc" $cpu -x c -Os -Wall -Wextra -Werror -nostdlib -ffreestanding -fno-stack-protector -I"${DDK_ROOT:-/usr}/$arch-w64-mingw32/include/ddk" -D_WIN32_WINNT=0x0501 -DNTDDI_VERSION=0x05010000 -DNTDDI_WINVISTA=0x06000000 -shared PNINFO.C ACPI.C -Wl,--entry,"$de",--subsystem,native,--image-base,0x10000 -o ../BIN/WINPWRNT/$out/PNINFO.SYS -lntoskrnl
 "$cc" $cpu -x c -Os -Wall -Wextra -fno-builtin -fno-stack-protector -nostdlib -mwindows ../TEST/PNCHECK.C -Wl,--entry,"$entry",--subsystem,windows:$ver -o ../BIN/WINPWRNT/$out/PNCHECK.EXE -lkernel32 -luser32 -ladvapi32

 done
cc -x c -std=c89 -Wall -Wextra -pedantic -fsanitize=address,undefined -I. ACPI.C POLICY.C ../TEST/CORE.C -o ../TEST/CORE
../TEST/CORE
rm ../TEST/CORE

as --32 APM.S -o ../BIN/WPWRDOS/APM.O
ld -m elf_i386 -Ttext 0x100 --oformat binary ../BIN/WPWRDOS/APM.O -o ../BIN/WPWRDOS/APM.COM
rm ../BIN/WPWRDOS/APM.O

cc -x c -std=c89 -Wall -Wextra -pedantic -fsanitize=address,undefined -I. OSNAME.C ../TEST/OSNAME.C -o ../TEST/OSNAME
../TEST/OSNAME
rm ../TEST/OSNAME

cc -x c -std=c89 -Wall -Wextra -pedantic -fsanitize=address,undefined -I. ../TEST/SESSION.C -o ../TEST/SESSION
../TEST/SESSION
rm ../TEST/SESSION

cc -x c -std=c89 -Wall -Wextra -Werror -pedantic -fsanitize=address,undefined -I. S5.C ACPI.C ../TEST/S5TEST.C -o ../TEST/S5TEST
../TEST/S5TEST
cc -x c -std=c89 -Wall -Wextra -Werror -pedantic -DPN_TIMER_INFO -fsanitize=address,undefined -I. S5.C ACPI.C ../TEST/S5TEST.C -o ../TEST/S5TEST
../TEST/S5TEST
rm ../TEST/S5TEST
cc -x c -std=c89 -Wall -Wextra -Werror -pedantic -fsanitize=address,undefined -I. PWRSEQ.C ../TEST/PWRTEST.C -o ../TEST/PWRTEST
../TEST/PWRTEST
rm ../TEST/PWRTEST
