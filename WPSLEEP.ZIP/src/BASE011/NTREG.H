#ifndef WINPOWER_NTREG_H
#define WINPOWER_NTREG_H
struct wp_regvalue { unsigned int magic,type,present,size; unsigned char data[256]; };
#define WP_REG_MAGIC 0x57505231U
int wp_reg_valid(const struct wp_regvalue *v);
int wp_reg_equal(const struct wp_regvalue *a,const struct wp_regvalue *b);
/* 0: already restored, 1: restore saved value, 2: preserve a later edit. */
int wp_reg_restore(const struct wp_regvalue *saved,const struct wp_regvalue *current);
#endif
