#ifndef PN_S5_H
#define PN_S5_H
/* Static ACPI namespace subset. No arbitrary AML execution or port writes. */
typedef int (*pn_read)(void *,unsigned long,unsigned char *,unsigned);
struct pn_acpi {
 unsigned rsdp_rev,fadt_rev,fadt_minor;
 unsigned off_ok,reset_ok,pm1a,pm1b,reset_port,reset_value;
 unsigned sleepa,sleepb,enable,disable;
 unsigned long smi;
#ifdef PN_TIMER_INFO
 unsigned timer_port,timer_bits;
#endif
};
int pn_tables(pn_read read,void *arg,unsigned long rsdp,struct pn_acpi *out,
              unsigned char *work,unsigned capacity);
int pn_s5(const unsigned char *aml,unsigned size,unsigned *a,unsigned *b);
#endif
