Historical minimal Win1 startup experiment.

The main BUILD16.SH now produces the working full Win1 GUI using normal
Open Watcom startup and WIN1FIX.ASM. These earlier minimal-test sources
are retained as development history; they are not used by the build.
No Microsoft SDK binaries are included.
