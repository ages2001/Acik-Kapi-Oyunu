.8086
.model large
extrn INITTASK:far
extrn WAITEVENT:far
extrn INITAPP:far
extrn WINMAIN:far
_NULL segment para public 'BEGDATA'
dw 0,0,5,0,0,0,0,0
_NULL ends
DGROUP group _NULL,_DATA
.data
 db 0
.stack 8192
.code
public PNSTART, _wstart_
_wstart_ label far
PNSTART proc far
 call INITTASK
 or ax,ax
 jz done
 push di
 push si
 push es
 push bx
 push dx
 xor ax,ax
 push ax
 call WAITEVENT
 push di
 call INITAPP
 call WINMAIN
 done:
 mov ah,4ch
 int 21h
PNSTART endp
end PNSTART
