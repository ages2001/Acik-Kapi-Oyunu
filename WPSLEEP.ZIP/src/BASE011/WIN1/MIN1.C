#include <windows.h>
int PASCAL WinMain(HINSTANCE h,HINSTANCE prev,LPSTR cmd,int show){
 HFILE f;
 (void)h;(void)prev;(void)cmd;(void)show;
 f=_lcreat("C:\\MINLOG.TXT",0);_lwrite(f,"entered\r\n",9);_lclose(f);
 MessageBox(0,"WINPOWER startup test","WINPOWER",MB_OK);
 f=_lopen("C:\\MINLOG.TXT",OF_WRITE);_llseek(f,0,2);_lwrite(f,"returned\r\n",10);_lclose(f);
 return 0;
}
