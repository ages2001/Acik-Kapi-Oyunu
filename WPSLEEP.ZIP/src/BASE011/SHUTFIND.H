#ifndef PN_SHUTFIND_H
#define PN_SHUTFIND_H
/* Bounded x86 call-pattern recognition for qualified NT3 images.
   This is not a general disassembler or support for unknown service packs. */
struct pn_shutmatch {
 unsigned long call_rva,target_rva,displacement;
};
typedef int (*pn_execfn)(void *,unsigned long,unsigned long);
int pn_shutfind(const unsigned char *,unsigned long,unsigned long,unsigned,
               pn_execfn,void *,struct pn_shutmatch *);
#endif
