/* SHA-256 for owned-file integrity on NT versions without CryptoAPI. */
#include "SHA256.H"
static const wp_word k[64]={
0x428a2f98U,0x71374491U,0xb5c0fbcfU,0xe9b5dba5U,0x3956c25bU,0x59f111f1U,0x923f82a4U,0xab1c5ed5U,
0xd807aa98U,0x12835b01U,0x243185beU,0x550c7dc3U,0x72be5d74U,0x80deb1feU,0x9bdc06a7U,0xc19bf174U,
0xe49b69c1U,0xefbe4786U,0x0fc19dc6U,0x240ca1ccU,0x2de92c6fU,0x4a7484aaU,0x5cb0a9dcU,0x76f988daU,
0x983e5152U,0xa831c66dU,0xb00327c8U,0xbf597fc7U,0xc6e00bf3U,0xd5a79147U,0x06ca6351U,0x14292967U,
0x27b70a85U,0x2e1b2138U,0x4d2c6dfcU,0x53380d13U,0x650a7354U,0x766a0abbU,0x81c2c92eU,0x92722c85U,
0xa2bfe8a1U,0xa81a664bU,0xc24b8b70U,0xc76c51a3U,0xd192e819U,0xd6990624U,0xf40e3585U,0x106aa070U,
0x19a4c116U,0x1e376c08U,0x2748774cU,0x34b0bcb5U,0x391c0cb3U,0x4ed8aa4aU,0x5b9cca4fU,0x682e6ff3U,
0x748f82eeU,0x78a5636fU,0x84c87814U,0x8cc70208U,0x90befffaU,0xa4506cebU,0xbef9a3f7U,0xc67178f2U};
static wp_word ror(wp_word x,unsigned n){return (x>>n)|(x<<(32-n));}
static void put(unsigned char *p,wp_word x){p[0]=(unsigned char)(x>>24);p[1]=(unsigned char)(x>>16);p[2]=(unsigned char)(x>>8);p[3]=(unsigned char)x;}
static void compress(struct wp_sha256 *s){
 wp_word w[64],a,b,c,d,e,f,g,h,t,u;unsigned i;
 for(i=0;i<16;i++){const unsigned char *p=s->block+i*4;w[i]=((wp_word)p[0]<<24)|((wp_word)p[1]<<16)|((wp_word)p[2]<<8)|p[3];}
 for(i=16;i<64;i++)w[i]=w[i-16]+(ror(w[i-15],7)^ror(w[i-15],18)^(w[i-15]>>3))+w[i-7]+(ror(w[i-2],17)^ror(w[i-2],19)^(w[i-2]>>10));
 a=s->state[0];b=s->state[1];c=s->state[2];d=s->state[3];e=s->state[4];f=s->state[5];g=s->state[6];h=s->state[7];
 for(i=0;i<64;i++){
  t=h+(ror(e,6)^ror(e,11)^ror(e,25))+((e&f)^((~e)&g))+k[i]+w[i];
  u=(ror(a,2)^ror(a,13)^ror(a,22))+((a&b)^(a&c)^(b&c));
  h=g;g=f;f=e;e=d+t;d=c;c=b;b=a;a=t+u;
 }
 s->state[0]+=a;s->state[1]+=b;s->state[2]+=c;s->state[3]+=d;
 s->state[4]+=e;s->state[5]+=f;s->state[6]+=g;s->state[7]+=h;
}
void wp_sha_init(struct wp_sha256 *s){
 static const wp_word initial[8]={0x6a09e667U,0xbb67ae85U,0x3c6ef372U,0xa54ff53aU,0x510e527fU,0x9b05688cU,0x1f83d9abU,0x5be0cd19U};unsigned i;
 for(i=0;i<8;i++){s->state[i]=initial[i];}
 s->low=s->high=s->used=0;
}
void wp_sha_add(struct wp_sha256 *s,const unsigned char *data,unsigned size){
 wp_word before=s->low;unsigned i;s->low+=(wp_word)size;if(s->low<before)s->high++;
 for(i=0;i<size;i++){s->block[s->used++]=data[i];if(s->used==64){compress(s);s->used=0;}}
}
void wp_sha_end(struct wp_sha256 *s,unsigned char digest[32]){
 unsigned i;s->block[s->used++]=0x80;
 if(s->used>56){while(s->used<64)s->block[s->used++]=0;compress(s);s->used=0;}
 while(s->used<56)s->block[s->used++]=0;
 put(s->block+56,(s->high<<3)|(s->low>>29));put(s->block+60,s->low<<3);compress(s);
 for(i=0;i<8;i++)put(digest+i*4,s->state[i]);
}
