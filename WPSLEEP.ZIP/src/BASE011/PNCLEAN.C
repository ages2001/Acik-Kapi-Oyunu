/* Remove only our stopped diagnostic service after an interrupted test. */
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
static void clip(char *out,const char *in,unsigned size) {
 if(!size)return;
 while(--size&&*in)*out++=*in++;
 *out=0;
}
void WINAPI WinMainCRTStartup(void) {
 char path[MAX_PATH],buffer[2048],message[768],actual[128],display[128];
 const char *stored;int mismatch=0;
 QUERY_SERVICE_CONFIGA *config=(QUERY_SERVICE_CONFIGA *)buffer;
 SC_HANDLE manager=0,service=0;SERVICE_STATUS state;
 DWORD needed,error=0;int i;
 GetModuleFileNameA(0,path,sizeof(path));
 for(i=lstrlenA(path)-1;i>=0&&path[i]!='\\';--i){}
 path[i+1]=0;lstrcatA(path,"PNINFO.SYS");
 manager=OpenSCManagerA(0,0,SC_MANAGER_CONNECT);
 if(!manager){error=GetLastError();goto done;}
 service=OpenServiceA(manager,"PNTEST",SERVICE_QUERY_CONFIG|SERVICE_QUERY_STATUS|DELETE);
 if(!service){error=GetLastError();if(error==ERROR_SERVICE_DOES_NOT_EXIST)error=0;goto done;}
 if(!QueryServiceConfigA(service,config,sizeof(buffer),&needed)||
    !QueryServiceStatus(service,&state)){error=GetLastError();goto done;}
 stored=config->lpBinaryPathName;
 if(stored[0]=='\\'&&stored[1]=='?'&&stored[2]=='?'&&stored[3]=='\\')stored+=4;
 else {const char *prefix="\\DosDevices\\";unsigned n;
  for(n=0;prefix[n]&&stored[n]==prefix[n];n++){}
  if(!prefix[n])stored+=n;
 }
 if(config->dwServiceType!=SERVICE_KERNEL_DRIVER||config->dwStartType!=SERVICE_DEMAND_START||
    lstrcmpiA(stored,path)||
    lstrcmpA(config->lpDisplayName,"WINPOWER diagnostic test")){
  clip(actual,config->lpBinaryPathName,sizeof(actual));
  clip(display,config->lpDisplayName,sizeof(display));mismatch=1;
  error=ERROR_INVALID_DATA;goto done;
 }
 if(state.dwCurrentState!=SERVICE_STOPPED){error=ERROR_SERVICE_CANNOT_ACCEPT_CTRL;goto done;}
 if(!DeleteService(service))error=GetLastError();
done:
 if(service)CloseServiceHandle(service);
 if(manager)CloseServiceHandle(manager);
 wsprintfA(message,"Stopped WINPOWER diagnostic service cleanup\r\nError: %lu\r\n\r\nOnly PNTEST with this folder's PNINFO.SYS and the expected\r\ntest configuration can be removed. A running driver is refused.",error);
 if(mismatch)wsprintfA(message+lstrlenA(message),"\r\n\r\nExisting path: %s\r\nExisting display name: %s",actual,display);
 MessageBoxA(0,message,"WINPOWER diagnostic cleanup",MB_OK|(error?MB_ICONEXCLAMATION:MB_ICONINFORMATION));
 ExitProcess(error?1:0);
}
