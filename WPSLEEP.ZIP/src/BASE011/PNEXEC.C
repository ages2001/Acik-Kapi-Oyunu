#include <windows.h>
/* Original Win16 LoadModule parameter block, including DOS command tail. */
struct loadargs { WORD environment; LPSTR tail; WORD FAR *show; DWORD reserved; };
UINT pn_exec(LPCSTR command){
 static char file[128],tail[128];static WORD show[2]={2,SW_SHOWNORMAL};
 static struct loadargs args;unsigned n=0,m=0;char quote=0;
 while(*command==' ')command++;
 if(*command=='"'){quote='"';command++;}
 while(*command&&((quote&&*command!=quote)||(!quote&&*command!=' '))){
  if(n>=sizeof(file)-1)return 2;file[n++]=*command++;
 }
 file[n]=0;if(quote&&*command=='"')command++;
 while(*command==' ')command++;
 while(*command){if(m>=125)return 2;tail[1+m++]=*command++;}
 tail[0]=(char)m;tail[m+1]='\r';tail[m+2]=0;
 args.environment=0;args.tail=tail;args.show=show;args.reserved=0;
 return (UINT)LoadModule(file,&args);
}
