/* NT4 uniprocessor research shim. Unsupported kernel IAT interception.
   Not installed by SETUP. No port access in IRP_MJ_SHUTDOWN.
   Once armed, the shim cannot unload; a reboot restores the original IAT. */
#include <ntddk.h>
#include "S5.H"
#include "PWRSEQ.H"
#include "ACPI.H"
NTSYSAPI NTSTATUS NTAPI ZwQuerySystemInformation(ULONG,PVOID,ULONG,PULONG);
__declspec(dllimport) VOID NTAPI HalReturnToFirmware(ULONG);
extern __declspec(dllimport) CCHAR KeNumberProcessors;
typedef struct {PVOID section,mapped,base;ULONG size,flags;USHORT load,init,count,name;UCHAR path[256];} MODULE;
typedef struct {ULONG count;MODULE item[1];} MODULES;
typedef VOID (NTAPI *RETURNFN)(ULONG);
static PUNICODE_STRING servicekey;
static void mark(ULONG value){OBJECT_ATTRIBUTES a;UNICODE_STRING n;HANDLE k;
 InitializeObjectAttributes(&a,servicekey,OBJ_CASE_INSENSITIVE,0,0);
 if(NT_SUCCESS(ZwOpenKey(&k,KEY_SET_VALUE,&a))){RtlInitUnicodeString(&n,L"Stage");ZwSetValueKey(k,&n,0,REG_DWORD,&value,sizeof(value));ZwClose(k);}}
static RETURNFN original;
static struct pn_acpi firmware;
static volatile LONG shutdown_seen;
static ULONG status[7],physical_limit;
static ULONG *iat;
static UNICODE_STRING linkname;
static unsigned get16(void *arg,unsigned port){USHORT value;(void)arg;__asm__ volatile("inw %w1,%0":"=a"(value):"d"((USHORT)port));return value;}
static void put16(void *arg,unsigned port,unsigned value){(void)arg;__asm__ volatile("outw %0,%w1"::"a"((USHORT)value),"d"((USHORT)port));}
static void put8(void *arg,unsigned port,unsigned value){(void)arg;__asm__ volatile("outb %0,%w1"::"a"((UCHAR)value),"d"((USHORT)port));}
static void waitio(void *arg,unsigned ticks){unsigned i;(void)arg;for(i=0;i<ticks*55;i++)KeStallExecutionProcessor(1000);}
static const struct pn_io ports={0,get16,put16,put8,waitio};
static VOID NTAPI final_power(ULONG action){
 status[6]=action;
 if(shutdown_seen){
  if((action==0||action==1)&&firmware.off_ok)pn_s5off(&firmware,&ports);
  else if((action==2||action==3)&&firmware.reset_ok)pn_reset(&firmware,&ports);
 }
 original(action);
}
static int readphys(void *arg,unsigned long address,unsigned char *out,unsigned size){
 PHYSICAL_ADDRESS a;PUCHAR mapped;(void)arg;
 if(!size||address>0xffffffffUL-size)return 0;
 if(!(address>=0x400&&address+size<=0x100000)&&
    !(address>=0x100000&&address+size<=physical_limit))return 0;
 a.QuadPart=address;mapped=MmMapIoSpace(a,size,MmNonCached);if(!mapped)return 0;
 RtlCopyMemory(out,mapped,size);MmUnmapIoSpace(mapped,size);return 1;
}
static int discover(void){
 ULONG basic[11],got=0,ebda,p,found=0;UCHAR bytes[36],*work;int ok;
 if(!NT_SUCCESS(ZwQuerySystemInformation(0,basic,sizeof(basic),&got)))return 0;
 /* SYSTEM_BASIC_INFORMATION: HighestPhysicalPage is DWORD 5. */
 if(basic[2]!=4096||basic[5]>=0xbff00)return 0;
 physical_limit=(basic[5]+1)*4096+0x100000;
 if(!readphys(0,0x40e,bytes,2))return 0;ebda=((ULONG)bytes[0]|((ULONG)bytes[1]<<8))<<4;
 if(ebda>=0x80000&&ebda<=0x9fc00)for(p=ebda;p<ebda+1024;p+=16){
  if(readphys(0,p,bytes,36)&&pn_rsdp(bytes,36)>=0){found=p;break;}
 }
 if(!found)for(p=0xe0000;p<=0x100000-36;p+=16){if(readphys(0,p,bytes,36)&&pn_rsdp(bytes,36)>=0){found=p;break;}}
 if(!found)return 0;work=ExAllocatePool(NonPagedPool,32768);if(!work)return 0;
 ok=pn_tables(readphys,0,found,&firmware,work,32768);ExFreePool(work);return ok&&firmware.off_ok;
}
static int same(const UCHAR *a,const char *b){unsigned i;for(i=0;i<256;i++){unsigned c=a[i],d=(UCHAR)b[i];if(c>='a'&&c<='z')c-=32;if(d>='a'&&d<='z')d-=32;if(c!=d)return 0;if(!c)return 1;}return 0;}
static ULONG *find_iat(void){
 MODULES *mods;ULONG need=0,i,n,rva,size,matches=0,*found=0;PUCHAR base;PUCHAR pe;ULONG offset;
 need=262144;mark(21);
 mods=ExAllocatePool(NonPagedPool,need);if(!mods)return 0;
 if(!NT_SUCCESS(ZwQuerySystemInformation(11,mods,need,&need))){ExFreePool(mods);return 0;}
 mark(22);n=mods->count;if(!n||n>(262144-4)/sizeof(MODULE)||need>262144){ExFreePool(mods);return 0;}
 mark(23);base=mods->item[0].base;size=mods->item[0].size;
 for(i=0;i<n;i++){mods->item[i].path[255]=0;if(mods->item[i].name<256&&same(mods->item[i].path+mods->item[i].name,"ACPI.SYS")){ExFreePool(mods);return 0;}}
 ExFreePool(mods);mark(24);
 if(!base||size<4096||size>0x1000000||!MmIsAddressValid(base))return 0;
 mark(25);if(*(USHORT*)base!=0x5a4d)return 0;offset=*(ULONG*)(base+60);if(offset>2048)return 0;
 mark(26);pe=base+offset;
 if(*(ULONG*)pe!=0x4550||*(USHORT*)(pe+4)!=0x14c||*(USHORT*)(pe+20)<224||*(USHORT*)(pe+24)!=0x10b||*(ULONG*)(pe+116)<=12)return 0;
 mark(27);rva=*(ULONG*)(pe+216);n=*(ULONG*)(pe+220);
 if(!n||n>4096||(rva&3)||(n&3)||rva>=size||n>size-rva)return 0;
 mark(28);for(i=0;i<n;i+=4){ULONG *slot=(ULONG*)(base+rva+i);if(!MmIsAddressValid(slot)||!MmIsAddressValid((PUCHAR)slot+3))return 0;
  if(*slot==(ULONG)original){found=slot;matches++;}
 }
 mark(290+matches);return matches==1?found:0;
}
static int arm(void){
 KIRQL old;ULONG cr0;int ok=0;
 /* NT4 has no supported final-power filter API. Scope is x86 UP only.
    Interrupts are masked for this one aligned IAT pointer store. */
 KeRaiseIrql(HIGH_LEVEL,&old);
 __asm__ volatile("mov %%cr0,%0":"=r"(cr0)::"memory");
 if(*iat==(ULONG)original){
  ULONG writable=cr0&~0x10000UL;
  __asm__ volatile("mov %0,%%cr0"::"r"(writable):"memory");
  *(volatile ULONG*)iat=(ULONG)final_power;
  __asm__ volatile("mov %0,%%cr0"::"r"(cr0):"memory");ok=1;
 }
 KeLowerIrql(old);return ok;
}
static NTSTATUS NTAPI dispatch(PDEVICE_OBJECT dev,PIRP irp){
 PIO_STACK_LOCATION s=IoGetCurrentIrpStackLocation(irp);NTSTATUS st=STATUS_INVALID_DEVICE_REQUEST;ULONG bytes=0;(void)dev;
 if(s->MajorFunction==IRP_MJ_CREATE||s->MajorFunction==IRP_MJ_CLOSE)st=STATUS_SUCCESS;
 else if(s->MajorFunction==IRP_MJ_SHUTDOWN){InterlockedExchange(&shutdown_seen,1);st=STATUS_SUCCESS;}
 else if(s->MajorFunction==IRP_MJ_DEVICE_CONTROL&&s->Parameters.DeviceIoControl.IoControlCode==0x00226000){
  if(s->Parameters.DeviceIoControl.OutputBufferLength<sizeof(status))st=STATUS_BUFFER_TOO_SMALL;
  else{status[5]=shutdown_seen;RtlCopyMemory(irp->AssociatedIrp.SystemBuffer,status,sizeof(status));bytes=sizeof(status);st=STATUS_SUCCESS;}
 }
 irp->IoStatus.Status=st;irp->IoStatus.Information=bytes;IoCompleteRequest(irp,IO_NO_INCREMENT);return st;
}
NTSTATUS NTAPI DriverEntry(PDRIVER_OBJECT driver,PUNICODE_STRING registry){
 ULONG major,minor,build,i;UNICODE_STRING name;PDEVICE_OBJECT dev;NTSTATUS st;(void)registry;
 servicekey=registry;mark(10);PsGetVersion(&major,&minor,&build,0);
 if(major!=4||minor!=0||build!=1381||KeNumberProcessors!=1)return STATUS_NOT_SUPPORTED;
 mark(20);original=HalReturnToFirmware;iat=find_iat();if(!iat)return STATUS_NOT_SUPPORTED;
 mark(30);if(!discover())return STATUS_NOT_SUPPORTED;
 mark(40);RtlInitUnicodeString(&name,L"\\Device\\PN4LAB");RtlInitUnicodeString(&linkname,L"\\DosDevices\\PN4LAB");
 st=IoCreateDevice(driver,0,&name,FILE_DEVICE_UNKNOWN,FILE_DEVICE_SECURE_OPEN,FALSE,&dev);if(!NT_SUCCESS(st))return st;
 for(i=0;i<=IRP_MJ_MAXIMUM_FUNCTION;i++)driver->MajorFunction[i]=dispatch;
 st=IoCreateSymbolicLink(&linkname,&name);if(!NT_SUCCESS(st)){IoDeleteDevice(dev);return st;}
 st=IoRegisterShutdownNotification(dev);if(!NT_SUCCESS(st)){IoDeleteSymbolicLink(&linkname);IoDeleteDevice(dev);return st;}
 status[0]=7;status[2]=firmware.rsdp_rev;status[3]=firmware.fadt_rev;status[4]=firmware.off_ok|(firmware.reset_ok<<1);
 mark(50);if(!arm()){IoUnregisterShutdownNotification(dev);IoDeleteSymbolicLink(&linkname);IoDeleteDevice(dev);return STATUS_UNSUCCESSFUL;}
 mark(60);status[1]=1;driver->DriverUnload=0;dev->Flags&=~DO_DEVICE_INITIALIZING;return STATUS_SUCCESS;
}
