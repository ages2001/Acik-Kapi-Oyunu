#include <stdio.h>
#include <string.h>
#include <dos.h>
#include "ACPIDOS.H"
unsigned __cdecl pn_cpu(void);
unsigned __cdecl pn_e820(unsigned long *,unsigned char *);
int main(int argc,char **argv){
 struct pn_acpi p;union REGS in,out;int answer;
 memset(&in,0,sizeof(in));in.w.ax=0x1600;int86(0x2f,&in,&out);
 if(out.h.al&&out.h.al!=0x80){puts("Run this utility only from standalone DOS.");return 1;}
 in.w.ax=0x4680;int86(0x2f,&in,&out);if(!out.w.ax)return 1;
 in.w.ax=0x160a;int86(0x2f,&in,&out);if(!out.w.ax)return 1;
 puts("WINPOWER ACPI DOS probe 0.6");
 if(argc==2&&!stricmp(argv[1],"/MAP")){
  unsigned long key=0,words[5];unsigned i;printf("386 CPU: %u\n",pn_cpu());
  if(!pn_cpu())return 1;
  for(i=0;i<64;i++){if(!pn_e820(&key,(unsigned char *)words)){puts("E820 ended with error.");break;}
   printf("%08lX:%08lX %08lX:%08lX type %lu\n",words[1],words[0],words[3],words[2],words[4]);if(!key)break;}
  argc=1;
 }

 if(!pn_probe(&p)){printf("ACPI tables unavailable or unsupported; RSDP=%u FADT=%u\n",p.rsdp_rev,p.fadt_rev);return 1;}
 printf("RSDP revision: %u; FADT revision: %u.%u\n",p.rsdp_rev,p.fadt_rev,p.fadt_minor);
 printf("Static S5: %s; ACPI reset: %s\n",p.off_ok?"available":"unavailable",p.reset_ok?"available":"unavailable");
 printf("PM1a: %04X; PM1b: %04X; S5 types: %u/%u\n",p.pm1a,p.pm1b,p.sleepa,p.sleepb);
 if(argc==1)return 0;
 if(argc!=2||(stricmp(argv[1],"/OFF")&&stricmp(argv[1],"/RESET"))){puts("Usage: PNACPI [/OFF | /RESET]");return 1;}
 puts("End this DOS session now? Type Y to continue:");answer=getchar();if(answer!='y'&&answer!='Y')return 1;
 memset(&in,0,sizeof(in));in.h.ah=0x0d;intdos(&in,&out);
 if(!stricmp(argv[1],"/OFF"))pn_acoff(&p);else pn_acreset(&p);
 puts("ACPI transition unavailable or returned. No APM fallback in this probe.");return 1;
}
