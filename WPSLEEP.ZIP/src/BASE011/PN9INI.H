#ifndef PN9_INI_H
#define PN9_INI_H
/* Preserve all unrelated bytes, including duplicate device= entries.
 * Return 1 for an edit, 2 for an already absent removal, or a negative
 * error. The caller supplies distinct, bounded input/output buffers. */
int pn9_ini(const char *input,unsigned length,char *output,unsigned capacity,
            const char *driver,int remove,unsigned *written);
#endif
