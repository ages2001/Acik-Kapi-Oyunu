#define COBJMACROS
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <shlobj.h>
#include <ddeml.h>
#ifdef PNNT_PACKAGE
#include "NTSET.H"
#include "NTDDE.H"
#define PRODUCT_VERSION "0.11"
#else
#define PRODUCT_VERSION "0.10"
#endif
#ifdef PN9_PACKAGE
#include "PN9SET.H"
#define PRODUCT_NAME "WINPWR9X"
#elif defined(PN9_GUI)
#define PRODUCT_NAME "WINPWR9X"
#else
#define PRODUCT_NAME "WINPWRNT"
#endif
void *memset(void*p,int c,size_t n){unsigned char*q=p;while(n--)*q++=(unsigned char)c;return p;}
static char folder[MAX_PATH],self[MAX_PATH],ini[MAX_PATH],app[MAX_PATH],uninst[MAX_PATH],desktop[MAX_PATH],linkpath[MAX_PATH];
static const char *regpath="Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\" PRODUCT_NAME;
static BOOL legacy;
#if !defined(PN9_PACKAGE) && !defined(PNNT_PACKAGE)
static BOOL queue9x(const char *path,const char *inifile){
 static char section[32768];DWORD n;
 n=GetPrivateProfileSectionA("Rename",section,sizeof(section),inifile);
 if(n>=sizeof(section)-2 || n+lstrlenA(path)+6>=sizeof(section))return FALSE;
 lstrcpyA(section+n,"NUL=");lstrcatA(section+n,path);
 n+=lstrlenA(section+n)+1;section[n]=0;
 return WritePrivateProfileSectionA("Rename",section,inifile);
}
#endif
#ifndef PNNT_PACKAGE
static HDDEDATA CALLBACK callback(UINT a,UINT b,HCONV c,HSZ d,HSZ e,HDDEDATA f,ULONG_PTR g,ULONG_PTR h){(void)a;(void)b;(void)c;(void)d;(void)e;(void)f;(void)g;(void)h;return 0;}
#endif
static BOOL progman(BOOL remove){
#ifdef PNNT_PACKAGE
 return nt_group(remove,app,uninst);
#else
 DWORD id=0,reply;HSZ name;HCONV conv;BOOL ok=FALSE;char cmd[900];
 if(DdeInitializeA(&id,callback,APPCMD_CLIENTONLY,0)!=DMLERR_NO_ERROR)return FALSE;
 name=DdeCreateStringHandleA(id,"PROGMAN",CP_WINANSI);conv=DdeConnect(id,name,name,0);
 if(conv){
  if(remove)lstrcpyA(cmd,"[DeleteGroup(WINPOWER)]");
  else wsprintfA(cmd,"[CreateGroup(WINPOWER)][AddItem(%s,WINPOWER,%s,0)][AddItem(%s,Uninstall WINPOWER,%s,1)]",app,app,uninst,uninst);
  ok=DdeClientTransaction((LPBYTE)cmd,lstrlenA(cmd)+1,conv,0,0,XTYP_EXECUTE,10000,&reply)!=0;DdeDisconnect(conv);
 }
 DdeFreeStringHandle(id,name);DdeUninitialize(id);return ok;
#endif
}
static BOOL shortcut(void){
 HMODULE ole;HRESULT hr;IShellLinkA *sl=0;IPersistFile *pf=0;WCHAR wide[MAX_PATH];
 typedef HRESULT(WINAPI *INIT)(LPVOID);typedef HRESULT(WINAPI *CREATE)(REFCLSID,LPUNKNOWN,DWORD,REFIID,LPVOID*);typedef void(WINAPI *UNINIT)(void);
 INIT init;CREATE create;UNINIT uninitfn;
 ole=LoadLibraryA("OLE32.DLL");if(!ole)return FALSE;
 init=(INIT)GetProcAddress(ole,"CoInitialize");create=(CREATE)GetProcAddress(ole,"CoCreateInstance");uninitfn=(UNINIT)GetProcAddress(ole,"CoUninitialize");
 if(!init||!create||!uninitfn){FreeLibrary(ole);return FALSE;}
 hr=init(0);if(FAILED(hr)){FreeLibrary(ole);return FALSE;}
 hr=create(&CLSID_ShellLink,0,CLSCTX_INPROC_SERVER,&IID_IShellLinkA,(void**)&sl);
 if(SUCCEEDED(hr)){
  hr=IShellLinkA_SetPath(sl,app);
  if(SUCCEEDED(hr))hr=IShellLinkA_SetWorkingDirectory(sl,folder);
  if(SUCCEEDED(hr))hr=IShellLinkA_SetIconLocation(sl,app,0);
  if(SUCCEEDED(hr))hr=IShellLinkA_QueryInterface(sl,&IID_IPersistFile,(void**)&pf);
  if(SUCCEEDED(hr)){
   if(!MultiByteToWideChar(CP_ACP,0,linkpath,-1,wide,MAX_PATH))hr=E_FAIL;
   else hr=IPersistFile_Save(pf,wide,TRUE);
   IPersistFile_Release(pf);
  }
  IShellLinkA_Release(sl);
 }
 uninitfn();FreeLibrary(ole);return SUCCEEDED(hr);
}
static BOOL value(HKEY k,const char*n,const char*v){return RegSetValueExA(k,n,0,REG_SZ,(const BYTE*)v,lstrlenA(v)+1)==ERROR_SUCCESS;}
static void message(const char*s){MessageBoxA(0,s,"WINPOWER Setup",MB_OK|MB_ICONINFORMATION);}
void WINAPI WinMainCRTStartup(void){
 DWORD ver=GetVersion(),size,disp;int i;char source[MAX_PATH],check[64],windir[MAX_PATH],command[MAX_PATH+8];HKEY k;BOOL remove,ok=FALSE,created=FALSE;
#if defined(PN9_PACKAGE) || defined(PNNT_PACKAGE)
 BOOL registered=FALSE,linked=FALSE;
#endif
#ifdef PNNT_PACKAGE
 BOOL external_remove=FALSE,grouped=FALSE;LPSTR tail=GetCommandLineA();
 if(*tail=='"'){tail++;while(*tail&&*tail!='"')tail++;if(*tail)tail++;}else while(*tail&&*tail!=' ')tail++;
 while(*tail==' ')tail++;external_remove=!lstrcmpiA(tail,"/REMOVE");
 if(*tail&&!external_remove){message("Usage: SETUP.EXE or SETUP.EXE /REMOVE.");ExitProcess(1);}
#endif
#ifdef PNNT_PACKAGE
 size=GetModuleFileNameA(0,self,MAX_PATH);if(!size||size>=MAX_PATH){message("Cannot determine the installer path.");ExitProcess(1);}lstrcpyA(source,self);
#else
 GetModuleFileNameA(0,self,MAX_PATH);lstrcpyA(source,self);
#endif
 for(i=lstrlenA(source)-1;i>=0&&source[i]!='\\';--i){}source[i+1]=0;
#ifdef PNNT_PACKAGE
 if(i<0||i>MAX_PATH-20){message("The source path is invalid or too long.");ExitProcess(1);}
#endif
 remove=lstrcmpiA(self+i+1,"UNINST.EXE")==0;
#ifdef PNNT_PACKAGE
 remove=remove||external_remove;
#endif
#if defined(PN9_PACKAGE) || defined(PN9_GUI)
 if(!(ver&0x80000000UL)){message("Use the WINPWRNT package on Windows NT and later NT-family systems.");ExitProcess(1);}
#else
 if(ver&0x80000000UL){message("Use the WINPWR9X package on Windows 95, 98 or ME.");ExitProcess(1);}
#endif
#ifdef PN9_PACKAGE
 if(!(ver&0x80000000UL)||LOBYTE(LOWORD(ver))!=4||(HIBYTE(LOWORD(ver))!=0&&HIBYTE(LOWORD(ver))!=10)){message("This separate power-driver package requires Windows 95 or Windows 98.");ExitProcess(1);}
 if(!remove&&MessageBoxA(0,"Install WINPOWER Win9x lab on this test VM?\r\n\r\nQualified profiles: Windows 95 RTM / Windows 98 FE,\r\n64 MiB RAM and BIOS boot. Active OS ACPI is rejected.\r\n\r\nInstalls the GUI and a driver startup entry.\r\nRestart is required. Read TEST\\WIN9LAB.TXT first.","WINPOWER Win9x Setup",MB_YESNO|MB_DEFBUTTON2|MB_ICONEXCLAMATION)!=IDYES)ExitProcess(0);
#endif
#ifdef PNNT_PACKAGE
 if(!remove&&!nt_preflight()){message(nt_reason());ExitProcess(1);}
#endif
 legacy=!(ver&0x80000000UL)&&LOBYTE(LOWORD(ver))<4;
 if(remove){
#ifdef PNNT_PACKAGE
  if(!nt_target(folder)){message(nt_reason());ExitProcess(1);}
#else
  lstrcpyA(folder,source);folder[lstrlenA(folder)-1]=0;
#endif
 }
 else{GetWindowsDirectoryA(windir,MAX_PATH);folder[0]=windir[0];folder[1]=':';folder[2]=0;lstrcatA(folder,"\\" PRODUCT_NAME);}
 wsprintfA(ini,"%s\\WINPOWER.INI",folder);wsprintfA(app,"%s\\" PRODUCT_NAME ".EXE",folder);wsprintfA(uninst,"%s\\UNINST.EXE",folder);
 GetPrivateProfileStringA("Setup","Product","",check,sizeof(check),ini);
 if(remove){
  if(lstrcmpA(check,PRODUCT_NAME)!=0){
#ifndef PNNT_PACKAGE
   message("Installation marker is missing. No files were removed.");ExitProcess(1);
#endif
  }
  if(MessageBoxA(0,"Remove WINPOWER? Close WINPOWER before continuing. A restart completes removal of this uninstaller.","Remove WINPOWER",MB_YESNO|MB_DEFBUTTON2)!=IDYES)ExitProcess(0);
#ifdef PN9_PACKAGE
  if(!pn9_remove(folder)){message(pn9_reason());ExitProcess(1);}
  if(!pn9_cleanup(folder)){message(pn9_reason());ExitProcess(1);}
#endif
#ifdef PNNT_PACKAGE
  if(!nt_remove(folder,external_remove)){message(nt_reason());ExitProcess(1);}
#endif
  if(!DeleteFileA(app)&&GetLastError()!=ERROR_FILE_NOT_FOUND){message("Cannot remove the installed application. Close the application and retry.");ExitProcess(1);}
  GetPrivateProfileStringA("Setup","Shortcut","",linkpath,MAX_PATH,ini);
#ifdef PNNT_PACKAGE
  if(legacy){if(!progman(TRUE)){message("Cannot remove the Program Manager items. Startup is disabled; retry SETUP.EXE /REMOVE.");ExitProcess(1);}}
  else if(linkpath[0]&&!DeleteFileA(linkpath)&&GetLastError()!=ERROR_FILE_NOT_FOUND){message("Cannot remove the desktop shortcut. Retry SETUP.EXE /REMOVE.");ExitProcess(1);}
  disp=RegDeleteKeyA(HKEY_LOCAL_MACHINE,regpath);
  if(disp!=ERROR_SUCCESS&&disp!=ERROR_FILE_NOT_FOUND){message("Cannot remove the uninstall registration. Retry SETUP.EXE /REMOVE.");ExitProcess(1);}
#else
  if(legacy)progman(TRUE);else if(linkpath[0])DeleteFileA(linkpath);
  RegDeleteKeyA(HKEY_LOCAL_MACHINE,regpath);
#endif
#ifdef PN9_PACKAGE
  if(!pn9_finish(folder)){message(pn9_reason());ExitProcess(1);}
#elif !defined(PNNT_PACKAGE)
  if(ver&0x80000000UL){
   typedef DWORD(WINAPI *SHORTFN)(LPCSTR,LPSTR,DWORD);
   SHORTFN shortfn=(SHORTFN)GetProcAddress(GetModuleHandleA("KERNEL32.DLL"),"GetShortPathNameA");
   char shortname[MAX_PATH];GetWindowsDirectoryA(windir,MAX_PATH);lstrcatA(windir,"\\WININIT.INI");
   if(!shortfn||!shortfn(uninst,shortname,MAX_PATH)||!queue9x(shortname,windir)){message("Application removed. Delete UNINST.EXE manually after closing this dialog.");ExitProcess(1);}
  }else{
   if(!MoveFileExA(uninst,0,MOVEFILE_DELAY_UNTIL_REBOOT)){message("Application removed. Delete UNINST.EXE manually after closing this dialog.");ExitProcess(1);}
   MoveFileExA(folder,0,MOVEFILE_DELAY_UNTIL_REBOOT);
  }
#endif
#ifdef PNNT_PACKAGE
  if(!nt_finish(folder)){message(nt_reason());ExitProcess(1);}
  message("WINPOWER startup was disabled and its services were removed. Restart to finish deleting the installed files. The current kernel backend stays active until restart.");ExitProcess(0);
#endif
#ifdef PN9_PACKAGE
  DeleteFileA(ini);message("WINPOWER startup entry and files were removed. The loaded driver remains active until restart. Restart and sign in to finish removing the uninstaller and empty WINPWR9X directory automatically.");
#else
  DeleteFileA(ini);message("WINPOWER was removed. Restart to delete the uninstaller. On Windows 95/98/ME, remove the empty application directory afterward.");
#endif
  ExitProcess(0);
 }
 if(GetFileAttributesA(folder)!=INVALID_FILE_ATTRIBUTES){message("The installation directory already exists. Uninstall the previous copy first, or move the directory before installing.");ExitProcess(1);}
 if(!legacy){
  if(RegOpenKeyExA(HKEY_CURRENT_USER,"Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Shell Folders",0,KEY_READ,&k)!=ERROR_SUCCESS){message("Cannot locate the Desktop folder.");ExitProcess(1);}
  size=sizeof(desktop);i=RegQueryValueExA(k,"Desktop",0,&disp,(BYTE*)desktop,&size);RegCloseKey(k);
  if(i!=ERROR_SUCCESS||disp!=REG_SZ||size>=sizeof(desktop)){message("Cannot read the Desktop folder.");ExitProcess(1);}desktop[size]=0;
  if(lstrlenA(desktop)>MAX_PATH-14){message("Desktop path is too long.");ExitProcess(1);}
  wsprintfA(linkpath,"%s\\" PRODUCT_NAME ".LNK",desktop);
  if(GetFileAttributesA(linkpath)!=INVALID_FILE_ATTRIBUTES){message("A WINPOWER desktop shortcut already exists. Move it before installing.");ExitProcess(1);}
 }
#if defined(PN9_PACKAGE) || defined(PNNT_PACKAGE)
 if(RegOpenKeyExA(HKEY_LOCAL_MACHINE,regpath,0,KEY_READ,&k)==ERROR_SUCCESS){RegCloseKey(k);message("The " PRODUCT_NAME " uninstall registration already exists. Remove that installation first.");ExitProcess(1);}
#endif
 if(!CreateDirectoryA(folder,0)){message("Cannot create the installation directory. Administrative access may be required.");ExitProcess(1);}created=TRUE;
 lstrcatA(source,PRODUCT_NAME ".EXE");
 if(!CopyFileA(source,app,TRUE)||!CopyFileA(self,uninst,TRUE))goto rollback;
#ifdef PN9_PACKAGE
 if(!pn9_stage(self,folder))goto rollback;
#endif
#ifdef PNNT_PACKAGE
 if(!nt_stage(self,folder))goto rollback;
#endif
 if(!WritePrivateProfileStringA("Setup","Product",PRODUCT_NAME,ini)||!WritePrivateProfileStringA("Setup","Shortcut",linkpath,ini))goto rollback;
 if(legacy){if(!progman(FALSE)){
#ifdef PNNT_PACKAGE
  nt_error("Cannot create the WINPOWER Program Manager group. Existing groups are preserved.",GetLastError());
#endif
  goto rollback;
 }
#ifdef PNNT_PACKAGE
  grouped=TRUE;
#endif
 }
 else{
  if(RegCreateKeyExA(HKEY_LOCAL_MACHINE,regpath,0,0,0,KEY_WRITE,0,&k,&disp)!=ERROR_SUCCESS)goto rollback;
#if defined(PN9_PACKAGE) || defined(PNNT_PACKAGE)
  registered=TRUE;
#endif
  wsprintfA(command,"\"%s\"",uninst);
  ok=value(k,"DisplayName",PRODUCT_NAME " " PRODUCT_VERSION)&&value(k,"UninstallString",command)&&value(k,"DisplayVersion",PRODUCT_VERSION);
  wsprintfA(command,"%s,1",uninst);ok=ok&&value(k,"DisplayIcon",command);RegCloseKey(k);
  if(!ok||!shortcut()){RegDeleteKeyA(HKEY_LOCAL_MACHINE,regpath);goto rollback;}
#if defined(PN9_PACKAGE) || defined(PNNT_PACKAGE)
  linked=TRUE;
#endif
 }
#ifdef PNNT_PACKAGE
 if(!nt_install(folder))goto rollback;
 message("WINPOWER is installed and its power backend is active. The startup service prepares it automatically on future boots, before sign-in. Restart and check the service status to verify automatic loading.");ExitProcess(0);
#endif
#ifdef PN9_PACKAGE
 if(!pn9_install(folder))goto rollback;
 message("WINPOWER Win9x lab is installed in WINPWR9X. Restart to load the driver. Then open the desktop shortcut and verify that the driver is active. A rejected profile retains the operating system power path.");ExitProcess(0);
#else
 message("WINPOWER GUI is installed. Experimental power drivers are separate; see STATUS.TXT for their supported test profiles.");ExitProcess(0);
#endif
 rollback:
#ifdef PNNT_PACKAGE
 if(created&&!nt_abort(folder)){message(nt_reason());ExitProcess(1);}
 if(linked)DeleteFileA(linkpath);
 if(registered)RegDeleteKeyA(HKEY_LOCAL_MACHINE,regpath);
 if(grouped)progman(TRUE);
#endif
#ifdef PN9_PACKAGE
 if(pn9_recovery()){message(pn9_reason());ExitProcess(1);}
 if(linked)DeleteFileA(linkpath);
 if(registered)RegDeleteKeyA(HKEY_LOCAL_MACHINE,regpath);
 if(created)pn9_cleanup(folder);
#endif
 if(created){DeleteFileA(app);DeleteFileA(uninst);DeleteFileA(ini);RemoveDirectoryA(folder);}
#ifdef PN9_PACKAGE
 message(pn9_reason());
#elif defined(PNNT_PACKAGE)
 message(nt_reason());
#else
 message("Installation failed and copied files were removed. Check permissions and that the variant application is beside SETUP.EXE.");ExitProcess(1);
#endif
 ExitProcess(1);
}
