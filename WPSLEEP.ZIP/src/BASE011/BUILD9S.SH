#!/bin/sh
set -eu
cd "$(dirname "$0")"
mkdir -p ../BIN/WINPWR9X/LAB ../TEST
i686-w64-mingw32-windres WINPOWER.RC -O coff -o ../TEST/ICON.O
i686-w64-mingw32-gcc -x c -march=i386 -Os -Wall -Wextra -Werror -Wno-cast-function-type -fno-builtin -fno-stack-protector -nostdlib -mwindows -DPN9_PACKAGE SETUP.C PN9SET.C PN9INI.C -x none ../TEST/ICON.O -Wl,--entry,_WinMainCRTStartup@0,--subsystem,windows:4.0 -o ../BIN/WINPWR9X/LAB/SETUP.EXE -luser32 -lkernel32 -ladvapi32 -luuid
cp ../BIN/WINPWRNT/X86/WINPWRNT.EXE ../BIN/WINPWR9X/LAB/WINPWR9X.EXE
i686-w64-mingw32-gcc -x c -march=i386 -Os -Wall -Wextra -Werror -fno-builtin -fno-stack-protector -nostdlib -mwindows -I. ../TEST/PNAUDIT.C PN9INI.C -Wl,--entry,_WinMainCRTStartup@0,--subsystem,windows:4.0 -o ../BIN/WINPWR9X/LAB/PNAUDIT.EXE -luser32 -lkernel32 -ladvapi32
rm ../TEST/ICON.O
