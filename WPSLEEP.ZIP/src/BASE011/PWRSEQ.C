#include "PWRSEQ.H"
static int sci(const struct pn_acpi *p,const struct pn_io *io,int enabled){
 unsigned i;for(i=0;i<54;i++){
  if(((io->get16(io->arg,p->pm1a)&1)!=0)==enabled&&(!p->pm1b||((io->get16(io->arg,p->pm1b)&1)!=0)==enabled))return 1;
  io->wait(io->arg,1);
 }return 0;
}
int pn_s5off(const struct pn_acpi *p,const struct pn_io *io){
 unsigned a,b=0;int changed=0;
 if(!p->off_ok)return 0;
 a=io->get16(io->arg,p->pm1a);if(p->pm1b)b=io->get16(io->arg,p->pm1b);
 /* Mixed ownership or an outstanding sleep command is not a safe start. */
 if((a&0x2000)||(b&0x2000)||(p->pm1b&&((a^b)&1)))return -1;
 if(!(a&1)){
  if(!p->smi||!p->enable||!p->disable)return 0;
  io->put8(io->arg,(unsigned)p->smi,p->enable);changed=1;
  if(!sci(p,io,1))goto restore;
 }
 a=io->get16(io->arg,p->pm1a);if(p->pm1b)b=io->get16(io->arg,p->pm1b);
 io->put16(io->arg,p->pm1a,(a&~0x3c00U)|(p->sleepa<<10)|0x2000);
 if(p->pm1b)io->put16(io->arg,p->pm1b,(b&~0x3c00U)|(p->sleepb<<10)|0x2000);
 io->wait(io->arg,54);
 io->put16(io->arg,p->pm1a,a&~0x2000U);if(p->pm1b)io->put16(io->arg,p->pm1b,b&~0x2000U);
 restore:
 if(changed){io->put8(io->arg,(unsigned)p->smi,p->disable);if(!sci(p,io,0))return -1;}
 /* Do not call legacy APM while ACPI mode remains active. */
 return (io->get16(io->arg,p->pm1a)&1)?-1:0;
}
int pn_reset(const struct pn_acpi *p,const struct pn_io *io){
 if(!p->reset_ok)return 0;
 io->put8(io->arg,p->reset_port,p->reset_value);io->wait(io->arg,18);return 0;
}
