/* Small resident C helpers for kernels without exported CRT routines. */
#include <stddef.h>
void *memcpy(void *out,const void *in,size_t n) {
 unsigned char *d=out;const unsigned char *s=in;
 while(n--)*d++=*s++;
 return out;
}
void *memset(void *out,int value,size_t n) {
 unsigned char *d=out;
 while(n--)*d++=(unsigned char)value;
 return out;
}
int strcmp(const char *a,const char *b) {
 while(*a&&*a==*b){a++;b++;}
 return (unsigned char)*a-(unsigned char)*b;
}
