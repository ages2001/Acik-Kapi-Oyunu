/* Program Manager item ownership for the persistent NT3 package. */
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <ddeml.h>
#include "NTDDE.H"
static char group_data[32768];
static HDDEDATA CALLBACK callback(UINT a,UINT b,HCONV c,HSZ d,HSZ e,HDDEDATA f,ULONG_PTR g,ULONG_PTR h){(void)a;(void)b;(void)c;(void)d;(void)e;(void)f;(void)g;(void)h;return 0;}
static int query(DWORD id,HCONV conv,HSZ item){
 HDDEDATA data;DWORD size,got,reply,i;UINT error;
 data=DdeClientTransaction(0,0,conv,item,CF_TEXT,XTYP_REQUEST,10000,&reply);
 if(!data){error=DdeGetLastError(id);return error==DMLERR_NOTPROCESSED?0:-1;}
 size=DdeGetData(data,0,0,0);
 if(!size||size>sizeof(group_data)){DdeFreeDataHandle(data);return -1;}
 got=DdeGetData(data,(BYTE*)group_data,size,0);DdeFreeDataHandle(data);
 /* Old Program Manager can include allocation padding after the first
    NUL. Bound the terminator search to the bytes actually returned. */
 if(got!=size)return -1;
 for(i=0;i<size;i++)if(!group_data[i])return 1;
 return -1;
}
static BOOL execute(HCONV conv,const char *command){
 DWORD reply;return DdeClientTransaction((BYTE*)command,lstrlenA(command)+1,conv,0,0,XTYP_EXECUTE,10000,&reply)!=0;
}
static unsigned items(unsigned *owned){
 const char *p=group_data;unsigned line=0,count=0;*owned=0;
 while(*p){
  const char *end=p;char title[64];unsigned n=0;
  while(*end&&*end!='\r'&&*end!='\n')end++;
  if(line&&end>p){
   count++;
   if(*p=='"'){
    const char *q=p+1;while(q<end&&*q!='"'&&n<sizeof(title)-1)title[n++]=*q++;
    title[n]=0;
    if(q<end&&*q=='"'){
     if(!lstrcmpiA(title,"WINPOWER"))*owned|=1;
     if(!lstrcmpiA(title,"Uninstall WINPOWER"))*owned|=2;
    }
   }
  }
  line++;p=end;while(*p=='\r'||*p=='\n')p++;
 }
 return count;
}
BOOL nt_group(BOOL remove,const char *app,const char *uninst){
 DWORD id=0;HSZ name=0,item=0;HCONV conv=0;BOOL ok=FALSE,created=FALSE;int present;unsigned owned;char command[900];DWORD error=ERROR_GEN_FAILURE;
 if(DdeInitializeA(&id,callback,APPCMD_CLIENTONLY,0)!=DMLERR_NO_ERROR)return FALSE;
 name=DdeCreateStringHandleA(id,"PROGMAN",CP_WINANSI);item=DdeCreateStringHandleA(id,"WINPOWER",CP_WINANSI);
 conv=DdeConnect(id,name,name,0);if(!conv)goto done;
 present=query(id,conv,item);if(present<0)goto done;
 if(!remove){
  if(present){error=ERROR_ALREADY_EXISTS;goto done;}
  if(!execute(conv,"[CreateGroup(WINPOWER)]"))goto done;created=TRUE;
  wsprintfA(command,"[AddItem(%s,WINPOWER,%s,0)][AddItem(%s,Uninstall WINPOWER,%s,1)]",app,app,uninst,uninst);
  ok=execute(conv,command);
  if(!ok&&created)execute(conv,"[DeleteGroup(WINPOWER)]");
 }else {
  if(!present){ok=TRUE;goto done;}
  items(&owned);
  if(owned&&!execute(conv,"[ShowGroup(WINPOWER,1)]"))goto done;
  if((owned&1)&&!execute(conv,"[DeleteItem(WINPOWER)]"))goto done;
  if((owned&2)&&!execute(conv,"[DeleteItem(Uninstall WINPOWER)]"))goto done;
  present=query(id,conv,item);if(present<0)goto done;
  if(!present){ok=TRUE;goto done;}
  if(!items(&owned))ok=execute(conv,"[DeleteGroup(WINPOWER)]");
  else ok=owned==0; /* Preserve additional user items and their group. */
 }
 done:
 if(conv)DdeDisconnect(conv);if(item)DdeFreeStringHandle(id,item);if(name)DdeFreeStringHandle(id,name);DdeUninitialize(id);
 if(!ok)SetLastError(error);return ok;
}
int nt_group_status(unsigned *owned,unsigned *other){
 DWORD id=0;HSZ name=0,item=0;HCONV conv=0;int result=-1;unsigned count,flags;
 *owned=*other=0;
 if(DdeInitializeA(&id,callback,APPCMD_CLIENTONLY,0)!=DMLERR_NO_ERROR)return -1;
 name=DdeCreateStringHandleA(id,"PROGMAN",CP_WINANSI);item=DdeCreateStringHandleA(id,"WINPOWER",CP_WINANSI);
 conv=DdeConnect(id,name,name,0);
 if(conv){result=query(id,conv,item);if(result==1){count=items(&flags);*owned=(flags&1?1:0)+(flags&2?1:0);*other=count>=*owned?count-*owned:count;}DdeDisconnect(conv);}
 if(item)DdeFreeStringHandle(id,item);if(name)DdeFreeStringHandle(id,name);DdeUninitialize(id);return result;
}
