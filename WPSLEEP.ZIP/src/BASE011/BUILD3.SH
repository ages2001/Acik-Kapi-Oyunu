#!/bin/sh
set -eu
cd "$(dirname "$0")"
mkdir -p ../BIN/WINPWRNT/NT3DIAG
cc=i686-w64-mingw32-gcc
"$cc" -x c -march=i386 -mno-sse -mno-mmx -Os -Wall -Wextra -Werror -nostdlib -ffreestanding -fno-stack-protector -I"${DDK_ROOT:-/usr}/i686-w64-mingw32/include/ddk" -DPN_NT3 -D_WIN32_WINNT=0x0501 -DNTDDI_VERSION=0x05010000 -DNTDDI_WINVISTA=0x06000000 -shared PNINFO.C ACPI.C -Wl,--entry,_DriverEntry@8,--subsystem,native:3.10,--image-base,0x10000 -o ../BIN/WINPWRNT/NT3DIAG/PNINFO.SYS -lntoskrnl
"$cc" -x c -march=i386 -mno-sse -mno-mmx -Os -Wall -Wextra -Werror -fno-builtin -fno-stack-protector -nostdlib -mwindows ../TEST/PNCHECK.C -Wl,--entry,_WinMainCRTStartup@0,--subsystem,windows:3.10 -o ../BIN/WINPWRNT/NT3DIAG/PNCHECK.EXE -lkernel32 -luser32 -ladvapi32
"$cc" -x c -march=i386 -mno-sse -mno-mmx -Os -Wall -Wextra -Werror -fno-builtin -fno-stack-protector -nostdlib -mwindows PNCLEAN.C -Wl,--entry,_WinMainCRTStartup@0,--subsystem,windows:3.10 -o ../BIN/WINPWRNT/NT3DIAG/PNCLEAN.EXE -lkernel32 -luser32 -ladvapi32
