.8086
.model large
public __AHSHIFT
__AHSHIFT equ 4
end
