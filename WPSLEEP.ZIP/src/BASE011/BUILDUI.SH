#!/bin/sh
# Build only the Win32 GUI and its installer; retain tested power drivers.
set -eu
cd "$(dirname "$0")"
mkdir -p ../BIN/WINPWRNT/X86 ../BIN/WINPWRNT/X64 ../TEST
for arch in i686 x86_64; do
 if [ "$arch" = i686 ]; then cpu='-march=i386 -mno-sse -mno-mmx'; out=X86; entry=_WinMainCRTStartup@0; ver=3.10; else cpu=''; out=X64; entry=WinMainCRTStartup; ver=5.2; fi
 "$arch-w64-mingw32-windres" WINPOWER.RC -O coff -o ../TEST/ICON.O
 "$arch-w64-mingw32-gcc" $cpu -x c -Os -Wall -Wextra -Werror -Wno-cast-function-type -fno-builtin -fno-stack-protector -nostdlib -mwindows WINPOWER.C OSINFO.C OSNAME.C ICONUI.C -x none ../TEST/ICON.O -Wl,--entry,"$entry",--subsystem,windows:$ver -o ../BIN/WINPWRNT/$out/WINPWRNT.EXE -luser32 -lkernel32 -lgdi32 -ladvapi32
 "$arch-w64-mingw32-gcc" $cpu -x c -Os -Wall -Wextra -Werror -Wno-cast-function-type -fno-builtin -fno-stack-protector -nostdlib -mwindows SETUP.C -x none ../TEST/ICON.O -Wl,--entry,"$entry",--subsystem,windows:$ver -o ../BIN/WINPWRNT/$out/SETUP.EXE -luser32 -lkernel32 -ladvapi32 -luuid
done
rm ../TEST/ICON.O

mkdir -p ../BIN/WINPWR9X/GUI
cp ../BIN/WINPWRNT/X86/WINPWRNT.EXE ../BIN/WINPWR9X/GUI/WINPWR9X.EXE
i686-w64-mingw32-windres WINPOWER.RC -O coff -o ../TEST/ICON.O
i686-w64-mingw32-gcc -march=i386 -mno-sse -mno-mmx -x c -Os -Wall -Wextra -Werror -Wno-cast-function-type -fno-builtin -fno-stack-protector -nostdlib -mwindows -DPN9_GUI SETUP.C -x none ../TEST/ICON.O -Wl,--entry,_WinMainCRTStartup@0,--subsystem,windows:4.0 -o ../BIN/WINPWR9X/GUI/SETUP.EXE -luser32 -lkernel32 -ladvapi32 -luuid
rm ../TEST/ICON.O
