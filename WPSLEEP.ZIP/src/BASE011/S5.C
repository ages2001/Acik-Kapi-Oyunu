#include "S5.H"
#include "ACPI.H"
#include <string.h>
static unsigned long u32(const unsigned char *p){return (unsigned long)p[0]|((unsigned long)p[1]<<8)|((unsigned long)p[2]<<16)|((unsigned long)p[3]<<24);
 }
/* PkgLength includes its own encoding, but excludes the preceding opcode. */
static int pkg(const unsigned char *p,unsigned end,unsigned *at,unsigned *stop){
 unsigned start=*at,k,n;unsigned long v;
 if(start>=end)return 0;
 n=p[(*at)++]>>6;v=n?(p[start]&15):(p[start]&63);
 if(n>end-*at)return 0;
 for(k=0;k<n;k++)v|=(unsigned long)p[(*at)++]<<(4+8*k);
 if(v<*at-start||v>end-start)return 0;
 *stop=start+(unsigned)v;return 1;
}
static int name(const unsigned char *p,unsigned end,unsigned *at,unsigned depth,unsigned *target,char last[5]){
 unsigned n=1,i,j;*target=depth;
 if(*at>=end)return 0;
 if(p[*at]=='\\'){*target=0;(*at)++;}
 while(*at<end&&p[*at]=='^'){if(!*target)return 0;
 --*target;(*at)++;}
 if(*at>=end)return 0;
 if(p[*at]==0){(*at)++;last[0]=0;return 1;
 }
 if(p[*at]==0x2e){n=2;(*at)++;}
 else if(p[*at]==0x2f){(*at)++;if(*at>=end)return 0;
 n=p[(*at)++];if(!n)return 0;
 }
 if(n>(end-*at)/4)return 0;
 for(i=0;i<n;i++)for(j=0;j<4;j++){
  unsigned c=p[(*at)++];if(c!='_'&&!(c>='A'&&c<='Z')&&!(j&&c>='0'&&c<='9'))return 0;
 last[j]=(char)c;
 }
 last[4]=0;*target+=n;return *target<64;
}
static int integer(const unsigned char *p,unsigned end,unsigned *at,unsigned long *v){
 unsigned op,n=0,i;*v=0;if(*at>=end)return 0;
 op=p[(*at)++];
 if(op==0||op==1){*v=op;return 1;
 }if(op==0xff){*v=0xffffffffUL;return 1;
 }
 if(op==0x0a)n=1;else if(op==0x0b)n=2;else if(op==0x0c)n=4;else if(op==0x0e)n=8;else return 0;
 if(n>end-*at)return 0;
 for(i=0;i<n;i++){unsigned c=p[(*at)++];if(i<4)*v|=(unsigned long)c<<(8*i);else if(c)return 0;
 }
 return 1;
}
static int data(const unsigned char *p,unsigned end,unsigned *at){
 unsigned save=*at,stop;unsigned long v;
 if(integer(p,end,at,&v))return 1;
 *at=save;
 if(*at>=end)return 0;
 if(p[*at]==0x0d){(*at)++;while(*at<end)if(p[(*at)++]==0)return 1;
 return 0;
 }
 if(p[*at]==0x11||p[*at]==0x12||p[*at]==0x13){(*at)++;if(!pkg(p,end,at,&stop))return 0;
 *at=stop;return 1;
 }
 return 0;
}
struct scan {unsigned found,a,b,hook;};
static int terms(const unsigned char *p,unsigned at,unsigned end,unsigned depth,unsigned nesting,struct scan *s){
 unsigned op,stop,target,k,ext;char nm[5];unsigned long a,b;
 if(nesting>24)return 0;
 while(at<end){
  op=p[at++];
  if(op==0x08){
   if(!name(p,end,&at,depth,&target,nm))return 0;
   if(target==1&&!strcmp(nm,"_S5_")){
    if(s->found||at>=end||p[at++]!=0x12||!pkg(p,end,&at,&stop)||at>=stop)return 0;
    k=p[at++];if(k<2||!integer(p,stop,&at,&a)||!integer(p,stop,&at,&b)||a>7||b>7)return 0;
    for(k-=2;k;k--)if(!data(p,stop,&at))return 0;
    if(at!=stop)return 0;
 s->found=1;s->a=(unsigned)a;s->b=(unsigned)b;
   }else if(!data(p,end,&at))return 0;
  }else if(op==0x10||op==0x14){
   if(!pkg(p,end,&at,&stop)||!name(p,stop,&at,depth,&target,nm))return 0;
   if(op==0x14){
    if(at>=stop)return 0;
    if(target==1&&(!strcmp(nm,"_PTS")||!strcmp(nm,"_GTS")||!strcmp(nm,"_S5_")||!strcmp(nm,"_SST")))s->hook=1;
   }else if(!terms(p,at,stop,target,nesting+1,s))return 0;
   at=stop;
  }else if(op==0x5b){
   if(at>=end)return 0;
 ext=p[at++];
   if(ext==0x82||ext==0x83||ext==0x84||ext==0x85){
    if(!pkg(p,end,&at,&stop)||!name(p,stop,&at,depth,&target,nm))return 0;
    k=ext==0x83?6:(ext==0x84?3:0);if(k>stop-at)return 0;
 at+=k;
    if(!terms(p,at,stop,target,nesting+1,s))return 0;
 at=stop;
   }else if(ext==0x81||ext==0x86||ext==0x87){if(!pkg(p,end,&at,&stop))return 0;
 at=stop;}
   else if(ext==0x80){
    if(!name(p,end,&at,depth,&target,nm)||at>=end)return 0;
 at++;
    if(!integer(p,end,&at,&a)||!integer(p,end,&at,&b))return 0;
   }else if(ext==1||ext==2){if(!name(p,end,&at,depth,&target,nm))return 0;
 if(ext==1){if(at>=end)return 0;
 at++;}}
   else return 0;
  }else if(op==0x06){
   /* Alias could redefine the sleep namespace: unsupported. */
   return 0;
  }else if(op==0xa3){ /* Noop */ }
  else return 0; /* Includes executable top-level If/Else and dynamic names. */
 }
 return at==end;
}
int pn_s5(const unsigned char *aml,unsigned size,unsigned *a,unsigned *b){
 struct scan s;memset(&s,0,sizeof(s));
 if(!aml||!terms(aml,0,size,0,0,&s)||!s.found||s.hook)return 0;
 *a=s.a;*b=s.b;return 1;
}
static int table(pn_read read,void *arg,unsigned long address,const char *sig,unsigned char *work,unsigned cap,unsigned *length){
 unsigned long n;unsigned i;unsigned char sum=0;
 if(!address||address>0xffffffffUL-36||cap<36||!read(arg,address,work,36)||memcmp(work,sig,4))return 0;
 n=u32(work+4);if(n<36||n>cap||address>0xffffffffUL-n)return 0;
 if(!read(arg,address,work,(unsigned)n))return 0;
 for(i=0;i<(unsigned)n;i++)sum=(unsigned char)(sum+work[i]);
 if(sum)return 0;
 *length=(unsigned)n;return 1;
}
static unsigned port(const unsigned char *gas,unsigned width){
 unsigned long addr=u32(gas+4);
 if(gas[0]!=1||gas[1]!=width||gas[2]!=0||(gas[3]&&gas[3]!=
#ifdef PN_TIMER_INFO
    (width==32?3:(width==16?2:1)))||
#else
    (width==16?2:1))||
#endif
    u32(gas+8)||!addr||addr>0x10000UL-width/8)return 0;
 return (unsigned)addr;
}
int pn_tables(pn_read read,void *arg,unsigned long rsdp,struct pn_acpi *out,unsigned char *w,unsigned cap){
 unsigned n,i,step,len,fadt_count=0,ssdt=0;unsigned long root,fadt=0,dsdt,flags,addr;int rev;
 unsigned char r[36],f[276];
 memset(out,0,sizeof(*out));out->rsdp_rev=0xffff;
 if(!read||!w||cap<276||rsdp>0xffffffffUL-36||!read(arg,rsdp,r,36))return 0;
 rev=pn_rsdp(r,36);if(rev<0)return 0;
 out->rsdp_rev=(unsigned)rev;
 root=u32(r+16);step=4;
 if(rev>=2&&u32(r+24)){if(u32(r+28))return 0;
 root=u32(r+24);step=8;}
 if(!table(read,arg,root,step==8?"XSDT":"RSDT",w,cap,&len)||(len-36)%step)return 0;
 n=(len-36)/step;if(n>128)return 0;
 /* Preserve entries before the work buffer is reused. */
 {unsigned long entries[128];
  for(i=0;i<n;i++){if(step==8&&u32(w+36+i*step+4))return 0;
 entries[i]=u32(w+36+i*step);}
  for(i=0;i<n;i++){
   addr=entries[i];if(!addr||addr>0xffffffffUL-36||!read(arg,addr,w,36))return 0;
   if(!memcmp(w,"FACP",4)){fadt=addr;fadt_count++;}
   if(!memcmp(w,"SSDT",4)||!memcmp(w,"PSDT",4))ssdt=1;
  }
 }
 if(fadt_count!=1||!table(read,arg,fadt,"FACP",w,cap,&len)||len<116)return 0;
 memset(f,0,sizeof(f));memcpy(f,w,len<sizeof(f)?len:sizeof(f));
 out->fadt_rev=f[8];out->fadt_minor=len>=132?f[131]:0;flags=u32(f+112);
#ifdef PN_TIMER_INFO
 /* Optional ACPI PM timer: DWORD port reads, 24 or 32 valid counter bits. */
 if(len>=220&&(u32(f+212)||u32(f+216))){
  if(f[209]==24){unsigned char gas[12];memcpy(gas,f+208,12);gas[1]=32;out->timer_port=port(gas,32);}
  else out->timer_port=port(f+208,32);
 }else{addr=u32(f+76);if(f[91]==4&&addr&&addr<=65532)out->timer_port=(unsigned)addr;}
 if(out->timer_port)out->timer_bits=(flags&0x100UL)?32:24;
#endif
 if(len>=129&&(flags&0x400UL)){out->reset_port=port(f+116,8);out->reset_value=f[128];out->reset_ok=out->reset_port!=0;}
 if((flags&0x100000UL)||ssdt)return 1;
 out->pm1a=0;out->pm1b=0;
 if(len>=196&&(u32(f+176)||u32(f+180))){
  out->pm1a=port(f+172,16);if(u32(f+188)||u32(f+192)){out->pm1b=port(f+184,16);if(!out->pm1b)return 1;
 }
 }else{
  addr=u32(f+64);if(f[89]!=2||!addr||addr>65534)return 1;
 out->pm1a=(unsigned)addr;
  addr=u32(f+68);if(addr>65534)return 1;
 out->pm1b=(unsigned)addr;
 }
 if(!out->pm1a||(out->pm1b&&(out->pm1b==out->pm1a||out->pm1b==out->pm1a+1||out->pm1a==out->pm1b+1)))return 1;
 dsdt=u32(f+40);
 if(len>=148&&(u32(f+140)||u32(f+144))){if(u32(f+144))return 1;
 dsdt=u32(f+140);}
 if(!table(read,arg,dsdt,"DSDT",w,cap,&len)||!pn_s5(w+36,len-36,&out->sleepa,&out->sleepb))return 1;
 out->smi=u32(f+48);out->enable=f[52];out->disable=f[53];
 if(out->smi>65535)return 1;
 out->off_ok=1;return 1;
}
