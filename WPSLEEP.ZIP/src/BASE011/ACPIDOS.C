#include <dos.h>
#include <i86.h>
#include <conio.h>
#include <string.h>
#include <stdlib.h>
#include "ACPIDOS.H"
#include "ACPI.H"
#include "PWRSEQ.H"
unsigned __cdecl pn_cpu(void);
unsigned __cdecl pn_e820(unsigned long *,unsigned char *);
struct range {unsigned long base,end;};
static struct range ranges[64],reserved[32];
static unsigned count;
static unsigned char transfer[258],gdt[48];
static unsigned long dword(const unsigned char *p){return (unsigned long)p[0]|((unsigned long)p[1]<<8)|((unsigned long)p[2]<<16)|((unsigned long)p[3]<<24);}
static unsigned long linear(void __far *p){return ((unsigned long)FP_SEG(p)<<4)+FP_OFF(p);}
static void descriptor(unsigned char *p,unsigned long address,unsigned bytes){
 p[0]=(bytes-1)&255;p[1]=(bytes-1)>>8;p[2]=(unsigned char)address;p[3]=(unsigned char)(address>>8);
 p[4]=(unsigned char)(address>>16);p[5]=0x93;p[6]=0;p[7]=(unsigned char)(address>>24);
}
static int allowed(unsigned long p,unsigned n){
 unsigned i;if(!n||p>0xffffffffUL-n)return 0;
 if(p>=0xe0000UL&&p+n<=0x100000UL)return 1;
 if(p>=0x400UL&&p+n<=0xa0000UL)return 1;
 for(i=0;i<count;i++)if(p>=ranges[i].base&&p+n<=ranges[i].end)return 1;
 return 0;
}
static int readmem(void *unused,unsigned long p,unsigned char *out,unsigned n){
 union REGS in,res;struct SREGS seg;unsigned chunk,even,i;unsigned char __far *low;
 (void)unused;if(!allowed(p,n))return 0;
 while(n){
  chunk=n>256?256:n;
  if(p<0x100000UL){low=MK_FP((unsigned)(p>>4),(unsigned)(p&15));for(i=0;i<chunk;i++)out[i]=low[i];}
  else{
   even=(chunk+1)&~1;if(!allowed(p,even))return 0;
   memset(gdt,0,sizeof(gdt));descriptor(gdt+16,p,even);descriptor(gdt+24,linear(transfer),even);
   memset(&in,0,sizeof(in));segread(&seg);in.w.ax=0x8700;in.w.cx=even/2;
   seg.es=FP_SEG(gdt);in.w.si=FP_OFF(gdt);int86x(0x15,&in,&res,&seg);
   if(res.w.cflag||res.h.ah)return 0;memcpy(out,transfer,chunk);
  }
  p+=chunk;out+=chunk;n-=chunk;
 }
 return 1;
}
int pn_probe(struct pn_acpi *out){
 unsigned char map[20],head[36],*work;unsigned i,j,reserved_count=0;unsigned long key=0,base,len,ebda,p,found=0;int ok=0;
 memset(out,0,sizeof(*out));out->rsdp_rev=0xffff;count=0;
 if(!pn_cpu())return 0;
 for(i=0;i<128;i++){
  if(!pn_e820(&key,map))break;
  base=dword(map);len=dword(map+8);
  if(!dword(map+4)&&!dword(map+12)&&len&&base<=0xffffffffUL-len&&
     (dword(map+16)==1||dword(map+16)==3||dword(map+16)==4)){
   if(count==64)return 0;ranges[count].base=base;ranges[count++].end=base+len;
  }
  if(!dword(map+4)&&!dword(map+12)&&dword(map+16)==2&&base>=0x100000UL&&
     base<0xc0000000UL&&len&&len<=0x100000UL&&reserved_count<32){
   reserved[reserved_count].base=base;reserved[reserved_count++].end=base+len;
  }
  if(!key)break;
 }
 if(i==128)return 0;
 /* Some BIOSes place tables in a small reserved tail directly adjoining RAM.
    Do not admit PCI/MMIO windows or arbitrary reserved regions. */
 for(i=0;i<reserved_count;i++)for(j=0;j<count;j++){
  if(ranges[j].base>=0x100000UL&&ranges[j].end==reserved[i].base){
   ranges[j].end=reserved[i].end;break;
  }
 }
 ebda=(unsigned long)*(unsigned __far *)MK_FP(0x40,0x0e)<<4;
 if(ebda>=0x80000UL&&ebda<=0x9fc00UL)for(p=ebda;p<ebda+1024;p+=16){
  if(readmem(0,p,head,36)&&!memcmp(head,"RSD PTR ",8)&&pn_rsdp(head,36)>=0){found=p;break;}
 }
 if(!found)for(p=0xe0000UL;p<=0x100000UL-36;p+=16){
  if(readmem(0,p,head,36)&&!memcmp(head,"RSD PTR ",8)&&pn_rsdp(head,36)>=0){found=p;break;}
 }
 if(!found)return 0;
 work=malloc(32768U);if(!work)return 0;
 ok=pn_tables(readmem,0,found,out,work,32768U);free(work);return ok;
}
static void delay_ticks(unsigned n){
 unsigned long start=*(unsigned long __far *)MK_FP(0x40,0x6c),now;
 do{now=*(volatile unsigned long __far *)MK_FP(0x40,0x6c);if(now<start)start=0;}while(now-start<n);
}
static unsigned get16(void *arg,unsigned port){(void)arg;return inpw(port);}
static void put16(void *arg,unsigned port,unsigned value){(void)arg;outpw(port,value);}
static void put8(void *arg,unsigned port,unsigned value){(void)arg;outp(port,value);}
static void pauseio(void *arg,unsigned ticks){(void)arg;delay_ticks(ticks);}
static const struct pn_io io={0,get16,put16,put8,pauseio};
int pn_acoff(const struct pn_acpi *p){return pn_s5off(p,&io);}
int pn_acreset(const struct pn_acpi *p){return pn_reset(p,&io);}
