#include "OSINFO.H"
#include "OSNAME.H"
void pn_osinfo(OSVERSIONINFOA *os,char *name,char *arch){
 typedef BOOL(WINAPI *VERFN)(LPOSVERSIONINFOA);
 typedef LONG(WINAPI *RTLFN)(OSVERSIONINFOEXW*);
 typedef VOID(WINAPI *SYSFN)(LPSYSTEM_INFO);
 typedef BOOL(WINAPI *WOWFN)(HANDLE,USHORT*,USHORT*);
 HMODULE k=GetModuleHandleA("KERNEL32.DLL"),nt=GetModuleHandleA("NTDLL.DLL");
 VERFN vf=(VERFN)GetProcAddress(k,"GetVersionExA");RTLFN rf=nt?(RTLFN)GetProcAddress(nt,"RtlGetVersion"):0;
 SYSFN nf=(SYSFN)GetProcAddress(k,"GetNativeSystemInfo");WOWFN wf=(WOWFN)GetProcAddress(k,"IsWow64Process2");
 OSVERSIONINFOEXA ex;OSVERSIONINFOEXW wide;SYSTEM_INFO si;DWORD v=GetVersion();unsigned product=0,bits=32;const char *machine="x86";USHORT pm=0,nm=0;
 ZeroMemory(os,sizeof(*os));os->dwOSVersionInfoSize=sizeof(*os);os->dwMajorVersion=LOBYTE(LOWORD(v));os->dwMinorVersion=HIBYTE(LOWORD(v));os->dwBuildNumber=HIWORD(v);os->dwPlatformId=(v&0x80000000UL)?VER_PLATFORM_WIN32_WINDOWS:VER_PLATFORM_WIN32_NT;
 ZeroMemory(&ex,sizeof(ex));ex.dwOSVersionInfoSize=sizeof(ex);
 if(vf){if(vf((LPOSVERSIONINFOA)&ex)){os->dwMajorVersion=ex.dwMajorVersion;os->dwMinorVersion=ex.dwMinorVersion;os->dwBuildNumber=ex.dwBuildNumber;os->dwPlatformId=ex.dwPlatformId;product=ex.wProductType;}else vf(os);}
 ZeroMemory(&wide,sizeof(wide));wide.dwOSVersionInfoSize=sizeof(wide);
 if(rf&&rf(&wide)==0){os->dwMajorVersion=wide.dwMajorVersion;os->dwMinorVersion=wide.dwMinorVersion;os->dwBuildNumber=wide.dwBuildNumber;os->dwPlatformId=wide.dwPlatformId;product=wide.wProductType;}
 if(os->dwPlatformId==VER_PLATFORM_WIN32_WINDOWS)os->dwBuildNumber&=0xffff;
 ZeroMemory(&si,sizeof(si));if(nf)nf(&si);else GetSystemInfo(&si);
 switch(si.wProcessorArchitecture){case 9:bits=64;machine="x64";break;case 6:bits=64;machine="IA64";break;case 12:bits=64;machine="ARM64";break;case 5:machine="ARM";break;case 1:machine="MIPS";break;case 2:machine="Alpha";break;case 3:machine="PowerPC";break;case 0:break;default:machine="unknown";}
 if(wf&&wf(GetCurrentProcess(),&pm,&nm)){if(nm==0xaa64){bits=64;machine="ARM64";}else if(nm==0x8664){bits=64;machine="x64";}else if(nm==0x14c){bits=32;machine="x86";}}
 wsprintfA(name,"%s | Build %lu",pn_osname(os->dwPlatformId,os->dwMajorVersion,os->dwMinorVersion,os->dwBuildNumber,product),os->dwBuildNumber);
 wsprintfA(arch,"OS: %u-bit (%s) | Application: %u-bit",bits,machine,(unsigned)(sizeof(void*)*8));
}
