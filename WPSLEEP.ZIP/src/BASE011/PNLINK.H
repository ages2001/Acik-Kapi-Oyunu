#ifndef PN_LINK_H
#define PN_LINK_H
/* Shared 16-bit DOS/Windows file protocol; never a hardware-write IOCTL. */
#define PN_MAGIC "WPDOS010"
#define PN_STATE "PNSTATE.DAT"
struct pn_state { char magic[8]; unsigned short ready; unsigned short action; unsigned short acpi_rev,fadt_rev,fadt_minor,cap_flags; };
typedef char pn_wire_size[(sizeof(struct pn_state)==20)?1:-1];
static int pn_valid(const struct pn_state *state){
 unsigned i;static const char magic[8]=PN_MAGIC;
 for(i=0;i<8;i++)if(state->magic[i]!=magic[i])return 0;
 return state->ready<=1&&state->action<=3&&state->cap_flags<=3&&
  (state->acpi_rev<=255||state->acpi_rev==0xffff)&&state->fadt_rev<=255&&state->fadt_minor<=255;
}
static unsigned pn_action(const struct pn_state *state,int rc){
 if(rc||!pn_valid(state)||state->ready!=1)return 0;
 return state->action?state->action:1;
}
#endif
