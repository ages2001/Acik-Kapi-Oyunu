/* Parse the x86 CM_RESOURCE_LIST from the NT physical-memory resource map. */
#include "MEMMAP.H"
static unsigned long u32(const unsigned char *p) {
 return (unsigned long)p[0]|((unsigned long)p[1]<<8)|
        ((unsigned long)p[2]<<16)|((unsigned long)p[3]<<24);
}
int pn_memmap(const unsigned char *p,unsigned n,struct pn_memmap *m) {
 unsigned full,i,j,at=4;unsigned long count,start,length,end;
 m->count=0;m->top=0;m->limit=0;
 if(n<4)return 0;
 full=(unsigned)u32(p);if(!full||full>32)return 0;
 for(i=0;i<full;i++) {
  if(at>n||n-at<16)return 0;
  count=u32(p+at+12);at+=16;
  if(!count||count>32||count>(n-at)/16)return 0;
  for(j=0;j<count;j++,at+=16) {
   if(p[at]!=3||u32(p+at+8))return 0;
   start=u32(p+at+4);length=u32(p+at+12);
   if(!length||start>=0xbff00000UL||length>0xbff00000UL-start||m->count==32)return 0;
   end=start+length;m->base[m->count]=start;m->length[m->count++]=length;
   if(end>m->top)m->top=end;
  }
 }
 if(at!=n||m->top<0x100000)return 0;
 /* Lab BIOS transport: allow only the reservation tail of the last MiB.
    This is a heuristic, not a firmware E820 map or universal MMIO policy. */
 m->limit=(m->top+0xfffffUL)&~0xfffffUL;
 return 1;
}
int pn_memread(const struct pn_memmap *m,unsigned long a,unsigned n) {
 unsigned i;
 if(!n||a>0xffffffffUL-n)return 0;
 if(a>=0x400&&a+n<=0x100000)return 1;
 for(i=0;i<m->count;i++)if(a>=m->base[i]&&a+n<=m->base[i]+m->length[i])return 1;
 return a>=m->top&&a+n<=m->limit;
}
