#!/bin/sh
set -eu
: "${WATCOM:?Set WATCOM to the Open Watcom 1.9 directory}"
cd "$(dirname "$0")"
python3 ICON.PY
export INCLUDE="$WATCOM/h:$WATCOM/h/win"
export PATH="$WATCOM/binl:$PATH"
run() { if [ -n "${WIN16_RUN:-}" ]; then "$WIN16_RUN" "$@"; else "$@"; fi; }
mkdir -p ../BIN/WPWRDOS ../BIN/WINPWR16/WIN1 ../BIN/WINPWR16/WIN2 ../BIN/WINPWR16/WIN3 ../TEST/TMP16
for name in OSNAME ICONUI PNEXEC; do
 run "$WATCOM/binl/wcc" -bt=windows -ml -os -fo=../TEST/TMP16/$name.OBJ $name.C
done
run "$WATCOM/binl/wasm" -fo=../TEST/TMP16/WIN1FIX.OBJ WIN1FIX.ASM
run "$WATCOM/binl/wrc" -30 -r -bt=windows -fo=../TEST/TMP16/WINPOWER.RES WINPOWER.RC
for version in 1 2 3; do
 define=""; extra=""; alignment=""
 case "$version" in
  1) dir=WIN1; define=-dPN_WIN1; extra=../TEST/TMP16/WIN1FIX.OBJ,; alignment="option alignment=16" ;;
  2) dir=WIN2; define=-dPN_WIN2 ;;
  3) dir=WIN3 ;;
 esac
 run "$WATCOM/binl/wcc" -bt=windows -ml -zW -os $define -fo=../TEST/TMP16/PNDDE.OBJ PNDDE.C
 for name in WINPWR16 UNINST; do
  mode=""; if [ "$name" = UNINST ]; then mode=-dPN_UNINST; fi
  run "$WATCOM/binl/wcc" -bt=windows -ml -zW -os $define $mode -fo=../TEST/TMP16/PNW16.OBJ PNW16.C
  run "$WATCOM/binl/wlink" system windows $alignment name ../BIN/WINPWR16/$dir/$name.EXE file "${extra}../TEST/TMP16/PNW16.OBJ,../TEST/TMP16/OSNAME.OBJ,../TEST/TMP16/ICONUI.OBJ,../TEST/TMP16/PNEXEC.OBJ,../TEST/TMP16/PNDDE.OBJ"
  if [ "$version" != 1 ]; then run "$WATCOM/binl/wrc" -30 ../TEST/TMP16/WINPOWER.RES ../BIN/WINPWR16/$dir/$name.EXE; fi
  python3 - "$dir" "$name" "$version" <<'PY'
from pathlib import Path
import struct,sys
p=Path('../BIN/WINPWR16')/sys.argv[1]/(sys.argv[2]+'.EXE');b=bytearray(p.read_bytes())
ne=struct.unpack_from('<I',b,60)[0]
struct.pack_into('<H',b,ne+62,int(sys.argv[3])*256);p.write_bytes(b)
PY
 done
done
run "$WATCOM/binl/wasm" -fo=../TEST/TMP16/BIOREAD.OBJ BIOREAD.ASM
for name in ACPI S5 PWRSEQ ACPIDOS; do
 run "$WATCOM/binl/wcc" -bt=dos -ml -0 -os -fo=../TEST/TMP16/$name.OBJ $name.C
done
for name in WPWRDOS PNINST PNACPI; do
 run "$WATCOM/binl/wcc" -bt=dos -ml -0 -os -fo=../TEST/TMP16/$name.OBJ $name.C
 extra=""
 if [ "$name" != PNINST ]; then extra=,../TEST/TMP16/ACPI.OBJ,../TEST/TMP16/S5.OBJ,../TEST/TMP16/PWRSEQ.OBJ,../TEST/TMP16/ACPIDOS.OBJ,../TEST/TMP16/BIOREAD.OBJ; fi
 run "$WATCOM/binl/wlink" system dos option stack=8192 name ../BIN/WPWRDOS/$name.EXE file ../TEST/TMP16/$name.OBJ$extra
 if [ "$name" != PNACPI ]; then for dir in WIN1 WIN2 WIN3; do cp ../BIN/WPWRDOS/$name.EXE ../BIN/WINPWR16/$dir/$name.EXE; done; fi
done
rm ../TEST/TMP16/*.OBJ ../TEST/TMP16/WINPOWER.RES
rmdir ../TEST/TMP16
