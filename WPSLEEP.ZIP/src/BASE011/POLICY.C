#include "POLICY.H"
int pn_eligible(int nt, unsigned major, unsigned minor, int os_acpi) {
    if (!os_acpi) return 0;
    if (nt) return (major == 5 && minor <= 2) ||
                   (major == 6 && minor <= 3) || (major == 10 && minor == 0);
    return major == 4 && (minor == 10 || minor == 90);
}
int pn_owner(int requested, int eligible, int backend_ready) {
    return requested && eligible && backend_ready;
}
