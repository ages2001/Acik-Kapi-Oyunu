.386p
_TEXT segment dword public use32 'CODE'
extrn control:near
public PN9_DDB
PN9_DDB label byte
dd 0
dw 0400h,0
db 0,9
dw 0
db 'PN9HOOK '
; Lowest initialization order makes the reverse exit notification last.
; The C guard rejects competing order-zero callbacks, except a verified
; Win95 VMM handler whose message 26h path only returns carry clear.
dd 0,offset control
dd 0,0,0,0,0,0,0,0,0
dd 80,0,0,0
_TEXT ends
end
