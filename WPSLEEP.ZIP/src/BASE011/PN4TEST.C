#define WIN32_LEAN_AND_MEAN
#include <windows.h>
void *memset(void *p,int c,size_t n){unsigned char*q=p;while(n--)*q++=(unsigned char)c;return p;}
static DWORD configure(int restore){
 const char *setting="Software\\Microsoft\\Windows NT\\CurrentVersion\\Winlogon";
 const char *backup="Software\\WINPOWER\\NT4LAB";
 struct {DWORD type,present,size;BYTE value[256];} record;
 HKEY key=0,saved=0;DWORD type,n,disp;LONG error;
 error=RegOpenKeyExA(HKEY_LOCAL_MACHINE,setting,0,KEY_QUERY_VALUE|KEY_SET_VALUE,&key);if(error)return error;
 if(restore)error=RegOpenKeyExA(HKEY_LOCAL_MACHINE,backup,0,KEY_QUERY_VALUE,&saved);
 else error=RegCreateKeyExA(HKEY_LOCAL_MACHINE,backup,0,0,0,KEY_QUERY_VALUE|KEY_SET_VALUE,0,&saved,&disp);
 if(error){RegCloseKey(key);return error;}
 n=sizeof(record);error=RegQueryValueExA(saved,"Saved",0,&type,(BYTE*)&record,&n);
 if(error==ERROR_FILE_NOT_FOUND&&!restore){
  ZeroMemory(&record,sizeof(record));record.size=sizeof(record.value);
  error=RegQueryValueExA(key,"PowerdownAfterShutdown",0,&record.type,record.value,&record.size);
  if(error==ERROR_FILE_NOT_FOUND){record.size=0;error=0;}else if(!error)record.present=1;
  if(!error){n=12+record.size;type=REG_BINARY;error=RegSetValueExA(saved,"Saved",0,type,(BYTE*)&record,n);}
 }
 if(!error&&(type!=REG_BINARY||n<12||record.size>256||n!=12+record.size||record.present>1))error=ERROR_INVALID_DATA;
 if(!error){
  if(!restore)error=RegSetValueExA(key,"PowerdownAfterShutdown",0,REG_SZ,(const BYTE*)"1",2);
  else if(record.present)error=RegSetValueExA(key,"PowerdownAfterShutdown",0,record.type,record.value,record.size);
  else {error=RegDeleteValueA(key,"PowerdownAfterShutdown");if(error==ERROR_FILE_NOT_FOUND)error=0;}
 }
 RegCloseKey(saved);RegCloseKey(key);
 if(!error&&restore)error=RegDeleteKeyA(HKEY_LOCAL_MACHINE,backup);
 return error;
}
void WINAPI WinMainCRTStartup(void){
 char path[MAX_PATH],result[768];SC_HANDLE manager=0,svc=0;HANDLE d;DWORD got,err=0,step=0,stage=0,v[7];int i,inspect=0,deleted=0;
 {LPSTR cmd=GetCommandLineA();if(*cmd=='"'){cmd++;while(*cmd&&*cmd!='"')cmd++;if(*cmd)cmd++;}else while(*cmd&&*cmd!=' ')cmd++;
  while(*cmd==' ')cmd++;
  inspect=!lstrcmpiA(cmd,"/STATUS");if(!lstrcmpiA(cmd,"/RESTORE")){err=configure(1);wsprintfA(result,"Restore original Winlogon setting: error %lu",err);MessageBoxA(0,result,"WINPOWER NT4 Lab",MB_OK);ExitProcess(err?1:0);}}
 if(!inspect&&MessageBoxA(0,"NT4 x86 uniprocessor research test.\r\nThis intercepts one kernel HAL import until reboot.\r\nIt cannot unload while armed. Use a disposable VM copy.\r\n\r\nArm the experimental shim for this boot?","WINPOWER NT4 Lab",MB_YESNO|MB_DEFBUTTON2|MB_ICONEXCLAMATION)!=IDYES)ExitProcess(0);
 GetModuleFileNameA(0,path,sizeof(path));for(i=lstrlenA(path)-1;i>=0&&path[i]!='\\';--i){}path[i+1]=0;lstrcatA(path,"PN4HOOK.SYS");
 ZeroMemory(v,sizeof(v));if(inspect)goto query;manager=OpenSCManagerA(0,0,SC_MANAGER_CREATE_SERVICE);if(!manager){err=GetLastError();step=1;goto done;}
 svc=CreateServiceA(manager,"PN4LAB","WINPOWER NT4 research test",SERVICE_START|DELETE,SERVICE_KERNEL_DRIVER,SERVICE_DEMAND_START,SERVICE_ERROR_NORMAL,path,0,0,0,0,0);
 if(!svc){err=GetLastError();step=2;goto done;}
 if(!StartServiceA(svc,0,0)){err=GetLastError();step=3;goto done;}
 query:
 d=CreateFileA("\\\\.\\PN4LAB",GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,0,OPEN_EXISTING,0,0);
 if(d==INVALID_HANDLE_VALUE){err=GetLastError();step=4;goto done;}
 if(!DeviceIoControl(d,0x00226000,0,0,v,sizeof(v),&got,0)){err=GetLastError();step=5;}
 else if(got!=sizeof(v)||v[0]!=7||v[1]!=1||(v[4]&~3UL)||!(v[4]&1)){err=ERROR_INVALID_DATA;step=5;}
 CloseHandle(d);
 if(!err&&!inspect){err=configure(0);if(err)step=6;}
 done:
 {HKEY k;DWORD size=4;if(!RegOpenKeyExA(HKEY_LOCAL_MACHINE,"System\\CurrentControlSet\\Services\\PN4LAB",0,KEY_QUERY_VALUE,&k)){RegQueryValueExA(k,"Stage",0,0,(BYTE*)&stage,&size);RegCloseKey(k);}}
 if(svc){deleted=DeleteService(svc);if(!deleted&&!err){err=GetLastError();step=7;}CloseServiceHandle(svc);}if(manager)CloseServiceHandle(manager);
 wsprintfA(result,"NT4 final-power research test\r\nStep: %lu  Error: %lu  Kernel stage: %lu\r\nArmed: %lu  RSDP: %lu  FADT: %lu\r\nCapabilities: %lu  Shutdown seen: %lu\r\n\r\n%s\r\n%s\r\n%s",step,err,stage,v[1],v[2],v[3],v[4],v[5],
  v[1]?"The armed shim stays resident until reboot.":"No active shim was reported.",
  inspect?"Status query only; no settings changed.":(deleted?"Temporary service marked for deletion.":"See the reported step/error before continuing."),
  v[1]?"After reboot, run PN4TEST /RESTORE to restore Winlogon.":"If an earlier test saved Winlogon, run PN4TEST /RESTORE.");
 MessageBoxA(0,result,"WINPOWER NT4 Lab result",MB_OK|(err?MB_ICONEXCLAMATION:MB_ICONINFORMATION));ExitProcess(err?1:0);
}
