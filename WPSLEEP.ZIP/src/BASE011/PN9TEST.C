/* Load/query the separately packaged, experimental Win9x power VxD. */
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
void WINAPI WinMainCRTStartup(void) {
 char dir[MAX_PATH],msg[768],*cmd=GetCommandLineA();DWORD i,size=0,error=0,info[16]={0},version=GetVersion();HANDLE h;BOOL statusonly;
 if(*cmd=='"'){cmd++;while(*cmd&&*cmd!='"')cmd++;if(*cmd)cmd++;}
 else while(*cmd&&*cmd!=' ')cmd++;
 while(*cmd==' ')cmd++;
 statusonly=lstrcmpiA(cmd,"/STATUS")==0;
 if(!(version&0x80000000UL)||LOBYTE(LOWORD(version))!=4){MessageBoxA(0,"This lab requires Windows 95 or 98.","WINPOWER Win9x lab",MB_OK);ExitProcess(50);}
 if(!statusonly&&MessageBoxA(0,"Load the experimental WINPOWER final-power VxD?\r\n\r\nUse only a disposable 64 MiB BIOS VM copy.\r\nThe driver intercepts final Windows shutdown and stays\r\nresident until reboot. Active OS ACPI is rejected.","WINPOWER Win9x lab",MB_YESNO|MB_ICONEXCLAMATION|MB_DEFBUTTON2)!=IDYES)ExitProcess(0);
 GetModuleFileNameA(0,dir,sizeof(dir));i=lstrlenA(dir);while(i&&dir[i-1]!='\\')i--;dir[i]=0;SetCurrentDirectoryA(dir);
 h=CreateFileA(statusonly?"\\\\.\\PN9HOOK":"\\\\.\\PN9HOOK.VXD",0,0,0,statusonly?OPEN_EXISTING:CREATE_NEW,statusonly?0:FILE_FLAG_DELETE_ON_CLOSE,0);
 if(h==INVALID_HANDLE_VALUE)error=GetLastError();
 else if(!DeviceIoControl(h,1,0,0,info,sizeof(info),&size,0))error=GetLastError();
 else if(size!=sizeof(info)||info[0]!=10)error=13;
 wsprintfA(msg,"Win9x final-power lab\r\nError: %lu  Stage: %lu  Armed: %lu\r\nVMM: %04lX  APM BIOS: %04lX\r\nRSDP: %lu  FADT: %lu  Capabilities: %lu\r\nPhysical pages: %lu  OS ACPI: %lu\r\nExit code: %08lX  Final calls: %lu\r\nLast callback: %lu  DDB count: %lu\r\nPM timer port: %04lX  Timer failure: %lu\r\n\r\nReboot removes dynamically loaded hooks.\r\nA SYSTEM.INI entry, if added manually, persists.",error,info[8],info[1],info[2],info[3],info[4],info[5],info[6],info[7],info[9],info[10],info[11],info[12],info[14],info[13],info[15]);
 MessageBoxA(0,msg,"WINPOWER Win9x lab result",MB_OK);
 if(h!=INVALID_HANDLE_VALUE)CloseHandle(h);
 ExitProcess(error);
}
