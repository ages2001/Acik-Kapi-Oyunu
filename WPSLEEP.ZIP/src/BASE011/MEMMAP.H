#ifndef PN_MEMMAP_H
#define PN_MEMMAP_H
struct pn_memmap {
 unsigned count;
 unsigned long base[32],length[32],top,limit;
};
int pn_memmap(const unsigned char *,unsigned,struct pn_memmap *);
int pn_memread(const struct pn_memmap *,unsigned long,unsigned);
#endif
