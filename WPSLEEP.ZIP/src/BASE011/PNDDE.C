#include <windows.h>
#include <dde.h>
#if defined(PN_WIN1) || defined(PN_WIN2)
BOOL pn_icons(HWND owner,HINSTANCE instance,LPCSTR directory,BOOL remove){
 (void)owner;(void)instance;(void)directory;(void)remove;return FALSE;
}
#else
/* Direct Win16 DDE also works on Windows 3.0, without DDEML. */
static HWND server,client;
static ATOM app,topic;
static HGLOBAL packet;
static BOOL starting,done,accepted,terminated,blocked;
static FARPROC callback;
long FAR PASCAL __export DdeProc(HWND h,UINT m,WPARAM w,LPARAM l){
 (void)h;
 if(m==WM_DDE_ACK){
  if(starting){
   if(LOWORD(l)==app&&HIWORD(l)==topic){server=(HWND)w;GlobalDeleteAtom(LOWORD(l));GlobalDeleteAtom(HIWORD(l));}
  }else if((HWND)w==server&&(HGLOBAL)HIWORD(l)==packet){
   accepted=(LOWORD(l)&0x8000)!=0;done=TRUE;GlobalFree(packet);packet=0;
  }
  return 0;
 }
 if(m==WM_DDE_TERMINATE){terminated=TRUE;return 0;}
 return DefWindowProc(h,m,w,l);
}
static void pump(BOOL *condition,DWORD duration){
 DWORD start=GetTickCount();MSG msg;
 while(!*condition&&(DWORD)(GetTickCount()-start)<duration){
  while(PeekMessage(&msg,client,0,0,PM_REMOVE)){TranslateMessage(&msg);DispatchMessage(&msg);}
  Yield();
 }
}
static BOOL execute(LPCSTR text){
 LPSTR p;unsigned size=lstrlen(text)+1;
 if(blocked)return FALSE;
 packet=GlobalAlloc(GMEM_MOVEABLE|GMEM_DDESHARE,size);if(!packet)return FALSE;
 p=GlobalLock(packet);if(!p){GlobalFree(packet);packet=0;return FALSE;}
 lstrcpy(p,text);GlobalUnlock(packet);done=accepted=FALSE;
 if(!PostMessage(server,WM_DDE_EXECUTE,(WPARAM)client,MAKELONG(0,packet))){GlobalFree(packet);packet=0;return FALSE;}
 pump(&done,3000);
 if(!done){blocked=TRUE;return FALSE;}
 return accepted;
}
BOOL pn_icons(HWND owner,HINSTANCE instance,LPCSTR directory,BOOL remove){
 WNDCLASS c;BOOL ok=FALSE;static char text[512],exe[160];
 if(blocked)return FALSE;
 if(!callback){
  callback=MakeProcInstance((FARPROC)DdeProc,instance);
  c.style=0;c.lpfnWndProc=(WNDPROC)callback;c.cbClsExtra=c.cbWndExtra=0;c.hInstance=instance;
  c.hIcon=0;c.hCursor=0;c.hbrBackground=0;c.lpszMenuName=0;c.lpszClassName="PNDDE";
  if(!RegisterClass(&c))return FALSE;
 }
 client=CreateWindow("PNDDE","",WS_POPUP,0,0,0,0,owner,0,instance,0);if(!client)return FALSE;
 server=0;starting=TRUE;app=GlobalAddAtom("PROGMAN");topic=GlobalAddAtom("PROGMAN");
 SendMessage((HWND)0xffff,WM_DDE_INITIATE,(WPARAM)client,MAKELONG(app,topic));
 starting=FALSE;GlobalDeleteAtom(app);GlobalDeleteAtom(topic);
 if(!server){DestroyWindow(client);return FALSE;}
 if(remove){
  if(execute("[ShowGroup(WINPOWER,1)]")){
   BOOL a=execute("[DeleteItem(WINPOWER Power Center)]");
   BOOL b=execute("[DeleteItem(Remove WINPOWER)]");ok=a&&b;
  }
 }else if(execute("[CreateGroup(WINPOWER)]")){
  execute("[DeleteItem(WINPOWER Power Center)]");
  lstrcpy(exe,directory);lstrcat(exe,"\\WINPWR16.EXE");
  lstrcpy(text,"[AddItem(\"");lstrcat(text,exe);lstrcat(text,"\",\"WINPOWER Power Center\",\"");lstrcat(text,exe);lstrcat(text,"\",0)]");
  if(execute(text)){
   execute("[DeleteItem(Remove WINPOWER)]");
   lstrcpy(exe,directory);lstrcat(exe,"\\UNINST.EXE");
   lstrcpy(text,"[AddItem(\"");lstrcat(text,exe);lstrcat(text,"\",\"Remove WINPOWER\",\"");lstrcat(text,exe);lstrcat(text,"\",1)]");ok=execute(text);
  }
 }
 terminated=FALSE;PostMessage(server,WM_DDE_TERMINATE,(WPARAM)client,0);pump(&terminated,1000);
 /* An unacknowledged execute block may still be read by the server.
    Keep that one block alive on timeout; do not repeat further requests. */
 DestroyWindow(client);client=0;SetActiveWindow(owner);return ok;
}
#endif
