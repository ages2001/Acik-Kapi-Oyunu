#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include "OSINFO.H"
#include "ICONUI.H"
#define ID_OFF 101
#define ID_BOOT 102
#define ID_INFO 103
void *memset(void *p, int c, size_t n) { unsigned char *q=p; while(n--) *q++=(unsigned char)c; return p; }
static HINSTANCE inst;
static HWND statusbox,ownerOS,ownerDriver;
static unsigned powerlab;
static unsigned batteryicon=8, acicon=10;
static BOOL compact;
static int status_y;
static char displayed[1024],ownerlabel[64];
static unsigned shownlab=~0U;
static HFONT titlefont, bodyfont;
static HBRUSH headerbrush, bodybrush;
static COLORREF headercolor, accentcolor;
static OSVERSIONINFOA os;
static char osname[160], architecture[80];
typedef BOOL (WINAPI *POWERFN)(LPSYSTEM_POWER_STATUS);
static void refresh(void) {
 SYSTEM_POWER_STATUS p; char text[1024], bat[64], charge[48], ac[64], life[64], rev[64],apm[32];
 unsigned oldbattery=batteryicon,oldac=acicon;
 HANDLE d; LONG v; DWORD got,lab[16];const char *owner="Operating system",*driver="WINPOWER driver (unavailable)";
 POWERFN fn=(POWERFN)GetProcAddress(GetModuleHandleA("KERNEL32.DLL"),"GetSystemPowerStatus");
 lstrcpyA(rev,"N/A");
 lstrcpyA(apm,"N/A");
 d=CreateFileA("\\\\.\\WINPOWER",GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,0,OPEN_EXISTING,0,0);
 if(d!=INVALID_HANDLE_VALUE){
  if(DeviceIoControl(d,0x00226000UL,0,0,&v,sizeof(v),&got,0)&&got==sizeof(v)&&v>=0)
   wsprintfA(rev,"RSDP %ld (ACPI %s)",v,v==0?"1.0":"2.0+");
  CloseHandle(d);
 }
 powerlab=0;
 if(os.dwPlatformId==VER_PLATFORM_WIN32_NT&&(os.dwMajorVersion==3||os.dwMajorVersion==4)){
  unsigned old3=os.dwMajorVersion==3;DWORD size=old3?48:28;
  d=CreateFileA(old3?"\\\\.\\PN3LAB":"\\\\.\\PN4LAB",GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,0,OPEN_EXISTING,0,0);
  if(d!=INVALID_HANDLE_VALUE){
   if(DeviceIoControl(d,0x00226000UL,0,0,lab,size,&got,0)&&got==size&&lab[0]==(old3?9UL:7UL)&&lab[1]==1&&(lab[4]&1)&&(!old3||lab[11]==1)){
    powerlab=old3?3:4;wsprintfA(rev,"RSDP %lu / FADT %lu",lab[2],lab[3]);
   }CloseHandle(d);
  }
 }
 if(os.dwPlatformId==VER_PLATFORM_WIN32_WINDOWS&&os.dwMajorVersion==4){
  /* No extension: query a resident VxD without loading a driver or hook. */
  d=CreateFileA("\\\\.\\PN9HOOK",0,0,0,OPEN_EXISTING,0,0);
  if(d!=INVALID_HANDLE_VALUE){
   if(DeviceIoControl(d,1,0,0,lab,sizeof(lab),&got,0)&&got==sizeof(lab)&&lab[0]==10){
    if(lab[3]>=0x100&&lab[3]<=0x102)wsprintfA(apm,"%lu.%lu",lab[3]>>8,lab[3]&255);
    if(lab[4]!=0xffff&&lab[5])wsprintfA(rev,"RSDP %lu / FADT %lu",lab[4],lab[5]);
    if(lab[1]==1&&(lab[6]&1)&&!lab[9])powerlab=9;
   }CloseHandle(d);
  }
 }
 if(powerlab==3){owner="WINPOWER NT3 lab";driver="WINPOWER NT3 lab (active)";}
 if(powerlab==4){owner="WINPOWER NT4 lab";driver="WINPOWER NT4 lab (active)";}
 if(powerlab==9){owner="WINPOWER Win9x lab";driver="WINPOWER Win9x lab (active)";}
 if(shownlab!=powerlab){
  SendMessageA(ownerOS,BM_SETCHECK,powerlab?BST_UNCHECKED:BST_CHECKED,0);
  SendMessageA(ownerDriver,BM_SETCHECK,powerlab?BST_CHECKED:BST_UNCHECKED,0);
  shownlab=powerlab;
 }
 /* The current labs have a fixed owner and reject an active OS ACPI stack.
    An ownership switch needs a separately qualified handoff backend. */
 if(IsWindowEnabled(ownerOS))EnableWindow(ownerOS,FALSE);
 if(IsWindowEnabled(ownerDriver))EnableWindow(ownerDriver,FALSE);
 if(lstrcmpA(ownerlabel,driver)){SetWindowTextA(ownerDriver,driver);lstrcpyA(ownerlabel,driver);}
 batteryicon=8;acicon=10;
 lstrcpyA(charge,"");
 lstrcpyA(bat,"N/A");lstrcpyA(ac,"N/A");lstrcpyA(life,"N/A");
 if(fn && fn(&p)) {
  if(p.ACLineStatus==0)lstrcpyA(ac,"Offline");
  if(p.ACLineStatus==1){lstrcpyA(ac,"Online");acicon=6;}
  if(p.BatteryFlag!=255 && (p.BatteryFlag&128))lstrcpyA(bat,"Not present");
  else if(p.BatteryLifePercent<=100) wsprintfA(bat,"%u%%",p.BatteryLifePercent);
  if(p.BatteryFlag!=255 && !(p.BatteryFlag&128)) {
   batteryicon=(p.BatteryFlag&8)?9:5;
   if(p.BatteryFlag&8)lstrcpyA(charge," / Charging");
   else if(p.BatteryFlag&4)lstrcpyA(charge," / Critical");
   else if(p.BatteryFlag&2)lstrcpyA(charge," / Low");
  }
  if(p.BatteryLifeTime!=0xffffffffUL)wsprintfA(life,"%lu seconds",p.BatteryLifeTime);
 }
 wsprintfA(text,compact?
 "%s\r\n%s\r\nACPI revision: %s\r\nAPM version: %s\r\nAC power: %s\r\nBattery: %s%s\r\nBattery time remaining: %s\r\nShutdown owner: %s\r\nFirmware control: %s":
 "%s\r\n%s\r\n\r\nACPI revision: %s\r\nAPM version: %s\r\n\r\nAC power: %s\r\nBattery: %s%s\r\nBattery time remaining: %s\r\n\r\nShutdown owner: %s\r\nFirmware control: %s",
 osname,architecture,rev,apm,ac,bat,charge,life,owner,powerlab?"ACPI S5 after Windows shutdown (lab)":"OS path; independent driver unavailable");
 if(lstrcmpA(displayed,text)){SetWindowTextA(statusbox,text);lstrcpyA(displayed,text);}
 /* Only the status icons need a parent repaint when their values change.
    Repainting the entire header every timer tick causes visible flicker
    on slow legacy display drivers. Static controls repaint themselves. */
 if(oldbattery!=batteryicon||oldac!=acicon){
  HWND h=GetParent(statusbox);HDC dc=GetDC(h);TEXTMETRICA tm;RECT r;
  HFONT old=(HFONT)SelectObject(dc,bodyfont);GetTextMetricsA(dc,&tm);
  SelectObject(dc,old);ReleaseDC(h,dc);
  r.left=22;r.right=38;r.top=status_y+(compact?4:6)*tm.tmHeight;
  r.bottom=r.top+tm.tmHeight+16;InvalidateRect(h,&r,FALSE);
 }
}
static void error(HWND h, const char *what) {
 char b[160];wsprintfA(b,"%s\r\nWindows error: %lu",what,GetLastError());
 MessageBoxA(h,b,"WINPOWER",MB_OK|MB_ICONEXCLAMATION);
}
static void power(HWND h,int reboot) {
 HANDLE token=0; TOKEN_PRIVILEGES tp,old; DWORD sz=sizeof(old); BOOL adjusted=FALSE;
 if(MessageBoxA(h,reboot?"Restart Windows now? Save your work first.":
 "Request Windows power off now? Save your work first.\r\nPhysical power off requires support from Windows and firmware.",
 "WINPOWER",MB_YESNO|MB_ICONQUESTION|MB_DEFBUTTON2)!=IDYES)return;
 if(os.dwPlatformId==VER_PLATFORM_WIN32_NT) {
  if(!OpenProcessToken(GetCurrentProcess(),TOKEN_ADJUST_PRIVILEGES|TOKEN_QUERY,&token)){error(h,"Cannot open process token.");return;}
  tp.PrivilegeCount=1;tp.Privileges[0].Attributes=SE_PRIVILEGE_ENABLED;
  if(!LookupPrivilegeValueA(0,"SeShutdownPrivilege",&tp.Privileges[0].Luid)){error(h,"Cannot find shutdown privilege.");CloseHandle(token);return;}
  SetLastError(0);
  if(!AdjustTokenPrivileges(token,FALSE,&tp,sizeof(old),&old,&sz)||GetLastError()!=ERROR_SUCCESS){error(h,"Shutdown privilege is unavailable.");CloseHandle(token);return;}
  adjusted=TRUE;
 }
 /* NT3.1 has no EWX_POWEROFF contract. The final-shutdown driver supplies
    power off after an ordinary EWX_SHUTDOWN has completed. Win9x also needs
    the SHUTDOWN bit: POWEROFF alone can log off the user. */
 if(!ExitWindowsEx(reboot?EWX_REBOOT:
    (os.dwPlatformId==VER_PLATFORM_WIN32_NT&&os.dwMajorVersion<4?EWX_SHUTDOWN:
    (EWX_POWEROFF|(os.dwPlatformId==VER_PLATFORM_WIN32_WINDOWS?EWX_SHUTDOWN:0))),0))
  error(h,"Windows rejected the power request.");
 if(adjusted)AdjustTokenPrivileges(token,FALSE,&old,0,0,0);
 if(token)CloseHandle(token);
}
static HWND child(HWND h,const char *cls,const char *s,DWORD style,int x,int y,int w,int ht,int id) {
 HWND c=CreateWindowA(cls,s,WS_CHILD|WS_VISIBLE|style,x,y,w,ht,h,(HMENU)(INT_PTR)id,inst,0);
 SendMessageA(c,WM_SETFONT,(WPARAM)bodyfont,TRUE);return c;
}
static LRESULT CALLBACK proc(HWND h,UINT m,WPARAM w,LPARAM l) {
 switch(m) {
 case WM_CREATE: {
  HWND c;HDC screen=GetDC(h);int colors=GetDeviceCaps(screen,BITSPIXEL)*GetDeviceCaps(screen,PLANES);
  int group_y=compact?222:274,button_y=compact?304:360;ReleaseDC(h,screen);
  headercolor=colors<=8?RGB(0,0,128):RGB(18,41,67);
  accentcolor=colors<=8?RGB(0,128,128):RGB(33,178,181);
  headerbrush=CreateSolidBrush(headercolor);bodybrush=CreateSolidBrush(GetSysColor(COLOR_BTNFACE));
  bodyfont=CreateFontA(-14,0,0,0,FW_NORMAL,0,0,0,ANSI_CHARSET,OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,DEFAULT_QUALITY,DEFAULT_PITCH,"MS Sans Serif");
  titlefont=CreateFontA(-24,0,0,0,FW_BOLD,0,0,0,ANSI_CHARSET,OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,DEFAULT_QUALITY,DEFAULT_PITCH,"Arial");
  status_y=compact?66:78;statusbox=child(h,"STATIC","",0,46,status_y,466,compact?150:190,0);
  child(h,"BUTTON","Shutdown and reboot owner",BS_GROUPBOX,16,group_y,500,72,0);
  ownerOS=c=child(h,"BUTTON","Operating system (default)",BS_AUTORADIOBUTTON|WS_GROUP,30,group_y+18,330,22,0);
  SendMessageA(c,BM_SETCHECK,BST_CHECKED,0);
  ownerDriver=c=child(h,"BUTTON","WINPOWER driver (unavailable)",BS_AUTORADIOBUTTON,30,group_y+44,360,22,0);EnableWindow(c,FALSE);
  child(h,"BUTTON","&Power off",WS_TABSTOP|BS_OWNERDRAW,20,button_y,145,32,ID_OFF);
  child(h,"BUTTON","&Restart",WS_TABSTOP|BS_OWNERDRAW,190,button_y,145,32,ID_BOOT);
  child(h,"BUTTON","&About",WS_TABSTOP|BS_OWNERDRAW,360,button_y,145,32,ID_INFO);
  refresh();SetTimer(h,1,5000,0);return 0;
 }
 case WM_DRAWITEM: {
  LPDRAWITEMSTRUCT d=(LPDRAWITEMSTRUCT)l;
  if(d->CtlType==ODT_BUTTON&&(d->CtlID==ID_OFF||d->CtlID==ID_BOOT||d->CtlID==ID_INFO)){
   pn_button(d,inst,d->CtlID==ID_OFF?3:(d->CtlID==ID_BOOT?4:7),bodyfont,bodybrush);return TRUE;
  }break;
 }
 case WM_PAINT: {
  PAINTSTRUCT ps;HDC dc=BeginPaint(h,&ps);RECT r;HBRUSH b;
  GetClientRect(h,&r);r.bottom=compact?58:68;FillRect(dc,&r,headerbrush);
  r.top=r.bottom;r.bottom+=3;b=CreateSolidBrush(accentcolor);FillRect(dc,&r,b);DeleteObject(b);
  /* Paint header text in the same pass as its background. Older USER
     versions do not repaint unchanged static children on parent refresh. */
  {const char *subtitle="Power status and system controls  /  Preview 0.10";
   HFONT old=(HFONT)SelectObject(dc,titlefont);
   SetBkMode(dc,TRANSPARENT);SetTextColor(dc,RGB(255,255,255));
   TextOutA(dc,64,10,"WINPOWER",8);SelectObject(dc,bodyfont);
   TextOutA(dc,64,compact?34:42,subtitle,lstrlenA(subtitle));SelectObject(dc,old);
  }
  DrawIcon(dc,18,compact?13:17,LoadIconA(inst,MAKEINTRESOURCEA(1)));
  {TEXTMETRICA tm;HFONT old=(HFONT)SelectObject(dc,bodyfont);GetTextMetricsA(dc,&tm);SelectObject(dc,old);
   pn_icon(dc,LoadIconA(inst,MAKEINTRESOURCEA(acicon)),22,status_y+(compact?4:6)*tm.tmHeight,16,bodybrush);
   pn_icon(dc,LoadIconA(inst,MAKEINTRESOURCEA(batteryicon)),22,status_y+(compact?5:7)*tm.tmHeight,16,bodybrush);
  }
  EndPaint(h,&ps);return 0;
 }
 case WM_CTLCOLORSTATIC:
  /* fall through */
 case WM_CTLCOLORBTN:
  SetBkColor((HDC)w,GetSysColor(COLOR_BTNFACE));
  SetTextColor((HDC)w,GetSysColor(COLOR_BTNTEXT));
  return (LRESULT)bodybrush;
 case WM_SYSCOLORCHANGE:
  DeleteObject(bodybrush);bodybrush=CreateSolidBrush(GetSysColor(COLOR_BTNFACE));InvalidateRect(h,0,TRUE);return 0;
 case WM_SYSKEYDOWN:
  if(w=='R'){power(h,1);return 0;}
  if(w=='P'){power(h,0);return 0;}
  break;
 case WM_TIMER: refresh();return 0;
 case WM_COMMAND:
  if(LOWORD(w)==ID_OFF)power(h,0);
  if(LOWORD(w)==ID_BOOT)power(h,1);
  if(LOWORD(w)==ID_INFO)MessageBoxA(h,"WINPOWER 0.10 - Engineering preview\r\n\r\nOS-controlled shutdown/reboot and power status.\r\nN/A means unavailable or not queried; it does not prove absence.\r\nWin9x / NT3 / NT4 lab activity appears in the main window.\r\nSee STATUS.TXT for the complete support matrix.","About WINPOWER",MB_OK|MB_ICONINFORMATION);
  return 0;
 case WM_DESTROY:KillTimer(h,1);DeleteObject(titlefont);DeleteObject(bodyfont);DeleteObject(headerbrush);DeleteObject(bodybrush);PostQuitMessage(0);return 0;
 }
 return DefWindowProcA(h,m,w,l);
}
void WINAPI WinMainCRTStartup(void) {
 WNDCLASSA wc; HWND h; MSG msg; int r,x,y;RECT area,window;
 DWORD style=WS_OVERLAPPED|WS_CAPTION|WS_SYSMENU|WS_MINIMIZEBOX;
 inst=GetModuleHandleA(0);pn_osinfo(&os,osname,architecture);
 ZeroMemory(&wc,sizeof(wc));wc.lpfnWndProc=proc;wc.hInstance=inst;wc.hCursor=LoadCursorA(0,IDC_ARROW);
 wc.hIcon=LoadIconA(inst,MAKEINTRESOURCEA(1));wc.hbrBackground=(HBRUSH)(COLOR_BTNFACE+1);wc.lpszClassName="WINPOWER";
 if(!RegisterClassA(&wc))ExitProcess(1);
 area.left=area.top=0;area.right=GetSystemMetrics(SM_CXSCREEN);area.bottom=GetSystemMetrics(SM_CYSCREEN);
 if(os.dwMajorVersion>=4){RECT work;if(SystemParametersInfoA(SPI_GETWORKAREA,0,&work,0))area=work;}
 compact=area.bottom-area.top<440;
 window.left=window.top=0;window.right=532;window.bottom=compact?346:410;
 AdjustWindowRect(&window,style,FALSE);window.right-=window.left;window.bottom-=window.top;
 x=area.left+(area.right-area.left-window.right)/2;y=area.top+(area.bottom-area.top-window.bottom)/2;
 if(x<area.left)x=area.left;
 if(y<area.top)y=area.top;
 h=CreateWindowA("WINPOWER","WINPOWER - Power Center",style,x,y,window.right,window.bottom,0,0,inst,0);
 if(!h)ExitProcess(2);
 ShowWindow(h,SW_SHOW);UpdateWindow(h);
 while((r=GetMessageA(&msg,0,0,0))>0){if(!IsDialogMessageA(h,&msg)){TranslateMessage(&msg);DispatchMessageA(&msg);}}
 ExitProcess(r<0?3:(UINT)msg.wParam);
}
