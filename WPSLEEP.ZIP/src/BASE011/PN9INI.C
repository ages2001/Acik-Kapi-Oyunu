#include "PN9INI.H"
static unsigned lower(unsigned c){return c>='A'&&c<='Z'?c+32:c;}
static int equal(const char *a,unsigned n,const char *b){
 unsigned i;for(i=0;i<n;i++)if(!b[i]||lower((unsigned char)a[i])!=lower((unsigned char)b[i]))return 0;
 return !b[n];
}
static int space(char c){return c==' '||c=='\t'||c=='\r';}
static unsigned length(const char *p){unsigned n=0;while(p[n])n++;return n;}
static void copy(char *d,const char *s,unsigned n){while(n--)*d++=*s++;}
int pn9_ini(const char *in,unsigned size,char *out,unsigned cap,
            const char *driver,int remove,unsigned *written){
 unsigned p=0,start,end,a,b,q,v,section=0,sections=0,insert=0,own=0,any=0;
 unsigned erase=0,eraseend=0,dl,extra,i,newline=0;
 if(!in||!out||!written||!driver||in==out)return -1;
 dl=length(driver);if(!dl||dl>240||size>65535)return -1;
 for(i=0;i<size;i++)if(!in[i])return -1;
 for(i=0;i<dl;i++)if(driver[i]=='\r'||driver[i]=='\n'||driver[i]=='"'||driver[i]==';')return -1;
 while(p<size){
  start=p;while(p<size&&in[p]!='\n')p++;end=p;if(p<size)p++;
  a=start;b=end;while(a<b&&space(in[a]))a++;while(b>a&&space(in[b-1]))b--;
  if(a==b||in[a]==';')continue;
  if(in[a]=='['){
   q=a+1;while(q<b&&in[q]!=']')q++;
   if(q==b)return -3;
   section=equal(in+a+1,q-a-1,"386enh");
   if(section){if(++sections>1)return -3;insert=p;newline=p==end;}
   continue;
  }
  if(!section)continue;
  q=a;while(q<b&&in[q]!='=')q++;if(q==b)continue;
  v=q;while(v>a&&space(in[v-1]))v--;if(!equal(in+a,v-a,"device"))continue;
  a=q+1;while(a<b&&space(in[a]))a++;
  /* INI comments are entire lines. Inline suffixes are not interpreted. */
  if(b>a+1&&in[a]=='"'&&in[b-1]=='"'){a++;b--;}
  v=b;while(v>a&&in[v-1]!='\\'&&in[v-1]!='/')v--;
  if(equal(in+v,b-v,"pn9hook.vxd")||equal(in+a,b-a,"*pn9hook"))any++;
  if(equal(in+a,b-a,driver)){if(++own>1)return -4;erase=start;eraseend=p;}
 }
 if(sections!=1)return -3;
 if(remove){
  if(!own){if(size>cap)return -5;copy(out,in,size);*written=size;return 2;}
  extra=eraseend-erase;if(size-extra>cap)return -5;
  copy(out,in,erase);copy(out+erase,in+eraseend,size-eraseend);*written=size-extra;return 1;
 }
 if(any||own)return -2;
 extra=7+dl+2+(newline?2:0);
 if(size>cap||extra>cap-size||size+extra>65535)return -5;
 copy(out,in,insert);p=insert;
 if(newline){out[p++]='\r';out[p++]='\n';}
 copy(out+p,"device=",7);p+=7;copy(out+p,driver,dl);p+=dl;out[p++]='\r';out[p++]='\n';
 copy(out+p,in+insert,size-insert);*written=size+extra;return 1;
}
