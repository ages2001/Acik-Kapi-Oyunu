"""Create and verify WINPOWER release ZIPs without rebuilding binaries.

Usage: python3 SRC/PACK.PY OUTPUT_DIR [INITIAL_IMAGE_DIR]
The optional image directory contains WIN101.ZIP, WIN203.ZIP, WIN211.ZIP.
"""
from pathlib import Path
import hashlib,json,re,subprocess,sys,zipfile

root=Path(__file__).resolve().parent.parent
output=Path(sys.argv[1]).resolve()
images=Path(sys.argv[2]).resolve() if len(sys.argv)>2 else None
output.mkdir(parents=True,exist_ok=True)
assert output!=root and root not in output.parents,'Keep release archives outside the project.'
def sha(path):
    digest=hashlib.sha256()
    with path.open('rb') as stream:
        while chunk:=stream.read(1024*1024):digest.update(chunk)
    return digest.hexdigest()
def names(name):
    assert all(re.fullmatch(r'[A-Z0-9_]{1,8}(\.[A-Z0-9_]{1,3})?',part) for part in name.split('/')),name
def manifest(items):
    return ''.join(digest+'  '+name+'\r\n' for name,digest in sorted(items.items())).encode('ascii')
def verify_zip(path):
    with zipfile.ZipFile(path) as archive:
        assert len(archive.namelist())==len(set(archive.namelist()))
        for name in archive.namelist():names(name)
        expected=dict(line.split('  ',1)[::-1] for line in archive.read('SHA256.TXT').decode('ascii').splitlines())
        assert set(expected)==set(archive.namelist())-{'SHA256.TXT'}
        for name,digest in expected.items():
            actual=hashlib.sha256()
            with archive.open(name) as stream:
                while chunk:=stream.read(1024*1024):actual.update(chunk)
            assert actual.hexdigest()==digest,(path.name,name)

subprocess.run([sys.executable,str(root/'TEST/VERIFY.PY')],check=True)
for p in root.rglob('*.TXT'):
    if p.name!='SHA256.TXT':p.write_bytes(p.read_text().replace('\n','\r\n').encode('ascii'))
files=sorted(p for p in root.rglob('*') if p.is_file() and p!=root/'SHA256.TXT')
hashes={str(p.relative_to(root)):sha(p) for p in files}
(root/'SHA256.TXT').write_bytes(manifest(hashes))
files.append(root/'SHA256.TXT')
project={root.name+'/'+str(p.relative_to(root)):p for p in files}

def build(path,entries,readme=None):
    temporary=path.with_suffix('.TMP');checks={}
    with zipfile.ZipFile(temporary,'w',zipfile.ZIP_DEFLATED,compresslevel=9,allowZip64=False) as archive:
        for name,p in sorted(entries.items()):
            names(name);archive.write(p,name);checks[name]=sha(p)
        if readme:
            data=readme.replace('\n','\r\n').encode('ascii')
            archive.writestr('README.TXT',data);checks['README.TXT']=hashlib.sha256(data).hexdigest()
        archive.writestr('SHA256.TXT',manifest(checks))
    verify_zip(temporary);temporary.replace(path)
    print(path.name,path.stat().st_size,'bytes',sha(path),flush=True)

build(output/'WINPOWER.ZIP',project)
delivered=[output/'WINPOWER.ZIP']
if images:
    expected=json.loads((root/'TEST/IMAGES.JSN').read_text())
    entries=dict(project)
    for name in ['WIN101.ZIP','WIN203.ZIP','WIN211.ZIP']:
        p=images/name;assert sha(p)==expected[name]['sha256'],name
        verify_zip(p);entries['IMAGES/'+name]=p
    readme='''WINPOWER 0.11 - PROJECT AND INITIAL OS IMAGES

WINPOWER/ contains BIN, SRC, TEST, English status reports and checksums.
Read WINPOWER/CURRENT.TXT and STATUS.TXT before using the binaries.
This is an unfinished engineering preview, not a universal ACPI/APM driver.
Active OS ACPI ownership handoff and full firmware support are incomplete.

IMAGES/WIN101.ZIP, WIN203.ZIP and WIN211.ZIP contain the initial installed
OS snapshots requested by the user, built from the supplied media on
separate DOS disk copies. Each has a raw IDE disk, screenshot, launch
script, README and checksums. No WINPOWER installation is in those images.
Win1.01 and Win2.03 use SETVER 3.30. The initial Win2.11 image retains its
original WIN200.BIN 3.40 entry: requested 3.30 failed OS startup on the
test copy. Current Win2.11 power tests used 3.40 and explicit WIN.COM
preparation; see WINPOWER/TEST/WIN16.TXT. Raw initial images are unchanged.

Windows 2000 tests used AHCI; every other guest used IDE. Experimental
test disks, original uploaded split archives and third-party compilers
are not duplicated here. The package has 54 actual guest power events
with binary provenance; this is not an exhaustive compatibility matrix.
All authored archive paths follow uppercase 8.3 naming.
'''
    build(output/'ALLFILES.ZIP',entries,readme);delivered.append(output/'ALLFILES.ZIP')
(output/'SHA256.TXT').write_bytes(manifest({p.name:sha(p) for p in delivered}))
print('PASS: archive CRC reads, member hashes, 8.3 paths and initial-image manifests')
