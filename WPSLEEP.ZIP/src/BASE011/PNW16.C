#include <windows.h>
#include <dos.h>
#include "OSNAME.H"
#include "ICONUI.H"
#include "PNLINK.H"
UINT pn_exec(LPCSTR command);
BOOL pn_icons(HWND,HINSTANCE,LPCSTR,BOOL);
#if defined(PN_WIN1) || defined(PN_WIN2)
/* Win1/2 export the original four-byte ExitWindows entry at USER ordinal 2. */
BOOL FAR PASCAL OldExitWindows(UINT,UINT);
#define ExitWindows OldExitWindows
#endif
static HINSTANCE instance;
static HWND panel;
static HBRUSH face;
static char status[400];
static unsigned api_ver;
static unsigned pending;
static unsigned batteryicon=5,acicon=6;
static HWND buttons[4];
static BOOL supervised;
static char statepath[144];
static BOOL installed;
static unsigned acpirev=0xffff,fadtrev,fadtminor,capflags;
static BOOL session(unsigned action,BOOL startup){
 HFILE f;static struct pn_state state;unsigned n;
 if(!statepath[0]){
  if(!GetModuleFileName(instance,statepath,sizeof(statepath)))return FALSE;
  n=lstrlen(statepath);while(n&&statepath[n-1]!='\\'&&statepath[n-1]!=':')n--;
  if(n>125)return FALSE;lstrcpy(statepath+n,PN_STATE);
 }
 f=_lopen(statepath,OF_READWRITE);if(f==HFILE_ERROR)return FALSE;
 if(_lread(f,(LPSTR)&state,sizeof(state))!=sizeof(state)||!pn_valid(&state)){_lclose(f);return FALSE;}
 if(!startup&&state.ready!=1){_lclose(f);return FALSE;}
 if(startup){acpirev=state.acpi_rev;fadtrev=state.fadt_rev;fadtminor=state.fadt_minor;capflags=state.cap_flags;}
 state.ready=1;state.action=action;_llseek(f,0,0);
 n=_lwrite(f,(LPSTR)&state,sizeof(state));if(_lclose(f)==HFILE_ERROR)return FALSE;return n==sizeof(state);
}
static BOOL icons(HWND h,BOOL remove){
 static char directory[144],marker[160];unsigned n;HFILE f;OFSTRUCT of;
 if(LOBYTE(LOWORD(GetVersion()))<3||!installed)return FALSE;
 lstrcpy(directory,statepath);n=lstrlen(directory);while(n&&directory[n-1]!='\\')n--;
 if(!n)return FALSE;directory[n-1]=0;lstrcpy(marker,directory);lstrcat(marker,"\\PNICONS.ID");
 if(!remove){f=_lopen(marker,OF_READ);if(f!=HFILE_ERROR){_lclose(f);return TRUE;}}
 if(remove){
  BOOL ok=pn_icons(h,instance,directory,TRUE);
  /* A partial DDE removal must not suppress recreation after a veto. */
  OpenFile(marker,&of,OF_DELETE);return ok;
 }
 if(!pn_icons(h,instance,directory,FALSE))return FALSE;
 f=_lcreat(marker,0);if(f!=HFILE_ERROR){_lwrite(f,"PNICONS5",8);_lclose(f);}
 return TRUE;
}
static unsigned buttonicon(unsigned id){return id==101?(pending==3?2:(pending==2?4:3)):(id==102?(pending?2:4):(id==103?4:7));}
/* Windows 2.x has no BS_OWNERDRAW. A small window class provides the same
   keyboard/mouse behavior and shared artwork without that control style. */
long FAR PASCAL __export ButtonProc(HWND h,UINT m,WPARAM w,LPARAM l) {
 switch(m){
 case WM_PAINT:{
  PAINTSTRUCT ps;DRAWITEMSTRUCT d;unsigned id=GetWindowWord(h,GWW_ID);
  d.CtlType=ODT_BUTTON;d.CtlID=id;d.itemID=0;d.itemAction=ODA_DRAWENTIRE;
  d.itemState=(GetFocus()==h?ODS_FOCUS:0)|(GetWindowWord(h,0)?ODS_SELECTED:0)|(!IsWindowEnabled(h)?ODS_DISABLED:0);
  d.hwndItem=h;d.hDC=BeginPaint(h,&ps);GetClientRect(h,&d.rcItem);
  pn_button(&d,instance,buttonicon(id),(HFONT)GetStockObject(SYSTEM_FONT),face);
  EndPaint(h,&ps);return 0;
 }
 case WM_SETFOCUS:case WM_KILLFOCUS:InvalidateRect(h,0,TRUE);return 0;
 case WM_LBUTTONDOWN:SetFocus(h);SetCapture(h);SetWindowWord(h,0,1);InvalidateRect(h,0,TRUE);return 0;
 case WM_LBUTTONUP:{
  RECT r;POINT p;int pressed=GetWindowWord(h,0);
  SetWindowWord(h,0,0);ReleaseCapture();InvalidateRect(h,0,TRUE);
  p.x=(short)LOWORD(l);p.y=(short)HIWORD(l);GetClientRect(h,&r);
  if(pressed&&PtInRect(&r,p))SendMessage(GetParent(h),WM_COMMAND,GetWindowWord(h,GWW_ID),0);
  return 0;
 }
 case WM_KEYDOWN:
  if(w==VK_ESCAPE&&pending){SendMessage(GetParent(h),WM_COMMAND,102,0);return 0;}
  if(w==VK_SPACE){SetWindowWord(h,0,1);InvalidateRect(h,0,TRUE);return 0;}
  if(w==VK_RETURN){SendMessage(GetParent(h),WM_COMMAND,GetWindowWord(h,GWW_ID),0);return 0;}
  if(w==VK_TAB){int i=(int)GetWindowWord(h,GWW_ID)-101;do{i=(i+((GetKeyState(VK_SHIFT)<0)?3:1))%4;}while(!IsWindowEnabled(buttons[i]));SetFocus(buttons[i]);return 0;}
  break;
 case WM_KEYUP:
  if(w==VK_SPACE&&GetWindowWord(h,0)){SetWindowWord(h,0,0);InvalidateRect(h,0,TRUE);SendMessage(GetParent(h),WM_COMMAND,GetWindowWord(h,GWW_ID),0);return 0;}
  break;
 }
 return DefWindowProc(h,m,w,l);
}
/* GetVersion on Windows 1.01 returns 1.0. The installed Executive's
   version text in WIN100.OVL distinguishes these early maintenance releases.
   OpenFile searches the Windows directory. Reject conflicting version texts. */
static unsigned win1minor(void) {
 OFSTRUCT info;HFILE f;char block[512];unsigned got,i,match=0,minor=0;
 static char prefix[]="Version 1.0";
 f=OpenFile("WIN100.OVL",&info,OF_READ);
 if(f==HFILE_ERROR)return 0;
 while((got=_lread(f,block,sizeof(block)))!=0 && got!=(unsigned)-1){
  for(i=0;i<got;i++){
   char c=block[i];
   if(match<11){if(c==prefix[match])match++;else match=(c=='V');}
   else {
    if(c>='1'&&c<='4'){
     unsigned value=(unsigned)(c-'0');
     if(minor&&minor!=value){_lclose(f);return 0;}
     minor=value;
    }
    match=(c=='V');
   }
  }
 }
 _lclose(f);return minor;
}
static void number(unsigned value){
 char text[4];unsigned n=0;if(value>=100)text[n++]='0'+value/100;
 if(value>=10)text[n++]='0'+(value/10)%10;text[n++]='0'+value%10;text[n]=0;lstrcat(status,text);
}
static void apmtext(void) {
 union REGS in,out; char v[8]; unsigned ver=0;
 in.w.ax=0x5300;in.w.bx=0;int86(0x15,&in,&out);
 {
 DWORD version=GetVersion();unsigned major=LOBYTE(LOWORD(version)),minor=HIBYTE(LOWORD(version));
 api_ver=LOWORD(version);
 if(major==1&&minor==0)minor=win1minor();
 lstrcpy(status,(major==1&&minor==0)?"Windows 1.x (API 1.0)":pn_osname(0,major,minor,0,0));
 lstrcat(status,"\r\nOS environment: 16-bit | Application: 16-bit\r\n\r\nACPI: ");
 if(acpirev==0xffff)lstrcat(status,"N/A");
 else {lstrcat(status,"RSDP ");number(acpirev);lstrcat(status," / FADT ");
  if(fadtrev){number(fadtrev);lstrcat(status,".");number(fadtminor);}else lstrcat(status,"N/A");}
 lstrcat(status,"\r\nAPM BIOS version: ");
 }
 if(out.w.cflag || out.w.bx!=0x504d)lstrcat(status,"N/A");
 else {
  ver=out.w.ax;v[0]='0'+((ver>>12)&15);v[1]='0'+((ver>>8)&15);v[2]='.';
  v[3]='0'+((ver>>4)&15);v[4]='0'+(ver&15);v[5]=0;lstrcat(status,v);
 }
 lstrcat(status,"\r\n\r\nBattery: ");
 in.w.ax=0x530a;in.w.bx=1;in.w.cx=0;int86(0x15,&in,&out);batteryicon=5;acicon=6;
 if(out.w.cflag)lstrcat(status,"N/A");
 else if(out.h.bl==0x80||(ver>=0x101&&out.h.ch!=255&&(out.h.ch&0x80))){lstrcat(status,"Not present");batteryicon=8;}
 else if(out.h.cl<=100){
  unsigned pct=out.h.cl;char number[5];unsigned n=0;
  if(pct==100)number[n++]='1';
  if(pct>=10)number[n++]='0'+((pct/10)%10);
  number[n++]='0'+pct%10;number[n++]='%';number[n]=0;lstrcat(status,number);
  if(out.h.bl==3){lstrcat(status," (charging)");batteryicon=9;}
  else if(out.h.bl==2)lstrcat(status," (critical)");
  else if(out.h.bl==1)lstrcat(status," (low)");
 }else lstrcat(status,"N/A");
 lstrcat(status,"\r\nAC power: ");
 if(out.w.cflag||out.h.bh==255)lstrcat(status,"N/A");
 else if(out.h.bh==1)lstrcat(status,"Online");
 else if(out.h.bh==0){lstrcat(status,"Offline");acicon=10;}
 else if(out.h.bh==2)lstrcat(status,"Backup power");
 else lstrcat(status,"N/A");
 lstrcat(status,"\r\n\r\n");
 if(!supervised)lstrcat(status,"Start Windows using WPWRDOS for power control.");
 else lstrcat(status,(capflags&1)?"Shutdown owner: WINPOWER DOS/ACPI-first":"Shutdown owner: WINPOWER DOS/APM");
 lstrcat(status,(capflags&1)?"\r\nACPI power control: Static S5":"\r\nACPI power control: Unavailable");
}
long FAR PASCAL __export PanelProc(HWND h,UINT m,WPARAM w,LPARAM l){
 if(m==WM_PAINT){
  PAINTSTRUCT ps;TEXTMETRIC tm;HDC dc=BeginPaint(h,&ps);unsigned i=0,start=0;int y=0;
  GetTextMetrics(dc,&tm);SetBkMode(dc,TRANSPARENT);SetTextColor(dc,RGB(0,0,0));
  while(status[i]){
   if(status[i]=='\r'||status[i]=='\n'){
    TextOut(dc,0,y,status+start,i-start);y+=tm.tmHeight+tm.tmExternalLeading;
    if(status[i]=='\r'&&status[i+1]=='\n')i++;start=++i;
   }else i++;
  }
  if(i>start)TextOut(dc,0,y,status+start,i-start);
  EndPaint(h,&ps);return 0;
 }
 return DefWindowProc(h,m,w,l);
}
static void confirm(HWND h,unsigned action){
 pending=action;
 SetWindowText(buttons[0],action==3?"Remove":(action==2?"Restart":"Power off"));
 SetWindowText(buttons[1],action?"Cancel":"Restart");
 EnableWindow(buttons[2],!action);EnableWindow(buttons[3],!action);
 ShowWindow(buttons[2],action?SW_HIDE:SW_SHOWNORMAL);ShowWindow(buttons[3],action?SW_HIDE:SW_SHOWNORMAL);
 if(action){
  lstrcpy(status,action==3?"Remove WINPOWER and end Windows?":(action==1?"Power off this computer?":"Restart this computer?"));
  lstrcat(status,"\r\n\r\nSave your work before confirming.\r\nWindows will ask applications to close.\r\n\r\nWINPOWER acts only after Windows exits.");
 }else apmtext();
 InvalidateRect(panel,0,TRUE);InvalidateRect(h,0,TRUE);
 InvalidateRect(buttons[0],0,TRUE);InvalidateRect(buttons[1],0,TRUE);
 SetFocus(buttons[action?1:0]);
 if(action&&LOBYTE(LOWORD(GetVersion()))==1){
  SetActiveWindow(h);PostMessage(h,WM_SYSCOMMAND,SC_MAXIMIZE,0L);
 }
}
long FAR PASCAL __export WindowProc(HWND h,UINT m,WPARAM w,LPARAM l) {
 switch(m){
 case WM_CREATE:
  face=CreateSolidBrush(LOBYTE(LOWORD(GetVersion()))<3?RGB(255,255,255):RGB(192,192,192));
  CreateWindow("STATIC","WINPOWER - Power Center",WS_CHILD|WS_VISIBLE,58,16,340,24,h,0,instance,0);
  panel=CreateWindow("PNPANEL","",WS_CHILD|WS_VISIBLE,40,46,406,190,h,0,instance,0);
  buttons[0]=CreateWindow("PNBUTTON","Power off",WS_CHILD|WS_VISIBLE|WS_TABSTOP,12,250,116,28,h,(HMENU)101,instance,0);
  buttons[1]=CreateWindow("PNBUTTON","Restart",WS_CHILD|WS_VISIBLE|WS_TABSTOP,134,250,108,28,h,(HMENU)102,instance,0);
  buttons[2]=CreateWindow("PNBUTTON","Refresh",WS_CHILD|WS_VISIBLE|WS_TABSTOP,248,250,100,28,h,(HMENU)103,instance,0);
  buttons[3]=CreateWindow("PNBUTTON","About",WS_CHILD|WS_VISIBLE|WS_TABSTOP,354,250,78,28,h,(HMENU)104,instance,0);
  supervised=session(0,TRUE);
  {char marker[144];unsigned n=lstrlen(statepath);HFILE f;
   lstrcpy(marker,statepath);while(n&&marker[n-1]!='\\')n--;lstrcpy(marker+n,"WINPWR16.ID");
   f=_lopen(marker,OF_READ);installed=f!=HFILE_ERROR;if(installed)_lclose(f);
  }
  EnableWindow(buttons[0],supervised);EnableWindow(buttons[1],supervised);
  apmtext();InvalidateRect(panel,0,TRUE);
  if(installed&&LOBYTE(LOWORD(GetVersion()))>=3)SetTimer(h,5,3000,0);return 0;
 case WM_TIMER:if(w==5){KillTimer(h,5);icons(h,FALSE);}return 0;
 case WM_DRAWITEM: {
  LPDRAWITEMSTRUCT d=(LPDRAWITEMSTRUCT)l;
  if(d->CtlType==ODT_BUTTON){pn_button(d,instance,buttonicon(d->CtlID),(HFONT)GetStockObject(SYSTEM_FONT),face);return TRUE;}
  break;
 }
 case WM_PAINT: {
  PAINTSTRUCT ps;TEXTMETRIC tm;HDC dc=BeginPaint(h,&ps);int line;
  GetTextMetrics(dc,&tm);line=tm.tmHeight+tm.tmExternalLeading;
  pn_pixel(dc,1,16,10,32);if(!pending){pn_pixel(dc,batteryicon,16,46+6*line,16);pn_pixel(dc,acicon,16,46+7*line,16);}
  EndPaint(h,&ps);return 0;
 }
 case WM_KEYDOWN:if(w==VK_TAB){SetFocus(buttons[supervised?0:2]);return 0;}break;
 case WM_COMMAND:
  if(w==103){apmtext();InvalidateRect(panel,0,TRUE);}
  if((w==101||w==102)&&supervised){
   if(!pending)confirm(h,w==101?1:2);
   else if(w==102)confirm(h,0);
   else {
    if(!session(pending,FALSE))MessageBox(h,"Cannot update the DOS supervisor.","WINPOWER",MB_OK|MB_ICONEXCLAMATION);
    else {
     BOOL removing=pending==3;
     if(removing)icons(h,TRUE);
     if(!ExitWindows(0,0)){session(0,FALSE);confirm(h,0);if(removing)icons(h,FALSE);MessageBox(h,"Windows did not end the session.","WINPOWER",MB_OK|MB_ICONEXCLAMATION);}
    }
   }
  }
  if(w==104)MessageBox(h,"WINPOWER 0.10 - DOS ACPI/APM session power control.","About WINPOWER",MB_OK);
  return 0;
 case WM_USER+5:
  if(installed&&supervised)confirm(h,3);
  else MessageBox(h,"No supervised installation was found.","WINPOWER",MB_OK);
  return 0;
 case WM_QUERYENDSESSION:return TRUE;
 case WM_DESTROY:DeleteObject(face);PostQuitMessage(0);return 0;
 }
 return DefWindowProc(h,m,w,l);
}
int PASCAL WinMain(HINSTANCE h,HINSTANCE prev,LPSTR cmd,int show) {
 WNDCLASS c;HWND win;MSG msg;FARPROC thunk,button_thunk,panel_thunk;
 (void)show;instance=h;
 win=0;
#ifdef PN_UNINST
 win=FindWindow(0,"WINPOWER");
#else
 if(prev)win=FindWindow(0,"WINPOWER");
#endif
 if(win){ShowWindow(win,SW_SHOWNORMAL);SetActiveWindow(win);
#ifdef PN_UNINST
  PostMessage(win,WM_USER+5,0,0);
#endif
  return 0;
 }
 thunk=MakeProcInstance((FARPROC)WindowProc,h);
 button_thunk=MakeProcInstance((FARPROC)ButtonProc,h);
 panel_thunk=MakeProcInstance((FARPROC)PanelProc,h);
 if(!prev){
  c.style=0;c.lpfnWndProc=(WNDPROC)thunk;c.cbClsExtra=0;c.cbWndExtra=0;c.hInstance=h;
  c.hIcon=LOBYTE(LOWORD(GetVersion()))<3?0:LoadIcon(h,MAKEINTRESOURCE(
#ifdef PN_UNINST
  2
#else
  1
#endif
  ));c.hCursor=LoadCursor(0,IDC_ARROW);
  /* Win1 needs a real brush handle, not the later COLOR_xxx+1 shortcut. */
  c.hbrBackground=(HBRUSH)GetStockObject(WHITE_BRUSH);c.lpszMenuName=0;c.lpszClassName="WINPOWER";
  if(!RegisterClass(&c))return 1;
  c.lpfnWndProc=(WNDPROC)button_thunk;c.cbWndExtra=2;c.hIcon=0;c.lpszClassName="PNBUTTON";
  if(!RegisterClass(&c))return 1;
  c.lpfnWndProc=(WNDPROC)panel_thunk;c.cbWndExtra=0;c.lpszClassName="PNPANEL";
  if(!RegisterClass(&c))return 1;
 }
 win=CreateWindow("WINPOWER","WINPOWER",WS_OVERLAPPEDWINDOW,20,20,460,330,0,0,h,0);
 if(!win)return 2;ShowWindow(win,SW_SHOWNORMAL);UpdateWindow(win);
#ifdef PN_UNINST
 PostMessage(win,WM_USER+5,0,0);
#else
 if(cmd[0]=='/'&&cmd[1]=='R'&&cmd[2]=='U'&&cmd[3]=='N'&&cmd[4]==' '){
  if(pn_exec(cmd+5)<32)MessageBox(win,"The requested application could not be started.","WINPOWER",MB_OK);
 }
#endif
 while(GetMessage(&msg,0,0,0)){TranslateMessage(&msg);DispatchMessage(&msg);}
 FreeProcInstance(panel_thunk);FreeProcInstance(button_thunk);FreeProcInstance(thunk);return msg.wParam;
}
