/* Persistent legacy NT installation, with owned-state rollback and removal. */
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include "NTSET.H"
#include "NTPWR.H"
static char reason[300];
static DWORD kind;
static BOOL copied_service,copied_driver,created_meta,created_service,created_kernel,saved_value;
static BOOL fail(const char *step,DWORD error){wsprintfA(reason,"%s\r\nWindows error: %lu",step,error);return FALSE;}
const char *nt_reason(void){return reason[0]?reason:"Installation did not complete.";}
void nt_error(const char *step,DWORD error){fail(step,error);}
static DWORD absent_service(SC_HANDLE manager,const char *name){
 SC_HANDLE service=OpenServiceA(manager,name,SERVICE_QUERY_STATUS);DWORD error;
 if(service){CloseServiceHandle(service);return ERROR_SERVICE_EXISTS;}
 error=GetLastError();return error==ERROR_SERVICE_DOES_NOT_EXIST?0:error;
}
BOOL nt_preflight(void){
 SC_HANDLE manager;HKEY key;DWORD error,words[12];
 kind=wp_kind();if(!kind)return fail("This power package requires Windows NT 3.x or NT 4 x86.",ERROR_NOT_SUPPORTED);
 error=RegOpenKeyExA(HKEY_LOCAL_MACHINE,WP_META,0,KEY_QUERY_VALUE,&key);
 if(!error){RegCloseKey(key);return fail("A WINPOWER startup installation already exists. Remove it first.",ERROR_ALREADY_EXISTS);}
 if(error!=ERROR_FILE_NOT_FOUND)return fail("Cannot inspect the startup installation record.",error);
 manager=OpenSCManagerA(0,0,SC_MANAGER_CREATE_SERVICE);if(!manager)return fail("Administrative access is required to install the startup service.",GetLastError());
 error=absent_service(manager,WP_SERVICE);
 if(!error)error=absent_service(manager,"PN3LAB");
 if(!error)error=absent_service(manager,"PN4LAB");
 CloseServiceHandle(manager);
 if(error)return fail("A related service already exists or is pending deletion. Remove the earlier installation and restart.",error);
 error=wp_backend(kind,words);
 if(error!=ERROR_FILE_NOT_FOUND&&error!=ERROR_PATH_NOT_FOUND)return fail("An existing kernel backend may still be active. Restart before installing.",ERROR_BUSY);
 return TRUE;
}
BOOL nt_stage(const char *self,const char *folder){
 char source[MAX_PATH],target[MAX_PATH];int i;DWORD error;
 if(!wp_folder(folder))return fail("Invalid destination directory.",ERROR_INVALID_NAME);
 if(lstrlenA(self)>=MAX_PATH)return fail("Source directory is too long.",ERROR_FILENAME_EXCED_RANGE);
 lstrcpyA(source,self);for(i=lstrlenA(source)-1;i>=0&&source[i]!='\\';i--){}
 if(i<0||i>MAX_PATH-18)return fail("Source directory is too long.",ERROR_FILENAME_EXCED_RANGE);
 lstrcpyA(source+i+1,"WINPSVC.EXE");wp_path(target,folder,"WINPSVC.EXE");
 if(!CopyFileA(source,target,TRUE))return fail("Cannot copy the startup service.",GetLastError());copied_service=TRUE;
 lstrcpyA(source+i+1,wp_driver(kind));wp_path(target,folder,wp_driver(kind));
 if(!CopyFileA(source,target,TRUE)){error=GetLastError();return fail("Cannot copy the selected kernel backend.",error);}copied_driver=TRUE;return TRUE;
}
static DWORD stop_service(SC_HANDLE service){
 SERVICE_STATUS state;DWORD start=GetTickCount(),error;BOOL requested=FALSE;
 for(;;){
  if(!QueryServiceStatus(service,&state))return GetLastError();
  if(state.dwCurrentState==SERVICE_STOPPED)return 0;
  if(!requested&&state.dwCurrentState==SERVICE_RUNNING){
   if(!ControlService(service,SERVICE_CONTROL_STOP,&state)){error=GetLastError();if(error!=ERROR_SERVICE_NOT_ACTIVE)return error;}
   requested=TRUE;
  }
  if(GetTickCount()-start>=20000)return ERROR_TIMEOUT;Sleep(100);
 }
}
static DWORD disable(SC_HANDLE service){
 if(!ChangeServiceConfigA(service,SERVICE_NO_CHANGE,SERVICE_DISABLED,SERVICE_NO_CHANGE,0,0,0,0,0,0,0)){
  DWORD error=GetLastError();return error==ERROR_SERVICE_MARKED_FOR_DELETE?0:error;
 }return 0;
}
static DWORD delete_service(SC_HANDLE service){
 if(!DeleteService(service)){DWORD error=GetLastError();return error==ERROR_SERVICE_MARKED_FOR_DELETE?0:error;}return 0;
}
BOOL nt_install(const char *folder){
 struct wp_config cfg;struct wp_regvalue value;HKEY meta=0,winlogon=0;SC_HANDLE manager=0,kernel=0,loader=0;
 DWORD error=0,disp,size,stage=0,last=0;unsigned i;char path[MAX_PATH],command[MAX_PATH+2];SERVICE_STATUS state;
 ZeroMemory(&cfg,sizeof(cfg));cfg.magic=WP_CONFIG_MAGIC;cfg.kind=kind;lstrcpyA(cfg.folder,folder);
 for(i=0;i<4;i++){wp_path(path,folder,wp_file(kind,i));error=wp_hash(path,cfg.hashes[i],0);if(error)goto done;}
 error=RegCreateKeyExA(HKEY_LOCAL_MACHINE,WP_META,0,0,0,KEY_QUERY_VALUE|KEY_SET_VALUE,0,&meta,&disp);if(error)goto done;
 if(disp!=REG_CREATED_NEW_KEY){error=ERROR_ALREADY_EXISTS;goto done;}created_meta=TRUE;
 error=RegSetValueExA(meta,"Config",0,REG_BINARY,(BYTE*)&cfg,sizeof(cfg));if(error)goto done;
 if(kind==4){
  error=RegOpenKeyExA(HKEY_LOCAL_MACHINE,"Software\\Microsoft\\Windows NT\\CurrentVersion\\Winlogon",0,KEY_QUERY_VALUE,&winlogon);if(error)goto done;
  error=wp_regread(winlogon,&value);RegCloseKey(winlogon);winlogon=0;if(error)goto done;
  error=RegSetValueExA(meta,"PowerBefore",0,REG_BINARY,(BYTE*)&value,sizeof(value));if(error)goto done;saved_value=TRUE;
 }
 if((error=wp_setnum(meta,"Removing",0))||(error=wp_setnum(meta,"Starts",0))||
    (error=wp_setnum(meta,"LastError",0))||(error=wp_setnum(meta,"Stage",0))||
    (error=wp_setnum(meta,"Ready",1))||(error=RegFlushKey(meta)))goto done;
 manager=OpenSCManagerA(0,0,SC_MANAGER_CREATE_SERVICE);if(!manager){error=GetLastError();goto done;}
 wp_path(path,folder,wp_driver(kind));
 kernel=CreateServiceA(manager,wp_kernel(kind),kind==3?"WINPOWER NT3 final power":"WINPOWER NT4 final power",SERVICE_ALL_ACCESS,SERVICE_KERNEL_DRIVER,SERVICE_DEMAND_START,SERVICE_ERROR_NORMAL,path,0,0,0,0,0);
 if(!kernel){error=GetLastError();goto done;}created_kernel=TRUE;
 /* The fixed 8.3 path has no spaces. NT 3.1/3.50 SCM does not reliably
    accept a quoted executable path here. */
 wp_path(path,folder,"WINPSVC.EXE");lstrcpyA(command,path);
 loader=CreateServiceA(manager,WP_SERVICE,"WINPOWER startup",SERVICE_ALL_ACCESS,SERVICE_WIN32_OWN_PROCESS,SERVICE_AUTO_START,SERVICE_ERROR_NORMAL,command,0,0,0,0,0);
 if(!loader){error=GetLastError();goto done;}created_service=TRUE;
 if(!StartServiceA(loader,0,0)){error=GetLastError();goto done;}
 size=GetTickCount();
 for(;;){
  if(!QueryServiceStatus(loader,&state)){error=GetLastError();break;}
  if(state.dwCurrentState==SERVICE_RUNNING){
   error=wp_getnum(meta,"Stage",&stage);if(error)break;
   if(stage==6)break;
  }
  if(state.dwCurrentState==SERVICE_STOPPED){error=state.dwWin32ExitCode?state.dwWin32ExitCode:ERROR_SERVICE_NOT_ACTIVE;break;}
  if(GetTickCount()-size>=20000){error=ERROR_TIMEOUT;break;}Sleep(100);
 }
 if(!error){error=wp_getnum(meta,"Stage",&stage);if(!error)error=wp_getnum(meta,"LastError",&last);if(!error&&(last||stage!=6))error=last?last:ERROR_INVALID_DATA;}
 done:
 if(loader)CloseServiceHandle(loader);if(kernel)CloseServiceHandle(kernel);if(manager)CloseServiceHandle(manager);
 if(winlogon)RegCloseKey(winlogon);if(meta)RegCloseKey(meta);
 return error?fail("The startup service could not activate this power backend.",error):TRUE;
}
BOOL nt_abort(const char *folder){
 SC_HANDLE manager=0,loader=0,kernel=0;HKEY meta=0;SERVICE_STATUS state;DWORD error=0,result;BOOL resident=FALSE;char path[MAX_PATH];
 if(created_meta){
  result=RegOpenKeyExA(HKEY_LOCAL_MACHINE,WP_META,0,KEY_QUERY_VALUE|KEY_SET_VALUE,&meta);
  if(result)error=result;else {result=wp_setnum(meta,"Removing",1);if(result)error=result;}
 }
 if(created_service||created_kernel){
  manager=OpenSCManagerA(0,0,SC_MANAGER_CONNECT);if(!manager)error=GetLastError();
  if(manager&&created_service){
   wp_path(path,folder,"WINPSVC.EXE");result=wp_owned(manager,WP_SERVICE,path,SERVICE_WIN32_OWN_PROCESS,&loader);
   if(result)error=result;else {result=disable(loader);if(!result)result=stop_service(loader);if(result)error=result;}
  }
  if(manager&&created_kernel){
   wp_path(path,folder,wp_driver(kind));result=wp_owned(manager,wp_kernel(kind),path,SERVICE_KERNEL_DRIVER,&kernel);
   if(result)error=result;else {result=disable(kernel);if(result)error=result;
    if(QueryServiceStatus(kernel,&state))resident=state.dwCurrentState!=SERVICE_STOPPED;else error=GetLastError();
   }
  }
 }
 if(saved_value&&meta){result=wp_winlogon(meta,TRUE);if(result)error=result;}
 if(!error&&!resident){
  if(loader){result=delete_service(loader);if(result)error=result;}
  if(kernel){result=delete_service(kernel);if(result)error=result;}
 }
 if(loader)CloseServiceHandle(loader);if(kernel)CloseServiceHandle(kernel);if(manager)CloseServiceHandle(manager);if(meta)RegCloseKey(meta);
 if(!error&&!resident&&created_meta){result=RegDeleteKeyA(HKEY_LOCAL_MACHINE,WP_META);if(result&&result!=ERROR_FILE_NOT_FOUND)error=result;}
 if(error||resident)return fail("Cleanup requires a restart. Installation files were retained. Restart, then run the installed UNINST.EXE to finish removal.",error?error:ERROR_BUSY);
 if(copied_driver){wp_path(path,folder,wp_driver(kind));if(!DeleteFileA(path))return fail("Cannot remove the staged driver. Installation files were retained.",GetLastError());}
 if(copied_service){wp_path(path,folder,"WINPSVC.EXE");if(!DeleteFileA(path))return fail("Cannot remove the staged service. Installation files were retained.",GetLastError());}
 return TRUE;
}
BOOL nt_remove(const char *folder,BOOL external){
 struct wp_config cfg;HKEY meta=0;SC_HANDLE manager=0,loader=0,kernel=0;HANDLE locks[4]={0,0,0,0},probe;
 DWORD error,removing;char path[MAX_PATH];BYTE digest[32];unsigned i;BOOL changed=FALSE;
 error=RegOpenKeyExA(HKEY_LOCAL_MACHINE,WP_META,0,KEY_QUERY_VALUE|KEY_SET_VALUE,&meta);if(error)goto done;
 error=wp_config(meta,&cfg);if(error)goto done;
 if(lstrcmpiA(cfg.folder,folder)){error=ERROR_INVALID_NAME;goto done;}
 error=wp_getnum(meta,"Removing",&removing);if(error||removing>1){if(!error)error=ERROR_INVALID_DATA;goto done;}
 /* A retry may follow partial delayed deletion. Validate all remaining
    owned files; accept missing files only after removal was recorded. */
 for(i=0;i<4;i++){
  wp_path(path,folder,wp_file(cfg.kind,i));error=wp_hash(path,digest,0);
  if(removing&&(error==ERROR_FILE_NOT_FOUND||error==ERROR_PATH_NOT_FOUND))error=0;
  else if(!error&&memcmp(digest,cfg.hashes[i],32))error=ERROR_CRC;
  if(error)goto done;
 }
 /* SETUP /REMOVE may recover an older compatible installation. All
    remaining installed files still have to match that installation's
    saved hashes; only the external recovery executable may be newer. */
 if(!external){
  if(!GetModuleFileNameA(0,path,MAX_PATH)){error=GetLastError();goto done;}
  error=wp_hash(path,digest,0);if(!error&&memcmp(digest,cfg.hashes[1],32))error=ERROR_CRC;if(error)goto done;
 }
 wp_path(path,folder,"WINPWRNT.EXE");
 probe=CreateFileA(path,GENERIC_READ|GENERIC_WRITE,0,0,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,0);
 if(probe==INVALID_HANDLE_VALUE){error=GetLastError();if(!removing||(error!=ERROR_FILE_NOT_FOUND&&error!=ERROR_PATH_NOT_FOUND))goto done;error=0;}
 else CloseHandle(probe);
 manager=OpenSCManagerA(0,0,SC_MANAGER_CONNECT);if(!manager){error=GetLastError();goto done;}
 wp_path(path,folder,"WINPSVC.EXE");error=wp_owned(manager,WP_SERVICE,path,SERVICE_WIN32_OWN_PROCESS,&loader);
 if(error==ERROR_SERVICE_DOES_NOT_EXIST||error==ERROR_SERVICE_MARKED_FOR_DELETE)error=0;if(error)goto done;
 wp_path(path,folder,wp_driver(cfg.kind));error=wp_owned(manager,wp_kernel(cfg.kind),path,SERVICE_KERNEL_DRIVER,&kernel);
 if(error==ERROR_SERVICE_DOES_NOT_EXIST||error==ERROR_SERVICE_MARKED_FOR_DELETE)error=0;if(error)goto done;
 error=wp_setnum(meta,"Removing",1);if(error)goto done;changed=TRUE;
 if(loader){error=disable(loader);if(!error)error=stop_service(loader);if(error)goto done;}
 if(kernel){error=disable(kernel);if(error)goto done;}
 if(cfg.kind==4){error=wp_winlogon(meta,TRUE);if(error)goto done;}
 if(loader){error=delete_service(loader);if(error)goto done;}
 if(kernel){error=delete_service(kernel);if(error)goto done;}
 done:
 wp_unlock(locks);if(loader)CloseServiceHandle(loader);if(kernel)CloseServiceHandle(kernel);if(manager)CloseServiceHandle(manager);if(meta)RegCloseKey(meta);
 if(error)return fail(changed?"Startup removal is incomplete. Files were retained; retry UNINST.EXE before restarting.":"Cannot remove the owned power installation. Close WINPOWER and check that its installed files are unchanged.",error);
 return TRUE;
}
BOOL nt_finish(const char *folder){
 struct wp_config cfg;HKEY meta=0;DWORD error,removing;unsigned i;char path[MAX_PATH];BYTE digest[32];
 error=RegOpenKeyExA(HKEY_LOCAL_MACHINE,WP_META,0,KEY_QUERY_VALUE,&meta);if(error)goto done;
 error=wp_config(meta,&cfg);if(error)goto done;
 error=wp_getnum(meta,"Removing",&removing);if(error||removing!=1||lstrcmpiA(cfg.folder,folder)){if(!error)error=ERROR_INVALID_DATA;goto done;}
 /* Only after startup is disabled and shell items are removed, queue the
    remaining files. A retained registry record permits SETUP /REMOVE to
    retry after an interrupted cleanup, including after a restart. */
 for(i=0;i<4;i++){
  wp_path(path,folder,wp_file(cfg.kind,i));error=wp_hash(path,digest,0);
  if(error==ERROR_FILE_NOT_FOUND||error==ERROR_PATH_NOT_FOUND){error=0;continue;}
  if(!error&&memcmp(digest,cfg.hashes[i],32))error=ERROR_CRC;if(error)goto done;
  if(!MoveFileExA(path,0,MOVEFILE_DELAY_UNTIL_REBOOT)){error=GetLastError();goto done;}
 }
 wp_path(path,folder,"WINPOWER.INI");
 if(GetFileAttributesA(path)!=INVALID_FILE_ATTRIBUTES){
  if(!MoveFileExA(path,0,MOVEFILE_DELAY_UNTIL_REBOOT)){error=GetLastError();goto done;}
 }else {error=GetLastError();if(error!=ERROR_FILE_NOT_FOUND&&error!=ERROR_PATH_NOT_FOUND)goto done;error=0;}
 if(!MoveFileExA(folder,0,MOVEFILE_DELAY_UNTIL_REBOOT)){error=GetLastError();goto done;}
 RegCloseKey(meta);meta=0;error=RegDeleteKeyA(HKEY_LOCAL_MACHINE,WP_META);
 if(error==ERROR_FILE_NOT_FOUND)error=0;
 if(!error)RegDeleteKeyA(HKEY_LOCAL_MACHINE,"Software\\WINPOWER");
 done:if(meta)RegCloseKey(meta);
 return error?fail("Startup is disabled, but file cleanup is incomplete. Retry the original SETUP.EXE /REMOVE to finish.",error):TRUE;
}
BOOL nt_target(char *folder){
 struct wp_config cfg;HKEY meta;DWORD error;
 error=RegOpenKeyExA(HKEY_LOCAL_MACHINE,WP_META,0,KEY_QUERY_VALUE,&meta);
 if(error)return fail("No valid startup installation was found.",error);
 error=wp_config(meta,&cfg);RegCloseKey(meta);
 if(error)return fail("The installation record is invalid.",error);
 lstrcpyA(folder,cfg.folder);return TRUE;
}
