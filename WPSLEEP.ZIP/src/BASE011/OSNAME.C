#include "OSNAME.H"
const char *pn_osname(unsigned p,unsigned a,unsigned b,unsigned long build,unsigned product){
 if(p==0){
  if(a==1){switch(b){case 0:return "Windows 1.0";case 1:return "Windows 1.01";case 2:return "Windows 1.02";case 3:return "Windows 1.03";case 4:return "Windows 1.04";}return "Windows 1.x";}
  /* Windows/386 2.11 reports 0x1102: its minor byte is BCD, unlike 3.x. */
  if(a==2){switch(b){case 0:return "Windows 2.0";case 1:return "Windows 2.01";case 3:return "Windows 2.03";case 10:case 0x10:return "Windows 2.10";case 11:case 0x11:return "Windows 2.11";}return "Windows 2.x";}
  if(a==3){if(b==0)return "Windows 3.0";if(b==10)return "Windows 3.1";if(b==11)return "Windows 3.11";}return "Windows (Win16)";
 }
 if(p==1&&a==4){if(b==0)return "Windows 95";if(b==10)return build==2222?"Windows 98 Second Edition":"Windows 98";if(b==90)return "Windows Me";return "Windows 9x";}
 if(p!=2)return "Windows (unidentified)";
 if(a==3){if(b==10)return "Windows NT 3.1";if(b==50)return "Windows NT 3.5";if(b==51)return "Windows NT 3.51";}
 if(a==4&&b==0)return "Windows NT 4.0";
 if(a==5){if(b==0)return "Windows 2000";if(b==1)return "Windows XP";if(b==2){if(product==1)return "Windows XP Professional x64";if(product==2||product==3)return "Windows Server 2003 family";return "Windows NT 5.2";}}
 if(a==6){
  if(product==1){switch(b){case 0:return "Windows Vista";case 1:return "Windows 7";case 2:return "Windows 8";case 3:return "Windows 8.1";}}
  else if(product==2||product==3){switch(b){case 0:return "Windows Server 2008";case 1:return "Windows Server 2008 R2";case 2:return "Windows Server 2012";case 3:return "Windows Server 2012 R2";}}
 }
 if(a==10&&b==0){
  if(product==1)return build>=22000?"Windows 11":"Windows 10";
  if(product==2||product==3){if(build==14393)return "Windows Server 2016";if(build==17763)return "Windows Server 2019";if(build==20348)return "Windows Server 2022";if(build==26100)return "Windows Server 2025";return "Windows Server (NT 10.0)";}
 }
 return "Windows NT (unidentified release)";
}
