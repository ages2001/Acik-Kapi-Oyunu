#ifndef WINPOWER_SHA256_H
#define WINPOWER_SHA256_H
typedef unsigned int wp_word;
typedef char wp_word_is_32_bits[(sizeof(wp_word)==4)?1:-1];
struct wp_sha256 { wp_word state[8],low,high; unsigned used; unsigned char block[64]; };
void wp_sha_init(struct wp_sha256 *s);
void wp_sha_add(struct wp_sha256 *s,const unsigned char *data,unsigned size);
void wp_sha_end(struct wp_sha256 *s,unsigned char digest[32]);
#endif
