#ifndef PN_PWRSEQ_H
#define PN_PWRSEQ_H
#include "S5.H"
struct pn_io {
 void *arg;
 unsigned (*get16)(void *,unsigned);
 void (*put16)(void *,unsigned,unsigned);
 void (*put8)(void *,unsigned,unsigned);
 void (*wait)(void *,unsigned);
};
int pn_s5off(const struct pn_acpi *,const struct pn_io *);
int pn_reset(const struct pn_acpi *,const struct pn_io *);
#endif
