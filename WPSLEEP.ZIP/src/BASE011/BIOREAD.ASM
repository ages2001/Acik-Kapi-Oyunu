.model large,c
.386
.code
public pn_cpu, pn_e820
; No 32-bit opcode executes until pn_cpu reports a 386 or newer processor.
pn_cpu proc far
 pushf
 pop cx
 mov ax,cx
 and ax,0fffh
 push ax
 popf
 pushf
 pop ax
 and ax,0f000h
 cmp ax,0f000h
 je short oldcpu
 mov ax,cx
 or ax,0f000h
 push ax
 popf
 pushf
 pop ax
 and ax,0f000h
 jz short oldcpu
 mov ax,1
 jmp short cpudone
oldcpu:
 xor ax,ax
cpudone:
 push cx
 popf
 ret
pn_cpu endp
; cdecl far pointers: continuation key, 20-byte E820 buffer.
pn_e820 proc far
 push bp
 mov bp,sp
 push ebx
 push ecx
 push edx
 push esi
 push edi
 push es
 les si,dword ptr [bp+6]
 mov ebx,es:[si]
 les di,dword ptr [bp+10]
 mov eax,0e820h
 mov edx,0534d4150h
 mov ecx,20
 int 15h
 jc short badmap
 cmp eax,0534d4150h
 jne short badmap
 cmp ecx,20
 jb short badmap
 les si,dword ptr [bp+6]
 mov es:[si],ebx
 mov ax,1
 jmp short mapdone
badmap:
 xor ax,ax
mapdone:
 pop es
 pop edi
 pop esi
 pop edx
 pop ecx
 pop ebx
 pop bp
 ret
pn_e820 endp
end
