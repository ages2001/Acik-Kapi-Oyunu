#include "SHUTFIND.H"
static unsigned long u32(const unsigned char *p) {
 return (unsigned long)p[0]|((unsigned long)p[1]<<8)|
        ((unsigned long)p[2]<<16)|((unsigned long)p[3]<<24);
}
static int target(const unsigned char *p,unsigned long rva,pn_execfn code,
                  void *arg,unsigned long *out) {
 unsigned long d=u32(p+1),next=rva+5,t;
 if(d&0x80000000UL) {
  unsigned long back=(~d+1)&0xffffffffUL;
  if(back>next)return 0;
  t=next-back;
 } else {
  if(d>0xffffffffUL-next)return 0;
  t=next+d;
 }
 if(!code(arg,t,1))return 0;
 *out=t;return 1;
}
int pn_shutfind(const unsigned char *b,unsigned long n,unsigned long base,
               unsigned profile,pn_execfn code,void *arg,
               struct pn_shutmatch *out) {
 unsigned long i,a,c,d,e;int count=0;
 if(!b||!code||!out||(profile!=31&&profile!=351)||n<64||
    base>0xffffffffUL||n>0xffffffffUL-base)return 0;
 for(i=16;i<=n-64;i++) {
  const unsigned char *p=b+i;
  if(p[0]!=0x53||p[1]!=0xe8||p[6]!=0x53||p[7]!=0xe8||
     p[12]!=0x53||p[13]!=0xe8||p[18]!=0x6a||p[19]!=1||
     p[20]!=0x53||p[21]!=0xe8||p[27]!=0xdb||p[28]!=0x74)
   continue;
  if(profile==31) {
   if(p[-2]!=0x6a||p[-1]!=0||p[26]!=0x0a||p[29]!=0x12||
      p[30]!=0x6a||p[31]!=0||p[32]!=0x6a||p[33]!=0xff||
      p[34]!=0x6a||p[35]!=0||p[36]!=0xe8||p[41]!=0x6a||
      p[42]!=3||p[43]!=0xe8||p[48]!=0x2b||p[49]!=0xc0||
      p[50]!=0x5b||p[51]!=0x83||p[52]!=0xc4||p[53]!=8||
      p[54]!=0xc2||p[55]!=4||p[56]!=0)continue;
  } else {
   if(p[-16]!=0x6a||p[-15]!=0||p[-14]!=0x83||p[-13]!=0xfe||
      p[-12]!=1||p[-11]!=0xc6||p[-10]!=5||p[-5]!=1||
      p[-4]!=0x1a||p[-3]!=0xdb||p[-2]!=0xfe||p[-1]!=0xc3||
      p[26]!=0x84||p[29]!=0x1c||p[30]!=0x6a||p[31]!=0||
      p[32]!=0x6a||p[33]!=0xff||p[34]!=0x6a||p[35]!=0||
      p[36]!=0xe8||p[41]!=0x83||p[42]!=0xfe||p[43]!=1||
      p[44]!=0x75||p[45]!=4||p[46]!=0x6a||p[47]!=3||
      p[48]!=0xeb||p[49]!=2||p[50]!=0x6a||p[51]!=1||
      p[52]!=0xff||p[53]!=0x15||p[58]!=0x33||p[59]!=0xc0||
      p[60]!=0x5e||p[61]!=0x5b||p[62]!=0xc2||p[63]!=4||
      i+64>=n||p[64]!=0)continue;
  }
  if(!code(arg,base+i,profile==31?57:65)||
     !target(p+1,base+i+1,code,arg,&a)||
     !target(p+7,base+i+7,code,arg,&c)||
     !target(p+13,base+i+13,code,arg,&d)||
     !target(p+21,base+i+21,code,arg,&e)||a!=e||a==c||a==d||c==d)
   continue;
  if(++count>1)return 0;
  out->call_rva=base+i+21;out->target_rva=a;
  out->displacement=u32(p+22);
 }
 return count==1;
}
