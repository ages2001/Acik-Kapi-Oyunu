/* Experimental Win95/98 final-power VxD, 64 MiB BIOS VM profile.
 * No firmware write occurs during ordinary shutdown notification.
 * See TEST/VXREF.TXT for VMM API layout references. */
#include <string.h>
#include "ACPI.H"
#include "S5.H"
#include "PWRSEQ.H"
typedef unsigned long U32;
typedef unsigned short U16;
typedef unsigned char U8;
extern U8 PN9_DDB[];
struct ddb { U32 next;U16 sdk,id;U8 major,minor;U16 flags;char name[8];U32 order,control; };
struct diop { U32 internal1,vm,internal2,code,in,insize,out,outsize,returned,overlapped,handle,process; };
static struct pn_acpi firmware;
static U8 work[32768];
static U8 *lowmap,*highmap;
static U32 status[16],original,exitcode=0xffffffffUL;
static int initialized;
static void hook93(void),hookbd(void);
static void byteout(U8 value);
#pragma aux byteout = "out 0e9h,al" parm [al] modify exact [];
static U32 in32(unsigned port);
#pragma aux in32 = "in eax,dx" parm [dx] value [eax] modify exact [eax];
static U16 in16(unsigned port);
#pragma aux in16 = "in ax,dx" parm [dx] value [ax] modify exact [ax];
static void out16(unsigned port,unsigned value);
#pragma aux out16 = "out dx,ax" parm [dx] [ax] modify exact [];
static void out8(unsigned port,unsigned value);
#pragma aux out8 = "out dx,al" parm [dx] [al] modify exact [];
static void halt(void);
#pragma aux halt = "cli" "stopped: hlt" "jmp stopped" modify exact [];
static void hex(U32 x) {int i;for(i=28;i>=0;i-=4){unsigned n=(unsigned)((x>>i)&15);byteout((U8)(n<10?'0'+n:'A'+n-10));}}
static void logvalue(U8 tag,U32 x){byteout(tag);byteout(' ');hex(x);byteout(10);}
static struct ddb *getddb(U32 id) {
 struct ddb *result=0;
 _asm { push edi
  mov eax,id
  xor edi,edi
  int 20h
  dw 146h
  dw 1
  mov result,ecx
  pop edi
 }
 return result;
}
static void __declspec(naked) __cdecl demand(U32 *info,U32 flags) {
 _asm { int 20h
  dw 806fh
  dw 1
 }
}
static U32 __declspec(naked) __cdecl map(U32 physical,U32 size,U32 flags) {
 _asm { int 20h
  dw 806ch
  dw 1
 }
}
static int vmm_noop_exit(const struct ddb *p) {
 const U8 *b=(const U8*)p->control;
 /* The supplied Win95 RTM VMM has an order-zero handler. Its only
  * possible action is for message 14h. For 26h both branches reach
  * CLC; RET. Reject other code shapes rather than assuming this. */
 return p->id==1&&p->sdk==0x400&&!p->order&&b&&(U32)b>=0xc0000000UL&&
  b[0]==0xf7&&b[1]==5&&b[10]==0x74&&b[11]==9&&
  b[12]==0x83&&b[13]==0xf8&&b[14]==0x14&&b[15]==0x0f&&b[16]==0x84&&
  b[21]==0xf8&&b[22]==0xc3;
}
static int unique_last(void) {
 struct ddb *first=getddb(1),*p=first;unsigned n=0,own=0;
 if(!p||(U32)p<0xc0000000UL||p->id!=1)return 0;
 do {
  if((U32)p<0xc0000000UL||((U32)p&3)||++n>256)return 0;
  if((U8*)p==PN9_DDB)own++;
  else if(p->control&&p->order==0&&!(p==first&&vmm_noop_exit(p))){logvalue('X',(U32)p);return 0;}
  p=(struct ddb*)p->next;
 }while(p&&p!=first);
 status[14]=n;return own==1;
}
static int readphys(void *arg,U32 address,U8 *out,unsigned n) {
 const U8 *source;(void)arg;
 if(!n||address>0xffffffffUL-n)return 0;
 if((address>=0x400&&address+n<=0xa0000)||(address>=0xe0000&&address+n<=0x100000))source=lowmap+address;
 else if(address>=0x3c00000&&address+n<=0x4000000)source=highmap+(address-0x3c00000);
 else return 0;
 memcpy(out,source,n);return 1;
}
static int discover(void) {
 U8 b[36];U32 memory[32],ebda,p,found=0;int result;
 memset(memory,0,sizeof(memory));demand(memory,0);
 status[7]=memory[1];logvalue('M',status[7]);
 /* This lab reader is qualified only for the supplied 64 MiB VM profile. */
 if(status[7]<0x3e00||status[7]>0x4000)return 0;
 lowmap=(U8*)map(0,0x100000,0);highmap=(U8*)map(0x3c00000,0x400000,0);
 if(!lowmap||(U32)lowmap==0xffffffffUL||!highmap||(U32)highmap==0xffffffffUL)return 0;
 if(!readphys(0,0x40e,b,2))return 0;ebda=((U32)b[0]|((U32)b[1]<<8))<<4;
 if(ebda>=0x80000&&ebda<=0x9fc00)for(p=ebda;p<ebda+1024;p+=16){if(readphys(0,p,b,36)&&pn_rsdp(b,36)>=0){found=p;break;}}
 if(!found)for(p=0xe0000;p<=0x100000-36;p+=16){if(readphys(0,p,b,36)&&pn_rsdp(b,36)>=0){found=p;break;}}
 if(!found)return 0;
 result=pn_tables(readphys,0,found,&firmware,work,sizeof(work));
 status[4]=firmware.rsdp_rev;status[5]=firmware.fadt_rev;
 status[6]=firmware.off_ok|(firmware.reset_ok<<1);status[13]=firmware.timer_port;
 return result&&firmware.off_ok&&firmware.timer_port;
}
static unsigned get16(void *unused,unsigned port){(void)unused;return in16(port);}
static void put16(void *unused,unsigned port,unsigned value){(void)unused;out16(port,value);}
static void put8(void *unused,unsigned port,unsigned value){(void)unused;out8(port,value);}
static void pauseio(void *unused,unsigned ticks) {
 U32 mask=firmware.timer_bits==32?0xffffffffUL:0xffffffUL,prior=in32(firmware.timer_port)&mask;
 U32 elapsed=0,need=(U32)ticks*196875UL,now;unsigned stalled=0;(void)unused;
 while(elapsed<need){now=in32(firmware.timer_port)&mask;
  if(now==prior){if(++stalled==1000000){status[15]=1;return;}}
  else{elapsed+=(now-prior)&mask;prior=now;stalled=0;}
 }
}
static const struct pn_io ports={0,get16,put16,put8,pauseio};
static void final_off(void) {
 int result;if(!status[1])return;status[11]++;logvalue('O',exitcode);
 result=pn_s5off(&firmware,&ports);logvalue('F',(U32)result);
 /* An un-restored ACPI mode must not fall through into legacy APM. */
 if(result<0)halt();
}
static void final_reset(void) {if(status[1]&&firmware.reset_ok){logvalue('R',exitcode);pn_reset(&firmware,&ports);}}
static void __stdcall control_seen(U32 code) {
 if(code==0x26&&status[2]==0x400&&status[12]&&unique_last()){
  if(exitcode==1)final_off();else if(exitcode==0x43)final_reset();
 }
}
static void __declspec(naked) hookbd(void) {
 _asm { mov exitcode,eax
  jmp dword ptr original
 }
}
static void __declspec(naked) hook93(void) {
 _asm { cmp eax,36h
  je poweroff
  cmp eax,18h
  je reboot
  jmp dword ptr original
 poweroff:
  call dword ptr original
  pushfd
  pushad
  call final_off
  popad
  popfd
  ret
 reboot:
  call dword ptr original
  pushfd
  pushad
  call final_reset
  popad
  popfd
  ret
 }
}
static void initialize(void) {
 U32 v=0,apm=0,service;void *handler;unsigned i;
 if(initialized)return;initialized=1;
 for(i=0;i<16;i++)status[i]=0;
 status[0]=10;status[4]=0xffff;status[8]=10;
 _asm { int 20h
  dw 0
  dw 1
  mov v,eax
 }
 status[2]=v&0xffff;
 if(status[2]!=0x400&&status[2]!=0x40a)return;
 status[8]=20;
 if(!getddb(0x26))return;
 _asm { int 20h
  dw 1
  dw 26h
  mov apm,eax
 }
 status[3]=apm;status[9]=getddb(0x4c)!=0;
 if(status[9]||getddb(0x2961))return;
 status[8]=30;if(!discover())return;
 status[12]=unique_last();logvalue('L',status[12]);
 if(status[2]==0x400&&!status[12])return;
 status[8]=40;pauseio(0,1);if(status[15])return;
 service=status[2]==0x400?0x100bdUL:0x10093UL;
 handler=status[2]==0x400?hookbd:hook93;
 _asm { mov eax,service
  mov esi,handler
  int 20h
  dw 90h
  dw 1
  mov original,esi
 }
 if(!original||original==(U32)handler)return;
 status[1]=1;status[8]=60;logvalue('A',status[2]);
}
static U32 __stdcall query(struct diop *p) {
 if(p->code==0||p->code==0xffffffffUL)return 0;
 if(p->code!=1)return 50;
 if(!p->out||p->outsize<sizeof(status)||!p->returned)return 87;
 status[10]=exitcode;memcpy((void*)p->out,status,sizeof(status));*(U32*)p->returned=sizeof(status);return 0;
}
void __declspec(naked) control(void) {
 _asm { pushad
  push eax
  call control_seen
  popad
  /* Win98 releases initialization pages after Init_Complete. Wait for
     Kernel32_Initialized so the bounded physical-pool check is stable. */
  cmp eax,31h
  je init
  cmp eax,1bh
  je init
  cmp eax,1ch
  je busy
  cmp eax,23h
  jne done
  push esi
  call query
  clc
  ret
 init:
  pushad
  call initialize
  popad
 done:
  clc
  ret
 busy:
  stc
  ret
 }
}
