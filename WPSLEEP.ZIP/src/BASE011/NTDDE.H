#ifndef WINPOWER_NTDDE_H
#define WINPOWER_NTDDE_H
#include <windows.h>
BOOL nt_group(BOOL remove,const char *app,const char *uninst);
int nt_group_status(unsigned *owned,unsigned *other);
#endif
