#ifndef PN_OSINFO_H
#define PN_OSINFO_H
#include <windows.h>
void pn_osinfo(OSVERSIONINFOA *os,char *name,char *arch);
#endif
