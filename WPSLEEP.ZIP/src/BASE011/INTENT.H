#ifndef PN_INTENT_H
#define PN_INTENT_H
struct pn_userregs { unsigned long eip,esp,ebx,edi; };
typedef int (*pn_usread)(void *,unsigned long,unsigned char *,unsigned);
/* Known Winlogon shutdown contexts only: 0 unknown, 1 off, 2 restart. */
unsigned pn_intent(unsigned,const struct pn_userregs *,pn_usread,void *);
#endif
