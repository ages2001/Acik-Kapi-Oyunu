#!/bin/sh
# Build the persistent legacy NT package; retain qualified core binaries.
set -eu
cd "$(dirname "$0")"
mkdir -p ../BIN/WINPWRNT/LEGACY ../TEST
cc=i686-w64-mingw32-gcc
i686-w64-mingw32-windres WINPOWER.RC -O coff -o ../TEST/ICON.O
"$cc" -march=i386 -mno-sse -mno-mmx -x c -Os -Wall -Wextra -Werror -Wno-misleading-indentation -Wno-cast-function-type -fno-builtin -fno-stack-protector -nostdlib -mwindows WINPSVC.C NTPWR.C NTREG.C SHA256.C -x none ../TEST/ICON.O -Wl,--entry,_WinMainCRTStartup@0,--subsystem,windows:3.10 -o ../BIN/WINPWRNT/LEGACY/WINPSVC.EXE -luser32 -lkernel32 -ladvapi32
"$cc" -march=i386 -mno-sse -mno-mmx -x c -Os -Wall -Wextra -Werror -Wno-misleading-indentation -Wno-cast-function-type -fno-builtin -fno-stack-protector -nostdlib -mwindows -DPNNT_PACKAGE SETUP.C NTSET.C NTDDE.C NTPWR.C NTREG.C SHA256.C -x none ../TEST/ICON.O -Wl,--entry,_WinMainCRTStartup@0,--subsystem,windows:3.10 -o ../BIN/WINPWRNT/LEGACY/SETUP.EXE -luser32 -lkernel32 -ladvapi32 -luuid
rm ../TEST/ICON.O
"$cc" -march=i386 -mno-sse -mno-mmx -x c -Os -Wall -Wextra -Werror -Wno-misleading-indentation -Wno-cast-function-type -fno-builtin -fno-stack-protector -nostdlib -mwindows -I. ../TEST/NTAUDIT.C NTDDE.C NTPWR.C NTREG.C SHA256.C -Wl,--entry,_WinMainCRTStartup@0,--subsystem,windows:3.10 -o ../BIN/WINPWRNT/LEGACY/NTAUDIT.EXE -luser32 -lkernel32 -ladvapi32
cp ../BIN/WINPWRNT/X86/WINPWRNT.EXE ../BIN/WINPWRNT/LEGACY/WINPWRNT.EXE
cp ../BIN/WINPWRNT/NT3LAB/PN3HOOK.SYS ../BIN/WINPWRNT/LEGACY/PN3HOOK.SYS
cp ../BIN/WINPWRNT/NT4LAB/PN4HOOK.SYS ../BIN/WINPWRNT/LEGACY/PN4HOOK.SYS
