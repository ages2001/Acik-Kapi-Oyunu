#ifndef PN_POLICY_H
#define PN_POLICY_H
/* A verified, active OS ACPI provider is required, not merely an ACPI BIOS. */
int pn_eligible(int nt, unsigned major, unsigned minor, int os_acpi);
int pn_owner(int requested, int eligible, int backend_ready);
#endif
