#ifndef PN_OSNAME_H
#define PN_OSNAME_H
/* platform: 0=Win16, 1=Win9x, 2=NT. product: 1=workstation, 2/3=server. */
const char *pn_osname(unsigned platform,unsigned major,unsigned minor,unsigned long build,unsigned product);
/* Display a known specification or raw FADT revision fields. Provide at
   least 20 bytes of output. A missing revision or minor is 0xffff. */
void pn_acpitext(unsigned rsdp_rev,unsigned fadt_rev,unsigned fadt_minor,char *out);
/* APM BIOS version word in BCD (0x0102) as "1.2". */
void pn_apmtext(unsigned bcd,char *out);
#endif
