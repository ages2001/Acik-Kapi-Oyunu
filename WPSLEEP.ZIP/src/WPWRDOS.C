/* DOS session supervisor. Firmware is touched only after the Windows loader returns. */
#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
#include <string.h>
#include <process.h>
#include <dos.h>
#include <i86.h>
#include <conio.h>
#include <direct.h>
#include "PNLINK.H"
#include "OWN16.H"
#include "ENTRY16.H"
#include "ACPIDOS.H"
#include "DOSINFO.H"
static struct pn_acpi firmware;
static char statepath[144],guipath[144],winpath[144],helper[144],launch[128];
static unsigned installed_owner(void){
 char path[144],magic[8];struct wp_pref16 pref;FILE *f;int valid;
 strcpy(path,guipath);strcpy(strrchr(path,'\\')+1,"WINPWR16.ID");
 f=fopen(path,"rb");if(!f)return 0;
 valid=fread(magic,1,8,f)==8&&!memcmp(magic,"WPINST10",8)&&
       !fseek(f,WP_PREF_POS,SEEK_SET)&&fread(&pref,1,sizeof(pref),f)==sizeof(pref)&&wp_pref_ok(&pref);
 fclose(f);return valid?pref.value:0;
}
static void trace(const char *message){
 char path[144],head[32];FILE *f;size_t n;static const char magic[]="WINPOWER power trace 0.10\r\n";
 strcpy(path,guipath);strcpy(strrchr(path,'\\')+1,"PNPOWER.LOG");
 f=fopen(path,"rb");if(f){n=fread(head,1,sizeof(magic)-1,f);fclose(f);if(n!=sizeof(magic)-1||memcmp(head,magic,n))return;}
 else {f=fopen(path,"wb");if(!f)return;fwrite(magic,1,sizeof(magic)-1,f);if(fclose(f))return;}
 f=fopen(path,"ab");if(!f)return;fputs(message,f);fputs("\r\n",f);fclose(f);
}
static int bios(unsigned ax,unsigned bx,unsigned cx,union REGS *out){
 union REGS in;memset(&in,0,sizeof(in));in.w.ax=ax;in.w.bx=bx;in.w.cx=cx;
 int86(0x15,&in,out);return !out->w.cflag;
}
/* Reset to an 80x25 text mode, which also blanks the screen. Used after a
   wrapped Windows session exits so no DOS text is shown before power-off. */
static void clearscreen(void){union REGS r;memset(&r,0,sizeof(r));r.w.ax=0x0003;int86(0x10,&r,&r);}
static int inwindows(void){return pn_inwindows();}
/* Commit DOS buffers and common write-behind caches before firmware I/O.
   SMARTDRV 4+ answers INT 2Fh AX=4A10h with AX=BABEh; BX=0001h commits. */
static void flushdos(void){
 union REGS in,out;unsigned long start,now;
 if(pn_int2f_ok()){
  memset(&in,0,sizeof(in));in.w.ax=0x4a10;in.w.bx=0;int86(0x2f,&in,&out);
  if(out.w.ax==0xbabe){memset(&in,0,sizeof(in));in.w.ax=0x4a10;in.w.bx=1;int86(0x2f,&in,&out);}
 }
 memset(&in,0,sizeof(in));in.h.ah=0x0d;intdos(&in,&out);
 /* Allow drive controllers to finish the committed writes (about 0.5 s). */
 start=*(volatile unsigned long __far *)MK_FP(0x40,0x6c);
 do{now=*(volatile unsigned long __far *)MK_FP(0x40,0x6c);if(now<start)break;}while(now-start<9);
}
unsigned __cdecl wp_apmoff(void);
static int poweroff(void){
 flushdos();wp_apmoff();
 puts("APM power off failed or returned. The PC remains on.");return 1;
}
static int restart(void){
 unsigned wait;void (__far *reset)(void)=(void (__far *)(void))MK_FP(0xffff,0);
 flushdos();_disable();
 *(unsigned __far *)MK_FP(0x40,0x72)=0x1234;
 for(wait=0;wait<65535U;wait++)if(!(inp(0x64)&2))break;
 outp(0x64,0xfe);
 for(wait=0;wait<65535U;wait++)inp(0x64);
 reset();_enable();puts("Firmware reset returned unexpectedly.");return 1;
}
static int command_tail(int wrapped){
 char __far *tail=(char __far *)MK_FP(_psp,0x80);char raw[128];unsigned i,n=(unsigned char)*tail;
 char *p,*start;unsigned used=0,len;
 if(n>126)return 0;for(i=0;i<n;i++)raw[i]=tail[i+1];raw[n]=0;p=raw;
 if(!wrapped){
  while(*p==' ')p++;
  if(*p=='"'){p++;while(*p&&*p!='"')p++;if(*p)p++;}
  else while(*p&&*p!=' ')p++;
 }
 while(*p==' ')p++;
 while(*p=='/'){
  start=p;while(*p&&*p!=' ')p++;len=(unsigned)(p-start);
  if(used+len+1>=sizeof(launch))return 0;
  memcpy(launch+used,start,len);used+=len;launch[used++]=' ';
  while(*p==' ')p++;
 }
 len=strlen(guipath);
 if(used+len+1>=sizeof(launch))return 0;
 memcpy(launch+used,guipath,len);used+=len;
 if(*p){
  len=strlen(p);if(used+6+len>=sizeof(launch))return 0;
  memcpy(launch+used," /RUN ",6);used+=6;memcpy(launch+used,p,len);used+=len;
 }
 launch[used]=0;return 1;
}
static int present(const char *p){unsigned attr;return _dos_getfileattr(p,&attr)==0;}
/* DOS 2.x does not pass the program path. Search the current directory and
   PATH for a file name, optionally requiring a companion file beside it. */
static int search(char *out,const char *name,const char *companion){
 char dir[144],test[160];const char *env=getenv("PATH"),*p;unsigned n;
 for(p=0;;){
  if(!p){if(!getcwd(dir,sizeof(dir)))dir[0]=0;p=env?env:"";}
  else{
   while(*p==';')p++;if(!*p)return 0;
   for(n=0;p[n]&&p[n]!=';'&&n<sizeof(dir)-1;n++)dir[n]=p[n];dir[n]=0;p+=n;
  }
  n=strlen(dir);if(!n||n>120)continue;
  if(dir[n-1]!='\\'&&dir[n-1]!='/')strcat(dir,"\\");
  strcpy(test,dir);strcat(test,name);
  if(!present(test))continue;
  if(companion){strcpy(test,dir);strcat(test,companion);if(!present(test))continue;strcpy(test,dir);strcat(test,name);}
  if(_fullpath(out,test,144))return 1;
 }
}
static void status(void){
 struct pn_dos dos;char name[48];union REGS out;
 pn_dosinfo(&dos);pn_dosname(&dos,name);
 printf("Operating system: %s%s\n",name,(dos.flags&PN_DOS_WIN9X)?" (Windows 9x/Me real-mode DOS)":"");
 if(dos.true_major!=dos.major||dos.true_minor!=dos.minor)printf("Reported version: %u.%02u (SETVER or OEM override)\n",dos.major,dos.minor);
 pn_probe(&firmware);
 if(firmware.rsdp_rev==0xffff)puts("ACPI: N/A");
 else{
  printf("ACPI: RSDP %u / FADT ",firmware.rsdp_rev);
  if(!firmware.fadt_rev)puts("N/A");
  else if(firmware.fadt_minor==0xffff)printf("%u\n",firmware.fadt_rev);
  else printf("%u.%u\n",firmware.fadt_rev,firmware.fadt_minor);
 }
 printf("ACPI power off: %s; ACPI reset register: %s\n",firmware.off_ok?
#ifdef PN_AML
  (pn_aml_prepared()?"S5 with _PTS/_GTS methods":"S5")
#else
  "static S5"
#endif
  :"unavailable",firmware.reset_ok?"available":"unavailable");
 if(bios(0x5300,0,0,&out)&&out.w.bx==0x504d)printf("APM BIOS version: %u.%u\n",out.h.ah,out.h.al);
 else puts("APM BIOS version: N/A");
 if(bios(0x530a,1,0,&out)){
  if(out.h.bh==1)puts("AC power: Online");else if(out.h.bh==0)puts("AC power: Offline");else puts("AC power: N/A");
  if(out.h.bl==0x80||out.h.cl>100)puts("Battery: N/A");else printf("Battery: %u%%\n",out.h.cl);
 }else{puts("AC power: N/A");puts("Battery: N/A");}
}
static int standalone(int argc,char **argv){
 int off=-1,yes=0,info=0,i,answer;
 for(i=1;i<argc;i++){
  if(!stricmp(argv[i],"/OFF"))off=1;
  else if(!stricmp(argv[i],"/RESTART")||!stricmp(argv[i],"/REBOOT"))off=0;
  else if(!stricmp(argv[i],"/STATUS"))info=1;
  else if(!stricmp(argv[i],"/Y"))yes=1;
  else return -1;
 }
 if(info&&off<0){status();return 0;}
 if(off<0)return -1;
 if(inwindows()){puts("Exit Windows before using WPWRDOS power commands.");return 1;}
 status();
 if(!yes){
  printf("%s this computer now? Type Y to continue: ",off?"Power off":"Restart");
  fflush(stdout);answer=getch();if(!answer)getch();
  printf("%c\n",(answer>=32&&answer<127)?answer:' ');
  if(answer!='y'&&answer!='Y'){puts("Cancelled. Nothing changed.");return 1;}
 }
 flushdos();
 if(!off){
  if(firmware.reset_ok){puts("Requesting ACPI reset.");flushdos();pn_acreset(&firmware);}
  if(firmware.reduced){puts("The ACPI reset register did not restart this system.");return 1;}
  return restart();
 }
 if(firmware.off_ok||firmware.reduced){
  puts("Requesting ACPI S5 power off.");flushdos();
  if(pn_acoff(&firmware)<0){puts("ACPI remains active; APM fallback was not attempted.");return 1;}
 }
 if(!pn_acapm(&firmware)){puts("The firmware power interface remains under ACPI control.");return 1;}
 puts("Using BIOS APM power off.");return poweroff();
}
static void usage(void){
 puts("Usage: WPWRDOS C:\\WINDOWS\\WIN.COM [Windows arguments]");
 puts("       WPWRDOS /OFF [/Y] | /RESTART [/Y] | /STATUS");
}
int main(int argc,char **argv){
 FILE *f;struct pn_state state;char *slash;int rc,wrapped;unsigned action;
 puts("WINPOWER DOS power supervisor 1.0");
 if(argv[0][0]){if(!_fullpath(guipath,argv[0],sizeof(guipath))){puts("Cannot locate WPWRDOS.");return 1;}}
 else if(!search(guipath,WP_ENTRY_FILE,"WINPWR16.ID")&&!search(guipath,"WPWRDOS.EXE",0)){puts("Cannot locate WPWRDOS.");return 1;}
 slash=strrchr(guipath,'\\');if(!slash || (slash-guipath)>125)return 1;
 wrapped=!stricmp(slash+1,WP_ENTRY_FILE);
 if(!wrapped&&argc>=2&&argv[1][0]=='/'){rc=standalone(argc,argv);if(rc<0){usage();return 1;}return rc;}
 if(inwindows()){puts("Exit Windows before starting WPWRDOS.");return 1;}
 if(!wrapped&&argc<2){usage();return 1;}
 if(wrapped){strcpy(winpath,guipath);strcpy(strrchr(winpath,'\\')+1,"PNWIN.COM");}
 else if(!_fullpath(winpath,argv[1],sizeof(winpath)))return 1;
 strcpy(slash+1,"WINPWR16.EXE");strcpy(statepath,guipath);strcpy(strrchr(statepath,'\\')+1,PN_STATE);
 if(!command_tail(wrapped)){puts("Windows command line is too long. Nothing was started.");return 1;}
 f=fopen(guipath,"rb");if(!f){puts("WINPWR16.EXE is missing beside the supervisor.");return 1;}fclose(f);
 f=fopen(statepath,"rb");if(f){fclose(f);puts("PNSTATE.DAT already exists. A session may still be active.");puts("After a cold boot only, remove that file and try again.");return 1;}
 memset(&state,0,sizeof(state));memcpy(state.magic,PN_MAGIC,8);state.owner=wrapped?installed_owner():0;
 pn_probe(&firmware);state.acpi_rev=firmware.rsdp_rev;state.fadt_rev=firmware.fadt_rev;
 state.fadt_minor=firmware.fadt_minor;state.cap_flags=(firmware.off_ok?1:0)|(firmware.reset_ok?2:0);
#ifdef PN_AML
 /* Interpreter buffers are not kept while Windows runs; firmware is
    probed again after Windows returns. */
 pn_release();
#endif
 f=fopen(statepath,"wb");if(!f){puts("Cannot create the session state file.");return 1;}
 if(fwrite(&state,1,sizeof(state),f)!=sizeof(state)){fclose(f);remove(statepath);return 1;}
 if(fclose(f)){remove(statepath);return 1;}flushdos();
 /* Give conventional memory used for firmware discovery back to DOS.
    Win2 real mode needs a large contiguous block at the next EXEC. */
 _fheapshrink();_nheapshrink();
 puts("Starting Windows. Save work before ending the session.");
 rc=spawnlp(P_WAIT,winpath,winpath,launch,NULL);
 f=fopen(statepath,"rb");if(!f){puts("Session state is missing; no power action.");return 1;}
 if(fread(&state,1,sizeof(state),f)!=sizeof(state))state.ready=0;
 fclose(f);remove(statepath);flushdos();
 if(wrapped && !installed_owner())state.owner=0;
 action=pn_action(&state,rc);
 if(action==4){trace("Operating system ownership: session returned to DOS");return 0;}
 if(!action){puts("Windows did not complete a confirmed session; no power action.");return 1;}
 if(inwindows()){puts("Windows is still active; no power action.");return 1;}
 if(action==3){
  if(!wrapped){puts("This session does not have an installed loader to remove.");return 1;}
  strcpy(helper,guipath);strcpy(strrchr(helper,'\\')+1,"PNUNINST.EXE");
  return spawnlp(P_WAIT,helper,helper,"/CLEAN",NULL);
 }
 /* The session powers the PC off now. Blank the screen first so the user
    sees no DOS prompt or supervisor text between Windows exiting and the
    machine turning off; progress is written to the trace log, not the
    screen. Only a genuine failure (the PC stays on) prints a message. */
 clearscreen();
 pn_probe(&firmware);flushdos();
 if(action==2){
  if(firmware.reset_ok){trace("ACPI reset requested");flushdos();pn_acreset(&firmware);}
  trace("Legacy reset requested");flushdos();
  if(firmware.reduced){puts("The ACPI reset register did not restart this system.");return 1;}
  return restart();
 }
 if(firmware.off_ok||firmware.reduced){
  trace("ACPI S5 requested");flushdos();
  if(pn_acoff(&firmware)<0){trace("ACPI returned; APM blocked");flushdos();puts("ACPI remains active; APM fallback was not attempted.");return 1;}
 }
 if(!pn_acapm(&firmware)){trace("APM blocked by ACPI ownership");return 1;}
 trace("APM power off requested");flushdos();return poweroff();
}
