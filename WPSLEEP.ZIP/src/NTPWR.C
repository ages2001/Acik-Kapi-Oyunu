/* Shared, bounded installation state for the legacy NT startup service. */
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include "NTPWR.H"
#include "SHA256.H"
void *memcpy(void *to,const void *from,size_t n){BYTE *d=to;const BYTE *s=from;while(n--)*d++=*s++;return to;}
int memcmp(const void *a,const void *b,size_t n){const BYTE *x=a,*y=b;while(n--){if(*x!=*y)return *x-*y;x++;y++;}return 0;}
DWORD wp_kind(void){DWORD v=GetVersion(),major=LOBYTE(LOWORD(v));return !(v&0x80000000UL)&&(major==3||major==4)?major:0;}
BOOL wp_folder(const char *folder){
 return lstrlenA(folder)==11&&((folder[0]>='A'&&folder[0]<='Z')||(folder[0]>='a'&&folder[0]<='z'))&&
        folder[1]==':'&&!lstrcmpiA(folder+2,"\\WINPWRNT");
}
BOOL wp_ownfolder(char *folder){
 DWORD n=GetModuleFileNameA(0,folder,MAX_PATH);int i;if(!n||n>=MAX_PATH)return FALSE;
 for(i=(int)n-1;i>=0&&folder[i]!='\\';i--){}if(i<0)return FALSE;folder[i]=0;return wp_folder(folder);
}
const char *wp_kernel(DWORD kind){return kind==3?"PN3LAB":"PN4LAB";}
const char *wp_driver(DWORD kind){return kind==3?"PN3HOOK.SYS":"PN4HOOK.SYS";}
const char *wp_file(DWORD kind,unsigned index){
 static const char *fixed[]={"WINPWRNT.EXE","UNINST.EXE","WINPSVC.EXE"};
 return index<3?fixed[index]:wp_driver(kind);
}
void wp_path(char *path,const char *folder,const char *file){lstrcpyA(path,folder);lstrcatA(path,"\\");lstrcatA(path,file);}
DWORD wp_setnum(HKEY key,const char *name,DWORD number){return RegSetValueExA(key,name,0,REG_DWORD,(const BYTE*)&number,4);}
DWORD wp_getnum(HKEY key,const char *name,DWORD *number){
 DWORD type,size=4;LONG error=RegQueryValueExA(key,name,0,&type,(BYTE*)number,&size);
 return error?(DWORD)error:(type==REG_DWORD&&size==4?0:ERROR_INVALID_DATA);
}
DWORD wp_config(HKEY key,struct wp_config *cfg){
 DWORD type,size=sizeof(*cfg);LONG error=RegQueryValueExA(key,"Config",0,&type,(BYTE*)cfg,&size);
 if(error)return error;
 if(type!=REG_BINARY||size!=sizeof(*cfg)||cfg->magic!=WP_CONFIG_MAGIC||
    (cfg->kind!=3&&cfg->kind!=4)||cfg->folder[MAX_PATH-1]||!wp_folder(cfg->folder))return ERROR_INVALID_DATA;
 return 0;
}
DWORD wp_hash(const char *path,BYTE digest[32],HANDLE *lock){
 struct wp_sha256 s;BYTE bytes[1024];DWORD got,error=0;HANDLE f;
 f=CreateFileA(path,GENERIC_READ,FILE_SHARE_READ,0,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,0);
 if(f==INVALID_HANDLE_VALUE)return GetLastError();wp_sha_init(&s);
 for(;;){if(!ReadFile(f,bytes,sizeof(bytes),&got,0)){error=GetLastError();break;}if(!got)break;wp_sha_add(&s,bytes,got);}
 if(error){CloseHandle(f);return error;}wp_sha_end(&s,digest);
 if(lock)*lock=f;else CloseHandle(f);return 0;
}
void wp_unlock(HANDLE locks[4]){unsigned i;for(i=0;i<4;i++)if(locks[i]){CloseHandle(locks[i]);locks[i]=0;}}
DWORD wp_checkfiles(const struct wp_config *cfg,HANDLE locks[4]){
 BYTE digest[32];char path[MAX_PATH];DWORD error;unsigned i;
 for(i=0;i<4;i++)locks[i]=0;
 for(i=0;i<4;i++){
  wp_path(path,cfg->folder,wp_file(cfg->kind,i));error=wp_hash(path,digest,&locks[i]);
  if(!error&&memcmp(digest,cfg->hashes[i],32))error=ERROR_CRC;
  if(error){wp_unlock(locks);return error;}
 }
 return 0;
}
DWORD wp_regread(HKEY key,struct wp_regvalue *value){
 DWORD type,size=sizeof(value->data);LONG error;ZeroMemory(value,sizeof(*value));value->magic=WP_REG_MAGIC;
 error=RegQueryValueExA(key,"PowerdownAfterShutdown",0,&type,value->data,&size);
 if(error==ERROR_FILE_NOT_FOUND)return 0;
 if(error)return error;value->present=1;value->type=type;value->size=size;return 0;
}
DWORD wp_saved(HKEY meta,struct wp_regvalue *value){
 DWORD size=sizeof(*value),type;LONG error=RegQueryValueExA(meta,"PowerBefore",0,&type,(BYTE*)value,&size);
 if(error)return error;
 return type==REG_BINARY&&size==sizeof(*value)&&wp_reg_valid(value)?0:ERROR_INVALID_DATA;
}
DWORD wp_winlogon(HKEY meta,BOOL restore){
 static const BYTE enabled[]={'1',0};struct wp_regvalue saved,current;HKEY key;DWORD error;int action;
 error=wp_saved(meta,&saved);if(error)return error;
 error=RegOpenKeyExA(HKEY_LOCAL_MACHINE,"Software\\Microsoft\\Windows NT\\CurrentVersion\\Winlogon",0,KEY_QUERY_VALUE|KEY_SET_VALUE,&key);if(error)return error;
 error=wp_regread(key,&current);if(error){RegCloseKey(key);return error;}
 action=wp_reg_restore(&saved,&current);
 if(action<0)error=ERROR_INVALID_DATA;
 else if(!restore){
  if(action==2)error=ERROR_INVALID_DATA;
  else error=RegSetValueExA(key,"PowerdownAfterShutdown",0,REG_SZ,enabled,sizeof(enabled));
 }else if(action==1){
  if(saved.present)error=RegSetValueExA(key,"PowerdownAfterShutdown",0,saved.type,saved.data,saved.size);
  else {error=RegDeleteValueA(key,"PowerdownAfterShutdown");if(error==ERROR_FILE_NOT_FOUND)error=0;}
 }
 if(!error)error=RegFlushKey(key);RegCloseKey(key);
 if(!error&&restore)error=wp_setnum(meta,"Restore",action==2?2:1);return error;
}
DWORD wp_owned(SC_HANDLE manager,const char *name,const char *path,DWORD type,SC_HANDLE *service){
 BYTE buffer[2048];QUERY_SERVICE_CONFIGA *cfg=(void*)buffer;DWORD need,error=0;char actual[MAX_PATH];const char *value;int n;
 *service=OpenServiceA(manager,name,SERVICE_QUERY_CONFIG|SERVICE_QUERY_STATUS|SERVICE_START|SERVICE_STOP|SERVICE_CHANGE_CONFIG|DELETE);
 if(!*service)return GetLastError();
 if(!QueryServiceConfigA(*service,cfg,sizeof(buffer),&need))error=GetLastError();
 else {
  value=cfg->lpBinaryPathName;
  if(lstrlenA(value)>=4&&value[0]=='\\'&&value[1]=='?'&&value[2]=='?'&&value[3]=='\\')value+=4;
  else if(lstrlenA(value)>=12&&value[0]=='\\'&&value[11]=='\\'){
   char prefix[13];unsigned j;for(j=0;j<12;j++)prefix[j]=value[j];prefix[12]=0;
   if(!lstrcmpiA(prefix,"\\DosDevices\\"))value+=12;
  }
  n=lstrlenA(value);if(n>=MAX_PATH)error=ERROR_INVALID_DATA;
  else {lstrcpyA(actual,value);if(n>=2&&actual[0]=='"'&&actual[n-1]=='"'){actual[n-1]=0;value=actual+1;}else value=actual;
   if(cfg->dwServiceType!=type||lstrcmpiA(value,path))error=ERROR_INVALID_DATA;
   if(type==SERVICE_KERNEL_DRIVER&&cfg->dwStartType!=SERVICE_DEMAND_START&&cfg->dwStartType!=SERVICE_DISABLED)error=ERROR_INVALID_DATA;
   if(type==SERVICE_WIN32_OWN_PROCESS&&(cfg->dwStartType!=SERVICE_AUTO_START&&cfg->dwStartType!=SERVICE_DISABLED))error=ERROR_INVALID_DATA;
   if(type==SERVICE_WIN32_OWN_PROCESS&&lstrcmpiA(cfg->lpServiceStartName,"LocalSystem"))error=ERROR_INVALID_DATA;
  }
 }
 if(error){CloseServiceHandle(*service);*service=0;}return error;
}
DWORD wp_backend(DWORD kind,DWORD *words){
 HANDLE device;DWORD size=kind==3?48:32,got,error=0;ZeroMemory(words,48);
 device=CreateFileA(kind==3?"\\\\.\\PN3LAB":"\\\\.\\PN4LAB",GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,0,OPEN_EXISTING,0,0);
 if(device==INVALID_HANDLE_VALUE)return GetLastError();
 if(!DeviceIoControl(device,0x00226000,0,0,words,size,&got,0))error=GetLastError();
 else if(got!=size||words[0]!=(kind==3?9UL:7UL)||words[1]!=1||!(words[4]&0x11)||(words[4]&~0xff1fUL)||(kind==3&&words[11]!=1))error=ERROR_INVALID_DATA;
 CloseHandle(device);return error;
}
/* Keep the Windows 4 PowerdownAfterShutdown value, the saved preference
   and the resident power owner consistent. Query the new protocol before
   making any changes: older drivers do not support handing control back. */
static DWORD legacy_mode(HANDLE dev,DWORD *value,BOOL write){
 DWORD bytes=0,word=0,error=0;
 if(write&&!DeviceIoControl(dev,0x22600c,value,sizeof(*value),0,0,&bytes,0))return GetLastError();
 if(!DeviceIoControl(dev,0x226014,0,0,&word,sizeof(word),&bytes,0))return GetLastError();
 if(bytes!=sizeof(word)||(word&~1UL)!=0x100)return ERROR_INVALID_DATA;
 if(write&&(word&1)!=*value)error=ERROR_INVALID_DATA;
 else *value=word&1;
 return error;
}
static DWORD apply_owner(HKEY meta,DWORD kind,DWORD mode,BOOL save){
 HANDLE dev;DWORD before=0,error;BOOL configured=FALSE,changed=FALSE;
 if(mode>1)return ERROR_INVALID_DATA;
 dev=CreateFileA(kind==3?"\\\\.\\PN3LAB":"\\\\.\\PN4LAB",GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,0,OPEN_EXISTING,0,0);
 if(dev==INVALID_HANDLE_VALUE)return GetLastError();
 error=legacy_mode(dev,&before,FALSE);
 if(!error&&kind==4&&meta){error=wp_winlogon(meta,!mode);configured=!error;}
 if(!error){error=legacy_mode(dev,&mode,TRUE);changed=!error;}
 if(!error&&meta&&save)error=wp_setnum(meta,"Owner",mode);
 if(error&&changed)legacy_mode(dev,&before,TRUE);
 if(error&&configured)wp_winlogon(meta,!before);
 CloseHandle(dev);return error;
}
static DWORD choose_locked(const char *folder,int requested);
DWORD wp_legacy_owner(DWORD kind,DWORD mode){
 HKEY key=0;DWORD error,removing;struct wp_config cfg;
 error=RegOpenKeyExA(HKEY_LOCAL_MACHINE,WP_META,0,KEY_QUERY_VALUE|KEY_SET_VALUE,&key);
 if(error==ERROR_FILE_NOT_FOUND||error==ERROR_PATH_NOT_FOUND)return apply_owner(0,kind,mode,FALSE);
 if(error)return error;
 error=wp_config(key,&cfg);if(!error&&cfg.kind!=kind)error=ERROR_INVALID_DATA;
 if(!error)error=wp_getnum(key,"Removing",&removing);
 if(!error&&removing)error=ERROR_SHUTDOWN_IN_PROGRESS;
 RegCloseKey(key);
 if(!error)error=choose_locked(cfg.folder,(int)mode);
 return error;
}
static DWORD basic_info(DWORD kind){
 typedef LONG (WINAPI *QUERY)(ULONG,PVOID,ULONG,PULONG);
 QUERY query=(QUERY)GetProcAddress(GetModuleHandleA("NTDLL.DLL"),"NtQuerySystemInformation");
 DWORD basic[11],got=0,error;HKEY key;char name[128];
 if(kind!=3)return 0;
 if(!query||query(0,basic,sizeof(basic),&got)<0||got!=sizeof(basic))return ERROR_NOT_SUPPORTED;
 if(basic[2]!=4096||basic[6]!=65536)return ERROR_INVALID_DATA;
 lstrcpyA(name,"System\\CurrentControlSet\\Services\\");lstrcatA(name,wp_kernel(kind));
 error=RegOpenKeyExA(HKEY_LOCAL_MACHINE,name,0,KEY_SET_VALUE,&key);if(error)return error;
 error=RegSetValueExA(key,"BasicInfo",0,REG_BINARY,(BYTE*)basic,sizeof(basic));RegCloseKey(key);return error;
}
static DWORD start_choice(const char *folder,int requested){
 struct wp_config cfg;HKEY meta=0;SC_HANDLE manager=0,kernel=0;SERVICE_STATUS service;
 HANDLE locks[4]={0,0,0,0};DWORD error,ready,removing,starts=0,stage=1,status[12];char path[MAX_PATH];DWORD owner=0;BOOL armed=FALSE;
 error=RegOpenKeyExA(HKEY_LOCAL_MACHINE,WP_META,0,KEY_QUERY_VALUE|KEY_SET_VALUE,&meta);if(error)return error;
 error=wp_setnum(meta,"Stage",1);if(error)goto done;
 error=wp_setnum(meta,"Armed",0);if(error)goto done;
 error=wp_config(meta,&cfg);if(error)goto done;
 if(lstrcmpiA(cfg.folder,folder)||cfg.kind!=wp_kind()){error=ERROR_NOT_SUPPORTED;goto done;}
 error=wp_getnum(meta,"Ready",&ready);if(error||ready!=1){if(!error)error=ERROR_INVALID_DATA;goto done;}
 error=wp_getnum(meta,"Removing",&removing);if(error||removing){if(!error)error=ERROR_SHUTDOWN_IN_PROGRESS;goto done;}
 error=wp_getnum(meta,"Starts",&starts);if(error)goto done;
 if(requested<0){error=wp_setnum(meta,"Starts",starts+1);if(error)goto done;}
 if(requested<0){
  error=wp_getnum(meta,"Owner",&owner);if(error==ERROR_FILE_NOT_FOUND){error=0;owner=0;}
  if(error||owner>1){if(!error)error=ERROR_INVALID_DATA;goto done;}
 }else owner=(DWORD)requested;
 stage=2;wp_setnum(meta,"Stage",stage);error=wp_checkfiles(&cfg,locks);if(error)goto done;
 manager=OpenSCManagerA(0,0,SC_MANAGER_CONNECT);if(!manager){error=GetLastError();goto done;}
 wp_path(path,folder,wp_driver(cfg.kind));error=wp_owned(manager,wp_kernel(cfg.kind),path,SERVICE_KERNEL_DRIVER,&kernel);if(error)goto done;
 if(!QueryServiceStatus(kernel,&service)){error=GetLastError();goto done;}
 if(service.dwCurrentState!=SERVICE_STOPPED&&service.dwCurrentState!=SERVICE_RUNNING){error=ERROR_SERVICE_CANNOT_ACCEPT_CTRL;goto done;}
 if(!owner&&service.dwCurrentState==SERVICE_STOPPED){
  if(cfg.kind==4&&requested>=0){error=wp_winlogon(meta,TRUE);if(error)goto done;}
  if(requested>=0){error=wp_setnum(meta,"Owner",0);if(error)goto done;}
  stage=6;goto done;
 }
 stage=3;wp_setnum(meta,"Stage",stage);error=basic_info(cfg.kind);if(error)goto done;

 stage=4;wp_setnum(meta,"Stage",stage);if(service.dwCurrentState==SERVICE_STOPPED&&!StartServiceA(kernel,0,0)){error=GetLastError();goto done;}
 stage=5;wp_setnum(meta,"Stage",stage);error=wp_backend(cfg.kind,status);if(error)goto done;
 error=apply_owner(meta,cfg.kind,owner,requested>=0);
 if(error)goto done;
 armed=TRUE;
 stage=6;
 done:
 wp_setnum(meta,"LastError",error);wp_setnum(meta,"Stage",stage);wp_setnum(meta,"Armed",armed?1:0);RegFlushKey(meta);
 wp_unlock(locks);if(kernel)CloseServiceHandle(kernel);if(manager)CloseServiceHandle(manager);RegCloseKey(meta);return error;
}

/* The SCM startup loader and a concurrent GUI choice serialize access to
   the persistent record. Pre-terminal-services NT uses one object namespace. */
static DWORD choose_locked(const char *folder,int requested){
 HANDLE lock=CreateMutexA(NULL,FALSE,WP_OWNER_MUTEX);DWORD wait,error;
 if(!lock)return GetLastError();
 wait=WaitForSingleObject(lock,30000);
 if(wait==WAIT_OBJECT_0||wait==WAIT_ABANDONED){
  error=start_choice(folder,requested);ReleaseMutex(lock);
 }else error=wait==WAIT_TIMEOUT?ERROR_TIMEOUT:GetLastError();
 CloseHandle(lock);return error;
}
DWORD wp_start(const char *folder){return choose_locked(folder,-1);}
