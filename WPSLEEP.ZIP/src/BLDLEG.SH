#!/bin/sh
# Build the selectable-owner NT 3.x/4.0 installed packages.
set -eu
cd "$(dirname "$0")"
mkdir -p ../TEST ../BIN/WINPWRNT/LEGACY
cp ../test/NTAUDIT.C ../test/PNREG.C ../test/MEMTEST.C ../test/INTTEST.C ../TEST/
sh BUILDP3.SH
sh BUILD4.SH
sh BUILDNT.SH all
cc=i686-w64-mingw32-gcc
i686-w64-mingw32-windres SLEEPUI.RC -O coff -o ../TEST/LEGICON.O
"$cc" -march=i386 -mno-sse -mno-mmx -x c -Os -Wall -Wextra -Werror -Wno-misleading-indentation -Wno-cast-function-type -fno-builtin -fno-stack-protector -nostdlib -mwindows -DWP_NT34CFG WINPOWER.C OSINFO.C OSNAME.C ICONUI.C FWAPI.C FWTABLE.C P9PREF.C NTPWR.C SHA256.C NTREG.C -x none ../TEST/LEGICON.O -Wl,--entry,_WinMainCRTStartup@0,--subsystem,windows:3.10 -o ../BIN/WINPWRNT/LEGACY/WINPWRNT.EXE -luser32 -lkernel32 -lgdi32 -ladvapi32
for f in SETUP.EXE WINPWRNT.EXE WINPSVC.EXE NTAUDIT.EXE PN4HOOK.SYS; do
 cp ../BIN/WINPWRNT/LEGACY/$f ../bin/NT3/
 cp ../BIN/WINPWRNT/LEGACY/$f ../bin/NT4/
done
cp ../BIN/WINPWRNT/LEGACY/PN3HOOK.SYS ../bin/NT3/
