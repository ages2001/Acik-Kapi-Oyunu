#!/bin/sh
set -eu
cd "$(dirname "$0")"
mkdir -p ../TEST
for arch in i686 x86_64; do
 if [ "$arch" = i686 ]; then out=2KXP; entry=_WinMainCRTStartup@0; ver=5.0; cpu=-march=i486
 else out=XPAMD64; entry=WinMainCRTStartup; ver=5.2; cpu=; fi
 "$arch-w64-mingw32-windres" WINPOWER.RC -O coff -o ../TEST/ICON5.O
 "$arch-w64-mingw32-windres" SLEEPUI.RC -O coff -o ../TEST/SLPICON.O
 flags="-x c $cpu -Os -Wall -Wextra -Werror -Wno-cast-function-type -Wno-misleading-indentation -fno-builtin -fno-stack-protector -nostdlib -mwindows"
 "$arch-w64-mingw32-gcc" $flags -DWP_NT5CFG WINPOWER.C OSINFO.C OSNAME.C ICONUI.C FWAPI.C FWTABLE.C P9PREF.C P5SCM.C -x none ../TEST/SLPICON.O -Wl,--entry,"$entry",--subsystem,windows:$ver -o ../bin/$out/WINPWRNT.EXE -luser32 -lkernel32 -lgdi32 -ladvapi32
 "$arch-w64-mingw32-gcc" $flags -DPN5_PACKAGE SETUP.C LINKOWN.C SHA256.C NTDDE.C P5SCM.C -x none ../TEST/ICON5.O -Wl,--entry,"$entry",--subsystem,windows:$ver -o ../bin/$out/SETUP.EXE -luser32 -lkernel32 -ladvapi32 -luuid
 "$arch-w64-mingw32-gcc" $flags HNDLOAD.C -Wl,--entry,"$entry",--subsystem,windows:$ver -o ../bin/$out/HNDLOAD.EXE -lkernel32 -luser32 -ladvapi32
done
rm ../TEST/ICON5.O
