#ifndef WP_N5HAND_H
#define WP_N5HAND_H
/* NT5 power-manager registrations. Windows owns the initial state. */
void wp_n5_initialize(void);
int wp_n5_arm(ULONG minor);
void wp_n5_latch(void);
NTSTATUS wp_n5_set(ULONG mode);
ULONG wp_n5_state(void);
void wp_n5_power(ULONG action);
#ifdef WP_2000
int wp_n5_has_reset_register(void);
#endif
#endif
