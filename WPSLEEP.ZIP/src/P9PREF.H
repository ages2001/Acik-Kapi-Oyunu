#ifndef WINPOWER_P9PREF_H
#define WINPOWER_P9PREF_H
DWORD wp9_add_pref(const char *folder);
DWORD wp9_del_pref(const char *folder);
DWORD wp9_remember(DWORD owner);
DWORD wp9_restore(void);
#endif
