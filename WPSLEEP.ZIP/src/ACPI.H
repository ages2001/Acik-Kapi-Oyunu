#ifndef PN_ACPI_H
#define PN_ACPI_H
/* Freestanding parser. A revision is valid only after checksum validation. */
int pn_rsdp(const unsigned char *p, unsigned long n);
#endif
