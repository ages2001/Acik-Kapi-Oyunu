#include "APMDATA.H"
static void descriptor(unsigned char *d,wp_apm_u32 base,wp_apm_u32 length,unsigned access,unsigned wide){
 wp_apm_u32 limit=length-1;
 d[0]=(unsigned char)limit;d[1]=(unsigned char)(limit>>8);
 d[2]=(unsigned char)base;d[3]=(unsigned char)(base>>8);d[4]=(unsigned char)(base>>16);
 d[5]=(unsigned char)access;d[6]=(unsigned char)(wide?0x40:0);d[7]=(unsigned char)(base>>24);
}
static wp_apm_u32 segment_length(wp_apm_u32 n){n&=0xffffUL;return n?n:65536UL;}
int wp_apm_decode(unsigned version,unsigned flags,unsigned mode,const struct wp_apm_raw *raw,struct wp_apm_map *out){
 struct wp_apm_map value;unsigned i;unsigned char *p=(unsigned char*)&value;
 if(!raw||!out)return 0;
 for(i=0;i<sizeof(value);i++)p[i]=0;
 /* Reserved flag bits and unknown versions do not establish a supported ABI. */
 if(version<0x100||version>0x102||(flags&~31U)||(raw->flags&1))return 0;
 if((mode!=16&&mode!=32)||!(flags&(mode==32?2:1)))return 0;
 value.mode=mode;value.count=mode==32?3:2;
 value.entry=mode==32?raw->bx:raw->bx&0xffffUL;
 value.base[0]=(raw->ax&0xffffUL)<<4;
 value.base[1]=(raw->cx&0xffffUL)<<4;
 value.base[2]=(raw->dx&0xffffUL)<<4;
 value.length[0]=version>=0x101?segment_length(raw->si):65536UL;
 if(mode==32){
  value.length[1]=version>=0x102?segment_length(raw->si>>16):65536UL;
  value.length[2]=version>=0x101?segment_length(raw->di):65536UL;
 }else {value.length[1]=version>=0x101?segment_length(raw->di):65536UL;value.base[2]=0;}
 if(value.entry>=value.length[0])return 0;
 for(i=0;i<value.count;i++){
  /* This diagnostic's bounded mapping profile excludes HMA/above-1MiB
     segment tails. Rejection is not proof that the BIOS lacks APM. */
  if(value.base[i]>0x100000UL-value.length[i])return 0;
  descriptor(value.descriptor+i*8,value.base[i],value.length[i],
             i+1==value.count?0x92:0x9a,mode==32&&i==0);
 }
 *out=value;return 1;
}
