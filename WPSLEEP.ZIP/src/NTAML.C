/* NT kernel glue for the bounded AML interpreter (AML.C) used by the
   NT3 and NT4 final-power backends. Hardware access policy:
   - SystemIO: any port except the PCI configuration window 0xCF8-0xCFF.
   - SystemMemory reads: firmware areas and memory above the NT-managed
     RAM top; writes: only above that top, the EBDA and 0xE0000-0xFFFFF.
     The backends run these methods from the shutdown thread at
     PASSIVE_LEVEL, before their final firmware write.
   - PCI_Config: configuration mechanism #1. */
#include <ntddk.h>
#include "S5.H"
#ifdef PN_NT3ABI
/* NT 3.1 exports the original (non-fastcall) IRQL routines from the HAL. */
#undef KeRaiseIrql
#undef KeLowerIrql
__declspec(dllimport) VOID NTAPI KeRaiseIrql(KIRQL,PKIRQL);
__declspec(dllimport) VOID NTAPI KeLowerIrql(KIRQL);
#endif
#include "NTAML.H"
#define NT_NODES 4096U
#define NT_ARENA 262144UL
static struct pn_amlctx ctx;
static ULONG ram_top,ram_high,ebda;
static int firmware_area(ULONG a,ULONG n){
 if(!n||a>0xffffffffUL-n)return 0;
 if(a>=0xe0000UL&&a+n<=0x100000UL)return 1;
 if(ebda&&a>=ebda&&a+n<=0xa0000UL)return 1;
 return !ram_high&&ram_top&&a>=ram_top;
}
static int map(ULONG a,unsigned w,ULONG *v,int write){
 PHYSICAL_ADDRESS p;volatile UCHAR *m;
 if(!firmware_area(a,w/8))return 0;
 p.QuadPart=a;m=MmMapIoSpace(p,w/8,MmNonCached);if(!m)return 0;
 if(write){if(w==8)*m=(UCHAR)*v;else if(w==16)*(volatile USHORT*)m=(USHORT)*v;else *(volatile ULONG*)m=*v;}
 else{if(w==8)*v=*m;else if(w==16)*v=*(volatile USHORT*)m;else *v=*(volatile ULONG*)m;}
 MmUnmapIoSpace((PVOID)m,w/8);return 1;
}
static int memr(void *g,pn_u32 a,unsigned w,pn_u32 *v){(void)g;return map(a,w,v,0);}
static int memw(void *g,pn_u32 a,unsigned w,pn_u32 v){(void)g;return map(a,w,&v,1);}
static ULONG in(unsigned port,unsigned w){
 ULONG v=0;USHORT p=(USHORT)port;
 if(w==8){UCHAR b;__asm__ volatile("inb %w1,%0":"=a"(b):"d"(p));v=b;}
 else if(w==16){USHORT s;__asm__ volatile("inw %w1,%0":"=a"(s):"d"(p));v=s;}
 else __asm__ volatile("inl %w1,%0":"=a"(v):"d"(p));
 return v;
}
static void out(unsigned port,unsigned w,ULONG v){
 USHORT p=(USHORT)port;
 if(w==8)__asm__ volatile("outb %0,%w1"::"a"((UCHAR)v),"d"(p));
 else if(w==16)__asm__ volatile("outw %0,%w1"::"a"((USHORT)v),"d"(p));
 else __asm__ volatile("outl %0,%w1"::"a"(v),"d"(p));
}
static int ior(void *g,pn_u32 p,unsigned w,pn_u32 *v){(void)g;if(p>0xffffUL||(w!=8&&w!=16&&w!=32))return 0;*v=in((unsigned)p,w);return 1;}
static int iow(void *g,pn_u32 p,unsigned w,pn_u32 v){
 (void)g;if(p>0xffffUL||(p>=0xcf8&&p<0xd00)||(w!=8&&w!=16&&w!=32))return 0;out((unsigned)p,w,v);return 1;
}
static int cfg(unsigned b,unsigned d,unsigned f,unsigned r,unsigned w,ULONG *a){
 if(b>255||d>31||f>7||r>255||(r&3)+w/8>4)return 0;
 *a=0x80000000UL|((ULONG)b<<16)|((ULONG)d<<11)|((ULONG)f<<8)|(r&0xfc);return 1;
}
static int pcir(void *g,unsigned b,unsigned d,unsigned f,unsigned r,unsigned w,pn_u32 *v){
 ULONG a,x;KIRQL old;(void)g;if(!cfg(b,d,f,r,w,&a))return 0;
 KeRaiseIrql(HIGH_LEVEL,&old);out(0xcf8,32,a);x=in(0xcfc,32);KeLowerIrql(old);
 *v=(x>>(8*(r&3)))&(w==32?0xffffffffUL:((1UL<<w)-1));return 1;
}
static int pciw(void *g,unsigned b,unsigned d,unsigned f,unsigned r,unsigned w,pn_u32 v){
 ULONG a;KIRQL old;(void)g;if(!cfg(b,d,f,r,w,&a))return 0;
 KeRaiseIrql(HIGH_LEVEL,&old);out(0xcf8,32,a);
 if(w==8)out(0xcfc+(r&3),8,v);else if(w==16)out(0xcfc+(r&2),16,v);else out(0xcfc,32,v);
 KeLowerIrql(old);return 1;
}
static void stall(void *g,pn_u32 us){(void)g;while(us>1000){KeStallExecutionProcessor(1000);us-=1000;}KeStallExecutionProcessor(us);}
static const struct pn_aml_env env={0,ior,iow,memr,memw,pcir,pciw,stall};
#ifdef PN_NT5_RANGES
#include "REGMEM.H"
/* Only FADT/MCFG fixed descriptors reach this callback. Device windows
   can lie between OS RAM ranges on PAE and AMD64 systems. Read the
   kernel-owned range list at discovery time, before final power IRQL. */
static int nt5_mmio_hole(PHYSICAL_ADDRESS address,unsigned bytes)
{
 PPHYSICAL_MEMORY_RANGE map=MmGetPhysicalMemoryRanges();
 unsigned i;int clear=0;
 if(!map)return 0;
 for(i=0;i<4096;i++){
  if(!map[i].BaseAddress.QuadPart&&!map[i].NumberOfBytes.QuadPart){
   clear=i!=0;break;
  }
  if(map[i].BaseAddress.QuadPart<0||map[i].NumberOfBytes.QuadPart<=0||
     !wp_ram_disjoint((uint64_t)address.QuadPart,bytes,
                      (uint64_t)map[i].BaseAddress.QuadPart,
                      (uint64_t)map[i].NumberOfBytes.QuadPart))break;
 }
 ExFreePool(map);return clear;
}
#endif
int pn_ntreg_bind(struct pn_reg *r){
 PHYSICAL_ADDRESS addr;
#ifdef PN_NT5_RANGES
 addr.LowPart=(ULONG)r->low;addr.HighPart=(LONG)r->high;
 if((!ram_top&&!ram_high)||addr.HighPart<0||r->space!=0||
    (r->bytes!=1&&r->bytes!=2)||(!r->high&&r->low<0x100000UL))return 0;
 if((r->high<ram_high||(r->high==ram_high&&r->low<ram_top))&&
    !nt5_mmio_hole(addr,r->bytes))return 0;
#else
 if((!ram_top&&!ram_high)||r->high<ram_high||(r->high==ram_high&&r->low<ram_top)||
    (!r->high&&r->low<0x100000UL))return 0;
 addr.LowPart=(ULONG)r->low;addr.HighPart=(LONG)r->high;
 if(addr.HighPart<0)return 0;
 if(r->bytes!=1&&r->bytes!=2)return 0;
#endif
 r->native=MmMapIoSpace(addr,r->bytes,MmNonCached);return r->native!=0;
}
int pn_ntreg_write(const struct pn_reg *r,unsigned value){
 if(!r->native)return 0;
 if(r->bytes==2)*(volatile USHORT *)r->native=(USHORT)value;
 else if(r->bytes==1)*(volatile UCHAR *)r->native=(UCHAR)value;
 else return 0;
 return 1;
}
int pn_ntreg_read16(const struct pn_reg *r,unsigned *v){
 if(!r->native||r->bytes!=2)return 0;
 *v=*(volatile USHORT *)r->native;return 1;
}
void pn_ntreg_release(struct pn_acpi *p){
 struct pn_reg *reg[5];unsigned i;
 reg[0]=&p->control_reg;reg[1]=&p->status_reg;reg[2]=&p->reset_reg;
 reg[3]=&p->pm1a_reg;reg[4]=&p->pm1b_reg;
 for(i=0;i<5;i++)if(reg[i]->native){MmUnmapIoSpace(reg[i]->native,reg[i]->bytes);reg[i]->native=0;}
}
static int setup_ram(unsigned long top,unsigned long high,unsigned long ebda_base){
 pn_ntaml_release();
 ram_top=top;ram_high=high;ebda=(ebda_base>=0x80000UL&&ebda_base<0xa0000UL)?ebda_base:0;
 ctx.nodes=ExAllocatePool(NonPagedPool,NT_NODES*sizeof(struct pn_aml_node));
 ctx.arena=ExAllocatePool(NonPagedPool,NT_ARENA);
 if(!ctx.nodes||!ctx.arena){pn_ntaml_release();return 0;}
 ctx.capacity=NT_NODES;ctx.arena_size=NT_ARENA;ctx.env=&env;pn_amlctx=&ctx;return 1;
}
void pn_ntaml_release(void){
 if(ctx.nodes)ExFreePool(ctx.nodes);if(ctx.arena)ExFreePool(ctx.arena);
 RtlZeroMemory(&ctx,sizeof(ctx));pn_amlctx=0;
}
/* After pn_tables: keep the namespace only when it is needed. */
int pn_ntaml_setup(unsigned long top,unsigned long ebda_base){
 return setup_ram(top,0,ebda_base);
}
int pn_ntaml_pages(unsigned long highest_page,unsigned long ebda_base){
 unsigned long high=(highest_page>>20)+((highest_page&0xfffffUL)==0xfffffUL);
 return setup_ram((highest_page+1UL)<<12,high,ebda_base);
}
void pn_ntaml_done(int keep){pn_amlctx=0;if(!keep||!ctx.loaded)pn_ntaml_release();}
int pn_ntaml_prepared(void){return ctx.loaded&&ctx.prepare;}
unsigned pn_ntaml_tables(void){return ctx.loaded?ctx.tables:0;}
int pn_ntaml_prepare(void *arg){
 (void)arg;
 if(ctx.loaded&&ctx.prepare)ctx.done=pn_aml_prepare(&ctx.aml,&env,5)?1:2;
 return ctx.done!=2;
}
unsigned pn_ntaml_result(void){return ctx.done;}
