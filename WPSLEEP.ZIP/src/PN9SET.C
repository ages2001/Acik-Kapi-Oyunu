/* Transactional SYSTEM.INI integration for the separate Win9x lab package. */
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include "PN9SET.H"
#include "PN9INI.H"
static char before[65536],after[65536],verify[65536],reason[600];
static BOOL recovery;
static void fail(const char *s){lstrcpynA(reason,s,sizeof(reason));}
const char *pn9_reason(void){return reason[0]?reason:"The Win9x driver installation could not be completed.";}
BOOL pn9_recovery(void){return recovery;}
static void join(char *out,const char *folder,const char *name){wsprintfA(out,"%s\\%s",folder,name);}
static BOOL readfile(const char *path,char *data,DWORD *size){
 HANDLE h;DWORD n,got;BOOL ok;
 h=CreateFileA(path,GENERIC_READ,FILE_SHARE_READ,0,OPEN_EXISTING,0,0);if(h==INVALID_HANDLE_VALUE)return FALSE;
 n=GetFileSize(h,0);ok=n>0&&n<65536&&ReadFile(h,data,n,&got,0)&&got==n;CloseHandle(h);
 if(ok)*size=n;
 return ok;
}
static BOOL same(const char *a,const char *b,DWORD n){while(n--)if(*a++!=*b++)return FALSE;return TRUE;}
BOOL pn9_stage(const char *self,const char *folder){
 char src[MAX_PATH],dst[MAX_PATH];int i;const char *name="PN9HOOK.VXD";
 lstrcpynA(src,self,sizeof(src));i=lstrlenA(src);while(i&&src[i-1]!='\\')i--;src[i]=0;
 if(i>MAX_PATH-16){fail("The source path is too long.");return FALSE;}
 {
  char file[MAX_PATH];lstrcpyA(file,src);lstrcatA(file,name);join(dst,folder,name);
  if(!CopyFileA(file,dst,TRUE)){fail("Keep PN9HOOK.VXD beside SETUP.EXE. The driver could not be copied.");return FALSE;}
  /* Only this newly copied destination is ours to normalize. */
  if(!SetFileAttributesA(dst,FILE_ATTRIBUTE_NORMAL)){fail("Attributes could not be set on the newly copied driver or helper.");return FALSE;}
 }return TRUE;
}
static BOOL edit(const char *folder,BOOL remove){
 char system[MAX_PATH],temp[MAX_PATH],old[MAX_PATH],backup[MAX_PATH],driver[MAX_PATH];
 DWORD n=0,m=0,got=0,attrs;unsigned written=0;int result;HANDLE h;BOOL ok;
 GetWindowsDirectoryA(system,MAX_PATH);lstrcatA(system,"\\SYSTEM.INI");
 GetWindowsDirectoryA(temp,MAX_PATH);lstrcatA(temp,"\\PN9NEW.INI");
 join(old,folder,"SYSOLD.INI");join(backup,folder,"SYSBACK.INI");join(driver,folder,"PN9HOOK.VXD");
 if(!readfile(system,before,&n)){fail("SYSTEM.INI could not be read or exceeds the supported 64 KiB bound.");return FALSE;}
 attrs=GetFileAttributesA(system);
 if(attrs==INVALID_FILE_ATTRIBUTES||(attrs&FILE_ATTRIBUTE_READONLY)){fail("SYSTEM.INI is read-only or unavailable.");return FALSE;}
 result=pn9_ini(before,n,after,sizeof(after),driver,remove,&written);
 if(result<0){fail(result==-2?"Another PN9HOOK startup entry already exists. Remove that installation before installing this package.":"SYSTEM.INI has an unsupported or ambiguous layout. No startup entry was changed.");return FALSE;}
 if(result==2)return TRUE;
 if(GetFileAttributesA(temp)!=INVALID_FILE_ATTRIBUTES||GetFileAttributesA(old)!=INVALID_FILE_ATTRIBUTES){fail("PN9NEW.INI or SYSOLD.INI already exists. Keep it for recovery and resolve the earlier transaction before retrying.");return FALSE;}
 if(!remove&&!CopyFileA(system,backup,TRUE)){fail("The original SYSTEM.INI backup could not be created.");return FALSE;}
 h=CreateFileA(temp,GENERIC_WRITE,0,0,CREATE_NEW,FILE_ATTRIBUTE_NORMAL,0);
 if(h==INVALID_HANDLE_VALUE){fail("The temporary SYSTEM.INI file could not be created.");return FALSE;}
 ok=WriteFile(h,after,written,&got,0)&&got==written&&FlushFileBuffers(h);CloseHandle(h);
 if(!ok){DeleteFileA(temp);fail("The temporary SYSTEM.INI file could not be flushed. The original was retained.");return FALSE;}
 if(!SetFileAttributesA(temp,attrs)){DeleteFileA(temp);fail("The original SYSTEM.INI attributes could not be preserved. The original file was retained.");return FALSE;}
 if(!readfile(system,verify,&m)||m!=n||!same(before,verify,n)||GetFileAttributesA(system)!=attrs){DeleteFileA(temp);fail("SYSTEM.INI changed during setup. No startup entry was changed; retry after closing other configuration tools.");return FALSE;}
 if(!MoveFileA(system,old)){DeleteFileA(temp);fail("SYSTEM.INI could not be moved to its recovery copy. The original was retained.");return FALSE;}
#ifdef PN_FAIL_RENAME
 /* Test-only injection after the original file has moved to recovery. */
 if(TRUE){
#else
 if(!MoveFileA(temp,system)){
#endif
  if(!MoveFileA(old,system)){
   recovery=TRUE;wsprintfA(reason,"SYSTEM.INI could not be restored. Keep the installation files. Restore %s to %s before restarting Windows.",old,system);return FALSE;
  }
  DeleteFileA(temp);fail("The SYSTEM.INI replacement failed. The original was restored.");return FALSE;
 }
 DeleteFileA(old);
 /* Drop profile API caches; never replace duplicate device keys through it. */
 WritePrivateProfileStringA(0,0,0,system);return TRUE;
}
BOOL pn9_install(const char *folder){return edit(folder,FALSE);}
BOOL pn9_remove(const char *folder){return edit(folder,TRUE);}
/* The statically loaded VxD can outlive all its files. Hand back a live
   installation before deleting them. Opening the resident device by name
   does not dynamically load the driver from disk. */
BOOL pn9_release(void){
 HANDLE device;
 DWORD actual=2,os=0,bytes=0,error;
 BOOL ok;
 device=CreateFileA("\\\\.\\PN9HOOK",0,0,NULL,OPEN_EXISTING,0,NULL);
 if(device==INVALID_HANDLE_VALUE){
  error=GetLastError();
  if(error==ERROR_FILE_NOT_FOUND||error==ERROR_PATH_NOT_FOUND||
     error==ERROR_MOD_NOT_FOUND||error==ERROR_DEV_NOT_EXIST)return TRUE;
  fail("Cannot identify the resident Win9x driver. Restart Windows and retry removal.");
  return FALSE;
 }
 ok=DeviceIoControl(device,5,NULL,0,&actual,sizeof(actual),&bytes,NULL)
    &&bytes==sizeof(actual)&&actual<=1;
 if(ok&&actual==1){
  ok=DeviceIoControl(device,4,&os,sizeof(os),NULL,0,&bytes,NULL)
     &&DeviceIoControl(device,5,NULL,0,&actual,sizeof(actual),&bytes,NULL)
     &&bytes==sizeof(actual)&&actual==0;
 }
 CloseHandle(device);
 if(!ok)fail("Windows could not confirm OS ownership. Restart Windows and retry removal.");
 return ok;
}
BOOL pn9_cleanup(const char *folder){
 static const char *names[]={"PN9HOOK.VXD","SYSBACK.INI","SYSOLD.INI"};
 char path[MAX_PATH];unsigned i;if(recovery)return FALSE;
 for(i=0;i<sizeof(names)/sizeof(names[0]);i++){
  join(path,folder,names[i]);
  if(!DeleteFileA(path)&&GetLastError()!=ERROR_FILE_NOT_FOUND){fail("A driver or helper file is still open. Close PN9TEST and retry removal; the startup entry has already been removed.");return FALSE;}
 }return TRUE;
}
BOOL pn9_finish(const char *folder){
 HKEY key;HANDLE file;DWORD size=0,kind=0,got=0,disp;LONG result;
 char windir[MAX_PATH],shortdir[MAX_PATH],batch[MAX_PATH],command[MAX_PATH+48],script[1024];BOOL ok;
 if(!GetWindowsDirectoryA(windir,sizeof(windir))||!GetShortPathNameA(windir,shortdir,sizeof(shortdir))){fail("Cannot locate the short Windows path for removal cleanup. Retry the uninstaller.");return FALSE;}
 join(batch,shortdir,"PN9CLN.BAT");
 if(RegCreateKeyExA(HKEY_LOCAL_MACHINE,"Software\\Microsoft\\Windows\\CurrentVersion\\RunOnce",0,0,0,KEY_QUERY_VALUE|KEY_SET_VALUE,0,&key,&disp)!=ERROR_SUCCESS){fail("Cannot schedule removal cleanup. Retry the uninstaller.");return FALSE;}
 result=RegQueryValueExA(key,"WINPWR9X",0,&kind,0,&size);
 if(result!=ERROR_FILE_NOT_FOUND){RegCloseKey(key);fail("A WINPWR9X RunOnce value already exists. Preserve it and finish that earlier cleanup before retrying.");return FALSE;}
 file=CreateFileA(batch,GENERIC_WRITE,0,0,CREATE_NEW,FILE_ATTRIBUTE_NORMAL,0);
 if(file==INVALID_HANDLE_VALUE){RegCloseKey(key);fail("PN9CLN.BAT already exists or cannot be created. Preserve it and resolve the earlier cleanup before retrying.");return FALSE;}
 wsprintfA(script,"@ECHO OFF\r\nIF EXIST %s\\UNINST.EXE DEL %s\\UNINST.EXE\r\nRD %s\r\nDEL %s\r\n",folder,folder,folder,batch);
 size=lstrlenA(script);ok=WriteFile(file,script,size,&got,0)&&got==size&&FlushFileBuffers(file);CloseHandle(file);
 wsprintfA(command,"%s\\COMMAND.COM /C %s",shortdir,batch);
 if(ok)ok=RegSetValueExA(key,"WINPWR9X",0,REG_SZ,(const BYTE*)command,lstrlenA(command)+1)==ERROR_SUCCESS;
 RegCloseKey(key);
 if(!ok){DeleteFileA(batch);fail("Removal cleanup could not be saved. Retry the uninstaller.");return FALSE;}
 return TRUE;
}
