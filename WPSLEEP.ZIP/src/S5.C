#include "S5.H"
#include "ACPI.H"
#include <string.h>
#ifdef PN_MULTI_S5
#include <limits.h>
#endif
#ifdef PN_AML
struct pn_amlctx *pn_amlctx;
#endif
static unsigned long u32(const unsigned char *p){return (unsigned long)p[0]|((unsigned long)p[1]<<8)|((unsigned long)p[2]<<16)|((unsigned long)p[3]<<24);
 }
/* PkgLength includes its own encoding, but excludes the preceding opcode. */
static int pkg(const unsigned char *p,unsigned end,unsigned *at,unsigned *stop){
 unsigned start=*at,k,n;unsigned long v;
 if(start>=end)return 0;
 n=p[(*at)++]>>6;v=n?(p[start]&15):(p[start]&63);
#ifdef PN_MULTI_S5
 if(n&&(p[start]&0x30))return 0;
#endif
 if(n>end-*at)return 0;
 for(k=0;k<n;k++)v|=(unsigned long)p[(*at)++]<<(4+8*k);
 if(v<*at-start||v>end-start)return 0;
 *stop=start+(unsigned)v;return 1;
}
static int name(const unsigned char *p,unsigned end,unsigned *at,unsigned depth,unsigned *target,char last[5]){
 unsigned n=1,i,j;*target=depth;
 if(*at>=end)return 0;
 if(p[*at]=='\\'){*target=0;(*at)++;}
 while(*at<end&&p[*at]=='^'){if(!*target)return 0;
 --*target;(*at)++;}
 if(*at>=end)return 0;
 if(p[*at]==0){(*at)++;last[0]=0;return 1;
 }
 if(p[*at]==0x2e){n=2;(*at)++;}
 else if(p[*at]==0x2f){(*at)++;if(*at>=end)return 0;
 n=p[(*at)++];if(!n)return 0;
 }
 if(n>(end-*at)/4)return 0;
 for(i=0;i<n;i++)for(j=0;j<4;j++){
  unsigned c=p[(*at)++];if(c!='_'&&!(c>='A'&&c<='Z')&&!(j&&c>='0'&&c<='9'))return 0;
 last[j]=(char)c;
 }
 last[4]=0;*target+=n;return *target<64;
}
/* Track a conservative depth interval. A relative Scope may search parent
   namespaces; its shallowest possible named target is a root child. No
   namespace lookup is guessed. Ambiguous root sleep objects fail closed. */
static int namespan(const unsigned char *p,unsigned end,unsigned *at,unsigned low,unsigned high,unsigned *target,unsigned *upper,char last[5],unsigned scope){
 unsigned start=*at;
 if(!name(p,end,at,low,target,last))return 0;
 *upper=*target;
#ifdef PN_MULTI_S5
 if(p[start]!='\\')*upper+=high-low;
 if(*upper>=64)return 0;
 if(scope&&p[start]!='\\'&&last[0]&&*target>1)*target=1;
#else
 (void)start;(void)high;(void)scope;
#endif
 return 1;
}
static int integer(const unsigned char *p,unsigned end,unsigned *at,unsigned long *v){
 unsigned op,n=0,i;*v=0;if(*at>=end)return 0;
 op=p[(*at)++];
 if(op==0||op==1){*v=op;return 1;
 }if(op==0xff){*v=0xffffffffUL;return 1;
 }
 if(op==0x0a)n=1;else if(op==0x0b)n=2;else if(op==0x0c)n=4;else if(op==0x0e)n=8;else return 0;
 if(n>end-*at)return 0;
 for(i=0;i<n;i++){unsigned c=p[(*at)++];if(i<4)*v|=(unsigned long)c<<(8*i);else if(c)return 0;
 }
 return 1;
}
static int data_level(const unsigned char *p,unsigned end,unsigned *at,unsigned level){
 unsigned save=*at,stop;unsigned long v;
#ifdef PN_MULTI_S5
 unsigned op;unsigned long count;
 if(level>24)return 0;
#else
 (void)level;
#endif
 if(integer(p,end,at,&v))return 1;
 *at=save;
 if(*at>=end)return 0;
 if(p[*at]==0x0d){(*at)++;while(*at<end)if(p[(*at)++]==0)return 1;
 return 0;
 }
 if(p[*at]==0x11||p[*at]==0x12||p[*at]==0x13){
#ifdef PN_MULTI_S5
 op=p[(*at)++];if(!pkg(p,end,at,&stop))return 0;
 if(op==0x11){
  /* BufferSize is a TermArg: only a literal rules out table-load code. */
  if(!integer(p,stop,at,&v))return 0;
 }else{
  if(op==0x12){if(*at>=stop)return 0;count=p[(*at)++];}
  else if(!integer(p,stop,at,&count))return 0;
  if(count>PN_NS_MAX_AML)return 0;
  while(count--)if(!data_level(p,stop,at,level+1))return 0;
  if(*at!=stop)return 0;
 }
#else
 (*at)++;if(!pkg(p,end,at,&stop))return 0;
#endif
 *at=stop;return 1;
 }
 return 0;
}
static int data(const unsigned char *p,unsigned end,unsigned *at){return data_level(p,end,at,0);}
static int powername(unsigned target,const char *name){
 return target==1 && (!strcmp(name,"_TTS") || !strcmp(name,"_PTS") ||
        !strcmp(name,"_GTS") || !strcmp(name,"_S5_") || !strcmp(name,"_SST"));
}
#ifdef PN_MULTI_S5
static int fieldbits(const unsigned char *p,unsigned end,unsigned *at){
 unsigned n,start=*at;
 if(start>=end)return 0;
 n=p[(*at)++]>>6;
 if((n&&(p[start]&0x30))||n>end-*at)return 0;
 *at+=n;return 1;
}
static int fields(const unsigned char *p,unsigned end,unsigned *at,unsigned depth,unsigned ext){
 unsigned target,i,op;char nm[5];unsigned long v;
 if(!name(p,end,at,depth,&target,nm))return 0;
 if(ext!=0x81&&!name(p,end,at,depth,&target,nm))return 0;
 if(ext==0x87&&!integer(p,end,at,&v))return 0;
 if(*at>=end)return 0;
 (*at)++; /* FieldFlags */
 while(*at<end){
  op=p[*at];
  if(op==0){(*at)++;if(!fieldbits(p,end,at))return 0;}
  else if(op==1||op==3){i=op==1?3:4;if(i>end-*at)return 0;*at+=i;}
  else if(op==2){
   (*at)++;if(*at>=end)return 0;
   if(p[*at]==0x11){if(!data(p,end,at))return 0;}
   else if(!name(p,end,at,depth,&target,nm))return 0;
  }else{
   if(end-*at<4)return 0;
   for(i=0;i<4;i++){
    unsigned c=p[(*at)++];if(c!='_'&&!(c>='A'&&c<='Z')&&!(i&&c>='0'&&c<='9'))return 0;
    nm[i]=(char)c;
   }
   nm[4]=0;if(powername(depth+1,nm)||!fieldbits(p,end,at))return 0;
  }
 }
 return *at==end;
}
#endif
#ifndef PN_MULTI_S5
struct pn_s5ns {unsigned found,a,b,hook;};
#endif
static int terms(const unsigned char *p,unsigned at,unsigned end,unsigned depth,unsigned high,unsigned nesting,struct pn_s5ns *s){
 unsigned op,stop,target,upper,k,ext;char nm[5];unsigned long a,b;
 if(nesting>24)return 0;
 while(at<end){
  op=p[at++];
  if(op==0x08){
   if(!namespan(p,end,&at,depth,high,&target,&upper,nm,0))return 0;
#ifdef PN_MULTI_S5
   if(!nm[0]||(powername(target,nm)&&strcmp(nm,"_S5_")))return 0;
#endif
   if(target==1&&!strcmp(nm,"_S5_")){
#ifdef PN_MULTI_S5
    if(upper!=1)return 0;
#endif
    if(s->found||at>=end||p[at++]!=0x12||!pkg(p,end,&at,&stop)||at>=stop)return 0;
    k=p[at++];if(k<2||!integer(p,stop,&at,&a)||!integer(p,stop,&at,&b)||a>7||b>7)return 0;
    for(k-=2;k;k--)if(!data(p,stop,&at))return 0;
    if(at!=stop)return 0;
 s->found=1;s->a=(unsigned)a;s->b=(unsigned)b;
   }else if(!data(p,end,&at))return 0;
  }else if(op==0x10||op==0x14){
   if(!pkg(p,end,&at,&stop))return 0;
   if(!namespan(p,stop,&at,depth,high,&target,&upper,nm,op==0x10))return 0;
#ifdef PN_MULTI_S5
   if((op==0x14&&!nm[0])||(op==0x10&&powername(target,nm)))return 0;
#endif
   if(op==0x14){
    if(at>=stop)return 0;
    if(powername(target,nm))s->hook=1;
   }else if(!terms(p,at,stop,target,upper,nesting+1,s))return 0;
   at=stop;
  }else if(op==0x5b){
   if(at>=end)return 0;
 ext=p[at++];
   if(ext==0x82||ext==0x83||ext==0x84||ext==0x85){
    if(!pkg(p,end,&at,&stop)||!namespan(p,stop,&at,depth,high,&target,&upper,nm,0))return 0;
#ifdef PN_MULTI_S5
    if(!nm[0]||powername(target,nm))return 0;
#endif
    k=ext==0x83?6:(ext==0x84?3:0);if(k>stop-at)return 0;
 at+=k;
    if(!terms(p,at,stop,target,upper,nesting+1,s))return 0;
 at=stop;
   }else if(ext==0x81||ext==0x86||ext==0x87){if(!pkg(p,end,&at,&stop))return 0;
#ifdef PN_MULTI_S5
    if(!fields(p,stop,&at,depth,ext))return 0;
#endif
 at=stop;}
   else if(ext==0x80){
    if(!namespan(p,end,&at,depth,high,&target,&upper,nm,0)||at>=end)return 0;
#ifdef PN_MULTI_S5
    if(!nm[0]||powername(target,nm))return 0;
#endif
 at++;
    if(!integer(p,end,&at,&a)||!integer(p,end,&at,&b))return 0;
   }else if(ext==1||ext==2){if(!namespan(p,end,&at,depth,high,&target,&upper,nm,0))return 0;
#ifdef PN_MULTI_S5
    if(!nm[0]||powername(target,nm))return 0;
#endif
 if(ext==1){if(at>=end)return 0;
 at++;}}
   else return 0;
  }else if(op==0x06){
   /* Alias could redefine the sleep namespace: unsupported. */
   return 0;
  }else if(op==0xa3){ /* Noop */ }
  else return 0; /* Includes executable top-level If/Else and dynamic names. */
 }
 return at==end;
}
int pn_s5(const unsigned char *aml,unsigned size,unsigned *a,unsigned *b){
 struct pn_s5ns s;memset(&s,0,sizeof(s));
 if(!aml||!terms(aml,0,size,0,0,0,&s)||!s.found||s.hook)return 0;
 *a=s.a;*b=s.b;return 1;
}
#ifdef PN_MULTI_S5
void pn_ns_begin(struct pn_s5ns *s){if(s)memset(s,0,sizeof(*s));}
int pn_ns_add(struct pn_s5ns *s,const unsigned char *aml,unsigned size){
 if(!s)return 0;
 if(s->failed)return 0;
 if(!aml||s->tables>=PN_NS_MAX_TABLES||
#if UINT_MAX > 65535U
    size>PN_NS_MAX_AML||
#endif
    !terms(aml,0,size,0,0,0,s)||s->hook){s->failed=1;return 0;}
 s->tables++;return 1;
}
int pn_ns_sleep(const struct pn_s5ns *s,unsigned *a,unsigned *b){
 if(!s||!a||!b||!s->tables||s->failed||!s->found||s->hook)return 0;
 *a=s->a;*b=s->b;return 1;
}
#endif
static pn_address table_address(const unsigned char *p,int wide){
 pn_address address=u32(p);
 if(wide){
#ifdef PN_WIDE_TABLES
  address|=(pn_address)u32(p+4)<<32;
#else
  if(u32(p+4))return 0;
#endif
 }
 return address;
}
static int table_range(pn_address address,unsigned long length){
#ifdef PN_WIDE_TABLES
 return address&&length&&address<=~(pn_address)0-(length-1);
#else
 return address&&length&&address<=0xffffffffUL-(length-1);
#endif
}
static int table(pn_read read,void *arg,pn_address address,const char *sig,unsigned char *work,unsigned cap,unsigned *length){
 unsigned long n;unsigned i;unsigned char sum=0;
 if(!table_range(address,36)||cap<36||!read(arg,address,work,36)||memcmp(work,sig,4))return 0;
 n=u32(work+4);if(n<36||n>cap||!table_range(address,n))return 0;
 if(!read(arg,address,work,(unsigned)n))return 0;
 for(i=0;i<(unsigned)n;i++)sum=(unsigned char)(sum+work[i]);
 if(sum)return 0;
 *length=(unsigned)n;return 1;
}
#ifdef PN_TIMER_INFO
static unsigned port(const unsigned char *gas,unsigned width){
 unsigned long addr=u32(gas+4);
 if(gas[0]!=1||gas[1]!=width||gas[2]!=0||(gas[3]&&gas[3]!=
    (width==32?3:(width==16?2:1)))||
    u32(gas+8)||!addr||addr>0x10000UL-width/8)return 0;
 return (unsigned)addr;
}
#endif
static int fixed_gas(const unsigned char *gas,unsigned bytes,struct pn_reg *r){
 unsigned long lo=u32(gas+4),hi=u32(gas+8);
 if(gas[0]>1||gas[1]!=bytes*8||gas[2]||(gas[3]&&gas[3]!=bytes)||(!lo&&!hi))return 0;
 if(gas[0]==1&&(hi||lo>65536UL-bytes))return 0;
 if(gas[0]==0&&bytes==2&&(lo&1))return 0;
 r->space=gas[0];r->bytes=bytes;r->low=lo;r->high=hi;return 1;
}
static int overlaps(const struct pn_reg *a,const struct pn_reg *b){
 if(!a->bytes||!b->bytes||a->space!=b->space||a->high!=b->high)return 0;
 return a->low<=b->low?b->low-a->low<a->bytes:a->low-b->low<b->bytes;
}
static int pm_control(const unsigned char *f,unsigned length,unsigned offset,unsigned legacy,
                      int optional,struct pn_reg *reg,unsigned *ioport){
 unsigned long addr=u32(f+legacy);
 if(length>=offset+12&&(u32(f+offset+4)||u32(f+offset+8))){
  if(f[8]<2||!fixed_gas(f+offset,2,reg))return 0;
 }else{
  if(!addr)return optional;
  if(f[89]!=2||addr>65534)return 0;
  reg->space=1;reg->low=addr;reg->bytes=2;
 }
 if(reg->space==1)*ioport=(unsigned)reg->low;
 return 1;
}
/* ACPI RESET_REG may identify a PCI configuration byte on segment 0,
   bus 0. Resolve it through the firmware's MCFG before the OS enters
   shutdown. No bus scan, configuration-port probing or runtime mapping. */
static int pci_reset(pn_read read,void *arg,pn_address mcfg,const unsigned char *gas,
                     unsigned char *work,unsigned capacity,struct pn_reg *reg){
 unsigned len,i,matches=0;
 unsigned long device=u32(gas+8),addr=u32(gas+4),function=addr>>16,offset=addr&65535UL;
 unsigned long base=0,high=0;
 if(gas[0]!=2||gas[1]!=8||gas[2]||gas[3]>1||device>31||function>7||offset>4095)return 0;
 if(!table(read,arg,mcfg,"MCFG",work,capacity,&len)||work[8]!=1||len<60||(len-44)%16)return 0;
 for(i=44;i<len;i+=16){
  if(work[i+8]||work[i+9]||work[i+10])continue;
  if(++matches>1||work[i+12]||work[i+13]||work[i+14]||work[i+15])return 0;
  base=u32(work+i);high=u32(work+i+4);
  if((base&0xfffffUL)||(!base&&!high))return 0;
 }
 if(matches!=1)return 0;
 reg->space=0;reg->bytes=1;reg->high=high;
 reg->low=base+(device<<15)+(function<<12)+offset;
 return 1;
}
int pn_tables(pn_read read,void *arg,pn_address rsdp,struct pn_acpi *out,unsigned char *w,unsigned cap){
 unsigned n,i,step,len,fadt_count=0,ssdt=0,mcfg_count=0;pn_address root,fadt=0,mcfg=0,dsdt,addr;unsigned long flags;int rev;
 unsigned char r[36],f[276];
#if defined(PN_MULTI_S5)
 pn_address entries[128];struct pn_s5ns ns;
#elif defined(PN_AML)
 static pn_address entries[128];
#endif
 memset(out,0,sizeof(*out));out->rsdp_rev=0xffff;
 if(!read||!w||cap<276||!table_range(rsdp,36)||!read(arg,rsdp,r,36))return 0;
 rev=pn_rsdp(r,36);if(rev<0)return 0;
 out->rsdp_rev=(unsigned)rev;
 root=u32(r+16);step=4;
 if(rev>=2&&(u32(r+24)||u32(r+28))){root=table_address(r+24,1);step=8;}
 if(!table(read,arg,root,step==8?"XSDT":"RSDT",w,cap,&len)||(len-36)%step)return 0;
 n=(len-36)/step;if(n>128)return 0;
 /* Preserve entries before the work buffer is reused. */
 {
#if !defined(PN_MULTI_S5)&&!defined(PN_AML)
  pn_address entries[128];
#endif
  for(i=0;i<n;i++)entries[i]=table_address(w+36+i*step,step==8);
  for(i=0;i<n;i++){
   addr=entries[i];if(!table_range(addr,36)||!read(arg,addr,w,36))return 0;
   if(!memcmp(w,"MCFG",4)){mcfg=addr;mcfg_count++;}
   if(!memcmp(w,"FACP",4)){fadt=addr;fadt_count++;}
   if(!memcmp(w,"SSDT",4)||!memcmp(w,"PSDT",4)){
#if defined(PN_MULTI_S5)||defined(PN_AML)
    /* Compact consumed entries in place; no second address array. */
    entries[ssdt++]=addr;
#else
    ssdt=1;
#endif
   }
  }
 }
 if(fadt_count!=1||!table(read,arg,fadt,"FACP",w,cap,&len)||len<116)return 0;
 memset(f,0,sizeof(f));memcpy(f,w,len<sizeof(f)?len:sizeof(f));
 out->fadt_rev=f[8];out->fadt_minor=(f[8]==5||f[8]==6)&&len>=132?f[131]:0xffff;flags=u32(f+112);out->where=2;
#ifdef PN_TIMER_INFO
 /* Optional ACPI PM timer: DWORD port reads, 24 or 32 valid counter bits. */
 if(len>=220&&(u32(f+212)||u32(f+216))){
  if(f[209]==24){unsigned char gas[12];memcpy(gas,f+208,12);gas[1]=32;out->timer_port=port(gas,32);}
  else out->timer_port=port(f+208,32);
 }else{addr=u32(f+76);if(f[91]==4&&addr&&addr<=65532)out->timer_port=(unsigned)addr;}
 if(out->timer_port)out->timer_bits=(flags&0x100UL)?32:24;
#endif
 if(!out->fadt_rev||out->fadt_rev>6)return 1;
 if(out->fadt_rev>=2&&len>=132&&(flags&0x400UL)){
  if(f[116]==2){
   if(mcfg_count==1)out->reset_ok=pci_reset(read,arg,mcfg,f+116,w,cap,&out->reset_reg);
   out->reset_pci=out->reset_ok;
  }else out->reset_ok=fixed_gas(f+116,1,&out->reset_reg);
  if(out->reset_ok&&out->reset_reg.space==1)out->reset_port=(unsigned)out->reset_reg.low;
  out->reset_value=f[128];
 }
 if(flags&0x100000UL){
  out->reduced=1;
  if(out->fadt_rev<5||len<268||!fixed_gas(f+244,1,&out->control_reg)||
     !fixed_gas(f+256,1,&out->status_reg)||overlaps(&out->control_reg,&out->status_reg))return 1;
  if(out->reset_ok&&(overlaps(&out->control_reg,&out->reset_reg)||
                    overlaps(&out->status_reg,&out->reset_reg))){out->reset_ok=0;return 1;}
 }
#if !defined(PN_MULTI_S5)&&!defined(PN_AML)
 if(ssdt)return 1;
#endif
#ifdef PN_AML
 if(ssdt&&!pn_amlctx)return 1;
#endif
 out->pm1a=0;out->pm1b=0;out->where=3;
 if(!out->reduced){
  if(!pm_control(f,len,172,64,0,&out->pm1a_reg,&out->pm1a)||
     !pm_control(f,len,184,68,1,&out->pm1b_reg,&out->pm1b)||
     overlaps(&out->pm1a_reg,&out->pm1b_reg))return 1;
  if(out->reset_ok&&(overlaps(&out->reset_reg,&out->pm1a_reg)||
                     overlaps(&out->reset_reg,&out->pm1b_reg))){
   out->reset_ok=0;return 1;
  }
 }
 dsdt=u32(f+40);
 if(len>=148&&(u32(f+140)||u32(f+144)))dsdt=table_address(f+140,1);
 out->where=4;
 if(!table(read,arg,dsdt,"DSDT",w,cap,&len))return 1;
 out->where=5;
#ifdef PN_AML
 if(pn_amlctx){
  struct pn_amlctx *c=pn_amlctx;unsigned j;
  out->where=6;
  c->used=0;c->prepare=0;c->tables=0;c->loaded=0;
  if(!c->arena||!c->nodes||!pn_aml_init(&c->aml,c->nodes,c->capacity,w[8]))goto s5scan;
  for(i=0;i<=ssdt;i++){
   pn_address at=i?entries[i-1]:dsdt;
   if(i){
    for(j=0;j+1<i;j++)if(entries[j]==entries[i-1])goto s5scan;
    if(!read(arg,at,w,36)||(memcmp(w,"SSDT",4)&&memcmp(w,"PSDT",4))||
       !table(read,arg,at,memcmp(w,"SSDT",4)?"PSDT":"SSDT",w,cap,&len))goto s5scan;
   }
   /* Tables stay resident for later method execution. */
   if(len-36>c->arena_size-c->used)goto s5scan;
   memcpy(c->arena+c->used,w+36,len-36);
   if(!pn_aml_load(&c->aml,c->arena+c->used,len-36))goto s5scan;
   c->used+=len-36;c->tables++;
  }
  c->loaded=1;out->where=7;
  if(!pn_aml_sleep_type(&c->aml,c->env,5,&out->sleepa,&out->sleepb))goto s5scan;
  out->where=8;
  /* Every discovered preparation method must complete before SLP_EN. */
  if(pn_aml_has_prepare(&c->aml)){
   if(!pn_aml_verify_prepare(&c->aml,5))return 1;
   c->prepare=1;
  }
  out->smi=u32(f+48);out->enable=f[52];out->disable=f[53];
  if(out->reduced)out->smi=0;
  if(out->smi>65535)return 1;
  out->off_ok=1;return 1;
 s5scan:
  c->prepare=0;c->loaded=0;out->where=9;
  if(ssdt||!table(read,arg,dsdt,"DSDT",w,cap,&len)||
     !pn_s5(w+36,len-36,&out->sleepa,&out->sleepb))return 1;
  out->smi=u32(f+48);out->enable=f[52];out->disable=f[53];
  if(out->reduced)out->smi=0;
  if(out->smi>65535)return 1;
  out->off_ok=1;return 1;
 }
#endif
#ifdef PN_MULTI_S5
 pn_ns_begin(&ns);if(!pn_ns_add(&ns,w+36,len-36))return 1;
 for(i=0;i<ssdt;i++){
  unsigned j;const char *sig;
  /* Duplicate references are not a second independent namespace table. */
  for(j=0;j<i;j++)if(entries[j]==entries[i])return 1;
  if(!read(arg,entries[i],w,36))return 1;
  if(!memcmp(w,"SSDT",4))sig="SSDT";
  else if(!memcmp(w,"PSDT",4))sig="PSDT";
  else return 1;
  if(!table(read,arg,entries[i],sig,w,cap,&len)||
     !pn_ns_add(&ns,w+36,len-36))return 1;
 }
 if(!pn_ns_sleep(&ns,&out->sleepa,&out->sleepb))return 1;
#else
 if(!pn_s5(w+36,len-36,&out->sleepa,&out->sleepb))return 1;
#endif
 out->smi=u32(f+48);out->enable=f[52];out->disable=f[53];
 if(out->reduced)out->smi=0;
  if(out->smi>65535)return 1;
 out->off_ok=1;return 1;
}
