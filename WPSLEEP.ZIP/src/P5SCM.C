#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include "P5SCM.H"

static DWORD open_owned(DWORD access, SC_HANDLE *result)
{
    SC_HANDLE manager, service;
    union { QUERY_SERVICE_CONFIGA config; BYTE bytes[1536]; } info;
    DWORD bytes, error;

    *result = NULL;
    manager = OpenSCManagerA(NULL, NULL, SC_MANAGER_CONNECT);
    if (!manager) return GetLastError();
    service = OpenServiceA(manager, WP5_NAME, SERVICE_QUERY_CONFIG | access);
    error = service ? ERROR_SUCCESS : GetLastError();
    CloseServiceHandle(manager);
    if (error) return error;
    if (!QueryServiceConfigA(service, &info.config, sizeof(info), &bytes))
        error = GetLastError();
    else if (info.config.dwServiceType != SERVICE_KERNEL_DRIVER ||
             lstrcmpiA(info.config.lpBinaryPathName, WP5_IMAGE) ||
             lstrcmpA(info.config.lpDisplayName, WP5_TITLE))
        error = ERROR_INVALID_DATA;
    if (error) CloseServiceHandle(service);
    else *result = service;
    return error;
}

DWORD wp5_start(void)
{
    SC_HANDLE service;
    DWORD error = open_owned(SERVICE_START, &service);
    if (error) return error;
    if (!StartServiceA(service, 0, NULL)) {
        error = GetLastError();
        if (error == ERROR_SERVICE_ALREADY_RUNNING) error = ERROR_SUCCESS;
    }
    CloseServiceHandle(service);
    return error;
}

DWORD wp5_remember(DWORD owner)
{
    SC_HANDLE service;
    DWORD start = owner ? SERVICE_AUTO_START : SERVICE_DEMAND_START;
    DWORD error = open_owned(SERVICE_CHANGE_CONFIG, &service);
    /* A stand-alone HNDLOAD session lasts only until reboot. */
    if (error == ERROR_SERVICE_DOES_NOT_EXIST) return ERROR_SUCCESS;
    if (error) return error;
    if (!ChangeServiceConfigA(service, SERVICE_NO_CHANGE, start,
            SERVICE_NO_CHANGE, NULL, NULL, NULL, NULL, NULL, NULL, NULL))
        error = GetLastError();
    CloseServiceHandle(service);
    return error;
}

static DWORD target_path(char *path)
{
    UINT n = GetSystemDirectoryA(path, MAX_PATH);
    if (!n || n >= MAX_PATH - sizeof("\\drivers\\WINPWR5.SYS"))
        return ERROR_BAD_PATHNAME;
    lstrcatA(path, "\\drivers\\WINPWR5.SYS");
    return ERROR_SUCCESS;
}

/* Return a resident 1.0 driver to OS control before any external restart.
   The original driver's shutdown notification cannot distinguish reset. */
DWORD wp5_disarm_legacy(BOOL *found)
{
    DWORD status[8], bytes, zero = 0, error = ERROR_SUCCESS;
    HANDLE dev;
    *found = FALSE;
    dev = CreateFileA("\\\\.\\PN5LAB", GENERIC_READ, FILE_SHARE_READ|FILE_SHARE_WRITE,
                      NULL, OPEN_EXISTING, 0, NULL);
    if (dev == INVALID_HANDLE_VALUE) {
        error = GetLastError();
        return error == ERROR_FILE_NOT_FOUND || error == ERROR_PATH_NOT_FOUND ? 0 : error;
    }
    if (!DeviceIoControl(dev,0x226000,NULL,0,status,sizeof(status),&bytes,NULL)) error=GetLastError();
    else if (bytes!=sizeof(status)) error=ERROR_INVALID_DATA;
    else if (status[0]==5) {
        *found = TRUE;
        if (!DeviceIoControl(dev,0x22600c,&zero,sizeof(zero),NULL,0,&bytes,NULL) ||
            !DeviceIoControl(dev,0x226000,NULL,0,status,sizeof(status),&bytes,NULL))
            error=GetLastError();
        else if (bytes!=sizeof(status) || (status[5]&1)) error=ERROR_INVALID_DATA;
    }
    CloseHandle(dev);
    return error;
}

DWORD wp5_install(const char *source)
{
    SC_HANDLE manager, service;
    char path[MAX_PATH], driver[MAX_PATH];
    DWORD error = target_path(path);
    if (error) return error;
    if (lstrlenA(source) >= MAX_PATH - (int)sizeof("PN5HOOK.SYS"))
        return ERROR_BAD_PATHNAME;
    lstrcpyA(driver, source);
    lstrcatA(driver, LOWORD(GetVersion())==5 ? "W2KHOOK.SYS" : "PN5HOOK.SYS");
    manager = OpenSCManagerA(NULL, NULL, SC_MANAGER_CREATE_SERVICE);
    if (!manager) return GetLastError();
    /* Reserve the service name first. Never overwrite another driver's file. */
    service = CreateServiceA(manager, WP5_NAME, WP5_TITLE, DELETE,
            SERVICE_KERNEL_DRIVER, SERVICE_DEMAND_START, SERVICE_ERROR_NORMAL,
            WP5_IMAGE, NULL, NULL, NULL, NULL, NULL);
    error = service ? ERROR_SUCCESS : GetLastError();
    CloseServiceHandle(manager);
    if (error) return error;
    if (!CopyFileA(driver, path, TRUE)) {
        error = GetLastError();
        if (!DeleteService(service)) error = GetLastError();
    } else if (!SetFileAttributesA(path, FILE_ATTRIBUTE_NORMAL)) {
        error = GetLastError();
        DeleteFileA(path);
        DeleteService(service);
    }
    CloseServiceHandle(service);
    return error;
}

DWORD wp5_remove(void)
{
    SC_HANDLE service;
    char path[MAX_PATH];
    DWORD error = target_path(path);
    HANDLE device;
    DWORD mode = 0, bytes, status[8];
    if (error) return error;
    error = open_owned(DELETE | SERVICE_CHANGE_CONFIG, &service);
    if (error == ERROR_SERVICE_DOES_NOT_EXIST ||
        error == ERROR_SERVICE_MARKED_FOR_DELETE) return ERROR_SUCCESS;
    if (error) return error;
    if (!ChangeServiceConfigA(service, SERVICE_NO_CHANGE, SERVICE_DISABLED,
            SERVICE_NO_CHANGE, NULL, NULL, NULL, NULL, NULL, NULL, NULL)) {
        error = GetLastError();
        goto done;
    }
    device = CreateFileA("\\\\.\\PN5LAB", GENERIC_READ,
            FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, OPEN_EXISTING, 0, NULL);
    if (device != INVALID_HANDLE_VALUE) {
        if (!DeviceIoControl(device, 0x22600c, &mode, sizeof(mode), NULL, 0, &bytes, NULL) ||
            !DeviceIoControl(device, 0x226000, NULL, 0, status, sizeof(status), &bytes, NULL))
            error = GetLastError();
        else if (bytes != sizeof(status) || (status[5] & 1)) error = ERROR_INVALID_DATA;
        CloseHandle(device);
        if (error) goto done;
    } else {
        error = GetLastError();
        if (error != ERROR_FILE_NOT_FOUND && error != ERROR_PATH_NOT_FOUND) goto done;
        error = ERROR_SUCCESS;
    }
    if (!DeleteFileA(path)) {
        error = GetLastError();
        if (error == ERROR_FILE_NOT_FOUND) error = ERROR_SUCCESS;
        else if ((error == ERROR_SHARING_VIOLATION || error == ERROR_ACCESS_DENIED) &&
                 MoveFileExA(path, NULL, MOVEFILE_DELAY_UNTIL_REBOOT))
            error = ERROR_SUCCESS;
    }
    if (!error && !DeleteService(service)) error = GetLastError();
done:
    CloseServiceHandle(service);
    return error;
}
