/* BIOS diagnostics driver; no register writes or power IOCTLs. */
#include <ntddk.h>
#ifdef PN_NT3
/* NT3.1 exports the original stdcall entry, not the later fastcall alias. */
#undef IoCompleteRequest
__declspec(dllimport) VOID NTAPI IoCompleteRequest(PIRP,CCHAR);
#endif
#include "ACPI.H"
#define PN_QUERY 0x00226000UL
static LONG revision = -1;
static UNICODE_STRING linkname;
static int scan(ULONG base, ULONG size) {
 PHYSICAL_ADDRESS a; PUCHAR p; ULONG i; int r=-1;
 a.QuadPart=base;
 p=MmMapIoSpace(a,size,MmNonCached);
 if(!p)return -1;
 for(i=0;i+20<=size;i+=16){r=pn_rsdp(p+i,size-i);if(r>=0)break;}
 MmUnmapIoSpace(p,size);return r;
}
static VOID NTAPI unload(PDRIVER_OBJECT driver) {
 IoDeleteSymbolicLink(&linkname);IoDeleteDevice(driver->DeviceObject);
}
static NTSTATUS NTAPI dispatch(PDEVICE_OBJECT device,PIRP irp) {
 PIO_STACK_LOCATION s=IoGetCurrentIrpStackLocation(irp);
 NTSTATUS st=STATUS_INVALID_DEVICE_REQUEST;ULONG_PTR bytes=0;
 (void)device;
 if(s->MajorFunction==IRP_MJ_CREATE||s->MajorFunction==IRP_MJ_CLOSE)st=STATUS_SUCCESS;
 else if(s->MajorFunction==IRP_MJ_DEVICE_CONTROL && s->Parameters.DeviceIoControl.IoControlCode==PN_QUERY) {
  if(s->Parameters.DeviceIoControl.OutputBufferLength<sizeof(LONG))st=STATUS_BUFFER_TOO_SMALL;
  else {*(LONG*)irp->AssociatedIrp.SystemBuffer=revision;bytes=sizeof(LONG);st=STATUS_SUCCESS;}
 }
 irp->IoStatus.Status=st;irp->IoStatus.Information=bytes;IoCompleteRequest(irp,IO_NO_INCREMENT);return st;
}
NTSTATUS NTAPI DriverEntry(PDRIVER_OBJECT driver,PUNICODE_STRING registry) {
 UNICODE_STRING devname;PDEVICE_OBJECT dev;NTSTATUS st;ULONG ebda;PHYSICAL_ADDRESS a;PUCHAR b;
 (void)registry;
 RtlInitUnicodeString(&devname,L"\\Device\\WINPOWER");
 RtlInitUnicodeString(&linkname,L"\\DosDevices\\WINPOWER");
 st=IoCreateDevice(driver,0,&devname,FILE_DEVICE_UNKNOWN,FILE_DEVICE_SECURE_OPEN,FALSE,&dev);
 if(!NT_SUCCESS(st))return st;
#ifdef PN_NT3
 /* NT3.1 allocates fewer major-function slots than modern DDKs describe.
    The I/O manager supplies defaults; assign only the entries we handle. */
 driver->MajorFunction[IRP_MJ_CREATE]=dispatch;
 driver->MajorFunction[IRP_MJ_CLOSE]=dispatch;
 driver->MajorFunction[IRP_MJ_DEVICE_CONTROL]=dispatch;
#else
 {ULONG i;for(i=0;i<=IRP_MJ_MAXIMUM_FUNCTION;i++)driver->MajorFunction[i]=dispatch;}
#endif
 driver->DriverUnload=unload;
 /* BIOS-only discovery. UEFI configuration-table discovery is not implemented. */
 a.QuadPart=0x400;b=MmMapIoSpace(a,0x100,MmNonCached);
 if(b){ebda=((ULONG)b[14]|((ULONG)b[15]<<8))<<4;MmUnmapIoSpace(b,0x100);
  if(ebda>=0x400 && ebda<=0x9ffff)revision=scan(ebda,1024);}
 if(revision<0)revision=scan(0xe0000,0x20000);
 st=IoCreateSymbolicLink(&linkname,&devname);
 if(!NT_SUCCESS(st)){IoDeleteDevice(dev);return st;}
 dev->Flags&=~DO_DEVICE_INITIALIZING;return STATUS_SUCCESS;
}
