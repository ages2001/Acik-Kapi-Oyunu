/* Real-mode APM 1.0, 1.1 and 1.2 final power-off. Position-independent.
   Caller flushes storage first. Always returns failure if power stays on.
   Only this function's own connection and state changes are undone. */
.code16
.text
.global wp_apm_seq
wp_apm_seq:
    pushw %bp
    movw %sp,%bp
    subw $8,%sp
    movw $0,-2(%bp)               /* initial installation flags */
    movw $0x0100,-4(%bp)          /* negotiated version */
    movw $0,-6(%bp)               /* restored changes: enabled, engaged */
    movw $0x5300,%ax
    xorw %bx,%bx
    call .Lbios
    jc .Ldone
    cmpw $0x504d,%bx
    jne .Ldone
    cmpw $0x0100,%ax
    jb .Ldone
    cmpw $0x0102,%ax
    ja .Ldone
    movw %ax,-8(%bp)
    movw %cx,-2(%bp)
    movw $0x5301,%ax
    xorw %bx,%bx
    call .Lbios
    jnc .Lowned
    cmpb $2,%ah                   /* Another real-mode client owns it. */
    jne .Ldone
    call .Loff                    /* Common to all versions; leave ownership alone. */
    jmp .Ldone
.Lowned:
    movw -8(%bp),%cx
.Lversion:
    cmpw $0x0100,%cx
    jbe .Lenable
    pushw %cx
    xorw %bx,%bx
    movw $0x530e,%ax
    call .Lbios
    popw %cx
    jnc .Lnegotiated
    decw %cx
    jmp .Lversion
.Lnegotiated:
    cmpw $0x0100,%ax
    jb .Ldisconnect
    cmpw %cx,%ax
    ja .Ldisconnect
    movw %ax,-4(%bp)
.Lenable:
    testw $8,-2(%bp)
    jz .Lengage
    call .Ldevice
    movw $1,%cx
    movw $0x5308,%ax
    call .Lbios
    jc .Ldisconnect
    orw $1,-6(%bp)
.Lengage:
    cmpw $0x0101,-4(%bp)
    jb .Lrequest
    testw $16,-2(%bp)
    jz .Lrequest
    movw $1,%bx
    movw $1,%cx
    movw $0x530f,%ax
    call .Lbios
    jc .Lrestore
    orw $2,-6(%bp)
.Lrequest:
    call .Loff
.Lrestore:
    testw $2,-6(%bp)
    jz .Ldisable
    movw $1,%bx
    xorw %cx,%cx
    movw $0x530f,%ax
    call .Lbios
.Ldisable:
    testw $1,-6(%bp)
    jz .Ldisconnect
    call .Ldevice
    xorw %cx,%cx
    movw $0x5308,%ax
    call .Lbios
.Ldisconnect:
    movw $0x5304,%ax
    xorw %bx,%bx
    call .Lbios
.Ldone:
    movw %bp,%sp
    popw %bp
    movw $1,%ax
    ret
.Ldevice:
    movw $1,%bx                   /* Enable PM uses FFFFh only on APM 1.0. */
    cmpw $0x0100,-4(%bp)
    jne .Ldevret
    decw %bx
    decw %bx
.Ldevret:
    ret
.Loff:
    movw $0x5307,%ax
    movw $1,%bx                   /* Set Power State always uses 0001h. */
    movw $3,%cx
.Lbios:
    pushw %bp
    int $0x15
    popw %bp
    ret
