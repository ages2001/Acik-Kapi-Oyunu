/* NT real-mode APM power-off fallback. See NTAPM.H for the contract.
 *
 * The machine is powered off by a one-way descent to real mode:
 *   1. a <1 MiB, page-aligned trampoline block is built at load time;
 *   2. at shutdown, the current page directory's entry 0 is pointed at an
 *      identity page table (reached through the x86 self-map at 0xC0300000),
 *      so linear 0..4 MiB maps to physical 0..4 MiB;
 *   3. CR3 is reloaded, then execution jumps to the trampoline's identity
 *      linear address, loads a tiny GDT, drops to 16-bit protected mode,
 *      clears PE/PG, and far-jumps to real mode;
 *   4. the real-mode IVT (limit 3FFh, base 0 - intact under NT) is restored
 *      and the APM BIOS is driven: 5300h check, 5301h connect, 530Eh set
 *      version 1.2, 5308h enable, 5307h set power state = off.
 * The trampoline traces its stages to port E9h (A, B, R, S, and f if the
 * APM call unexpectedly returns). Nothing is restored: on success the
 * system powers off, otherwise it halts. */
#include <ntddk.h>
#include "NTAPM.H"
#include "APMBYTE.H"

#define PDE_SELFMAP 0xC0300000UL   /* NT x86 recursive page-directory base */
#define BLOCK_SIZE  0x2000UL
#define ENTRY_OFF   0x30UL
/* The round-trip APM-version probe and the one-way power-off trampoline are
   never resident at the same time: the probe is built into the block, run,
   then overwritten by build() before any shutdown. Both enter at ENTRY_OFF. */

/* Scratch area shared between the C probe driver and the round-trip
   trampoline. Filled in NT context (flat DS, paging on) before the descent
   and in real mode during it; read back after the ascent. */
#define S_BASE 0x600UL
#define S_GDTR (S_BASE+0x00)   /* NT GDT pseudo-descriptor (limit+base32)   */
#define S_IDTR (S_BASE+0x08)   /* NT IDT pseudo-descriptor                  */
#define S_CR3  (S_BASE+0x10)
#define S_CR0  (S_BASE+0x14)
#define S_ESP  (S_BASE+0x18)
#define S_SS   (S_BASE+0x1C)
#define S_DS   (S_BASE+0x20)
#define S_ES   (S_BASE+0x24)
#define S_FS   (S_BASE+0x28)
#define S_GS   (S_BASE+0x2C)
#define S_AX   (S_BASE+0x30)   /* APM 5300h results captured in real mode   */
#define S_BX   (S_BASE+0x34)
#define S_CX   (S_BASE+0x38)
#define S_FL   (S_BASE+0x3C)   /* FLAGS after INT 15h (carry = not present) */
#define S_DONE (S_BASE+0x40)   /* set to 1 by the trampoline: it ran        */
#define S_OPDE (S_BASE+0x44)   /* original PD entry 0, saved for restore     */

static PVOID block_kva;
static ULONG block_phys;
static PVOID pt_kva;
static ULONG pt_phys;
static int ready;
static unsigned apm_bcd;
static ULONG apm_ivec;   /* real-mode INT 15h vector (seg<<16|off), saved early */
#ifndef PN_NO_APM_PROBE
static ULONG probe_farfix; /* offset in the block of the ascent far-jump's 32-bit target */

#endif

static ULONG read_cr3(void){ULONG v;__asm__ __volatile__("mov %%cr3,%0":"=r"(v));return v;}

/* Build the trampoline bytes into p with real-mode/PM segment base B. */
static void build(unsigned char *p, ULONG B){
 ULONG o, pm16off, realoff, pm16_fix, real_fix;
 RtlZeroMemory(p, 0x200);
 /* GDT: null, 16-bit code (base B), 16-bit data (base B). */
 p[8]=0xFF;p[9]=0xFF;p[10]=(UCHAR)B;p[11]=(UCHAR)(B>>8);p[12]=(UCHAR)(B>>16);p[13]=0x9A;p[14]=0x00;p[15]=(UCHAR)(B>>24);
 p[16]=0xFF;p[17]=0xFF;p[18]=(UCHAR)B;p[19]=(UCHAR)(B>>8);p[20]=(UCHAR)(B>>16);p[21]=0x92;p[22]=0x00;p[23]=(UCHAR)(B>>24);
 /* GDTR pseudo-descriptor at 0x18: limit 0x17, base = linear of GDT = B. */
 p[0x18]=0x17;p[0x19]=0x00;*(ULONG UNALIGNED*)(p+0x1A)=B;
 /* Real-mode IDTR pseudo-descriptor at 0x20: limit 0x3FF, base 0. */
 p[0x20]=0xFF;p[0x21]=0x03;*(ULONG UNALIGNED*)(p+0x22)=0;
 o=ENTRY_OFF;
#define EMIT(b) (p[o++]=(UCHAR)(b))
 /* Stage trace to port E9h, compiled in only when PN_APM_TRACE is defined
    (debugcon diagnostics); the port is inert on production hardware. */
#ifdef PN_APM_TRACE
#define TRC(c) do{EMIT(0xB0);EMIT(c);EMIT(0xE6);EMIT(0xE9);}while(0)
#else
#define TRC(c) ((void)0)
#endif
 /* 32-bit entry, executed at identity linear B+0x30. */
 EMIT(0xFA);                                   /* cli */
 TRC('A');
 EMIT(0x0F);EMIT(0x01);EMIT(0x15);*(ULONG UNALIGNED*)(p+o)=B+0x18;o+=4; /* lgdt [B+0x18] */
 EMIT(0xEA);pm16_fix=o;o+=4;EMIT(0x08);EMIT(0x00);                      /* ljmp 0x08:pm16 */
 pm16off=o;
 /* 16-bit protected mode (CS base B). */
 TRC('B');
 EMIT(0x0F);EMIT(0x20);EMIT(0xC0);                         /* mov eax,cr0 */
 EMIT(0x66);EMIT(0x25);EMIT(0xFE);EMIT(0xFF);EMIT(0xFF);EMIT(0x7F); /* and eax,7FFFFFFEh */
 EMIT(0x0F);EMIT(0x22);EMIT(0xC0);                         /* mov cr0,eax */
 EMIT(0xEA);real_fix=o;o+=2;*(USHORT UNALIGNED*)(p+o)=(USHORT)(B>>4);o+=2; /* ljmp (B>>4):real */
 realoff=o;
 /* Real mode. */
 EMIT(0xB8);*(USHORT UNALIGNED*)(p+o)=(USHORT)(B>>4);o+=2; /* mov ax,B>>4 */
 EMIT(0x8E);EMIT(0xD8);EMIT(0x8E);EMIT(0xC0);EMIT(0x8E);EMIT(0xD0); /* mov ds/es/ss,ax */
 /* Load the FULL esp: the BIOS INT 15h handler transitions to 32-bit mode
    internally and uses esp, so the high word must be cleared - a 16-bit
    'mov sp' would leave NT's kernel-stack bits there and the handler would
    run on a wild stack. */
 EMIT(0x66);EMIT(0xBC);EMIT(0xFE);EMIT(0x1F);EMIT(0x00);EMIT(0x00); /* mov esp,1FFEh */
 TRC('R');
 EMIT(0x0F);EMIT(0x01);EMIT(0x1E);EMIT(0x20);EMIT(0x00);   /* lidt [0x20] */
 /* Interrupts stay masked: NT has overwritten most of the low-memory
    real-mode IVT, so enabling them would fault through a stale vector on
    the first IRQ. The APM BIOS power-off path does not require them.
    The INT 15h vector itself is restored from the value saved at init, in
    case NT reused page 0; the handler it points at is in ROM and intact. */
 EMIT(0x31);EMIT(0xC0);EMIT(0x8E);EMIT(0xC0);             /* xor ax,ax; mov es,ax */
 EMIT(0x26);EMIT(0xC7);EMIT(0x06);EMIT(0x54);EMIT(0x00);*(USHORT UNALIGNED*)(p+o)=(USHORT)apm_ivec;o+=2;       /* mov [es:54],off */
 EMIT(0x26);EMIT(0xC7);EMIT(0x06);EMIT(0x56);EMIT(0x00);*(USHORT UNALIGNED*)(p+o)=(USHORT)(apm_ivec>>16);o+=2; /* mov [es:56],seg */
 /* Mask every hardware IRQ at both 8259 PICs. The BIOS APM handler may set
    IF internally; with the rest of the real-mode IVT stale, an unmasked IRQ
    would fault. Masking at the controller blocks them regardless of IF. */
 EMIT(0xB0);EMIT(0xFF);EMIT(0xE6);EMIT(0x21);             /* mov al,0FFh; out 21h,al */
 EMIT(0xE6);EMIT(0xA1);                                   /* out A1h,al */
 TRC('L');
 /* Near-call the shared BIOS routine. Its only return path is failure. */
 EMIT(0xe8);EMIT(0x03);EMIT(0x00);
 EMIT(0xe9);EMIT(sizeof(wp_apm_code)&255);EMIT(sizeof(wp_apm_code)>>8);
 RtlCopyMemory(p+o,wp_apm_code,sizeof(wp_apm_code));o+=sizeof(wp_apm_code);
 TRC('f');
 EMIT(0xF4);EMIT(0xEB);EMIT(0xFD);                         /* hlt; jmp $-1 */
#undef EMIT
 *(ULONG UNALIGNED*)(p+pm16_fix)=pm16off;   /* far offset within CS base B */
 *(USHORT UNALIGNED*)(p+real_fix)=(USHORT)realoff;
}

#ifndef PN_NO_APM_PROBE
/* Build the round-trip APM-version probe trampoline into p (segment base B).
   It performs the SAME descent to real mode as build(), but instead of powering
   the machine off it runs only the APM installation check (INT 15h, AX=5300h),
   captures the version/signature/flags into the shared scratch area, and then
   ascends back to 32-bit NT: it reloads NT's GDT/CR3/CR0 and segment registers
   and far-jumps to a 32-bit continuation whose linear address pn_apm_probe()
   patches into the ascent at run time. The page-directory entry 0 stays mapped
   to the identity table across the whole excursion (the caller restores it
   afterwards), so the low trampoline code remains addressable while paging is
   re-enabled. */
static void build_probe(unsigned char *p, ULONG B){
 ULONG o, pm16off, realoff, pm16_fix, real_fix;
 RtlZeroMemory(p, 0x200);
 /* GDT: null, 16-bit code (base B), 16-bit data (base B) - identical to build(). */
 p[8]=0xFF;p[9]=0xFF;p[10]=(UCHAR)B;p[11]=(UCHAR)(B>>8);p[12]=(UCHAR)(B>>16);p[13]=0x9A;p[14]=0x00;p[15]=(UCHAR)(B>>24);
 p[16]=0xFF;p[17]=0xFF;p[18]=(UCHAR)B;p[19]=(UCHAR)(B>>8);p[20]=(UCHAR)(B>>16);p[21]=0x92;p[22]=0x00;p[23]=(UCHAR)(B>>24);
 p[0x18]=0x17;p[0x19]=0x00;*(ULONG UNALIGNED*)(p+0x1A)=B;      /* our 16-bit GDTR  */
 p[0x20]=0xFF;p[0x21]=0x03;*(ULONG UNALIGNED*)(p+0x22)=0;      /* real-mode IDTR   */
 o=ENTRY_OFF;
#define EMIT(b) (p[o++]=(UCHAR)(b))
#define EMITW(w) do{EMIT((w)&0xFF);EMIT(((w)>>8)&0xFF);}while(0)
 /* --- descent: 32-bit entry at identity linear B+0x30 (same as build) --- */
 EMIT(0xFA);                                   /* cli */
 EMIT(0x0F);EMIT(0x01);EMIT(0x15);*(ULONG UNALIGNED*)(p+o)=B+0x18;o+=4; /* lgdt [B+0x18] */
 EMIT(0xEA);pm16_fix=o;o+=4;EMIT(0x08);EMIT(0x00);                      /* ljmp 0x08:pm16 */
 pm16off=o;
 EMIT(0x0F);EMIT(0x20);EMIT(0xC0);                         /* mov eax,cr0 */
 EMIT(0x66);EMIT(0x25);EMIT(0xFE);EMIT(0xFF);EMIT(0xFF);EMIT(0x7F); /* and eax,7FFFFFFE (clear PG|PE) */
 EMIT(0x0F);EMIT(0x22);EMIT(0xC0);                         /* mov cr0,eax */
 EMIT(0xEA);real_fix=o;o+=2;EMITW((USHORT)(B>>4));         /* ljmp (B>>4):real */
 realoff=o;
 EMIT(0xB8);EMITW((USHORT)(B>>4));                         /* mov ax,B>>4 */
 EMIT(0x8E);EMIT(0xD8);EMIT(0x8E);EMIT(0xC0);EMIT(0x8E);EMIT(0xD0); /* mov ds/es/ss,ax */
 EMIT(0x66);EMIT(0xBC);EMIT(0xFE);EMIT(0x1F);EMIT(0x00);EMIT(0x00); /* mov esp,1FFEh */
 EMIT(0x0F);EMIT(0x01);EMIT(0x1E);EMIT(0x20);EMIT(0x00);   /* lidt [0x20] (real IVT) */
 EMIT(0x31);EMIT(0xC0);EMIT(0x8E);EMIT(0xC0);              /* xor ax,ax; mov es,ax */
 EMIT(0x26);EMIT(0xC7);EMIT(0x06);EMIT(0x54);EMIT(0x00);EMITW((USHORT)apm_ivec);       /* mov [es:54],off */
 EMIT(0x26);EMIT(0xC7);EMIT(0x06);EMIT(0x56);EMIT(0x00);EMITW((USHORT)(apm_ivec>>16)); /* mov [es:56],seg */
 EMIT(0xB0);EMIT(0xFF);EMIT(0xE6);EMIT(0x21);              /* mov al,FFh; out 21h,al  */
 EMIT(0xE6);EMIT(0xA1);                                    /* out A1h,al (mask PICs)  */
 /* --- APM installation check only (no power action), results -> scratch --- */
 EMIT(0x31);EMIT(0xDB);                                    /* xor bx,bx */
 EMIT(0xB8);EMIT(0x00);EMIT(0x53);                         /* mov ax,5300h */
 EMIT(0xCD);EMIT(0x15);                                    /* int 15h (DS=B: scratch addressable) */
 EMIT(0xA3);EMITW((USHORT)S_AX);                           /* mov [S_AX],ax (version BCD) */
 EMIT(0x89);EMIT(0x1E);EMITW((USHORT)S_BX);                /* mov [S_BX],bx (signature)   */
 EMIT(0x89);EMIT(0x0E);EMITW((USHORT)S_CX);                /* mov [S_CX],cx (flags)       */
 EMIT(0x9C);EMIT(0x58);EMIT(0xA3);EMITW((USHORT)S_FL);     /* pushf; pop ax; mov [S_FL],ax */
 EMIT(0xC7);EMIT(0x06);EMITW((USHORT)S_DONE);EMIT(0x01);EMIT(0x00); /* mov word [S_DONE],1 */
 /* --- ascent: real mode -> 32-bit NT, far-jump to the C continuation --- */
 EMIT(0xFA);                                               /* cli */
 EMIT(0x8B);EMIT(0x0E);EMITW((USHORT)S_SS);                /* mov cx,[S_SS]   (NT SS)  */
 EMIT(0x8B);EMIT(0x16);EMITW((USHORT)S_DS);                /* mov dx,[S_DS]   (NT DS)  */
 EMIT(0x66);EMIT(0x8B);EMIT(0x36);EMITW((USHORT)S_ESP);    /* mov esi,[S_ESP] (NT ESP) */
 EMIT(0x66);EMIT(0x0F);EMIT(0x01);EMIT(0x16);EMITW((USHORT)S_GDTR); /* lgdt32 [S_GDTR] (NT GDT) */
 EMIT(0x66);EMIT(0xA1);EMITW((USHORT)S_CR3);               /* mov eax,[S_CR3] */
 EMIT(0x0F);EMIT(0x22);EMIT(0xD8);                         /* mov cr3,eax (TLB flush, same CR3) */
 EMIT(0x66);EMIT(0xA1);EMITW((USHORT)S_CR0);               /* mov eax,[S_CR0] */
 EMIT(0x0F);EMIT(0x22);EMIT(0xC0);                         /* mov cr0,eax (restore PE|PG) */
 EMIT(0x8E);EMIT(0xD1);                                    /* mov ss,cx */
 EMIT(0x66);EMIT(0x89);EMIT(0xF4);                         /* mov esp,esi */
 EMIT(0x8E);EMIT(0xDA);                                    /* mov ds,dx */
 EMIT(0x8E);EMIT(0xC2);                                    /* mov es,dx */
 EMIT(0x66);EMIT(0xEA);probe_farfix=o;o+=4;EMIT(0x08);EMIT(0x00); /* ljmp 0x08:<cont patched> */
#undef EMITW
#undef EMIT
 *(ULONG UNALIGNED*)(p+pm16_fix)=pm16off;
 *(USHORT UNALIGNED*)(p+real_fix)=(USHORT)realoff;
}

/* Run the round-trip probe once, on a uniprocessor NT, to read the APM BIOS
   version into apm_bcd. Must be called at PASSIVE_LEVEL with the block and the
   identity page table already built. On any multiprocessor kernel the probe is
   skipped (altering PD entry 0 would affect other CPUs sharing the directory),
   leaving apm_bcd at 0; APM power-off itself is unaffected. */
static void pn_apm_probe(void){
 volatile ULONG *pd=(volatile ULONG*)PDE_SELFMAP;
 unsigned char *b=(unsigned char*)block_kva;
 KIRQL old;
 ULONG entry=block_phys+ENTRY_OFF, orig;
 if(KeNumberProcessors!=1)return;
 build_probe(b, block_phys);
 ((ULONG*)(b+S_DONE))[0]=0;
 orig=pd[0];
 KeRaiseIrql(HIGH_LEVEL,&old);
 /* Save the NT context and PD[0] to scratch, point PD[0] at the identity table,
    then jump into the low trampoline. Nothing is referenced through a register
    after the excursion (the trampoline clobbers every GP register), so the asm
    has no memory operands past the "1:" return label - the restores happen in a
    second, ordinary asm below. The trampoline reloads NT's GDT/CR3/CR0 and
    SS/ESP/DS and far-jumps back to "1:". */
 pd[0]=pt_phys|3;
 /* The trampoline clobbers EBX/ESI (and ECX/EDX/EAX); EBX/ESI/EDI are preserved
    across the excursion with push/pop so GCC may use them to address the scratch
    operands and still see them unchanged. Only EAX/ECX/EDX are clobbered. */
 __asm__ __volatile__(
  "pushl %%ebx\n\t pushl %%esi\n\t pushl %%edi\n\t"
  "cli\n\t"
  "sgdt %[gdtr]\n\t"
  "sidt %[idtr]\n\t"
  "movl %%cr3,%%eax\n\t movl %%eax,%[cr3]\n\t"
  "movl %%cr0,%%eax\n\t movl %%eax,%[cr0]\n\t"
  "movl %%esp,%[esp]\n\t"
  "xorl %%eax,%%eax\n\t"
  "movw %%ss,%%ax\n\t movl %%eax,%[ss]\n\t"
  "movw %%ds,%%ax\n\t movl %%eax,%[ds]\n\t"
  "movw %%es,%%ax\n\t movl %%eax,%[es]\n\t"
  "movw %%fs,%%ax\n\t movl %%eax,%[fs]\n\t"
  "movw %%gs,%%ax\n\t movl %%eax,%[gs]\n\t"
  "movl $1f,%%eax\n\t movl %%eax,%[farfix]\n\t"   /* patch ascent far-jump target */
  "movl %%cr3,%%eax\n\t movl %%eax,%%cr3\n\t"     /* flush TLB for the new PD[0] */
  "jmp *%[entry]\n\t"                              /* into the low trampoline */
  "1:\n\t"                                         /* trampoline returns here (SS/ESP/DS restored) */
  "popl %%edi\n\t popl %%esi\n\t popl %%ebx\n\t"
  : [gdtr]"=m"(*(ULONG(*)[2])(b+S_GDTR)),
    [idtr]"=m"(*(ULONG(*)[2])(b+S_IDTR)),
    [cr3]"=m"(*(ULONG*)(b+S_CR3)),
    [cr0]"=m"(*(ULONG*)(b+S_CR0)),
    [esp]"=m"(*(ULONG*)(b+S_ESP)),
    [ss]"=m"(*(ULONG*)(b+S_SS)),
    [ds]"=m"(*(ULONG*)(b+S_DS)),
    [es]"=m"(*(ULONG*)(b+S_ES)),
    [fs]"=m"(*(ULONG*)(b+S_FS)),
    [gs]"=m"(*(ULONG*)(b+S_GS)),
    [farfix]"=m"(*(ULONG*)(b+probe_farfix))
  : [entry]"m"(entry)
  : "eax","ecx","edx","memory","cc");
 /* Back in NT 32-bit context (interrupts still masked). Restore the IDT, the
    remaining segment registers and PD[0], then re-enable interrupts. */
 __asm__ __volatile__(
  "lidt %[idtr]\n\t"
  "movl %[es],%%eax\n\t movw %%ax,%%es\n\t"
  "movl %[fs],%%eax\n\t movw %%ax,%%fs\n\t"
  "movl %[gs],%%eax\n\t movw %%ax,%%gs\n\t"
  : : [idtr]"m"(*(ULONG(*)[2])(b+S_IDTR)),
      [es]"m"(*(ULONG*)(b+S_ES)),
      [fs]"m"(*(ULONG*)(b+S_FS)),
      [gs]"m"(*(ULONG*)(b+S_GS))
  : "eax","memory");
 pd[0]=orig;                       /* restore the original PD[0] */
 __asm__ __volatile__("movl %%cr3,%%eax\n\t movl %%eax,%%cr3\n\t sti":::"eax","memory");
 KeLowerIrql(old);
 if(((ULONG*)(b+S_DONE))[0]==1
    && (((ULONG*)(b+S_BX))[0]&0xFFFF)==0x504D
    && !(((ULONG*)(b+S_FL))[0]&1)){
  apm_bcd=((ULONG*)(b+S_AX))[0]&0xFFFF;
 }
}
#endif

int pn_apm_init(void){
 PHYSICAL_ADDRESS high,zero;volatile ULONG *pd;ULONG cr3,i;
 volatile UCHAR *low;UCHAR seg_hi;
 if(ready)return 1;
 /* Confirm the page-directory self-map before relying on it. */
 cr3=read_cr3();
 pd=(volatile ULONG*)PDE_SELFMAP;
 if((pd[0x300]>>12)!=(cr3>>12))return 0;
 /* Trampoline block in the first MiB (real-mode addressable). */
 high.QuadPart=0xFFFFFUL;
 block_kva=MmAllocateContiguousMemory(BLOCK_SIZE,high);
 if(!block_kva)return 0;
 block_phys=MmGetPhysicalAddress(block_kva).LowPart;
 if(block_phys>=0x100000UL||(block_phys&0xFFF)){pn_apm_cleanup();return 0;}
 /* Identity page table for linear 0..4 MiB. */
 high.QuadPart=0xFFFFFFFFUL;
 pt_kva=MmAllocateContiguousMemory(0x1000,high);
 if(!pt_kva){pn_apm_cleanup();return 0;}
 pt_phys=MmGetPhysicalAddress(pt_kva).LowPart;
 if(pt_phys&0xFFF){pn_apm_cleanup();return 0;}
 for(i=0;i<1024;i++)((ULONG*)pt_kva)[i]=(i<<12)|3;
 /* APM presence: the real-mode INT 15h vector must point into the BIOS.
    Capture the whole vector now, while the IVT is still intact, so the
    trampoline can restore it before issuing the APM calls. */
 zero.QuadPart=0;
 low=(volatile UCHAR*)MmMapIoSpace(zero,0x1000,MmNonCached);
 if(low){
  seg_hi=low[0x54+3];
  apm_ivec=(ULONG)low[0x54]|((ULONG)low[0x55]<<8)|((ULONG)low[0x56]<<16)|((ULONG)low[0x57]<<24);
  if(seg_hi>=0xF0){ready=1;}
  MmUnmapIoSpace((PVOID)low,0x1000);
 }
 if(!ready){pn_apm_cleanup();return 0;}
#ifndef PN_NO_APM_PROBE
 /* Read the APM BIOS version (uniprocessor only) before installing the one-way
    power-off trampoline; the probe reuses and then overwrites the block. */
 pn_apm_probe();
#endif
 build((unsigned char*)block_kva,block_phys);
 return 1;
}

int pn_apm_available(void){return ready;}
unsigned pn_apm_version(void){return apm_bcd;}

void pn_apm_cleanup(void){
 if(block_kva){MmFreeContiguousMemory(block_kva);block_kva=0;}
 if(pt_kva){MmFreeContiguousMemory(pt_kva);pt_kva=0;}
 ready=0;
}

#ifdef PN_APM_TRACE
#define APMDBG(c) __asm__ __volatile__("outb %0,$0xe9"::"a"((unsigned char)(c)))
#else
#define APMDBG(c) ((void)0)
#endif
/* Final power-off. Runs at any IRQL; does not return on success. */
void pn_apm_off(void){
 void (*enter)(void);
 APMDBG('E');
 if(!ready){APMDBG('0');return;}
 APMDBG('e');
 enter=(void(*)(void))(block_phys+ENTRY_OFF);
 __asm__ __volatile__("cli");
 /* Point current PD entry 0 at the identity table via the self-map. */
 *(volatile ULONG*)PDE_SELFMAP=pt_phys|3;
 /* Flush the TLB, then jump to the identity-mapped trampoline. */
 __asm__ __volatile__(
  "mov %%cr3,%%eax\n\t"
  "mov %%eax,%%cr3\n\t"
  "jmp *%0\n\t"
  : : "r"(enter) : "eax","memory");
}
