#define COBJMACROS
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <shlobj.h>
#include <ddeml.h>
#ifdef PN5_PACKAGE
#include "P5SCM.H"
#endif
#ifdef PNNT_PACKAGE
#include "NTSET.H"
#include "NTDDE.H"
#define PRODUCT_VERSION "0.12"
#else
#include "LINKOWN.H"
#include "NTDDE.H"
#define PRODUCT_VERSION "0.12"
#endif
#ifdef PN9_PACKAGE
#include "PN9SET.H"
#include "P9PREF.H"
#define PRODUCT_NAME "WINPWR9X"
#elif defined(PN9_GUI)
#define PRODUCT_NAME "WINPWR9X"
#else
#define PRODUCT_NAME "WINPWRNT"
#endif
void *memset(void*p,int c,size_t n){unsigned char*q=p;while(n--)*q++=(unsigned char)c;return p;}
static char folder[MAX_PATH],self[MAX_PATH],ini[MAX_PATH],app[MAX_PATH],uninst[MAX_PATH],desktop[MAX_PATH],linkpath[MAX_PATH];
static const char *regpath="Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\" PRODUCT_NAME;
static BOOL legacy;
static BOOL progman(BOOL remove){
#ifdef PNNT_PACKAGE
 nt_group_ini(ini);
#endif
 return nt_group(remove,app,uninst);
}
static BOOL shortcut(void){
 HMODULE ole;HRESULT hr;IShellLinkA *sl=0;IPersistFile *pf=0;WCHAR wide[MAX_PATH];
 typedef HRESULT(WINAPI *INIT)(LPVOID);typedef HRESULT(WINAPI *CREATE)(REFCLSID,LPUNKNOWN,DWORD,REFIID,LPVOID*);typedef void(WINAPI *UNINIT)(void);
 INIT init;CREATE create;UNINIT uninitfn;
 ole=LoadLibraryA("OLE32.DLL");if(!ole)return FALSE;
 init=(INIT)GetProcAddress(ole,"CoInitialize");create=(CREATE)GetProcAddress(ole,"CoCreateInstance");uninitfn=(UNINIT)GetProcAddress(ole,"CoUninitialize");
 if(!init||!create||!uninitfn){FreeLibrary(ole);return FALSE;}
 hr=init(0);if(FAILED(hr)){FreeLibrary(ole);return FALSE;}
 hr=create(&CLSID_ShellLink,0,CLSCTX_INPROC_SERVER,&IID_IShellLinkA,(void**)&sl);
 if(SUCCEEDED(hr)){
  hr=IShellLinkA_SetPath(sl,app);
  if(SUCCEEDED(hr))hr=IShellLinkA_SetWorkingDirectory(sl,folder);
  if(SUCCEEDED(hr))hr=IShellLinkA_SetIconLocation(sl,app,0);
  if(SUCCEEDED(hr))hr=IShellLinkA_QueryInterface(sl,&IID_IPersistFile,(void**)&pf);
  if(SUCCEEDED(hr)){
   if(!MultiByteToWideChar(CP_ACP,0,linkpath,-1,wide,MAX_PATH))hr=E_FAIL;
   else hr=IPersistFile_Save(pf,wide,TRUE);
   IPersistFile_Release(pf);
  }
  IShellLinkA_Release(sl);
 }
 uninitfn();FreeLibrary(ole);return SUCCEEDED(hr);
}
static BOOL value(HKEY k,const char*n,const char*v){return RegSetValueExA(k,n,0,REG_SZ,(const BYTE*)v,lstrlenA(v)+1)==ERROR_SUCCESS;}
static void message(const char*s){MessageBoxA(0,s,"WINPOWER Setup",MB_OK|MB_ICONINFORMATION);}
#ifdef PNNT_PACKAGE
/* A self-drawn progress window. NT 3.1/3.5 predate the COMCTL32 progress-bar
   control, so the bar is painted with plain USER32/GDI32 calls. */
static HWND prog_win;static int prog_pct;static char prog_text[128];static char warnbuf[384];
static LRESULT CALLBACK prog_proc(HWND w,UINT m,WPARAM wp,LPARAM lp){
 if(m==WM_PAINT){
  PAINTSTRUCT ps;RECT rc,bar,t,f;HDC dc;HBRUSH b;int fill;
  dc=BeginPaint(w,&ps);GetClientRect(w,&rc);
  b=CreateSolidBrush(GetSysColor(COLOR_BTNFACE));FillRect(dc,&rc,b);DeleteObject(b);
  t=rc;t.left+=16;t.right-=16;t.top+=14;t.bottom=t.top+18;
  SetBkMode(dc,TRANSPARENT);SetTextColor(dc,GetSysColor(COLOR_BTNTEXT));
  DrawTextA(dc,prog_text,-1,&t,DT_LEFT|DT_SINGLELINE|DT_END_ELLIPSIS);
  bar.left=rc.left+16;bar.right=rc.right-16;bar.top=rc.top+46;bar.bottom=bar.top+24;
  FillRect(dc,&bar,(HBRUSH)GetStockObject(WHITE_BRUSH));
  b=CreateSolidBrush(GetSysColor(COLOR_BTNSHADOW));FrameRect(dc,&bar,b);DeleteObject(b);
  fill=prog_pct<0?0:(prog_pct>100?100:prog_pct);
  f=bar;f.left++;f.top++;f.bottom--;f.right=bar.left+1+((bar.right-bar.left-2)*fill)/100;
  if(f.right>f.left){b=CreateSolidBrush(GetSysColor(COLOR_ACTIVECAPTION));FillRect(dc,&f,b);DeleteObject(b);}
  EndPaint(w,&ps);return 0;
 }
 if(m==WM_CLOSE)return 0;
 return DefWindowProcA(w,m,wp,lp);
}
static void prog_pump(void){MSG msg;while(PeekMessageA(&msg,0,0,0,PM_REMOVE)){TranslateMessage(&msg);DispatchMessageA(&msg);}}
static void prog_set(int pct,const char *text){
 if(!prog_win)return;
 prog_pct=pct;if(text&&lstrlenA(text)<(int)sizeof(prog_text))lstrcpyA(prog_text,text);
 InvalidateRect(prog_win,0,TRUE);UpdateWindow(prog_win);prog_pump();
}
static void prog_cb(int pct){prog_set(pct,0);}
static void prog_create(void){
 WNDCLASSA wc;HINSTANCE inst=(HINSTANCE)GetModuleHandleA(0);int sw,sh,ww=440,wh=150;
 ZeroMemory(&wc,sizeof(wc));
 wc.lpfnWndProc=prog_proc;wc.hInstance=inst;wc.hCursor=LoadCursorA(0,IDC_ARROW);
 wc.hbrBackground=(HBRUSH)(COLOR_BTNFACE+1);wc.lpszClassName="WPSetupProgress";
 RegisterClassA(&wc);
 sw=GetSystemMetrics(SM_CXSCREEN);sh=GetSystemMetrics(SM_CYSCREEN);
 prog_win=CreateWindowExA(WS_EX_DLGMODALFRAME,"WPSetupProgress","WINPOWER Setup",
  WS_POPUP|WS_CAPTION|WS_VISIBLE,(sw-ww)/2,(sh-wh)/2,ww,wh,0,0,inst,0);
 if(prog_win){ShowWindow(prog_win,SW_SHOW);prog_pump();}
}
static void prog_destroy(void){if(prog_win){DestroyWindow(prog_win);prog_win=0;prog_pump();}}
#endif
#ifndef PNNT_PACKAGE
static void shell_notice(void){
 if(nt_groupnotice())message("Modified or unverified Program Manager items were preserved in the WINPOWER group.");
 if(lo_notice()==1)message("The desktop shortcut was modified after installation and was preserved.");
 else if(lo_notice()==2)message("Desktop shortcut ownership could not be verified. Any remaining shortcut was preserved; remove it manually if no longer needed.");
}
#endif
void WINAPI WinMainCRTStartup(void){
 DWORD ver=GetVersion(),size,disp;int i;char source[MAX_PATH],check[64],windir[MAX_PATH],command[MAX_PATH+8];HKEY k;BOOL remove,ok=FALSE,created=FALSE;
 BOOL registered=FALSE,linked=FALSE;
#ifdef PN9_PACKAGE
 BOOL pref_created=FALSE;
 HANDLE gui_lock=INVALID_HANDLE_VALUE;
#endif
#ifdef PN5_PACKAGE
 char source_dir[MAX_PATH]; DWORD service_error; BOOL old_resident=FALSE;
#endif
#ifndef PNNT_PACKAGE
 BOOL grouped=FALSE,copied_app=FALSE,copied_uninst=FALSE;
#endif
#ifdef PNNT_PACKAGE
 BOOL external_remove=FALSE,grouped=FALSE;LPSTR tail=GetCommandLineA();
 if(*tail=='"'){tail++;while(*tail&&*tail!='"')tail++;if(*tail)tail++;}else while(*tail&&*tail!=' ')tail++;
 while(*tail==' ')tail++;external_remove=!lstrcmpiA(tail,"/REMOVE");
 if(*tail&&!external_remove){message("Usage: SETUP.EXE or SETUP.EXE /REMOVE.");ExitProcess(1);}
#endif
#ifdef PNNT_PACKAGE
 size=GetModuleFileNameA(0,self,MAX_PATH);if(!size||size>=MAX_PATH){message("Cannot determine the installer path.");ExitProcess(1);}lstrcpyA(source,self);
#else
 GetModuleFileNameA(0,self,MAX_PATH);lstrcpyA(source,self);
#endif
 for(i=lstrlenA(source)-1;i>=0&&source[i]!='\\';--i){}source[i+1]=0;
#ifdef PNNT_PACKAGE
 if(i<0||i>MAX_PATH-20){message("The source path is invalid or too long.");ExitProcess(1);}
#endif
 remove=lstrcmpiA(self+i+1,"UNINST.EXE")==0;
#ifdef PN5_PACKAGE
 if (i < 0 || i > MAX_PATH-20) {message("The package path is too long.");ExitProcess(1);}
 lstrcpyA(source_dir,source);
#endif
#ifdef PNNT_PACKAGE
 remove=remove||external_remove;
#endif
#if defined(PN9_PACKAGE) || defined(PN9_GUI)
 if(!(ver&0x80000000UL)){message("Use the WINPWRNT package on Windows NT and later NT-family systems.");ExitProcess(1);}
#else
 if(ver&0x80000000UL){message("Use the WINPWR9X package on Windows 95, 98 or ME.");ExitProcess(1);}
#endif
#ifdef PN9_PACKAGE
 if(!(ver&0x80000000UL)||LOBYTE(LOWORD(ver))!=4||(HIBYTE(LOWORD(ver))!=0&&HIBYTE(LOWORD(ver))!=10&&HIBYTE(LOWORD(ver))!=90)){message("Use this package on Windows 95, 98 or Me.");ExitProcess(1);}
 if(!remove&&MessageBoxA(0,"Install WINPOWER and its Win9x power driver?\r\nRestart after setup. Windows controls shutdown by default. Driver control requires a compatible VMM and firmware.","WINPOWER Setup",MB_YESNO|MB_ICONQUESTION)!=IDYES)ExitProcess(0);
#endif
#ifdef PNNT_PACKAGE
 if(!remove&&!nt_preflight()){message(nt_reason());ExitProcess(1);}
#endif
#ifdef PN5_PACKAGE
 if ((ver & 0x80000000UL) || LOBYTE(LOWORD(ver)) != 5) {
  message("This driver package requires Windows 2000, XP or Server 2003."); ExitProcess(1);
 }
#ifndef _WIN64
 {
  typedef BOOL (WINAPI *WOWFUNC)(HANDLE,PBOOL);
  BOOL wow=FALSE;
  WOWFUNC iswow=(WOWFUNC)GetProcAddress(GetModuleHandleA("KERNEL32"),"IsWow64Process");
  if (iswow && (!iswow(GetCurrentProcess(), &wow) || wow)) {
   message("Use the native XPAMD64 package on 64-bit Windows."); ExitProcess(1);
  }
 }
#endif
 if (!remove && MessageBoxA(0,"Install WINPOWER and its power driver?\r\nWindows controls shutdown by default. Selecting Driver starts the driver and saves that choice for future boots.","WINPOWER Setup",MB_YESNO|MB_ICONQUESTION)!=IDYES) ExitProcess(0);
#endif
#ifdef PN5_PACKAGE
 if(!remove){
  service_error=wp5_disarm_legacy(&old_resident);
  if(service_error){wsprintfA(command,"Could not verify the resident power driver (Windows error %lu).",service_error);message(command);ExitProcess(1);}
  if(old_resident)message("The old driver is back under OS control. Restart after setup before selecting Driver.");
 }
#endif
 legacy=!(ver&0x80000000UL)&&LOBYTE(LOWORD(ver))<4;
 if(remove){
#ifdef PNNT_PACKAGE
  if(!nt_target(folder)){message(nt_reason());ExitProcess(1);}
#else
  lstrcpyA(folder,source);folder[lstrlenA(folder)-1]=0;
#endif
 }
 else{GetWindowsDirectoryA(windir,MAX_PATH);folder[0]=windir[0];folder[1]=':';folder[2]=0;lstrcatA(folder,"\\" PRODUCT_NAME);}
 wsprintfA(ini,"%s\\WINPOWER.INI",folder);wsprintfA(app,"%s\\" PRODUCT_NAME ".EXE",folder);wsprintfA(uninst,"%s\\UNINST.EXE",folder);
 GetPrivateProfileStringA("Setup","Product","",check,sizeof(check),ini);
 if(remove){
  if(lstrcmpA(check,PRODUCT_NAME)!=0){
#ifndef PNNT_PACKAGE
   message("Installation marker is missing. No files were removed.");ExitProcess(1);
#endif
  }
  if(MessageBoxA(0,"Uninstall WINPOWER? Close WINPOWER before continuing. A restart completes removal of this uninstaller.","Uninstall WINPOWER",MB_YESNO|MB_DEFBUTTON2)!=IDYES)ExitProcess(0);
#ifdef PN5_PACKAGE
  service_error=wp5_remove();
  if(service_error){wsprintfA(command,"Driver removal failed (Windows error %lu). Restart if necessary and retry the uninstaller.",service_error);message(command);ExitProcess(1);}
#endif
#ifdef PN9_PACKAGE
  /* Block a concurrent start of the installed GUI while switching back to
     Windows. ExitProcess closes the handle on any recoverable error. */
  gui_lock=CreateFileA(app,GENERIC_READ,0,NULL,OPEN_EXISTING,0,NULL);
  if(gui_lock==INVALID_HANDLE_VALUE&&GetLastError()!=ERROR_FILE_NOT_FOUND){
   message("Close WINPOWER and retry removal.");ExitProcess(1);
  }
  if(wp9_del_pref(folder)){message("The startup preference changed or could not be removed. Check the WINPWR9X RunServices entry and retry.");ExitProcess(1);}
  if(!pn9_release()){message(pn9_reason());ExitProcess(1);}
  if(wp9_remember(0)){message("The OS shutdown setting could not be saved. Retry removal.");ExitProcess(1);}
  if(!pn9_remove(folder)){message(pn9_reason());ExitProcess(1);}
  if(!pn9_cleanup(folder)){message(pn9_reason());ExitProcess(1);}
  if(gui_lock!=INVALID_HANDLE_VALUE)CloseHandle(gui_lock);
#endif
#ifdef PNNT_PACKAGE
  if(!nt_remove(folder,external_remove)){message(nt_reason());ExitProcess(1);}
#endif
#ifdef PNNT_PACKAGE
  if(!DeleteFileA(app)){
   disp=GetLastError();
   if(disp!=ERROR_FILE_NOT_FOUND&&disp!=ERROR_PATH_NOT_FOUND){message("Cannot remove the installed application. Close the application and retry.");ExitProcess(1);}
  }
#else
  if(!DeleteFileA(app)&&GetLastError()!=ERROR_FILE_NOT_FOUND){message("Cannot remove the installed application. Close the application and retry.");ExitProcess(1);}
#endif
#ifdef PNNT_PACKAGE
  if(legacy){if(!progman(TRUE)){message("Cannot remove the Program Manager items. Startup is disabled; retry SETUP.EXE /REMOVE.");ExitProcess(1);}}
  else if(!nt_linkremove(folder)){message(nt_reason());ExitProcess(1);}
  disp=RegDeleteKeyA(HKEY_LOCAL_MACHINE,regpath);
  if(disp!=ERROR_SUCCESS&&disp!=ERROR_FILE_NOT_FOUND){message("Cannot remove the uninstall registration. Retry SETUP.EXE /REMOVE.");ExitProcess(1);}
#else
  if(legacy){if(!progman(TRUE)){message("Cannot remove the Program Manager items. Installed recovery files were retained; retry UNINST.EXE.");ExitProcess(1);}}
  else {
   if(!lo_remove(regpath,PRODUCT_NAME ".LNK")){message(lo_reason());ExitProcess(1);}
   disp=RegDeleteKeyA(HKEY_LOCAL_MACHINE,regpath);
   if(disp!=ERROR_SUCCESS&&disp!=ERROR_FILE_NOT_FOUND){message("Cannot remove the uninstall registration. Retry UNINST.EXE.");ExitProcess(1);}
  }
#endif
#ifdef PN9_PACKAGE
  if(!pn9_finish(folder)){message(pn9_reason());ExitProcess(1);}
#elif !defined(PNNT_PACKAGE)
  if(ver&0x80000000UL){
   if(!lo_finish9(folder)){message(lo_reason());ExitProcess(1);}
  }else{
   if(!MoveFileExA(uninst,0,MOVEFILE_DELAY_UNTIL_REBOOT)){message("Application removed. Delete UNINST.EXE manually after closing this dialog.");ExitProcess(1);}
   MoveFileExA(folder,0,MOVEFILE_DELAY_UNTIL_REBOOT);
  }
#endif
#ifdef PNNT_PACKAGE
  if(!nt_finish(folder)){message(nt_reason());ExitProcess(1);}
  if(nt_groupnotice())message("Modified or unverified Program Manager items were preserved in the WINPOWER group.");
  if(nt_linknotice()==1)message("The desktop shortcut was modified after installation and was preserved.");
  else if(nt_linknotice()==2)message("Desktop shortcut ownership could not be verified. Any remaining shortcut was preserved; remove it manually if no longer needed.");
  message("WINPOWER startup was disabled and its services were removed. Restart to finish deleting the installed files. The current kernel backend stays active until restart.");ExitProcess(0);
#endif
#ifndef PNNT_PACKAGE
  shell_notice();
#endif
#ifdef PN9_PACKAGE
  DeleteFileA(ini);message("Windows controls shutdown. WINPOWER startup and its files were removed. Restart and sign in to finish removing the uninstaller and application folder.");
#else
  DeleteFileA(ini);
#ifdef PNNT_PACKAGE
  message("WINPOWER was removed. Restart to delete the uninstaller. On Windows 95/98/ME, remove the empty application directory afterward.");
#else
  message("WINPOWER was removed. Restart and sign in to delete the uninstaller and empty application directory automatically. Additional files are preserved.");
#endif
#endif
  ExitProcess(0);
 }
#ifdef PNNT_PACKAGE
 if(nt_installed(folder)){message("An existing WINPOWER directory or service was found. Remove the previous installation with its uninstaller, restart, then run Setup.");ExitProcess(1);}
 if(MessageBoxA(0,"Install WINPOWER and its startup power service?","WINPOWER Setup",MB_YESNO|MB_ICONQUESTION)!=IDYES)ExitProcess(0);
#elif !defined(PN9_PACKAGE) && !defined(PN5_PACKAGE)
 if(MessageBoxA(0,"Install the WINPOWER application?","WINPOWER Setup",MB_YESNO|MB_ICONQUESTION)!=IDYES)ExitProcess(0);
#endif
 if(!legacy){
  if(RegOpenKeyExA(HKEY_CURRENT_USER,"Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Shell Folders",0,KEY_READ,&k)!=ERROR_SUCCESS){message("Cannot locate the Desktop folder.");ExitProcess(1);}
  size=sizeof(desktop);i=RegQueryValueExA(k,"Desktop",0,&disp,(BYTE*)desktop,&size);RegCloseKey(k);
  if(i!=ERROR_SUCCESS||disp!=REG_SZ||size>=sizeof(desktop)){message("Cannot read the Desktop folder.");ExitProcess(1);}desktop[size]=0;
  if(lstrlenA(desktop)>MAX_PATH-14){message("Desktop path is too long.");ExitProcess(1);}
  wsprintfA(linkpath,"%s\\" PRODUCT_NAME ".LNK",desktop);
 }
 if(GetFileAttributesA(folder)!=INVALID_FILE_ATTRIBUTES){message("The installation directory already exists. Uninstall the previous copy first, or move the directory before installing.");ExitProcess(1);}
 if(!legacy){
  disp=RegOpenKeyExA(HKEY_LOCAL_MACHINE,regpath,0,KEY_READ,&k);
  if(disp==ERROR_SUCCESS){RegCloseKey(k);message("The " PRODUCT_NAME " uninstall registration already exists. Remove that installation first.");ExitProcess(1);}
  if(disp!=ERROR_FILE_NOT_FOUND&&disp!=ERROR_PATH_NOT_FOUND){message("Cannot inspect the uninstall registration.");ExitProcess(1);}
  if(GetFileAttributesA(linkpath)!=INVALID_FILE_ATTRIBUTES){message("The desktop shortcut already exists. Preserve or rename it before installing.");ExitProcess(1);}
 }
#ifdef PNNT_PACKAGE
 prog_create();nt_setprogress(prog_cb);prog_set(12,"Preparing to install WINPOWER...");
#endif
 if(!CreateDirectoryA(folder,0)){
#ifdef PNNT_PACKAGE
  prog_destroy();
#endif
  message("Cannot create a new installation directory. Check that it is unused and you have sufficient rights.");ExitProcess(1);
 }
 created=TRUE;
 lstrcatA(source,PRODUCT_NAME ".EXE");
#ifdef PNNT_PACKAGE
 prog_set(25,"Copying the WINPOWER application...");
 if(!CopyFileA(source,app,TRUE)||!nt_newfile(app))goto rollback;
 prog_set(40,"Copying the uninstaller...");
 if(!CopyFileA(self,uninst,TRUE)||!nt_newfile(uninst))goto rollback;
#else
 if(!CopyFileA(source,app,TRUE))goto rollback;
 copied_app=TRUE;
 if(!lo_newfile(app))goto rollback;
 if(!CopyFileA(self,uninst,TRUE))goto rollback;
 copied_uninst=TRUE;
 if(!lo_newfile(uninst))goto rollback;
#endif
#ifdef PN9_PACKAGE
 if(!pn9_stage(self,folder))goto rollback;
#endif
#ifdef PNNT_PACKAGE
 prog_set(50,"Copying the power driver and startup service...");
 if(!nt_stage(self,folder))goto rollback;
 prog_set(65,"Registering WINPOWER...");
#endif
 if(!WritePrivateProfileStringA("Setup","Product",PRODUCT_NAME,ini)||!WritePrivateProfileStringA("Setup","Shortcut",linkpath,ini))goto rollback;
 if(legacy){if(!progman(FALSE)){
#ifdef PNNT_PACKAGE
  nt_error("Cannot create the WINPOWER Program Manager group. Existing groups are preserved.",GetLastError());
#else
  message("Cannot create the WINPOWER Program Manager group. Existing groups are preserved.");
#endif
  goto rollback;
 }
  grouped=TRUE;
 }
 else{
  if(RegCreateKeyExA(HKEY_LOCAL_MACHINE,regpath,0,0,0,KEY_WRITE,0,&k,&disp)!=ERROR_SUCCESS)goto rollback;
  if(disp!=REG_CREATED_NEW_KEY){RegCloseKey(k);message("The uninstall registration changed during setup. The existing registration was preserved.");goto rollback;}
  registered=TRUE;
  wsprintfA(command,"\"%s\"",uninst);
  /* No version is published to Add/Remove Programs: the name carries no
     version suffix and no DisplayVersion value is written. */
  ok=value(k,"DisplayName",PRODUCT_NAME)&&value(k,"UninstallString",command);
  wsprintfA(command,"%s,1",uninst);ok=ok&&value(k,"DisplayIcon",command);RegCloseKey(k);
#ifdef PNNT_PACKAGE
  if(!ok||!shortcut()){RegDeleteKeyA(HKEY_LOCAL_MACHINE,regpath);goto rollback;}
  linked=TRUE;
  if(!nt_linkmark(linkpath))goto rollback;
#else
  if(!ok)goto rollback;
  if(!shortcut()){
   /* Save may have created a partial file. Its identity is unavailable. */
   if(GetFileAttributesA(linkpath)!=INVALID_FILE_ATTRIBUTES)linked=TRUE;
   goto rollback;
  }
  linked=TRUE;
  if(!lo_save(regpath,linkpath,PRODUCT_NAME ".LNK"))goto rollback;
#endif
 }
#ifdef PNNT_PACKAGE
 prog_set(78,"Starting the power service...");
 if(!nt_install(folder))goto rollback;
 prog_set(100,"Installation complete.");prog_destroy();
 if(nt_backendwarning()){
  wsprintfA(warnbuf,"WINPOWER is installed, but its power backend could not activate (error %lu, driver stage %lu). The driver found no usable ACPI S5 or APM power method on this machine. Open WINPOWER to see the detected ACPI status. The operating-system power path is used until the backend can arm, for example after a restart.",nt_backendwarning(),nt_backendstage());
  message(warnbuf);ExitProcess(0);
 }
 message("WINPOWER is installed. Windows owns shutdown by default. Open WINPOWER to select Driver control. The startup service restores your choice on later boots.");ExitProcess(0);
#endif
#ifdef PN5_PACKAGE
 service_error = wp5_install(source_dir);
 if(service_error){
  wsprintfA(command,"The power service could not be installed (Windows error %lu). Check administrator rights, the matching driver file and any previous installation.",service_error);
  message(command);goto rollback;
 }
 message("WINPOWER is installed. Open the desktop shortcut to choose OS or Driver control. Windows controls shutdown by default.");ExitProcess(0);
#endif
#ifdef PN9_PACKAGE
 if(wp9_add_pref(folder)){message("The shutdown owner startup preference could not be registered.");goto rollback;}
 pref_created=TRUE;
 if(!pn9_install(folder))goto rollback;
 message("WINPOWER is installed. Restart to load the driver, then open the desktop shortcut to choose OS or Driver control.");ExitProcess(0);
#else
 message("WINPOWER is installed. Open the desktop shortcut to view status and request power off or restart.");ExitProcess(0);
#endif
 rollback:
#ifdef PNNT_PACKAGE
 prog_destroy();
 if(created&&!nt_abort(folder)){message(nt_reason());ExitProcess(1);}
 if(linked&&!nt_linkundo()){message(nt_reason());ExitProcess(1);}
 if(registered){
  disp=RegDeleteKeyA(HKEY_LOCAL_MACHINE,regpath);
  if(disp!=ERROR_SUCCESS&&disp!=ERROR_FILE_NOT_FOUND){nt_error("Rollback could not remove the uninstall registration. Retry SETUP.EXE /REMOVE.",disp);message(nt_reason());ExitProcess(1);}
 }
 if(grouped&&!progman(TRUE)){message("Rollback could not remove Program Manager items. Recovery files were retained; retry SETUP.EXE /REMOVE.");ExitProcess(1);}
 if(created){
  if(!DeleteFileA(app)&&GetLastError()!=ERROR_FILE_NOT_FOUND){nt_error("Rollback could not remove the application. Recovery files were retained.",GetLastError());message(nt_reason());ExitProcess(1);}
  if(!DeleteFileA(uninst)&&GetLastError()!=ERROR_FILE_NOT_FOUND){nt_error("Rollback could not remove the uninstaller. Retry SETUP.EXE /REMOVE.",GetLastError());message(nt_reason());ExitProcess(1);}
  if(!DeleteFileA(ini)&&GetLastError()!=ERROR_FILE_NOT_FOUND){nt_error("Rollback could not remove the INI file. Retry SETUP.EXE /REMOVE.",GetLastError());message(nt_reason());ExitProcess(1);}
  if(!RemoveDirectoryA(folder)&&GetLastError()!=ERROR_PATH_NOT_FOUND){nt_error("Rollback could not remove the installation folder. Other files were preserved.",GetLastError());message(nt_reason());ExitProcess(1);}
  if(!nt_abortfinish()){message(nt_reason());ExitProcess(1);}
 }
 if(nt_linknotice()==1)message("The desktop shortcut changed during installation and was preserved.");
 else if(nt_linknotice()==2)message("Desktop shortcut ownership could not be verified. Any remaining shortcut was preserved.");
 if(nt_groupnotice())message("Modified or unverified Program Manager items were preserved in the WINPOWER group.");
#endif
#ifdef PN9_PACKAGE
 if(pref_created && wp9_del_pref(folder)){message("The startup preference could not be rolled back.");ExitProcess(1);}
 if(pn9_recovery()){message(pn9_reason());ExitProcess(1);}
#endif
#ifndef PNNT_PACKAGE
 if(linked&&!lo_undo()){message(lo_reason());ExitProcess(1);}
 if(registered){
  disp=RegDeleteKeyA(HKEY_LOCAL_MACHINE,regpath);
  if(disp!=ERROR_SUCCESS&&disp!=ERROR_FILE_NOT_FOUND){message("Rollback could not remove the uninstall registration. Installation files were retained.");ExitProcess(1);}
 }
 if(grouped&&!progman(TRUE)){message("Rollback could not remove the Program Manager items. Installation files were retained.");ExitProcess(1);}
#ifdef PN9_PACKAGE
 if(created&&!pn9_cleanup(folder)){message(pn9_reason());ExitProcess(1);}
#endif
 if(created){
  if(copied_app&&!DeleteFileA(app)&&GetLastError()!=ERROR_FILE_NOT_FOUND){message("Rollback could not remove the copied application. Installation files were retained.");ExitProcess(1);}
  if(copied_uninst&&!DeleteFileA(uninst)&&GetLastError()!=ERROR_FILE_NOT_FOUND){message("Rollback could not remove the copied uninstaller. Installation files were retained.");ExitProcess(1);}
  if(!DeleteFileA(ini)&&GetLastError()!=ERROR_FILE_NOT_FOUND){message("Rollback could not remove the INI file. The installation folder was retained.");ExitProcess(1);}
  if(!RemoveDirectoryA(folder)&&GetLastError()!=ERROR_PATH_NOT_FOUND){message("Rollback could not remove the installation folder. Other files were preserved.");ExitProcess(1);}
 }
 shell_notice();
#endif
#ifdef PN9_PACKAGE
 message(lo_reason()?lo_reason():pn9_reason());
#elif defined(PNNT_PACKAGE)
 message(nt_reason());
#else
 message(lo_reason()?lo_reason():"Installation failed and copied files were removed. Check permissions and that the variant application is beside SETUP.EXE.");ExitProcess(1);
#endif
 ExitProcess(1);
}
