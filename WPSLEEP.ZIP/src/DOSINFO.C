/* DOS family/version detection. Uses only DOS 2.0 calls unless a later
   call is first proven safe; INT 2Fh is not called through a null vector. */
#include <dos.h>
#include <i86.h>
#include <string.h>
#include "DOSINFO.H"
int pn_int2f_ok(void){
 union REGS in,out;struct SREGS seg;
 memset(&in,0,sizeof(in));segread(&seg);in.h.ah=0x35;in.h.al=0x2f;
 intdosx(&in,&out,&seg);
 return seg.es!=0||out.w.bx!=0;
}
int pn_inwindows(void){
 union REGS in,out;
 if(!pn_int2f_ok())return 0;
 memset(&in,0,sizeof(in));in.w.ax=0x1600;int86(0x2f,&in,&out);
 if(out.h.al&&out.h.al!=0x80)return 1;
 memset(&in,0,sizeof(in));in.w.ax=0x4680;int86(0x2f,&in,&out);if(!out.w.ax)return 1;
 memset(&in,0,sizeof(in));in.w.ax=0x160a;int86(0x2f,&in,&out);return !out.w.ax;
}
void pn_dosinfo(struct pn_dos *d){
 union REGS in,out;
 memset(d,0,sizeof(*d));
 memset(&in,0,sizeof(in));in.h.ah=0x30;in.h.al=0;intdos(&in,&out);
 d->major=out.h.al;d->minor=out.h.ah;d->oem=out.h.bh;
 if(pn_int2f_ok())d->flags|=PN_DOS_INT2F;
 /* DR-DOS/Novell DOS answer IOCTL AX=4452h with a version code; other
    systems reject this subfunction with carry set. Accept only the
    documented version-code range. */
 memset(&in,0,sizeof(in));in.w.ax=0x4452;intdos(&in,&out);
 if(!out.w.cflag&&out.w.ax>=0x1060&&out.w.ax<=0x10ff)d->drdos=out.w.ax;
 if(d->major>=5){
  memset(&in,0,sizeof(in));in.w.ax=0x3306;in.w.bx=0;intdos(&in,&out);
  if(out.h.al!=0xff&&out.h.bl>=5&&out.h.bl<=99){
   d->true_major=out.h.bl;d->true_minor=out.h.bh;d->flags|=PN_DOS_TRUEVER;
   if(out.h.dh&8)d->flags|=PN_DOS_ROM;
   if(out.h.dh&16)d->flags|=PN_DOS_HMA;
  }
 }
 if(!d->true_major){d->true_major=d->major;d->true_minor=d->minor;}
 if(d->drdos)d->vendor=PN_VENDOR_DR;
 else if(d->oem==0xfd)d->vendor=PN_VENDOR_FREE;
 else if(d->oem==0xff)d->vendor=PN_VENDOR_MS;
 else if(d->oem==0x00)d->vendor=PN_VENDOR_IBM;
 else if(d->oem==0xee)d->vendor=PN_VENDOR_DR;
 else d->vendor=PN_VENDOR_OTHER;
 /* MS-DOS 7.x/8.0 are the Windows 9x/ME real-mode kernels. */
 if(d->vendor==PN_VENDOR_MS&&d->true_major>=7)d->flags|=PN_DOS_WIN9X;
}
static char *put2(char *p,unsigned v){*p++=(char)('0'+(v/10)%10);*p++=(char)('0'+v%10);return p;}
void pn_dosname(const struct pn_dos *d,char *out){
 const char *name;char *p;unsigned major=d->true_major,minor=d->true_minor;
 switch(d->vendor){
 case PN_VENDOR_MS:name="MS-DOS";break;
 case PN_VENDOR_IBM:name="PC DOS";break;
 case PN_VENDOR_DR:name=(d->drdos>=0x1072)?"Novell/DR-DOS":"DR DOS";break;
 case PN_VENDOR_FREE:name="FreeDOS";break;
 default:name="DOS";break;
 }
 strcpy(out,name);p=out+strlen(out);*p++=' ';
 if(!major){strcpy(p,"1.x");return;}
 if(major>=10)*p++=(char)('0'+(major/10)%10);
 *p++=(char)('0'+major%10);*p++='.';p=put2(p,minor);*p=0;
 if(d->vendor==PN_VENDOR_OTHER){
  strcpy(p," (OEM ");p+=6;
  *p++="0123456789ABCDEF"[d->oem>>4];*p++="0123456789ABCDEF"[d->oem&15];*p++=')';*p=0;
 }
 if(d->vendor==PN_VENDOR_DR&&d->drdos){
  static const char hex[]="0123456789ABCDEF";
  strcpy(p," [");p+=2;
  *p++=hex[(d->drdos>>12)&15];*p++=hex[(d->drdos>>8)&15];*p++=hex[(d->drdos>>4)&15];*p++=hex[d->drdos&15];
  *p++=']';*p=0;
 }
}
