#!/bin/sh
# Experimental native handoff build; separate from distributable binaries.
set -eu
cd "$(dirname "$0")"
: "${DDK_ROOT:=/usr}"
for arch in i686 x86_64; do
 if [ "$arch" = i686 ]; then
  dest=NT5LAB; cpu=-march=i486; entry=_DriverEntry@8; version=5.0; apm=NTAPM.C
 else
  dest=NT5X64; cpu=; entry=DriverEntry; version=5.2; apm=NTAPMX64.C
 fi
 mkdir -p ../BIN/WINPWRNT/$dest
 "$arch-w64-mingw32-gcc" -x c $cpu -Os -Wall -Wextra -Werror -Wno-misleading-indentation \
  -nostdlib -ffreestanding -fno-stack-protector \
  -I"$DDK_ROOT/$arch-w64-mingw32/include/ddk" \
  -D_WIN32_WINNT=0x0502 -DNTDDI_VERSION=0x05020000 -DNTDDI_WINVISTA=0x06000000 \
  -DPN_AML -DPN_NT5_RANGES -shared PN5HOOK.C N5HAND.C S5.C ACPI.C PWRSEQ.C AML.C NTAML.C "$apm" \
  -Wl,--entry,"$entry",--subsystem,native:$version,--image-base,0x10000 \
  -o ../BIN/WINPWRNT/$dest/PN5HOOK.SYS -lntoskrnl -lhal
done
