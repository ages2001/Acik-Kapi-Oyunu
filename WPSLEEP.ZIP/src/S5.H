#ifndef PN_S5_H
#define PN_S5_H
/* Static ACPI namespace subset. No arbitrary AML execution or port writes. */
#if defined(_WIN64) && !defined(PN_WIDE_TABLES)
#define PN_WIDE_TABLES
#endif
#ifdef PN_WIDE_TABLES
#include <stdint.h>
typedef uint64_t pn_address;
#else
typedef unsigned long pn_address;
#endif
typedef int (*pn_read)(void *,pn_address,unsigned char *,unsigned);
/* A fixed firmware register supplied by a validated FADT. native is private
   to the backend and is populated before shutdown, never from user input. */
struct pn_reg { unsigned space,bytes;unsigned long low,high;void *native; };
struct pn_acpi {
 unsigned reduced,reset_pci;
 struct pn_reg control_reg,status_reg,reset_reg,pm1a_reg,pm1b_reg;
 unsigned rsdp_rev,fadt_rev,fadt_minor;
 unsigned off_ok,reset_ok,pm1a,pm1b,reset_port,reset_value;
 unsigned sleepa,sleepb,enable,disable;
 unsigned long smi;
 unsigned where; /* diagnostic: where pn_tables stopped when off_ok stays 0 */
#ifdef PN_TIMER_INFO
 unsigned timer_port,timer_bits;
#endif
};
int pn_tables(pn_read read,void *arg,pn_address rsdp,struct pn_acpi *out,
              unsigned char *work,unsigned capacity);
int pn_s5(const unsigned char *aml,unsigned size,unsigned *a,unsigned *b);
#ifdef PN_MULTI_S5
/* Optional combined static namespace. Feed all DSDT/SSDT/PSDT AML bodies
   before asking for sleep values. The caller validates table checksums.
   Failure is sticky; zero-length tables are allowed with a non-NULL body.
   This is a bounded parser, not an AML interpreter or power authority. */
#define PN_NS_MAX_TABLES 128U
#define PN_NS_MAX_AML 65535U
struct pn_s5ns {unsigned found,a,b,hook,failed,tables;};
void pn_ns_begin(struct pn_s5ns *);
int pn_ns_add(struct pn_s5ns *,const unsigned char *,unsigned);
int pn_ns_sleep(const struct pn_s5ns *,unsigned *,unsigned *);
#endif
#ifdef PN_AML
/* Optional bounded AML interpreter backend (AML.C). When pn_amlctx is set
   before pn_tables, DSDT and every SSDT/PSDT are copied into the arena and
   loaded; \_S5 may then be a method, and \_TTS/\_PTS/\_GTS are admitted
   when statically verified. prepare is set when such methods exist; the
   caller must run pn_aml_prepare before writing SLP_EN. */
#include "AML.H"
struct pn_amlctx {
 struct pn_aml aml;struct pn_aml_node *nodes;unsigned capacity;
 unsigned char *arena;unsigned long arena_size,used;
 const struct pn_aml_env *env;unsigned prepare,tables,loaded,done;
};
extern struct pn_amlctx *pn_amlctx;
#endif
#endif
