#!/bin/sh
set -eu
cd "$(dirname "$0")"
mkdir -p ../BIN/WINPWRNT/NT5LAB
cc=i686-w64-mingw32-gcc
case "${1:-all}" in all|helper) ;; *) echo 'Usage: BUILD5.SH [all|helper]' >&2; exit 2;; esac
if [ "${1:-all}" = all ]; then
"$cc" -x c -march=i486 -Os -Wall -Wextra -Wno-misleading-indentation -nostdlib -ffreestanding -fno-stack-protector -I"${DDK_ROOT:-/usr}/i686-w64-mingw32/include/ddk" -D_WIN32_WINNT=0x0501 -DNTDDI_VERSION=0x05010000 -DNTDDI_WINVISTA=0x06000000 -DPN_AML -shared PN5HOOK.C N5HAND.C S5.C ACPI.C PWRSEQ.C AML.C NTAML.C NTAPM.C -Wl,--entry,_DriverEntry@8,--subsystem,native:5.0,--image-base,0x10000 -o ../BIN/WINPWRNT/NT5LAB/PN5HOOK.SYS -lntoskrnl -lhal
fi
"$cc" -x c -march=i486 -Os -Wall -Wextra -fno-builtin -fno-stack-protector -nostdlib -mwindows PN5TEST.C -Wl,--entry,_WinMainCRTStartup@0,--subsystem,windows:4.0 -o ../BIN/WINPWRNT/NT5LAB/PN5TEST.EXE -lkernel32 -luser32 -ladvapi32
