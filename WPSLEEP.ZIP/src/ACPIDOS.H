#ifndef PN_ACPIDOS_H
#define PN_ACPIDOS_H
#include "S5.H"
int pn_probe(struct pn_acpi *out);
/* Called only in standalone DOS after all Windows sessions have ended.
   Return 0: unavailable/failed with legacy mode restored; -1: do not fallback. */
int pn_acoff(const struct pn_acpi *info);
int pn_acapm(const struct pn_acpi *info);
int pn_acreset(const struct pn_acpi *info);
#ifdef PN_AML
/* Frees interpreter buffers (call before starting Windows). */
void pn_release(void);
/* 1 when firmware preparation methods will run before S5. */
int pn_aml_prepared(void);
#endif
#endif
