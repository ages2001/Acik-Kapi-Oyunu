#!/bin/sh
# Build only the Win32 GUI and its installer; retain tested power drivers.
set -eu
mode=${1:-all}
case "$mode" in all|gui|setup) ;; *) echo 'Usage: BUILDUI.SH [all|gui|setup]' >&2; exit 2;; esac
case "${2:-all}" in all) targets='i686 x86_64';; x86) targets=i686;; x64) targets=x86_64;; *) echo 'Architecture must be all, x86 or x64.' >&2; exit 2;; esac
cd "$(dirname "$0")"
mkdir -p ../BIN/WINPWRNT/X86 ../BIN/WINPWRNT/X64 ../BIN/WINPWRNT/LEGACY ../BIN/WINPWR9X/LAB ../TEST
for arch in $targets; do
 if [ "$arch" = i686 ]; then cpu='-march=i386 -mno-sse -mno-mmx'; out=X86; entry=_WinMainCRTStartup@0; ver=3.10; else cpu=''; out=X64; entry=WinMainCRTStartup; ver=5.2; fi
 "$arch-w64-mingw32-windres" WINPOWER.RC -O coff -o ../TEST/ICON.O
 if [ "$mode" != setup ]; then
 "$arch-w64-mingw32-windres" SLEEPUI.RC -O coff -o ../TEST/SLPICON.O
 "$arch-w64-mingw32-gcc" $cpu -x c -Os -Wall -Wextra -Werror -Wno-cast-function-type -Wno-misleading-indentation -fno-builtin -fno-stack-protector -nostdlib -mwindows WINPOWER.C OSINFO.C OSNAME.C ICONUI.C FWAPI.C FWTABLE.C P9PREF.C -x none ../TEST/SLPICON.O -Wl,--entry,"$entry",--subsystem,windows:$ver -o ../BIN/WINPWRNT/$out/WINPWRNT.EXE -luser32 -lkernel32 -lgdi32 -ladvapi32
 fi
 if [ "$mode" != gui ]; then
 "$arch-w64-mingw32-gcc" $cpu -x c -Os -Wall -Wextra -Werror -Wno-cast-function-type -Wno-misleading-indentation -fno-builtin -fno-stack-protector -nostdlib -mwindows SETUP.C LINKOWN.C SHA256.C NTDDE.C -x none ../TEST/ICON.O -Wl,--entry,"$entry",--subsystem,windows:$ver -o ../BIN/WINPWRNT/$out/SETUP.EXE -luser32 -lkernel32 -ladvapi32 -luuid
 fi
done
rm ../TEST/ICON.O

mkdir -p ../BIN/WINPWR9X/GUI
cp ../BIN/WINPWRNT/X86/WINPWRNT.EXE ../BIN/WINPWR9X/GUI/WINPWR9X.EXE
cp ../BIN/WINPWRNT/X86/WINPWRNT.EXE ../BIN/WINPWR9X/LAB/WINPWR9X.EXE
cp ../BIN/WINPWRNT/X86/WINPWRNT.EXE ../BIN/WINPWRNT/LEGACY/WINPWRNT.EXE
if [ "$mode" != gui ]; then
i686-w64-mingw32-windres WINPOWER.RC -O coff -o ../TEST/ICON.O
i686-w64-mingw32-gcc -march=i386 -mno-sse -mno-mmx -x c -Os -Wall -Wextra -Werror -Wno-cast-function-type -Wno-misleading-indentation -fno-builtin -fno-stack-protector -nostdlib -mwindows -DPN9_GUI SETUP.C LINKOWN.C SHA256.C NTDDE.C -x none ../TEST/ICON.O -Wl,--entry,_WinMainCRTStartup@0,--subsystem,windows:4.0 -o ../BIN/WINPWR9X/GUI/SETUP.EXE -luser32 -lkernel32 -ladvapi32 -luuid
rm ../TEST/ICON.O
fi
