#ifndef PN_NTAML_H
#define PN_NTAML_H
/* NT kernel AML glue; see NTAML.C for the access policy. */
struct pn_reg;
struct pn_acpi;
int pn_ntreg_bind(struct pn_reg *);
int pn_ntreg_read16(const struct pn_reg *,unsigned *);
int pn_ntreg_write(const struct pn_reg *,unsigned);
void pn_ntreg_release(struct pn_acpi *);
int pn_ntaml_setup(unsigned long ram_top,unsigned long ebda);
int pn_ntaml_pages(unsigned long highest_page,unsigned long ebda);
void pn_ntaml_release(void);
void pn_ntaml_done(int keep);
int pn_ntaml_prepared(void);
unsigned pn_ntaml_tables(void);
int pn_ntaml_prepare(void *arg);
/* 0 = not run, 1 = completed, 2 = a method failed (S5 inhibited). */
unsigned pn_ntaml_result(void);
#endif
