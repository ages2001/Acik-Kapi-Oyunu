WINPOWER v1.0 source

Read ../BUILD.TXT and TOOLS.TXT for dependencies and the full build.
Run python3 src/PACK.PY from the extracted root to verify the release.
