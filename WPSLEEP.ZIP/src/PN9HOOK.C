#include "FWVER.H"
/* Windows 95, 98 and Me power handoff for supported PC BIOS systems.
 * Firmware writes require an armed backend and Driver ownership.
 * Windows 98 and Me finish their own resets after VFAT commits its writes. */
#include <string.h>
#include "ACPI.H"
#include "S5.H"
#include "PWRSEQ.H"
#ifdef PN_AML
#include "AML.H"
#endif
typedef unsigned long U32;
typedef unsigned short U16;
typedef unsigned char U8;
extern U8 PN9_DDB[];
struct ddb { U32 next;U16 sdk,id;U8 major,minor;U16 flags;char name[8];U32 order,control; };
struct diop { U32 internal1,vm,internal2,code,in,insize,out,outsize,returned,overlapped,handle,process; };
static struct pn_acpi firmware;
static U8 work[32768];
static U8 *lowmap;
static U32 status[16],original,exitcode=0xffffffffUL;
/* Native-shutdown owner: 0 = the OS powers the machine off itself (default),
   1 = this VxD takes over a native Windows shutdown and performs the ACPI S5.
   GUI buttons request orderly Windows shutdown and use this same owner. */
static U32 ownermode;
static int initialized;
static void hook93(void),hookbd(void);
static void byteout(U8 value);
#pragma aux byteout = "out 0e9h,al" parm [al] modify exact [];
static U32 in32(unsigned port);
#pragma aux in32 = "in eax,dx" parm [dx] value [eax] modify exact [eax];
static U16 in16(unsigned port);
#pragma aux in16 = "in ax,dx" parm [dx] value [ax] modify exact [ax];
static void out16(unsigned port,unsigned value);
#pragma aux out16 = "out dx,ax" parm [dx] [ax] modify exact [];
static void out8(unsigned port,unsigned value);
#pragma aux out8 = "out dx,al" parm [dx] [al] modify exact [];
static unsigned in8(unsigned port);
#pragma aux in8 = "in al,dx" "movzx eax,al" parm [dx] value [eax] modify exact [eax];
static void out32(unsigned port,U32 value);
#pragma aux out32 = "out dx,eax" parm [dx] [eax] modify exact [];
static void cli_(void);
#pragma aux cli_ = "cli" modify exact [];
static void sti_(void);
#pragma aux sti_ = "sti" modify exact [];
static void halt(void);
#pragma aux halt = "cli" "stopped: hlt" "jmp stopped" modify exact [];
static void hex(U32 x) {int i;for(i=28;i>=0;i-=4){unsigned n=(unsigned)((x>>i)&15);byteout((U8)(n<10?'0'+n:'A'+n-10));}}
static void logvalue(U8 tag,U32 x){byteout(tag);byteout(' ');hex(x);byteout(10);}
static struct ddb *getddb(U32 id) {
 struct ddb *result=0;
 _asm { push edi
  mov eax,id
  xor edi,edi
  int 20h
  dw 146h
  dw 1
  mov result,ecx
  pop edi
 }
 return result;
}
static void __declspec(naked) __cdecl demand(U32 *info,U32 flags) {
 _asm { int 20h
  dw 806fh
  dw 1
 }
}
static U32 __declspec(naked) __cdecl map(U32 physical,U32 size,U32 flags) {
 _asm { int 20h
  dw 806ch
  dw 1
 }
}
static int vmm_noop_exit(const struct ddb *p) {
 const U8 *b=(const U8*)p->control;
 /* The supplied Win95 RTM VMM has an order-zero handler. Its only
  * possible action is for message 14h. For 26h both branches reach
  * CLC; RET. Reject other code shapes rather than assuming this. */
 return p->id==1&&p->sdk==0x400&&!p->order&&b&&(U32)b>=0xc0000000UL&&
  b[0]==0xf7&&b[1]==5&&b[10]==0x74&&b[11]==9&&
  b[12]==0x83&&b[13]==0xf8&&b[14]==0x14&&b[15]==0x0f&&b[16]==0x84&&
  b[21]==0xf8&&b[22]==0xc3;
}
static int unique_last(void) {
 struct ddb *first=getddb(1),*p=first;unsigned n=0,own=0;
 if(!p||(U32)p<0xc0000000UL||p->id!=1)return 0;
 do {
  if((U32)p<0xc0000000UL||((U32)p&3)||++n>256)return 0;
  if((U8*)p==PN9_DDB)own++;
  else if(p->control&&p->order==0&&!(p==first&&(vmm_noop_exit(p)||status[2]!=0x400))){logvalue('X',(U32)p);return 0;}
  p=(struct ddb*)p->next;
 }while(p&&p!=first);
 status[14]=n;return own==1;
}
/* On-demand physical mapping: _MapPhysToLinear a page-aligned window and
 * cache the eight most recent single-page windows. Larger spans (a whole
 * ACPI table during discovery) are mapped once without caching. This
 * removes the earlier fixed 64 MiB table-window assumption. */
#define PN9_NWIN 8
static U32 winbase[PN9_NWIN];
static U8 *winlin[PN9_NWIN];
static unsigned winnext;
static U8 *mapwin(U32 phys,unsigned n) {
 U32 base=phys&~0xfffUL;unsigned span=((unsigned)(phys&0xfff)+n+0xfffU)&~0xfffU,i;U8 *lin;
 if(span<=0x1000) {
  for(i=0;i<PN9_NWIN;i++)if(winlin[i]&&winbase[i]==base)return winlin[i]+(phys-base);
  lin=(U8*)map(base,0x1000,0);if(!lin||(U32)lin==0xffffffffUL)return 0;
  winbase[winnext]=base;winlin[winnext]=lin;winnext=(winnext+1)&(PN9_NWIN-1);
  return lin+(phys-base);
 }
 lin=(U8*)map(base,span,0);if(!lin||(U32)lin==0xffffffffUL)return 0;
 return lin+(phys-base);
}
static int readphys(void *arg,U32 address,U8 *out,unsigned n) {
 const U8 *source;(void)arg;
 if(!n||address>0xffffffffUL-n)return 0;
 if(address+n<=0x100000UL)source=lowmap+address;
 else{source=mapwin(address,n);if(!source)return 0;}
 memcpy(out,source,n);return 1;
}
#ifdef PN_AML
/* Bounded AML interpreter ring-0 environment for Win9x.
 * Policy: any I/O port except the PCI configuration window; physical
 * reads anywhere; physical writes only to firmware memory (top of RAM
 * where QEMU keeps the ACPI tables and NVS, the BIOS area and the EBDA),
 * never into general RAM; PCI configuration mechanism #1. */
#define PN9_NODES 1400
#define PN9_ARENA 65536UL
static struct pn_aml_node amlnodes[PN9_NODES];
static U8 amlarena[PN9_ARENA];
static struct pn_amlctx amlctx;
static U32 ramtop,ebda_base;
static int aml_memr(void *g,U32 a,unsigned w,U32 *v) {
 U8 *p;unsigned i,n=w/8;(void)g;
 p=(a+n<=0x100000UL)?lowmap+a:mapwin(a,n);if(!p)return 0;
 *v=0;for(i=0;i<n;i++)*v|=(U32)p[i]<<(8*i);return 1;
}
static int aml_firmware(U32 a,unsigned n) {
 if(!n||a>0xffffffffUL-n)return 0;
 if(a>=0xe0000UL&&a+n<=0x100000UL)return 1;
 if(ebda_base&&a>=ebda_base&&a+n<=0xa0000UL)return 1;
 return ramtop&&a>=ramtop-0x100000UL;      /* top 1 MiB of RAM, and above */
}
static int aml_memw(void *g,U32 a,unsigned w,U32 v) {
 U8 *p;unsigned i,n=w/8;(void)g;
 if(!aml_firmware(a,n))return 0;
 p=(a+n<=0x100000UL)?lowmap+a:mapwin(a,n);if(!p)return 0;
 for(i=0;i<n;i++)p[i]=(U8)(v>>(8*i));return 1;
}
static int aml_ior(void *g,U32 port,unsigned w,U32 *v) {
 (void)g;if(port>0xffffUL)return 0;
 if(w==8)*v=in8((unsigned)port);else if(w==16)*v=in16((unsigned)port);
 else if(w==32)*v=in32((unsigned)port);else return 0;
 return 1;
}
static int aml_iow(void *g,U32 port,unsigned w,U32 v) {
 (void)g;if(port>0xffffUL||(port>=0xcf8UL&&port<0xd00UL))return 0;
 if(w==8)out8((unsigned)port,(unsigned)v);else if(w==16)out16((unsigned)port,(unsigned)v);
 else if(w==32)out32((unsigned)port,v);else return 0;
 return 1;
}
static int aml_cfg(unsigned b,unsigned d,unsigned f,unsigned r,unsigned w,U32 *a) {
 if(b>255||d>31||f>7||r>255||((r&3)+w/8)>4)return 0;
 *a=0x80000000UL|((U32)b<<16)|((U32)d<<11)|((U32)f<<8)|(r&0xfc);return 1;
}
static int aml_pcir(void *g,unsigned b,unsigned d,unsigned f,unsigned r,unsigned w,U32 *v) {
 U32 a,x;(void)g;if(!aml_cfg(b,d,f,r,w,&a))return 0;
 cli_();out32(0xcf8,a);x=in32(0xcfc);sti_();
 *v=(x>>(8*(r&3)))&(w==32?0xffffffffUL:((1UL<<w)-1));return 1;
}
static int aml_pciw(void *g,unsigned b,unsigned d,unsigned f,unsigned r,unsigned w,U32 v) {
 U32 a;(void)g;if(!aml_cfg(b,d,f,r,w,&a))return 0;
 cli_();out32(0xcf8,a);
 if(w==8)out8(0xcfc+(r&3),(unsigned)v);else if(w==16)out16(0xcfc+(r&2),(unsigned)v);else out32(0xcfc,v);
 sti_();return 1;
}
static void aml_stall(void *g,U32 us) {
 U32 mask=firmware.timer_bits==32?0xffffffffUL:0xffffffUL,prior,now,elapsed=0,need;unsigned guard=0;(void)g;
 if(!firmware.timer_port)return;
 need=(us*229UL)>>6;                           /* ~3.579 PM-timer ticks per us */
 prior=in32(firmware.timer_port)&mask;
 while(elapsed<need){now=in32(firmware.timer_port)&mask;
  if(now==prior){if(++guard==1000000UL)return;}
  else{elapsed+=(now-prior)&mask;prior=now;guard=0;}
 }
}
static const struct pn_aml_env amlenv={0,aml_ior,aml_iow,aml_memr,aml_memw,aml_pcir,aml_pciw,aml_stall};
static int bind_byte(struct pn_reg *r){
 if(!ramtop||r->high||r->low<ramtop)return 0;
 if(r->bytes!=1&&r->bytes!=2)return 0;
 r->native=mapwin(r->low,r->bytes);return r->native!=0;
}
static int write_mmio(const struct pn_reg *r,unsigned value){
 if(!r->native)return 0;
 if(r->bytes==2)*(volatile U16 *)r->native=(U16)value;
 else if(r->bytes==1)*(volatile U8 *)r->native=(U8)value;
 else return 0;
 return 1;
}
static int read_mmio16(const struct pn_reg *r,unsigned *v){
 if(!r->native||r->bytes!=2)return 0;
 *v=*(volatile U16 *)r->native;return 1;
}
static int prepare9(void *arg) {
 (void)arg;
 if(amlctx.loaded&&amlctx.prepare)amlctx.done=pn_aml_prepare(&amlctx.aml,&amlenv,5)?1:2;
 return amlctx.done!=2;
}
#endif
static int discover(void) {
 U8 b[36];U32 memory[32],ebda,p,found=0;int result;
 memset(memory,0,sizeof(memory));demand(memory,0);
 status[7]=memory[1];logvalue('M',status[7]);
 /* Any RAM size: tables are reached through on-demand physical windows. */
 if(status[7]<0x800||status[7]>0x100000UL)return 0;   /* 8 MiB .. 4 GiB */
 lowmap=(U8*)map(0,0x100000,0);
 if(!lowmap||(U32)lowmap==0xffffffffUL)return 0;
 if(!readphys(0,0x40e,b,2))return 0;ebda=((U32)b[0]|((U32)b[1]<<8))<<4;
 if(ebda>=0x400&&ebda<=0x9ffff)for(p=ebda;p+36<=ebda+1024&&p+36<=0x100000;p+=16){if(readphys(0,p,b,36)&&pn_rsdp(b,36)>=0){found=p;break;}}
 if(!found)for(p=0xe0000;p<=0x100000-36;p+=16){if(readphys(0,p,b,36)&&pn_rsdp(b,36)>=0){found=p;break;}}
 if(!found)return 0;
#ifdef PN_AML
 ramtop=status[7]<<12;ebda_base=ebda;
 memset(&amlctx,0,sizeof(amlctx));
 amlctx.nodes=amlnodes;amlctx.capacity=PN9_NODES;
 amlctx.arena=amlarena;amlctx.arena_size=PN9_ARENA;amlctx.env=&amlenv;
 pn_amlctx=&amlctx;
 result=pn_tables(readphys,0,found,&firmware,work,sizeof(work));
 pn_amlctx=0;
 if(result)pn_bindregs(&firmware,bind_byte);
 status[6]=firmware.off_ok|(firmware.reset_ok<<1)|(amlctx.tables?4:0)|(amlctx.prepare?8:0);
#else
 result=pn_tables(readphys,0,found,&firmware,work,sizeof(work));
 if(result)pn_bindregs(&firmware,0);
 status[6]=firmware.off_ok|(firmware.reset_ok<<1);
#endif
 if(status[2]>=0x40a)status[6]|=0x40; /* Windows completes Restart. */
 status[6]|=WP_FW_MINOR(firmware.fadt_rev,firmware.fadt_minor);
 status[4]=firmware.rsdp_rev;status[5]=firmware.fadt_rev;status[13]=firmware.timer_port;
 return result&&firmware.off_ok&&firmware.timer_port;
}
static unsigned get16(void *unused,unsigned port){(void)unused;return in16(port);}
static void put16(void *unused,unsigned port,unsigned value){(void)unused;out16(port,value);}
static void put8(void *unused,unsigned port,unsigned value){(void)unused;out8(port,value);}
static void pauseio(void *unused,unsigned ticks) {
 U32 mask=firmware.timer_bits==32?0xffffffffUL:0xffffffUL,prior=in32(firmware.timer_port)&mask;
 U32 elapsed=0,need=(U32)ticks*196875UL,now;unsigned stalled=0;(void)unused;
 while(elapsed<need){now=in32(firmware.timer_port)&mask;
  if(now==prior){if(++stalled==1000000){status[15]=1;return;}}
  else{elapsed+=(now-prior)&mask;prior=now;stalled=0;}
 }
}
#ifdef PN_AML
static const struct pn_io ports={0,get16,put16,put8,pauseio,prepare9,write_mmio,read_mmio16};
#else
static const struct pn_io ports={0,get16,put16,put8,pauseio,0,0,0};
#endif
static void final_off(void) {
 int result;if(!status[1])return;status[11]++;logvalue('O',exitcode);
 result=pn_s5off(&firmware,&ports);logvalue('F',(U32)result);
 /* An un-restored ACPI mode must not fall through into legacy APM. */
 if(result<0)halt();
}
static void final_reset(void) {if(status[1]){logvalue('R',exitcode);pn_reset(&firmware,&ports);}}  /* PC reset fallbacks */
/* Both GUI and Start-menu requests arrive through normal Windows shutdown.
   Act only when the driver owns the final transition. */
static void native_off(void){if(ownermode==1)final_off();}
static void note_windows_reset(void) {
 /* The 98/Me critical reboot notification can precede VFAT's last writes.
    Returning to the dispatcher preserves the requested Windows reset. */
 if(ownermode==1)logvalue('W',status[2]);
}
static void __stdcall control_seen(U32 code) {
 if(code==0x26&&status[2]>=0x400&&status[2]<0x40a&&status[12]&&unique_last()){
  if(ownermode==1){if(exitcode==1)final_off();else if(exitcode==0x43)final_reset();}
 }
}
static void __declspec(naked) hookbd(void) {
 _asm { mov exitcode,eax
  jmp dword ptr original
 }
}
static void __declspec(naked) hook93(void) {
 _asm { cmp eax,36h
  je poweroff
  cmp eax,18h
  je reboot
  jmp dword ptr original
 poweroff:
  call dword ptr original
  pushfd
  pushad
  call native_off
  popad
  popfd
  ret
 reboot:
  call dword ptr original
  pushfd
  pushad
  call note_windows_reset
  popad
  popfd
  ret
 }
}
/* Install the shell shutdown hook (Win95 0x100bd / Win98 0x10093). Returns
   non-zero when the hook is in place. Used in both firmware modes so the
   owner hand-off can take over a native Windows shutdown. */
static int install_hook(void) {
 U32 service;void *handler;
 status[12]=unique_last();logvalue('L',status[12]);
 if(status[2]<0x40a&&!status[12])return 0;
 pauseio(0,1);if(status[15])return 0;
 service=(status[2]<0x40a)?0x100bdUL:0x10093UL;
 handler=(status[2]<0x40a)?(void*)hookbd:(void*)hook93;
 _asm { mov eax,service
  mov esi,handler
  int 20h
  dw 90h
  dw 1
  mov original,esi
 }
 return original&&original!=(U32)handler;
}
static void initialize(void) {
 U32 v=0,apm=0;unsigned i;
 if(initialized)return;initialized=1;
 for(i=0;i<16;i++)status[i]=0;
 status[0]=10;status[4]=0xffff;status[8]=10;
 _asm { int 20h
  dw 0
  dw 1
  mov v,eax
 }
  status[2]=v&0xffff;
 /* Windows Me build 3000 reports 045Ah (4.90) through Get_VMM_Version.
    Keep eligibility narrow; the existing service and firmware checks must
    also succeed before the driver accepts ownership. */
 if(status[2]<0x400||(status[2]>0x40f&&status[2]!=0x45a))return;
 status[8]=20;
 /* ACPI mode need not expose legacy VPOWERD. It still requires a verified
    native final hook; discovering S5 alone does not establish a handoff. */
 status[9]=(getddb(0x4c)!=0)||(getddb(0x2961)!=0);
 if(status[9]){
  status[8]=35;if(!discover())return;
  pauseio(0,1);if(status[15])return;
  status[6]|=0x10;status[8]=40;
  if(!install_hook())return;
  status[6]|=0x20;status[1]=1;status[8]=60;logvalue('H',status[2]);
  return;
 }
 /* APM mode: the VMM VPOWERD device (26h) supplies the APM version and the
    shell shutdown hook is installed to drive the final power-off. */
 if(!getddb(0x26))return;
 _asm { int 20h
  dw 1
  dw 26h
  mov apm,eax
 }
 status[3]=apm;
 status[8]=30;if(!discover())return;
 status[8]=40;
 if(!install_hook())return;
 status[1]=1;status[8]=60;logvalue('A',status[2]);
}
static U32 __stdcall query(struct diop *p) {
 if(p->code==0||p->code==0xffffffffUL)return 0;
 /* Immediate power IOCTLs are intentionally unavailable. They bypass
    application cancellation and the Windows storage shutdown sequence. */
 if(p->code==2||p->code==3)return 50;
 /* Set the native-shutdown owner (0 = OS, 1 = this driver). */
 if(p->code==4){
  if(!p->in||p->insize!=sizeof(U32)||*(U32*)p->in>1)return 87;
  if(!status[1])return 50;
  ownermode=*(U32*)p->in;return 0;
 }
 /* Separate owner query preserves the existing 16-DWORD status ABI. */
 if(p->code==5){
  if(!p->out||p->outsize<sizeof(U32)||!p->returned)return 87;
  *(U32*)p->out=ownermode;*(U32*)p->returned=sizeof(U32);return 0;
 }
 if(p->code!=1)return 50;
 if(!p->out||p->outsize<sizeof(status)||!p->returned)return 87;
 status[10]=exitcode;memcpy((void*)p->out,status,sizeof(status));*(U32*)p->returned=sizeof(status);return 0;
}
void __declspec(naked) control(void) {
 _asm { pushad
  push eax
  call control_seen
  popad
  /* Win98 releases initialization pages after Init_Complete. Wait for
     Kernel32_Initialized so the bounded physical-pool check is stable. */
  cmp eax,31h
  je init
  cmp eax,1bh
  je init
  cmp eax,1ch
  je busy
  cmp eax,23h
  jne done
  push esi
  call query
  clc
  ret
 init:
  pushad
  call initialize
  popad
 done:
  clc
  ret
 busy:
  stc
  ret
 }
}
