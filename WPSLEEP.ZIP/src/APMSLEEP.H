#ifndef WP_APMSLEEP_H
#define WP_APMSLEEP_H

/* An APM real-mode client owns its connection for one cooperative request. */
struct wp_apm_result { unsigned ax, bx, cx; };
typedef int (*wp_apm_call)(unsigned, unsigned, unsigned, struct wp_apm_result *);
enum wp_apm_status { WP_RETURNED, WP_ABSENT, WP_BUSY, WP_VERSION,
                     WP_UNAVAILABLE, WP_DECLINED, WP_RESTORE };
static enum wp_apm_status wp_apm_sleep(unsigned state, wp_apm_call bios)
{
    struct wp_apm_result r;
    unsigned flags, version, try_version, device;
    unsigned enabled = 0, engaged = 0;
    enum wp_apm_status status = WP_DECLINED;
    if (state != 1 && state != 2) return WP_UNAVAILABLE;
    if (!bios(0x5300, 0, 0, &r) || r.bx != 0x504d) return WP_ABSENT;
    flags = r.cx;
    if (r.ax < 0x100 || r.ax > 0x102) return WP_VERSION;
    try_version = r.ax;
    if (!bios(0x5301, 0, 0, &r)) return WP_BUSY;
    version = 0x100;
    while (try_version > 0x100) {
        if (bios(0x530e, 0, try_version, &r)) {
            if (r.ax < 0x100 || r.ax > try_version) { status = WP_VERSION; goto finish; }
            version = r.ax;
            break;
        }
        --try_version;
    }
    device = version == 0x100 ? 0xffff : 1;
    if (version == 0x102) {
        if (!bios(0x5310, 0, 0, &r) || !(r.cx & (1u << (state - 1)))) {
            status = WP_UNAVAILABLE;
            goto finish;
        }
    }
    if (flags & 8) {
        if (!bios(0x5308, device, 1, &r)) goto finish;
        enabled = 1;
    }
    if (version >= 0x101 && (flags & 16)) {
        if (!bios(0x530f, 1, 1, &r)) goto finish;
        engaged = 1;
    }
    if (bios(0x5307, 1, state, &r)) status = WP_RETURNED;
finish:
    if (engaged && !bios(0x530f, 1, 0, &r)) status = WP_RESTORE;
    if (enabled && !bios(0x5308, device, 0, &r)) status = WP_RESTORE;
    if (!bios(0x5304, 0, 0, &r)) status = WP_RESTORE;
    return status;
}
#endif
