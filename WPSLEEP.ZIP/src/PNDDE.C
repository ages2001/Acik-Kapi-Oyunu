#include <windows.h>
#include <dde.h>
#if defined(PN_WIN1) || defined(PN_WIN2)
BOOL pn_icons(HWND owner,HINSTANCE instance,LPCSTR directory,BOOL remove){
 (void)owner;(void)instance;(void)directory;(void)remove;return FALSE;
}
#else
/* Direct Win16 DDE also works on Windows 3.0, without DDEML. */
static HWND server,client;
static ATOM app,topic;
static HGLOBAL packet;
static BOOL starting,done,accepted,terminated,blocked,answered;
static ATOM asked;
static char answer[256];
static FARPROC callback;
long FAR PASCAL __export DdeProc(HWND h,UINT m,WPARAM w,LPARAM l){
 (void)h;
 if(m==WM_DDE_ACK){
  if(starting){
   if(LOWORD(l)==app&&HIWORD(l)==topic){server=(HWND)w;GlobalDeleteAtom(LOWORD(l));GlobalDeleteAtom(HIWORD(l));}
  }else if((HWND)w==server&&asked&&(ATOM)HIWORD(l)==asked){
   /* Negative acknowledgement of a request: the shell has no such data. */
   answered=TRUE;
  }else if((HWND)w==server&&(HGLOBAL)HIWORD(l)==packet){
   accepted=(LOWORD(l)&0x8000)!=0;done=TRUE;GlobalFree(packet);packet=0;
  }
  return 0;
 }
 if(m==WM_DDE_DATA&&(HWND)w==server){
  HGLOBAL data=(HGLOBAL)LOWORD(l);ATOM item=(ATOM)HIWORD(l);DDEDATA FAR *d;BOOL release=FALSE;
  answer[0]=0;
  if(data&&(d=(DDEDATA FAR *)GlobalLock(data))!=0){
   if(d->cfFormat==CF_TEXT){unsigned i;for(i=0;i<sizeof(answer)-1&&d->Value[i];i++)answer[i]=d->Value[i];answer[i]=0;}
   release=d->fRelease;
   if(d->fAckReq)PostMessage(server,WM_DDE_ACK,(WPARAM)client,MAKELONG(0x8000,item));
   else if(item)GlobalDeleteAtom(item);
   GlobalUnlock(data);
   if(release)GlobalFree(data);
  }
  if(item==asked)answered=TRUE;
  return 0;
 }
 if(m==WM_DDE_TERMINATE){terminated=TRUE;return 0;}
 return DefWindowProc(h,m,w,l);
}
static void pump(BOOL *condition,DWORD duration){
 DWORD start=GetTickCount();MSG msg;
 while(!*condition&&(DWORD)(GetTickCount()-start)<duration){
  while(PeekMessage(&msg,client,0,0,PM_REMOVE)){TranslateMessage(&msg);DispatchMessage(&msg);}
  Yield();
 }
}
static BOOL execute(LPCSTR text){
 LPSTR p;unsigned size=lstrlen(text)+1;
 if(blocked)return FALSE;
 packet=GlobalAlloc(GMEM_MOVEABLE|GMEM_DDESHARE,size);if(!packet)return FALSE;
 p=GlobalLock(packet);if(!p){GlobalFree(packet);packet=0;return FALSE;}
 lstrcpy(p,text);GlobalUnlock(packet);done=accepted=FALSE;
 if(!PostMessage(server,WM_DDE_EXECUTE,(WPARAM)client,MAKELONG(0,packet))){GlobalFree(packet);packet=0;return FALSE;}
 pump(&done,3000);
 if(!done){blocked=TRUE;return FALSE;}
 return accepted;
}
/* Request a Program Manager group description. The first line is
   "name",path,count[,...]. Returns the item count, or -1 when unknown
   (for example when this shell version does not answer group requests). */
static int groupcount(LPCSTR group){
 char *p;int count=0,commas=0;
 if(blocked)return -1;
 asked=GlobalAddAtom(group);if(!asked)return -1;
 answered=FALSE;answer[0]=0;
 if(!PostMessage(server,WM_DDE_REQUEST,(WPARAM)client,MAKELONG(CF_TEXT,asked))){GlobalDeleteAtom(asked);asked=0;return -1;}
 pump(&answered,3000);asked=0;
 if(!answered||!answer[0])return -1;
 for(p=answer;*p&&*p!='\r'&&*p!='\n';p++){
  if(*p=='"'){p++;while(*p&&*p!='"')p++;if(!*p)return -1;continue;}
  if(*p==','){if(++commas==3)break;continue;}
  if(commas==2){if(*p<'0'||*p>'9')return -1;count=count*10+(*p-'0');if(count>999)return -1;}
 }
 return commas>=2?count:-1;
}
/* Windows 3.0 Program Manager has no DeleteItem command and does not
   answer group requests. Read its group file directly: the group may be
   deleted only when it is named WINPOWER and every item is one of the two
   items this package creates. Any other content keeps the group. */
static unsigned word(const unsigned char *p){return (unsigned)p[0]|((unsigned)p[1]<<8);}
static BOOL named(const unsigned char *b,unsigned size,unsigned at,LPCSTR text){
 unsigned i;
 for(i=0;text[i];i++)if(at+i>=size||b[at+i]!=(unsigned char)text[i])return FALSE;
 return at+i<size&&b[at+i]==0;
}
static BOOL ownedonly(void){
 static unsigned char b[4096];static char key[8],file[160];
 unsigned n,size,items,i,item;OFSTRUCT of;HFILE f;char extra;
 for(n=1;n<=40;n++){
  lstrcpy(key,"Group");if(n>=10){key[5]=(char)('0'+n/10);key[6]=(char)('0'+n%10);key[7]=0;}else{key[5]=(char)('0'+n);key[6]=0;}
  if(!GetPrivateProfileString("Groups",key,"",file,sizeof(file),"PROGMAN.INI"))continue;
  f=OpenFile(file,&of,OF_READ);if(f==HFILE_ERROR)continue;
  size=_lread(f,(LPSTR)b,sizeof(b));
  if(size==(unsigned)-1||_lread(f,(LPSTR)&extra,1)!=0){_lclose(f);continue;}
  _lclose(f);
  if(size<34||b[0]!='P'||b[1]!='M'||b[2]!='C'||b[3]!='C')continue;
  if(!named(b,size,word(b+22),"WINPOWER"))continue;
  items=word(b+32);if(34+2*items>size)return FALSE;
  for(i=0;i<items;i++){
   item=word(b+34+2*i);if(!item)continue;
   if(item+20>size)return FALSE;
   {unsigned at=word(b+item+18);
    if(!named(b,size,at,"WINPOWER")&&!named(b,size,at,"Uninstall WINPOWER")&&
       !named(b,size,at,"WINPOWER Power Center")&&!named(b,size,at,"Remove WINPOWER"))return FALSE;}
  }
  return TRUE;
 }
 return FALSE;
}
BOOL pn_icons(HWND owner,HINSTANCE instance,LPCSTR directory,BOOL remove){
 WNDCLASS c;BOOL ok=FALSE;static char text[512],exe[160];
 if(blocked)return FALSE;
 if(!callback){
  callback=MakeProcInstance((FARPROC)DdeProc,instance);
  c.style=0;c.lpfnWndProc=(WNDPROC)callback;c.cbClsExtra=c.cbWndExtra=0;c.hInstance=instance;
  c.hIcon=0;c.hCursor=0;c.hbrBackground=0;c.lpszMenuName=0;c.lpszClassName="PNDDE";
  if(!RegisterClass(&c))return FALSE;
 }
 client=CreateWindow("PNDDE","",WS_POPUP,0,0,0,0,owner,0,instance,0);if(!client)return FALSE;
 server=0;starting=TRUE;app=GlobalAddAtom("PROGMAN");topic=GlobalAddAtom("PROGMAN");
 SendMessage((HWND)0xffff,WM_DDE_INITIATE,(WPARAM)client,MAKELONG(app,topic));
 starting=FALSE;GlobalDeleteAtom(app);GlobalDeleteAtom(topic);
 if(!server){DestroyWindow(client);return FALSE;}
 if(remove&&LOWORD(GetVersion())==0x0003){
  /* Windows 3.0: DeleteItem is not a Program Manager command. */
  if(ownedonly())ok=execute("[DeleteGroup(WINPOWER)]");
 }else if(remove){
  if(execute("[ShowGroup(WINPOWER,1)]")){
   BOOL a=execute("[DeleteItem(WINPOWER)]");
   BOOL b=execute("[DeleteItem(Uninstall WINPOWER)]");ok=a&&b;
   /* Items from earlier releases used longer titles. */
   if(!ok&&execute("[DeleteItem(WINPOWER Power Center)]")&&execute("[DeleteItem(Remove WINPOWER)]"))ok=TRUE;
   /* Remove the group only when the shell confirms that it is now empty;
      a group that holds user-added items, or an unknown count, is kept. */
   if(ok&&groupcount("WINPOWER")==0)execute("[DeleteGroup(WINPOWER)]");
  }
 }else if(execute("[CreateGroup(WINPOWER)]")){
  execute("[DeleteItem(WINPOWER)]");
  lstrcpy(exe,directory);lstrcat(exe,"\\WINPWR16.EXE");
  lstrcpy(text,"[AddItem(\"");lstrcat(text,exe);lstrcat(text,"\",\"WINPOWER\",\"");lstrcat(text,exe);lstrcat(text,"\",0,16,8)]");
  if(execute(text)){
   execute("[DeleteItem(Uninstall WINPOWER)]");
   lstrcpy(exe,directory);lstrcat(exe,"\\UNINST.EXE");
   lstrcpy(text,"[AddItem(\"");lstrcat(text,exe);lstrcat(text,"\",\"Uninstall WINPOWER\",\"");lstrcat(text,exe);lstrcat(text,"\",1,120,8)]");ok=execute(text);
  }
 }
 terminated=FALSE;PostMessage(server,WM_DDE_TERMINATE,(WPARAM)client,0);pump(&terminated,1000);
 /* An unacknowledged execute block may still be read by the server.
    Keep that one block alive on timeout; do not repeat further requests. */
 DestroyWindow(client);client=0;SetActiveWindow(owner);return ok;
}
#endif
