/* Program Manager item ownership for the persistent NT3 package. */
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <ddeml.h>
#include "NTDDE.H"
#include "NTITEM.H"
static char group_data[32768];
static unsigned group_notice;
#ifdef PNNT_PACKAGE
static const char *setup_ini;
static BOOL tools_group;
void nt_group_ini(const char *path){setup_ini=path;}
#endif
unsigned nt_groupnotice(void){return group_notice;}
static HDDEDATA CALLBACK callback(UINT a,UINT b,HCONV c,HSZ d,HSZ e,HDDEDATA f,ULONG_PTR g,ULONG_PTR h){(void)a;(void)b;(void)c;(void)d;(void)e;(void)f;(void)g;(void)h;return 0;}
static int query(DWORD id,HCONV conv,HSZ item){
 HDDEDATA data;DWORD size,got,reply,i;UINT error;
 data=DdeClientTransaction(0,0,conv,item,CF_TEXT,XTYP_REQUEST,10000,&reply);
 if(!data){error=DdeGetLastError(id);return error==DMLERR_NOTPROCESSED?0:-1;}
 size=DdeGetData(data,0,0,0);
 if(!size||size>sizeof(group_data)){DdeFreeDataHandle(data);return -1;}
 got=DdeGetData(data,(BYTE*)group_data,size,0);DdeFreeDataHandle(data);
 /* Old Program Manager can include allocation padding after the first
    NUL. Bound the terminator search to the bytes actually returned. */
 if(got!=size)return -1;
 for(i=0;i<size;i++)if(!group_data[i])return 1;
 return -1;
}
static BOOL execute(HCONV conv,const char *command){
 DWORD reply;return DdeClientTransaction((BYTE*)command,lstrlenA(command)+1,conv,0,0,XTYP_EXECUTE,10000,&reply)!=0;
}
/* After choosing an unoccupied group, use that exact group on removal.
   Only the group argument changes; both installed item titles stay fixed. */
#ifdef PNNT_PACKAGE
static BOOL group_command(HCONV conv,const char *command){
 char buf[128];const char *slot;
 if(!tools_group)return execute(conv,command);
 slot=command;while(*slot&&*slot!='(')slot++;
 if(*slot!='('||(unsigned)lstrlenA(command)>=sizeof(buf)-8)return FALSE;
 CopyMemory(buf,command,(SIZE_T)(slot-command)+1);buf[(slot-command)+1]=0;
 lstrcatA(buf,"WINPOWER Tools");lstrcatA(buf,slot+1+8);
 return execute(conv,buf);
}
#else
#define group_command execute
#endif
static BOOL clean_group(DWORD id,HCONV conv,HSZ item,const char *app,const char *uninst){
 int present;struct nt_itemstat state;
 present=query(id,conv,item);if(present<0)return FALSE;if(!present)return TRUE;
 ni_scan(group_data,app,uninst,&state);group_notice|=state.preserved;
 if((state.owned&1)&&!group_command(conv,"[ShowGroup(WINPOWER,1)][DeleteItem(WINPOWER)]"))return FALSE;
 /* Request fresh data before the second deletion. Preserve a command
    changed while processing the first item. */
 present=query(id,conv,item);if(present<0)return FALSE;if(!present)return TRUE;
 ni_scan(group_data,app,uninst,&state);group_notice|=state.preserved;
 if((state.owned&2)&&!group_command(conv,"[ShowGroup(WINPOWER,1)][DeleteItem(Uninstall WINPOWER)]"))return FALSE;
 present=query(id,conv,item);if(present<0)return FALSE;if(!present)return TRUE;
 ni_scan(group_data,app,uninst,&state);group_notice|=state.preserved;
 if(!state.count)return group_command(conv,"[DeleteGroup(WINPOWER)]");
 return state.owned==0; /* Additional and changed items keep their group. */
}
BOOL nt_group(BOOL remove,const char *app,const char *uninst){
 DWORD id=0;HSZ name=0,item=0;HCONV conv=0;BOOL ok=FALSE;int present;char command[900];DWORD error=ERROR_GEN_FAILURE;
 if(DdeInitializeA(&id,callback,APPCMD_CLIENTONLY,0)!=DMLERR_NO_ERROR)return FALSE;
 name=DdeCreateStringHandleA(id,"PROGMAN",CP_WINANSI);item=DdeCreateStringHandleA(id,"WINPOWER",CP_WINANSI);
 conv=DdeConnect(id,name,name,0);if(!conv)goto done;
#ifdef PNNT_PACKAGE
 if(!setup_ini)goto done;
 tools_group=remove && GetPrivateProfileIntA("Setup","ToolsGroup",0,setup_ini)==1;
 if(tools_group){
  DdeFreeStringHandle(id,item);item=DdeCreateStringHandleA(id,"WINPOWER Tools",CP_WINANSI);
  if(!item)goto done;
 }
#endif
 present=query(id,conv,item);if(present<0)goto done;
 if(!remove){
#ifdef PNNT_PACKAGE
  if(present){
   DdeFreeStringHandle(id,item);item=DdeCreateStringHandleA(id,"WINPOWER Tools",CP_WINANSI);
   if(!item)goto done;
   present=query(id,conv,item);if(present<0)goto done;
   tools_group=TRUE;
  }
  if(!WritePrivateProfileStringA("Setup","ToolsGroup",tools_group?"1":"0",setup_ini))goto done;
#endif
  if(present){error=ERROR_ALREADY_EXISTS;goto done;}
  if(!group_command(conv,"[CreateGroup(WINPOWER)]"))goto done;
  wsprintfA(command,"[AddItem(%s,WINPOWER,%s,0)][AddItem(%s,Uninstall WINPOWER,%s,1)]",app,app,uninst,uninst);
  ok=execute(conv,command);
  if(!ok)clean_group(id,conv,item,app,uninst);
 }else {
  if(!present){ok=TRUE;goto done;}
  ok=clean_group(id,conv,item,app,uninst);
 }
 done:
 if(conv)DdeDisconnect(conv);if(item)DdeFreeStringHandle(id,item);if(name)DdeFreeStringHandle(id,name);DdeUninitialize(id);
 if(!ok)SetLastError(error);return ok;
}
int nt_group_status(unsigned *owned,unsigned *other){
 DWORD id=0,size;HSZ name=0,item=0;HCONV conv=0;int result=-1;struct nt_itemstat state;char windir[MAX_PATH],app[MAX_PATH],uninst[MAX_PATH],ini[MAX_PATH];
 *owned=*other=0;
 size=GetWindowsDirectoryA(windir,sizeof(windir));if(size<3||size>=sizeof(windir)||windir[1]!=':')return -1;
 wsprintfA(app,"%c:\\WINPWRNT\\WINPWRNT.EXE",windir[0]);wsprintfA(uninst,"%c:\\WINPWRNT\\UNINST.EXE",windir[0]);
 if(DdeInitializeA(&id,callback,APPCMD_CLIENTONLY,0)!=DMLERR_NO_ERROR)return -1;
 wsprintfA(ini,"%c:\\WINPWRNT\\WINPOWER.INI",windir[0]);
 name=DdeCreateStringHandleA(id,"PROGMAN",CP_WINANSI);
 item=DdeCreateStringHandleA(id,GetPrivateProfileIntA("Setup","ToolsGroup",0,ini)==1?"WINPOWER Tools":"WINPOWER",CP_WINANSI);
 conv=DdeConnect(id,name,name,0);
 if(conv){result=query(id,conv,item);if(result==1){ni_scan(group_data,app,uninst,&state);*owned=(state.owned&1?1:0)+(state.owned&2?1:0);*other=state.count>=*owned?state.count-*owned:state.count;}DdeDisconnect(conv);}
 if(item)DdeFreeStringHandle(id,item);if(name)DdeFreeStringHandle(id,name);DdeUninitialize(id);return result;
}
