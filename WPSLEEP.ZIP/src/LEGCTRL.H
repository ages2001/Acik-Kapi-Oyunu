#ifndef WP_LEGCTRL_H
#define WP_LEGCTRL_H
/* NT3 and NT4. The native final callback only consumes the latched owner.
   Neither the query nor the setter performs a hardware operation. */
/* These documented stdcall exports exist from NT 3.1 onward. New DDK
   headers otherwise substitute fastcall names absent from the NT 3.1 HAL. */
#undef KeAcquireSpinLock
#undef KeReleaseSpinLock
__declspec(dllimport) VOID NTAPI KeAcquireSpinLock(PKSPIN_LOCK,PKIRQL);
__declspec(dllimport) VOID NTAPI KeReleaseSpinLock(PKSPIN_LOCK,KIRQL);
#define WP_LEG_QUERY 0x00226014UL
#define WP_LEG_SET   0x0022600cUL
static KSPIN_LOCK leg_lock;
static volatile ULONG leg_owner, leg_at_shutdown;
static BOOLEAN leg_closing;
static void leg_latch(void) {
 KIRQL irql;
 KeAcquireSpinLock(&leg_lock,&irql);
 leg_at_shutdown=leg_owner;leg_closing=TRUE;
 KeReleaseSpinLock(&leg_lock,irql);
}
static NTSTATUS leg_control(ULONG code, PVOID buffer, ULONG inlen, ULONG outlen, ULONG *written) {
 KIRQL irql;NTSTATUS result=STATUS_SUCCESS;
 *written=0;
 if(code==WP_LEG_QUERY){
  if(!buffer||outlen<sizeof(ULONG))return STATUS_BUFFER_TOO_SMALL;
 }else if(code==WP_LEG_SET){
  if(!buffer||inlen!=sizeof(ULONG)||*(ULONG*)buffer>1)return STATUS_INVALID_PARAMETER;
 }else return STATUS_INVALID_DEVICE_REQUEST;
 KeAcquireSpinLock(&leg_lock,&irql);
 if(code==WP_LEG_QUERY){*(ULONG*)buffer=0x100UL|leg_owner;*written=sizeof(ULONG);}
 else if(leg_closing)result=STATUS_SHUTDOWN_IN_PROGRESS;
 else leg_owner=*(ULONG*)buffer;
 KeReleaseSpinLock(&leg_lock,irql);
 return result;
}
#endif
