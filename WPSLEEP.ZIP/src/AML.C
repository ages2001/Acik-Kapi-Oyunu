/* WINPOWER bounded AML interpreter. See AML.H for scope and policy.
   Two modes share one parser: EXEC performs the operations; VERIFY walks
   every reachable path once without hardware access and fails on any
   construct that EXEC could not perform. */
#include "AML.H"

#define MAXDEPTH 16
#define MAXSTEPS 200000UL
#define MAXSEG 16
#define CTL_NONE 0
#define CTL_RETURN 1
#define CTL_BREAK 2
#define CTL_CONTINUE 3
#define F_VERIFIED 0x80
#define F_VERIFYING 0x40
#define F_CACHED 0x20     /* Region offset/length evaluated */
#define F_SERIAL 0x08

struct path {unsigned char root,up,count;char seg[MAXSEG][4];};
struct frame {
 struct pn_aml_obj arg[7],local[8],result;
 unsigned scope,ctl,argc;
};
struct exec {
 struct pn_aml *a;const struct pn_aml_env *env;
 int verify,readonly,loading;unsigned depth,nest;pn_u32 steps;
};

static void zero(void *p,unsigned n){unsigned char *c=(unsigned char *)p;while(n--)*c++=0;}
/* Records the first failing opcode; runtime failures do not poison the
   loaded namespace, but a failure while loading does (see pn_aml_load). */
static int fail(struct exec *x,unsigned op,unsigned t,pn_u32 at){
 if(!x->a->last_op){x->a->last_op=op?op:0xffff;x->a->last_at=at;x->a->last_table=t;}
 return 0;
}
static int byte(struct exec *x,unsigned t,pn_u32 at,pn_u32 end,unsigned *v){
 if(at>=end||at>=x->a->size[t])return 0;*v=x->a->aml[t][at];return 1;
}
static int pkglen(struct exec *x,unsigned t,pn_u32 *at,pn_u32 end,pn_u32 *stop){
 pn_u32 start=*at,v;unsigned b0,n,k,c;
 if(!byte(x,t,*at,end,&b0))return 0;
 (*at)++;n=b0>>6;v=n?(b0&15):(b0&63);
 if(n&&(b0&0x30))return 0;
 for(k=0;k<n;k++){if(!byte(x,t,*at,end,&c))return 0;(*at)++;v|=(pn_u32)c<<(4+8*k);}
 if(v<*at-start||v>end-start)return 0;
 *stop=start+v;return 1;
}
static int leadchar(unsigned c){return c=='_'||(c>='A'&&c<='Z');}
static int namechar(unsigned c){return leadchar(c)||(c>='0'&&c<='9');}
static int namestring(struct exec *x,unsigned t,pn_u32 *at,pn_u32 end,struct path *p){
 unsigned c,i,j,n=1;
 p->root=0;p->up=0;p->count=0;
 if(!byte(x,t,*at,end,&c))return 0;
 if(c=='\\'){p->root=1;(*at)++;}
 else while(c=='^'){if(++p->up>32)return 0;(*at)++;if(!byte(x,t,*at,end,&c))return 0;}
 if(!byte(x,t,*at,end,&c))return 0;
 if(c==0){(*at)++;return 1;}
 if(c==0x2e){n=2;(*at)++;}
 else if(c==0x2f){(*at)++;if(!byte(x,t,*at,end,&n))return 0;(*at)++;if(!n||n>MAXSEG)return 0;}
 else if(!leadchar(c))return 0;
 for(i=0;i<n;i++)for(j=0;j<4;j++){
  if(!byte(x,t,*at,end,&c)||!(j?namechar(c):leadchar(c)))return 0;
  p->seg[i][j]=(char)c;(*at)++;
 }
 p->count=(unsigned char)n;return 1;
}
static int isname(struct exec *x,unsigned t,pn_u32 at,pn_u32 end){
 unsigned c;if(!byte(x,t,at,end,&c))return 0;
 return c=='\\'||c=='^'||c==0x2e||c==0x2f||leadchar(c);
}
static int same4(const char *a,const char *b){return a[0]==b[0]&&a[1]==b[1]&&a[2]==b[2]&&a[3]==b[3];}
static unsigned child(struct pn_aml *a,unsigned parent,const char *nm){
 unsigned i;
 for(i=1;i<a->nodes;i++)if(a->node[i].type!=PN_NODE_FREE&&a->node[i].parent==parent&&same4(a->node[i].name,nm))return i;
 return 0;
}
static unsigned alias(struct pn_aml *a,unsigned n){
 unsigned k=0;while(n&&a->node[n].type==PN_NODE_ALIAS&&k++<8)n=a->node[n].link;
 return (n&&a->node[n].type==PN_NODE_ALIAS)?0:n;
}
/* ACPI name resolution: single relative segments search toward the root. */
static unsigned lookup(struct pn_aml *a,unsigned scope,const struct path *p){
 unsigned base=p->root?0:scope,i,n;
 if(!p->count)return p->root?0:0xffffu;
 for(i=0;i<p->up;i++){if(!base)return 0;base=a->node[base].parent;}
 if(!p->root&&!p->up&&p->count==1){
  for(;;){n=child(a,base,p->seg[0]);if(n)return alias(a,n);if(!base)return 0;base=a->node[base].parent;}
 }
 n=base;
 for(i=0;i<p->count;i++){n=child(a,n,p->seg[i]);if(!n)return 0;if(i+1<p->count)n=alias(a,n);}
 return alias(a,n);
}
static unsigned create(struct pn_aml *a,unsigned scope,const struct path *p,unsigned type,unsigned t){
 unsigned base=p->root?0:scope,i,n;
 if(!p->count)return 0;
 for(i=0;i<p->up;i++){if(!base)return 0;base=a->node[base].parent;}
 for(i=0;i+1<p->count;i++){base=alias(a,child(a,base,p->seg[i]));if(!base)return 0;}
 n=child(a,base,p->seg[p->count-1]);
 if(n){
  /* Scope-like redefinition (Device after External, repeated Scope) reuses. */
  if(a->node[n].type==PN_NODE_EXTERNAL||(type==PN_NODE_SCOPE&&a->node[n].type==PN_NODE_SCOPE)){a->node[n].type=(unsigned char)type;return n;}
  return 0;
 }
 if(a->nodes>=a->capacity)return 0;
 n=a->nodes++;zero(&a->node[n],sizeof(a->node[n]));
 for(i=0;i<4;i++)a->node[n].name[i]=p->seg[p->count-1][i];
 a->node[n].parent=(unsigned short)base;a->node[n].type=(unsigned char)type;a->node[n].table=(unsigned char)t;
 return n;
}
static void setint(struct pn_aml_obj *o,pn_u32 v){zero(o,sizeof(*o));o->type=PN_OBJ_INT;o->value=v;}
static void unknown(struct pn_aml_obj *o){zero(o,sizeof(*o));o->type=PN_OBJ_UNKNOWN;}

static int term(struct exec *x,struct frame *f,unsigned t,pn_u32 *at,pn_u32 end,struct pn_aml_obj *out);
static int termlist(struct exec *x,struct frame *f,unsigned t,pn_u32 at,pn_u32 end);
static int termlist2(struct exec *x,struct frame *f,unsigned t,pn_u32 at,pn_u32 end);
static int readnode(struct exec *x,unsigned n,struct pn_aml_obj *out);
static int writenode(struct exec *x,unsigned n,const struct pn_aml_obj *v);
static int call(struct exec *x,unsigned n,struct pn_aml_obj *args,unsigned argc,struct pn_aml_obj *out);

static int toint(struct exec *x,const struct pn_aml_obj *o,pn_u32 *v){
 const unsigned char *p;pn_u32 i;
 *v=0;
 switch(o->type){
 case PN_OBJ_INT:*v=o->value;return 1;
 case PN_OBJ_UNKNOWN:return x->verify;
 case PN_OBJ_BUFFER:
  p=x->a->aml[o->table]+o->value;
  for(i=0;i<4&&i<o->length&&i<(pn_u32)o->count;i++)*v|=(pn_u32)p[i]<<(8*i);
  return 1;
 case PN_OBJ_STRING:{
  /* Implicit string conversion is hexadecimal. */
  pn_u32 n=0;p=x->a->aml[o->table]+o->value;
  for(i=0;i<o->length;i++){
   unsigned c=p[i],d;
   if(c>='0'&&c<='9')d=c-'0';else if(c>='a'&&c<='f')d=c-'a'+10;else if(c>='A'&&c<='F')d=c-'A'+10;else break;
   if(n>0x0fffffffUL)return 0;n=n*16+d;
  }
  *v=n;return 1;
 }
 }
 return 0;
}
/* Integer constants, including 64-bit values whose upper half is zero or
   all ones (Ones in revision 2 tables); any other wide value fails. */
static int constant(struct exec *x,unsigned t,pn_u32 *at,pn_u32 end,unsigned op,pn_u32 *v){
 unsigned n,i,c,hi=0;
 n=op==0x0a?1:op==0x0b?2:op==0x0c?4:8;
 *v=0;
 for(i=0;i<n;i++){
  if(!byte(x,t,*at,end,&c))return 0;(*at)++;
  if(i<4)*v|=(pn_u32)c<<(8*i);
  else{if(i==4)hi=c;if(c!=hi||(c!=0&&c!=0xff))return 0;}
 }
 if(n==8&&hi==0xff&&*v!=0xffffffffUL)return 0;
 return 1;
}
/* Data objects inside packages: skip one element. */
static int element(struct exec *x,unsigned t,pn_u32 *at,pn_u32 end){
 unsigned op;pn_u32 v,stop;struct path p;
 if(!byte(x,t,*at,end,&op))return 0;
 if(op==0||op==1||op==0xff){(*at)++;return 1;}
 if(op==0x0a||op==0x0b||op==0x0c||op==0x0e){(*at)++;return constant(x,t,at,end,op,&v);}
 if(op==0x0d){(*at)++;while(byte(x,t,*at,end,&op)){(*at)++;if(!op)return 1;}return 0;}
 if(op==0x11||op==0x12||op==0x13){(*at)++;if(!pkglen(x,t,at,end,&stop))return 0;*at=stop;return 1;}
 if(op==0x5b){unsigned e;if(!byte(x,t,*at+1,end,&e)||e!=0x30)return 0;*at+=2;return 1;}
 return namestring(x,t,at,end,&p);
}
static int pkgelement(struct exec *x,const struct pn_aml_obj *pkg,unsigned index,struct pn_aml_obj *out){
 pn_u32 at=pkg->value;unsigned i,t=pkg->table;struct frame f;
 if(index>=pkg->count)return 0;
 for(i=0;i<index;i++){
  if(at>=pkg->length){setint(out,0);return 1;} /* Uninitialized element */
  if(!element(x,t,&at,pkg->length))return 0;
 }
 if(at>=pkg->length){setint(out,0);return 1;}
 zero(&f,sizeof(f));f.scope=pkg->node;
 {
  /* Package name elements are references; evaluate them in the
     package's defining scope without calling methods. */
  if(isname(x,t,at,pkg->length)){
   struct path p;unsigned n;if(!namestring(x,t,&at,pkg->length,&p))return 0;
   n=lookup(x->a,pkg->node,&p);if(!n||n==0xffffu)return x->verify?(unknown(out),1):0;
   if(x->a->node[n].type==PN_NODE_METHOD){zero(out,sizeof(*out));out->type=PN_OBJ_REF;out->node=(unsigned short)n;return 1;}
   return readnode(x,n,out);
  }
 }
 return term(x,&f,t,&at,pkg->length,out);
}
static int region_base(struct exec *x,unsigned r){
 struct pn_aml_node *n=&x->a->node[r];struct frame f;struct pn_aml_obj o;pn_u32 at,off,len;
 if(n->flags&F_CACHED)return 1;
 if(x->verify)return 1;
 zero(&f,sizeof(f));f.scope=n->parent;at=n->start;
 {int ro=x->readonly;x->readonly=1;
  if(!term(x,&f,n->table,&at,n->end,&o)||!toint(x,&o,&off)){x->readonly=ro;return 0;}
  if(!term(x,&f,n->table,&at,n->end,&o)||!toint(x,&o,&len)){x->readonly=ro;return 0;}
  x->readonly=ro;}
 n->bit=off;n->bits=len;n->flags|=F_CACHED;return 1;
}
/* PCI address of a region: _ADR of its device, bus from _BBN of the root
   bridge and secondary bus numbers of intermediate bridges. */
static int pciaddr(struct exec *x,unsigned r,unsigned *bus,unsigned *dev,unsigned *fn){
 unsigned chain[12],k=0,i,n=x->a->node[r].parent,sb;struct pn_aml_obj o;pn_u32 v;static const char adr[4]={'_','A','D','R'},bbn[4]={'_','B','B','N'};
 sb=child(x->a,0,"_SB_");
 while(n&&x->a->node[n].parent!=sb&&n!=sb){if(k>=12)return 0;chain[k++]=n;n=x->a->node[n].parent;}
 if(!n||n==sb)return 0;
 *bus=0;i=child(x->a,n,bbn);
 if(i){if(!readnode(x,i,&o)||!toint(x,&o,&v)||v>255)return 0;*bus=(unsigned)v;}
 if(!k){i=child(x->a,n,adr);v=0;if(i&&(!readnode(x,i,&o)||!toint(x,&o,&v)))return 0;*dev=(unsigned)(v>>16)&31;*fn=(unsigned)v&7;return 1;}
 while(k--){
  i=child(x->a,chain[k],adr);if(!i||!readnode(x,i,&o)||!toint(x,&o,&v))return 0;
  *dev=(unsigned)(v>>16)&31;*fn=(unsigned)v&7;
  if(k){
   pn_u32 sec;
   if(!x->env->pci_read||!x->env->pci_read(x->env->arg,*bus,*dev,*fn,0x19,8,&sec))return 0;
   *bus=(unsigned)sec&255;
  }
 }
 return 1;
}
static int access(struct exec *x,unsigned r,pn_u32 offset,unsigned width,pn_u32 *value,int write){
 struct pn_aml_node *n=&x->a->node[r];const struct pn_aml_env *e=x->env;
 if(n->type!=PN_NODE_REGION)return 0;
 if(x->verify){
  if(n->space>2)return 0;
  *value=0;return 1;
 }
 /* Namespace loading and table-only callers have no hardware interface. */
 if(!e||(write&&x->readonly))return 0;
 if(!region_base(x,r))return 0;
 if(offset+width/8>n->bits)return 0;
 switch(n->space){
 case 0:if(n->bit>0xffffffffUL-offset)return 0;
  return write?(e->mem_write&&e->mem_write(e->arg,n->bit+offset,width,*value)):(e->mem_read&&e->mem_read(e->arg,n->bit+offset,width,value));
 case 1:if(n->bit+offset>0xffffUL)return 0;
  return write?(e->io_write&&e->io_write(e->arg,n->bit+offset,width,*value)):(e->io_read&&e->io_read(e->arg,n->bit+offset,width,value));
 case 2:{unsigned bus=0,dev=0,fn=0;pn_u32 reg=n->bit+offset;
  if(reg>255||!pciaddr(x,r,&bus,&dev,&fn))return 0;
  return write?(e->pci_write&&e->pci_write(e->arg,bus,dev,fn,(unsigned)reg,width,*value)):(e->pci_read&&e->pci_read(e->arg,bus,dev,fn,(unsigned)reg,width,value));}
 }
 return 0;
}
static unsigned accwidth(unsigned flags){
 switch(flags&15){case 0:case 1:case 5:return 8;case 2:return 16;case 3:return 32;}
 return 0;
}
static pn_u32 mask(unsigned bits){return bits>=32?0xffffffffUL:(((pn_u32)1<<bits)-1);}
/* Read or write a field through its region; bit fields up to 32 bits. */
static int fieldio(struct exec *x,unsigned fnode,pn_u32 *value,int write){
 struct pn_aml_node *f=&x->a->node[fnode];unsigned w=accwidth(f->space),r;pn_u32 bit,done=0,result=0;
 if(!w||f->bits>32||!f->bits)return 0;
 if(f->type==PN_NODE_INDEXFLD){
  /* Write the byte index to the index field, then use the data field. */
  pn_u32 base=(f->bit/w)*(w/8),v;unsigned idx=f->link,dat=f->link2;
  if(!idx||!dat)return 0;
  if((f->bit%w)+f->bits>w)return 0;
  v=base;if(!fieldio(x,idx,&v,1))return 0;
  if(!fieldio(x,dat,&v,0))return 0;
  if(!write){*value=(v>>(f->bit%w))&mask((unsigned)f->bits);return 1;}
  {pn_u32 m=mask((unsigned)f->bits)<<(f->bit%w),cur;unsigned rule=(f->space>>5)&3;
   cur=rule==1?0xffffffffUL:(rule==2?0:v);cur=(cur&~m)|((*value<<(f->bit%w))&m);
   v=base;if(!fieldio(x,idx,&v,1))return 0;return fieldio(x,dat,&cur,1);}
 }
 if(f->type==PN_NODE_BANKFLD){
  pn_u32 b=f->bank;if(!f->link2||!fieldio(x,f->link2,&b,1))return 0;
 }
 r=f->link;if(!r)return 0;
 if(write&&x->readonly&&!x->verify)return 0;
 for(bit=f->bit;done<f->bits;){
  pn_u32 unit=(bit/w)*(w/8),shift=bit%w,take=w-shift,cur=0;
  if(take>f->bits-done)take=f->bits-done;
  if(!write){
   if(!access(x,r,unit,w,&cur,0))return 0;
   result|=((cur>>shift)&mask((unsigned)take))<<done;
  }else{
   unsigned rule=(f->space>>5)&3;pn_u32 m=mask((unsigned)take)<<shift;
   if(take==w)cur=0;
   else if(rule==1)cur=0xffffffffUL&mask(w);
   else if(rule==2)cur=0;
   else if(!access(x,r,unit,w,&cur,0))return 0;
   cur=(cur&~m)|(((*value>>done)<<shift)&m);
   if(!access(x,r,unit,w,&cur,1))return 0;
  }
  done+=take;bit+=take;
 }
 if(!write)*value=result;
 return 1;
}
static int readnode(struct exec *x,unsigned n,struct pn_aml_obj *out){
 struct pn_aml_node *d;
 n=alias(x->a,n);if(!n)return 0;d=&x->a->node[n];
 switch(d->type){
 case PN_NODE_NAME:*out=d->value;return 1;
 case PN_NODE_FIELD:case PN_NODE_INDEXFLD:case PN_NODE_BANKFLD:{
  pn_u32 v=0;if(!fieldio(x,n,&v,0))return 0;
  if(x->verify)unknown(out);else setint(out,v);return 1;}
 case PN_NODE_METHOD:return call(x,n,0,0,out);
 case PN_NODE_SCOPE:case PN_NODE_REGION:case PN_NODE_MUTEX:case PN_NODE_EVENT:
  zero(out,sizeof(*out));out->type=PN_OBJ_REF;out->node=(unsigned short)n;return 1;
 }
 return 0;
}
static int writenode(struct exec *x,unsigned n,const struct pn_aml_obj *v){
 struct pn_aml_node *d;pn_u32 i;
 n=alias(x->a,n);if(!n)return 0;d=&x->a->node[n];
 switch(d->type){
 case PN_NODE_NAME:
  if(x->verify)return 1;
  if(x->readonly)return 0;
  /* Integer-typed names keep integer semantics; others take the object. */
  if(d->value.type==PN_OBJ_INT){if(!toint(x,v,&i))return 0;setint(&d->value,i);}
  else d->value=*v;
  return 1;
 case PN_NODE_FIELD:case PN_NODE_INDEXFLD:case PN_NODE_BANKFLD:
  if(!toint(x,v,&i))return 0;
  return fieldio(x,n,&i,1);
 }
 return 0;
}
/* Store/target references. */
struct ref {unsigned kind,index,node;struct pn_aml_obj obj;};
#define R_NONE 0
#define R_LOCAL 1
#define R_ARG 2
#define R_NODE 3
#define R_DEBUG 4
#define R_INDEX 5
static int target(struct exec *x,struct frame *f,unsigned t,pn_u32 *at,pn_u32 end,struct ref *r){
 unsigned op,e;struct path p;
 zero(r,sizeof(*r));
 if(!byte(x,t,*at,end,&op))return 0;
 if(op==0){(*at)++;return 1;}
 if(op>=0x60&&op<=0x67){(*at)++;r->kind=R_LOCAL;r->index=op-0x60;return 1;}
 if(op>=0x68&&op<=0x6e){(*at)++;r->kind=R_ARG;r->index=op-0x68;return 1;}
 if(op==0x5b){if(!byte(x,t,*at+1,end,&e)||e!=0x31)return 0;*at+=2;r->kind=R_DEBUG;return 1;}
 if(op==0x88||op==0x83){
  /* Index(...) or DerefOf(...) as a target. */
  struct pn_aml_obj o;if(!term(x,f,t,at,end,&o))return 0;
  if(o.type==PN_OBJ_UNKNOWN&&x->verify){r->kind=R_DEBUG;return 1;}
  if(o.type==PN_OBJ_REF){r->kind=R_NODE;r->node=o.node;return 1;}
  if(o.type==PN_OBJ_INDEX){r->kind=R_INDEX;r->obj=o;return 1;}
  return 0;
 }
 if(!isname(x,t,*at,end))return 0;
 if(!namestring(x,t,at,end,&p))return 0;
 r->node=lookup(x->a,f->scope,&p);
 if(!r->node||r->node==0xffffu){if(x->verify)return 0;return 0;}
 r->kind=R_NODE;return 1;
}
static int store(struct exec *x,struct frame *f,const struct ref *r,const struct pn_aml_obj *v){
 switch(r->kind){
 case R_NONE:case R_DEBUG:return 1;
 case R_LOCAL:f->local[r->index]=*v;return 1;
 case R_ARG:
  if(f->arg[r->index].type==PN_OBJ_REF)return writenode(x,f->arg[r->index].node,v);
  f->arg[r->index]=*v;return 1;
 case R_NODE:return writenode(x,r->node,v);
 case R_INDEX:return x->verify; /* Package element writes are unsupported. */
 }
 return 0;
}
static int intarg(struct exec *x,struct frame *f,unsigned t,pn_u32 *at,pn_u32 end,pn_u32 *v){
 struct pn_aml_obj o;
 if(!term(x,f,t,at,end,&o))return 0;
 if(o.type==PN_OBJ_UNKNOWN){*v=0;return x->verify;}
 return toint(x,&o,v);
}
static int bincalc(unsigned op,pn_u32 a,pn_u32 b,pn_u32 *r){
 switch(op){
 case 0x72:*r=a+b;return 1;
 case 0x74:*r=a-b;return 1;
 case 0x77:*r=a*b;return 1;
 case 0x79:*r=b>=32?0:a<<b;return 1;
 case 0x7a:*r=b>=32?0:a>>b;return 1;
 case 0x7b:*r=a&b;return 1;
 case 0x7c:*r=~(a&b);return 1;
 case 0x7d:*r=a|b;return 1;
 case 0x7e:*r=~(a|b);return 1;
 case 0x7f:*r=a^b;return 1;
 case 0x85:if(!b)return 0;*r=a%b;return 1;
 }
 return 0;
}
static int call(struct exec *x,unsigned n,struct pn_aml_obj *args,unsigned argc,struct pn_aml_obj *out){
 struct pn_aml_node *m=&x->a->node[n];struct frame f;unsigned i,saved;int ok;
 if(m->type==PN_NODE_BUILTIN){
  /* \_OSI: WINPOWER is not the operating system; answer no interface. */
  if(x->verify){unknown(out);return 1;}
  if(argc!=1||args[0].type!=PN_OBJ_STRING)return 0;
  setint(out,0);return 1;
 }
 if(m->type!=PN_NODE_METHOD||argc!=(unsigned)(m->flags&7))return 0;
 if(x->verify){
  unknown(out);
  if(m->flags&(F_VERIFIED|F_VERIFYING))return 1;
 }
 if(x->depth>=MAXDEPTH)return 0;
 zero(&f,sizeof(f));f.scope=n;f.argc=argc;
 for(i=0;i<argc;i++)f.arg[i]=args[i];
 if(x->verify)for(i=0;i<7;i++)if(i>=argc)unknown(&f.arg[i]);
 if(x->verify)for(i=0;i<8;i++)unknown(&f.local[i]);
 setint(&f.result,0);
 saved=x->a->nodes;x->depth++;
 if(x->verify)m->flags|=F_VERIFYING;
 ok=termlist(x,&f,m->table,m->start,m->end);
 x->depth--;
 if(x->verify){x->a->node[n].flags&=(unsigned char)~F_VERIFYING;if(ok)x->a->node[n].flags|=F_VERIFIED;}
 /* Objects created by Name inside this invocation are released. */
 for(i=saved;i<x->a->nodes;i++)x->a->node[i].type=PN_NODE_FREE;
 x->a->nodes=saved;
 if(!ok)return 0;
 if(!x->verify)*out=f.result;
 return 1;
}
static int name_term(struct exec *x,struct frame *f,unsigned t,pn_u32 *at,pn_u32 end,struct pn_aml_obj *out){
 struct path p;unsigned n,i;struct pn_aml_obj args[7];pn_u32 start=*at;
 if(!namestring(x,t,at,end,&p))return fail(x,0x2e,t,start);
 n=lookup(x->a,f->scope,&p);
 if(!n||n==0xffffu)return fail(x,0x2e,t,start);
 if(x->a->node[n].type==PN_NODE_METHOD||x->a->node[n].type==PN_NODE_BUILTIN){
  unsigned argc=x->a->node[n].type==PN_NODE_BUILTIN?1:(x->a->node[n].flags&7);
  for(i=0;i<argc;i++)if(!term(x,f,t,at,end,&args[i]))return 0;
  if(!call(x,n,args,argc,out))return fail(x,0x14,t,start);
  return 1;
 }
 if(x->a->node[n].type==PN_NODE_EXTERNAL)return fail(x,0x15,t,start);
 if(!readnode(x,n,out))return fail(x,0x2e,t,start);
 return 1;
}
static int define(struct exec *x,struct frame *f,unsigned t,pn_u32 *at,pn_u32 end,unsigned op,unsigned ext);

static int term2(struct exec *x,struct frame *f,unsigned t,pn_u32 *at,pn_u32 end,struct pn_aml_obj *out);
/* Expression nesting is bounded separately from method calls so that a
   corrupt table cannot exhaust a small (16-bit) stack. */
static int term(struct exec *x,struct frame *f,unsigned t,pn_u32 *at,pn_u32 end,struct pn_aml_obj *out){
 int ok;
 if(x->nest>=48)return fail(x,0xffe,t,*at);
 x->nest++;ok=term2(x,f,t,at,end,out);x->nest--;return ok;
}
static int term2(struct exec *x,struct frame *f,unsigned t,pn_u32 *at,pn_u32 end,struct pn_aml_obj *out){
 unsigned op,e;pn_u32 start=*at,v,w,stop;struct pn_aml_obj a,b;struct ref r;
 if(++x->steps>MAXSTEPS)return fail(x,0xfff,t,start);
 if(!byte(x,t,*at,end,&op))return fail(x,0x100,t,start);
 if(isname(x,t,*at,end))return name_term(x,f,t,at,end,out);
 (*at)++;
 switch(op){
 case 0x00:setint(out,0);return 1;
 case 0x01:setint(out,1);return 1;
 case 0xff:setint(out,0xffffffffUL);return 1;
 case 0x0a:case 0x0b:case 0x0c:case 0x0e:if(!constant(x,t,at,end,op,&v))return fail(x,op,t,start);setint(out,v);return 1;
 case 0x0d:
  zero(out,sizeof(*out));out->type=PN_OBJ_STRING;out->table=(unsigned char)t;out->value=*at;
  while(byte(x,t,*at,end,&e)){(*at)++;if(!e){out->length=*at-1-out->value;return 1;}}
  return fail(x,op,t,start);
 case 0x11:
  if(!pkglen(x,t,at,end,&stop)||!intarg(x,f,t,at,stop,&v))return fail(x,op,t,start);
  zero(out,sizeof(*out));out->type=PN_OBJ_BUFFER;out->table=(unsigned char)t;out->value=*at;out->length=v;
  out->count=(unsigned short)((stop-*at)>0xffffUL?0xffffU:(stop-*at));*at=stop;return 1;
 case 0x12:case 0x13:
  if(!pkglen(x,t,at,end,&stop))return fail(x,op,t,start);
  if(op==0x12){if(!byte(x,t,*at,stop,&e))return fail(x,op,t,start);(*at)++;v=e;}
  else if(!intarg(x,f,t,at,stop,&v)||v>0xffffUL)return fail(x,op,t,start);
  zero(out,sizeof(*out));out->type=PN_OBJ_PACKAGE;out->table=(unsigned char)t;out->value=*at;out->length=stop;
  out->count=(unsigned short)v;out->node=(unsigned short)f->scope;
  if(x->verify){pn_u32 p=*at;while(p<stop)if(!element(x,t,&p,stop))return fail(x,op,t,start);}
  *at=stop;return 1;
 case 0x60:case 0x61:case 0x62:case 0x63:case 0x64:case 0x65:case 0x66:case 0x67:
  *out=f->local[op-0x60];if(out->type==PN_OBJ_NONE)setint(out,0);return 1;
 case 0x68:case 0x69:case 0x6a:case 0x6b:case 0x6c:case 0x6d:case 0x6e:
  if(!x->verify&&op-0x68>=f->argc)return fail(x,op,t,start);
  *out=f->arg[op-0x68];
  if(out->type==PN_OBJ_REF&&!x->verify){unsigned n=out->node;if(x->a->node[n].type!=PN_NODE_SCOPE&&x->a->node[n].type!=PN_NODE_REGION)return readnode(x,n,out);}
  return 1;
 case 0x70:
  if(!term(x,f,t,at,end,&a)||!target(x,f,t,at,end,&r)||!store(x,f,&r,&a))return fail(x,op,t,start);
  *out=a;return 1;
 case 0x71:{
  struct path p;unsigned n;
  if(!byte(x,t,*at,end,&e))return fail(x,op,t,start);
  if(e>=0x60&&e<=0x6e){(*at)++;
   /* RefOf(LocalX/ArgX): only argument references carried through. */
   if(e>=0x68&&f->arg[e-0x68].type==PN_OBJ_REF){*out=f->arg[e-0x68];return 1;}
   return fail(x,op,t,start);}
  if(!namestring(x,t,at,end,&p))return fail(x,op,t,start);
  n=lookup(x->a,f->scope,&p);if(!n||n==0xffffu)return fail(x,op,t,start);
  zero(out,sizeof(*out));out->type=PN_OBJ_REF;out->node=(unsigned short)n;return 1;}
 case 0x72:case 0x74:case 0x77:case 0x79:case 0x7a:case 0x7b:case 0x7c:case 0x7d:case 0x7e:case 0x7f:case 0x85:
  if(!intarg(x,f,t,at,end,&v)||!intarg(x,f,t,at,end,&w)||!target(x,f,t,at,end,&r))return fail(x,op,t,start);
  if(x->verify)unknown(out);
  else{pn_u32 res;if(!bincalc(op,v,w,&res))return fail(x,op,t,start);setint(out,res);}
  if(!store(x,f,&r,out))return fail(x,op,t,start);
  return 1;
 case 0x78:{
  struct ref q;
  if(!intarg(x,f,t,at,end,&v)||!intarg(x,f,t,at,end,&w)||!target(x,f,t,at,end,&r)||!target(x,f,t,at,end,&q))return fail(x,op,t,start);
  if(x->verify){unknown(out);unknown(&a);}
  else{if(!w)return fail(x,op,t,start);setint(&a,v%w);setint(out,v/w);}
  if(!store(x,f,&r,&a)||!store(x,f,&q,out))return fail(x,op,t,start);
  return 1;}
 case 0x75:case 0x76:{
  pn_u32 save=*at;
  if(!intarg(x,f,t,at,end,&v))return fail(x,op,t,start);
  *at=save;if(!target(x,f,t,at,end,&r))return fail(x,op,t,start);
  if(x->verify)unknown(out);else setint(out,op==0x75?v+1:v-1);
  if(!store(x,f,&r,out))return fail(x,op,t,start);return 1;}
 case 0x80:case 0x81:case 0x82:case 0x99:{
  if(!intarg(x,f,t,at,end,&v)||!target(x,f,t,at,end,&r))return fail(x,op,t,start);
  if(x->verify)unknown(out);
  else if(op==0x80)setint(out,~v);
  else if(op==0x99)setint(out,v);
  else{unsigned k=0;if(v){if(op==0x81){k=32;while(!(v&0x80000000UL)){v<<=1;k--;}}else{k=1;while(!(v&1)){v>>=1;k++;}}}setint(out,k);}
  if(!store(x,f,&r,out))return fail(x,op,t,start);return 1;}
 case 0x83:
  if(!term(x,f,t,at,end,&a))return fail(x,op,t,start);
  if(x->verify){unknown(out);return 1;}
  if(a.type==PN_OBJ_REF)return readnode(x,a.node,out)?1:fail(x,op,t,start);
  if(a.type==PN_OBJ_INDEX){
   struct pn_aml_obj pkg=a;pkg.type=PN_OBJ_PACKAGE;
   if(a.length==0xffffffffUL){
    /* Buffer element: a.value is the buffer data offset. */
    if(a.index>=a.count){setint(out,0);return 1;}
    setint(out,x->a->aml[a.table][a.value+a.index]);return 1;
   }
   return pkgelement(x,&pkg,a.index,out)?1:fail(x,op,t,start);
  }
  return fail(x,op,t,start);
 case 0x86:
  if(!term(x,f,t,at,end,&a)||!intarg(x,f,t,at,end,&v))return fail(x,op,t,start);
  setint(out,0);return 1;
 case 0x87:
  if(!byte(x,t,*at,end,&e))return fail(x,op,t,start);
  if(!term(x,f,t,at,end,&a))return fail(x,op,t,start);
  if(x->verify){unknown(out);return 1;}
  if(a.type==PN_OBJ_STRING||a.type==PN_OBJ_BUFFER)setint(out,a.length);
  else if(a.type==PN_OBJ_PACKAGE)setint(out,a.count);
  else return fail(x,op,t,start);
  return 1;
 case 0x88:
  if(!term(x,f,t,at,end,&a)||!intarg(x,f,t,at,end,&v)||!target(x,f,t,at,end,&r))return fail(x,op,t,start);
  if(x->verify){unknown(out);return store(x,f,&r,out)?1:fail(x,op,t,start);}
  if(a.type==PN_OBJ_PACKAGE){if(v>=a.count)return fail(x,op,t,start);*out=a;out->type=PN_OBJ_INDEX;out->index=(unsigned short)v;}
  else if(a.type==PN_OBJ_BUFFER){if(v>=a.length)return fail(x,op,t,start);*out=a;out->type=PN_OBJ_INDEX;out->index=(unsigned short)v;out->length=0xffffffffUL;}
  else return fail(x,op,t,start);
  if(!store(x,f,&r,out))return fail(x,op,t,start);
  return 1;
 case 0x8e:{
  if(!term(x,f,t,at,end,&a))return fail(x,op,t,start);
  if(x->verify){unknown(out);return 1;}
  v=a.type==PN_OBJ_INT?1:a.type==PN_OBJ_STRING?2:a.type==PN_OBJ_BUFFER?3:a.type==PN_OBJ_PACKAGE?4:0;
  setint(out,v);return 1;}
 case 0x90:case 0x91:
  if(!intarg(x,f,t,at,end,&v)||!intarg(x,f,t,at,end,&w))return fail(x,op,t,start);
  if(x->verify)unknown(out);else setint(out,(op==0x90?(v&&w):(v||w))?0xffffffffUL:0);
  return 1;
 case 0x92:
  if(!intarg(x,f,t,at,end,&v))return fail(x,op,t,start);
  if(x->verify)unknown(out);else setint(out,v?0:0xffffffffUL);return 1;
 case 0x93:case 0x94:case 0x95:
  if(!term(x,f,t,at,end,&a)||!term(x,f,t,at,end,&b))return fail(x,op,t,start);
  if(x->verify){unknown(out);return 1;}
  if(a.type==PN_OBJ_STRING&&b.type==PN_OBJ_STRING&&op==0x93){
   pn_u32 i;int eq=a.length==b.length;
   for(i=0;eq&&i<a.length;i++)if(x->a->aml[a.table][a.value+i]!=x->a->aml[b.table][b.value+i])eq=0;
   setint(out,eq?0xffffffffUL:0);return 1;
  }
  if(!toint(x,&a,&v)||!toint(x,&b,&w))return fail(x,op,t,start);
  setint(out,(op==0x93?v==w:op==0x94?v>w:v<w)?0xffffffffUL:0);return 1;
 case 0x9d:
  if(!term(x,f,t,at,end,&a)||!target(x,f,t,at,end,&r)||!store(x,f,&r,&a))return fail(x,op,t,start);
  *out=a;return 1;
 case 0xa4:
  if(!term(x,f,t,at,end,&a))return fail(x,op,t,start);
  f->result=a;if(!x->verify)f->ctl=CTL_RETURN;setint(out,0);return 1;
 case 0x5b:
  if(!byte(x,t,*at,end,&e))return fail(x,op,t,start);
  (*at)++;
  switch(e){
  case 0x12:{
   struct path p;unsigned n;pn_u32 ns=*at;
   if(!namestring(x,t,at,end,&p)){
    /* CondRefOf also accepts a local/arg; treat those as present. */
    *at=ns;if(!term(x,f,t,at,end,&a))return fail(x,0x5b12,t,start);
    if(!target(x,f,t,at,end,&r))return fail(x,0x5b12,t,start);setint(out,0xffffffffUL);return 1;
   }
   n=lookup(x->a,f->scope,&p);
   if(!target(x,f,t,at,end,&r))return fail(x,0x5b12,t,start);
   if(n&&n!=0xffffu&&x->a->node[n].type!=PN_NODE_EXTERNAL){
    zero(&a,sizeof(a));a.type=PN_OBJ_REF;a.node=(unsigned short)n;
    if(!store(x,f,&r,&a))return fail(x,0x5b12,t,start);
    if(x->verify)unknown(out);else setint(out,0xffffffffUL);
   }else setint(out,0);
   return 1;}
  case 0x21:case 0x22:
   if(!intarg(x,f,t,at,end,&v))return fail(x,0x5b00|e,t,start);
   if(!x->verify){
    if(!x->env||!x->env->stall)return fail(x,0x5b00|e,t,start);
    if(e==0x21){if(v>100)v=100;x->env->stall(x->env->arg,v);}
    else{if(v>2000)v=2000;x->env->stall(x->env->arg,v*1000UL);}
   }
   setint(out,0);return 1;
  case 0x23:
   if(!term(x,f,t,at,end,&a))return fail(x,0x5b23,t,start);
   if(!byte(x,t,*at,end,&op))return fail(x,0x5b23,t,start);
   *at+=2;setint(out,0);return 1; /* Single-threaded: acquired */
  case 0x24:case 0x26:case 0x27:
   if(!term(x,f,t,at,end,&a))return fail(x,0x5b00|e,t,start);setint(out,0);return 1;
  case 0x25:
   if(!term(x,f,t,at,end,&a)||!intarg(x,f,t,at,end,&v))return fail(x,0x5b25,t,start);
   setint(out,0);return 1;
  case 0x28:case 0x29:
   if(!intarg(x,f,t,at,end,&v)||!target(x,f,t,at,end,&r))return fail(x,0x5b00|e,t,start);
   if(x->verify)unknown(out);
   else if(e==0x28){pn_u32 res=0,mul=1;while(v){res+=(v&15)*mul;mul*=10;v>>=4;}setint(out,res);}
   else{pn_u32 res=0;unsigned s=0;while(v&&s<32){res|=(v%10)<<s;v/=10;s+=4;}setint(out,res);}
   if(!store(x,f,&r,out))return fail(x,0x5b00|e,t,start);return 1;
  case 0x30:setint(out,2);return 1;
  case 0x31:zero(out,sizeof(*out));out->type=PN_OBJ_DEBUG;return 1;
  case 0x33:setint(out,0);return 1;
  }
  *at=start;return define(x,f,t,at,end,0x5b,e)?(setint(out,0),1):0;
 }
 *at=start;
 return define(x,f,t,at,end,op,0)?(setint(out,0),1):0;
}
/* Statement-level and declaration opcodes, shared with table loading. */
static int fieldlist(struct exec *x,unsigned t,pn_u32 at,pn_u32 end,unsigned scope,unsigned type,unsigned link,unsigned link2,pn_u32 bank){
 unsigned flags,op,c,i;pn_u32 bit=0,len,k;struct path p;
 if(!byte(x,t,at,end,&flags))return 0;at++;
 while(at<end){
  if(!byte(x,t,at,end,&op))return 0;
  if(op==0){
   unsigned b0,n2;pn_u32 v2;at++;if(!byte(x,t,at,end,&b0))return 0;
   n2=b0>>6;v2=n2?(b0&15):(b0&63);if((n2&&(b0&0x30))||end-at<1+n2)return 0;
   for(k=0;k<n2;k++)v2|=(pn_u32)x->a->aml[t][at+1+k]<<(4+8*k);
   at+=1+n2;bit+=v2;continue;
  }
  if(op==1){if(end-at<3)return 0;flags=(flags&0xf0)|(x->a->aml[t][at+1]&15);at+=3;continue;}
  if(op==3){if(end-at<4)return 0;flags=(flags&0xf0)|(x->a->aml[t][at+1]&15);at+=4;continue;}
  if(op==2)return 0; /* Connection(): GenericSerialBus/GPIO unsupported */
  if(end-at<5)return 0;
  for(i=0;i<4;i++){c=x->a->aml[t][at+i];if(!(i?namechar(c):leadchar(c)))return 0;p.seg[0][i]=(char)c;}
  at+=4;p.root=0;p.up=0;p.count=1;
  {unsigned b0=x->a->aml[t][at],n=b0>>6;pn_u32 v=n?(b0&15):(b0&63);
   if(n&&(b0&0x30))return 0;if(end-at<1+n)return 0;
   for(k=0;k<n;k++)v|=(pn_u32)x->a->aml[t][at+1+k]<<(4+8*k);at+=1+n;len=v;}
  {unsigned node=create(x->a,scope,&p,type,t);if(!node)return 0;
   x->a->node[node].space=(unsigned char)flags;x->a->node[node].link=(unsigned short)link;
   x->a->node[node].link2=(unsigned short)link2;x->a->node[node].bank=bank;
   x->a->node[node].bit=bit;x->a->node[node].bits=len;}
  bit+=len;
 }
 return 1;
}
static int define(struct exec *x,struct frame *f,unsigned t,pn_u32 *at,pn_u32 end,unsigned op,unsigned ext){
 pn_u32 start=*at,stop,v;struct path p;struct pn_aml_obj o;unsigned n,e,scope=f->scope;int load=x->loading;
 (*at)++;if(op==0x5b)(*at)++;
 if(op!=0x5b)switch(op){
 case 0x08:
  if(!namestring(x,t,at,end,&p))return fail(x,op,t,start);
  {int ro=x->readonly,vf=x->verify;
   /* Name values are data objects; packages capture their scope. */
   if(load){x->readonly=1;x->verify=0;}
   if(!term(x,f,t,at,end,&o)){x->readonly=ro;x->verify=vf;return fail(x,op,t,start);}
   x->readonly=ro;x->verify=vf;}
  if(o.type==PN_OBJ_UNKNOWN){if(!x->verify)return fail(x,op,t,start);}
  n=create(x->a,scope,&p,PN_NODE_NAME,t);if(!n)return fail(x,op,t,start);
  if(o.type==PN_OBJ_PACKAGE&&load)o.node=(unsigned short)scope;
  x->a->node[n].value=o;return 1;
 case 0x10:
  if(!pkglen(x,t,at,end,&stop)||!namestring(x,t,at,stop,&p))return fail(x,op,t,start);
  if(!load)return fail(x,op,t,start);
  if(!p.count)n=p.root?0:scope;
  else{
   n=lookup(x->a,scope,&p);
   if(n==0xffffu)return fail(x,op,t,start);
   if(!n)n=create(x->a,scope,&p,PN_NODE_SCOPE,t);
   else if(x->a->node[n].type==PN_NODE_EXTERNAL)x->a->node[n].type=PN_NODE_SCOPE;
   if(!n||(x->a->node[n].type!=PN_NODE_SCOPE))return fail(x,op,t,start);
  }
  {unsigned s=f->scope;f->scope=n;if(!termlist(x,f,t,*at,stop)){f->scope=s;return 0;}f->scope=s;}
  *at=stop;return 1;
 case 0x14:
  if(!pkglen(x,t,at,end,&stop)||!namestring(x,t,at,stop,&p)||!byte(x,t,*at,stop,&e))return fail(x,op,t,start);
  (*at)++;
  if(!load)return fail(x,op,t,start);
  n=create(x->a,scope,&p,PN_NODE_METHOD,t);if(!n)return fail(x,op,t,start);
  x->a->node[n].flags=(unsigned char)(e&7);x->a->node[n].start=*at;x->a->node[n].end=stop;
  *at=stop;return 1;
 case 0x15:
  if(!namestring(x,t,at,end,&p)||end-*at<2)return fail(x,op,t,start);
  *at+=2;
  if(load&&!lookup(x->a,scope,&p)){n=create(x->a,scope,&p,PN_NODE_EXTERNAL,t);(void)n;}
  return 1;
 case 0x06:{
  struct path q;unsigned src;
  if(!namestring(x,t,at,end,&p)||!namestring(x,t,at,end,&q))return fail(x,op,t,start);
  src=lookup(x->a,scope,&p);if(!src||src==0xffffu)return fail(x,op,t,start);
  n=create(x->a,scope,&q,PN_NODE_ALIAS,t);if(!n)return fail(x,op,t,start);
  x->a->node[n].link=(unsigned short)src;return 1;}
 case 0xa0:{
  pn_u32 thenstop,elsestop=0,save;unsigned c;
  if(!pkglen(x,t,at,end,&thenstop))return fail(x,op,t,start);
  {int ro=x->readonly;if(load)x->readonly=1;
   if(!intarg(x,f,t,at,thenstop,&v)){x->readonly=ro;return fail(x,op,t,start);}x->readonly=ro;}
  save=thenstop;
  if(byte(x,t,save,end,&c)&&c==0xa1){save++;if(!pkglen(x,t,&save,end,&elsestop))return fail(x,0xa1,t,thenstop);}
  if(x->verify&&!load){
   if(!termlist(x,f,t,*at,thenstop))return 0;
   if(elsestop&&!termlist(x,f,t,save,elsestop))return 0;
  }else if(v){
   if(!termlist(x,f,t,*at,thenstop))return 0;
  }else if(elsestop){
   if(!termlist(x,f,t,save,elsestop))return 0;
  }
  *at=elsestop?elsestop:thenstop;return 1;}
 case 0xa2:{
  pn_u32 body,iter=0;
  if(load||!pkglen(x,t,at,end,&stop))return fail(x,op,t,start);
  body=*at;
  for(;;){
   pn_u32 p2=body;
   if(!intarg(x,f,t,&p2,stop,&v))return fail(x,op,t,start);
   if(x->verify){if(!termlist(x,f,t,p2,stop))return 0;break;}
   if(!v)break;
   if(++iter>65535UL)return fail(x,op,t,start);
   if(!termlist(x,f,t,p2,stop))return 0;
   if(f->ctl==CTL_BREAK){f->ctl=CTL_NONE;break;}
   if(f->ctl==CTL_CONTINUE)f->ctl=CTL_NONE;
   if(f->ctl==CTL_RETURN)break;
  }
  *at=stop;return 1;}
 case 0xa5:if(!x->verify)f->ctl=CTL_BREAK;return 1;
 case 0x9f:if(!x->verify)f->ctl=CTL_CONTINUE;return 1;
 case 0xa3:case 0xcc:return 1;
 }
 if(op==0x5b)switch(ext){
 case 0x01:
  if(!namestring(x,t,at,end,&p)||!byte(x,t,*at,end,&e))return fail(x,0x5b01,t,start);(*at)++;
  n=create(x->a,scope,&p,PN_NODE_MUTEX,t);return n?1:fail(x,0x5b01,t,start);
 case 0x02:
  if(!namestring(x,t,at,end,&p))return fail(x,0x5b02,t,start);
  n=create(x->a,scope,&p,PN_NODE_EVENT,t);return n?1:fail(x,0x5b02,t,start);
 case 0x80:{
  pn_u32 args;
  if(!namestring(x,t,at,end,&p)||!byte(x,t,*at,end,&e))return fail(x,0x5b80,t,start);
  (*at)++;args=*at;
  {int vf=x->verify;x->verify=1;
   if(!term(x,f,t,at,end,&o)||!term(x,f,t,at,end,&o)){x->verify=vf;return fail(x,0x5b80,t,start);}
   x->verify=vf;}
  n=create(x->a,scope,&p,PN_NODE_REGION,t);if(!n)return fail(x,0x5b80,t,start);
  x->a->node[n].space=(unsigned char)e;x->a->node[n].start=args;x->a->node[n].end=*at;
  return 1;}
 case 0x81:case 0x86:case 0x87:{
  unsigned r1=0,r2=0;pn_u32 bankval=0;
  if(!pkglen(x,t,at,end,&stop)||!namestring(x,t,at,stop,&p))return fail(x,0x5b00|ext,t,start);
  r1=lookup(x->a,scope,&p);if(!r1||r1==0xffffu)return fail(x,0x5b00|ext,t,start);
  if(ext!=0x81){struct path q;if(!namestring(x,t,at,stop,&q))return fail(x,0x5b00|ext,t,start);
   r2=lookup(x->a,scope,&q);if(!r2||r2==0xffffu)return fail(x,0x5b00|ext,t,start);}
  if(ext==0x87){int ro=x->readonly;x->readonly=1;if(!intarg(x,f,t,at,stop,&bankval)){x->readonly=ro;return fail(x,0x5b87,t,start);}x->readonly=ro;}
  if(ext==0x81){if(x->a->node[r1].type!=PN_NODE_REGION)return fail(x,0x5b81,t,start);
   if(!fieldlist(x,t,*at,stop,scope,PN_NODE_FIELD,r1,0,0))return fail(x,0x5b81,t,start);}
  else if(ext==0x86){if(!fieldlist(x,t,*at,stop,scope,PN_NODE_INDEXFLD,r1,r2,0))return fail(x,0x5b86,t,start);}
  else{if(x->a->node[r1].type!=PN_NODE_REGION)return fail(x,0x5b87,t,start);
   if(!fieldlist(x,t,*at,stop,scope,PN_NODE_BANKFLD,r1,r2,bankval))return fail(x,0x5b87,t,start);}
  *at=stop;return 1;}
 case 0x82:case 0x83:case 0x84:case 0x85:{
  unsigned skip=ext==0x83?6:(ext==0x84?3:0);
  if(!load||!pkglen(x,t,at,end,&stop)||!namestring(x,t,at,stop,&p))return fail(x,0x5b00|ext,t,start);
  if(stop-*at<skip)return fail(x,0x5b00|ext,t,start);*at+=skip;
  n=create(x->a,scope,&p,PN_NODE_SCOPE,t);if(!n)return fail(x,0x5b00|ext,t,start);
  {unsigned s=f->scope;f->scope=n;if(!termlist(x,f,t,*at,stop)){f->scope=s;return 0;}f->scope=s;}
  *at=stop;return 1;}
 }
 return fail(x,op==0x5b?(0x5b00|ext):op,t,start);
}
static int termlist(struct exec *x,struct frame *f,unsigned t,pn_u32 at,pn_u32 end){
 int ok;
 if(x->nest>=48)return fail(x,0xffe,t,at);
 x->nest++;ok=termlist2(x,f,t,at,end);x->nest--;return ok;
}
static int termlist2(struct exec *x,struct frame *f,unsigned t,pn_u32 at,pn_u32 end){
 struct pn_aml_obj o;unsigned op;
 while(at<end){
  if(!byte(x,t,at,end,&op))return 0;
  if(op==0x08||op==0x10||op==0x14||op==0x15||op==0x06||op==0xa0||op==0xa2||op==0xa5||op==0x9f||op==0xa3||op==0xcc||
     (op==0x5b&&at+1<end&&(x->a->aml[t][at+1]==0x01||x->a->aml[t][at+1]==0x02||x->a->aml[t][at+1]>=0x80))){
   if(!define(x,f,t,&at,end,op,op==0x5b?x->a->aml[t][at+1]:0))return 0;
  }else if(!term(x,f,t,&at,end,&o))return 0;
  if(f->ctl!=CTL_NONE)return 1;
 }
 return at==end;
}
int pn_aml_init(struct pn_aml *a,struct pn_aml_node *nodes,unsigned capacity,unsigned revision){
 static const char osi[4]={'_','O','S','I'},sb[4]={'_','S','B','_'},gl[4]={'_','G','L','_'},
  os[4]={'_','O','S','_'},rev[4]={'_','R','E','V'},gpe[4]={'_','G','P','E'},pr[4]={'_','P','R','_'},
  si[4]={'_','S','I','_'},tz[4]={'_','T','Z','_'};
 static const char ostext[]="Microsoft Windows NT";
 struct path p;unsigned i;
 if(!a||!nodes||capacity<64||capacity>65000U)return 0;
 zero(a,sizeof(*a));a->node=nodes;a->capacity=capacity;a->revision=revision;
 zero(&nodes[0],sizeof(nodes[0]));nodes[0].type=PN_NODE_SCOPE;nodes[0].name[0]='\\';
 a->nodes=1;
 p.root=1;p.up=0;p.count=1;
 {const char *scopes[6];scopes[0]=sb;scopes[1]=gpe;scopes[2]=pr;scopes[3]=si;scopes[4]=tz;scopes[5]=0;
  for(i=0;scopes[i];i++){unsigned j;for(j=0;j<4;j++)p.seg[0][j]=scopes[i][j];if(!create(a,0,&p,PN_NODE_SCOPE,0))return 0;}}
 for(i=0;i<4;i++)p.seg[0][i]=osi[i];
 {unsigned n=create(a,0,&p,PN_NODE_BUILTIN,0);if(!n)return 0;a->node[n].flags=1;}
 for(i=0;i<4;i++)p.seg[0][i]=gl[i];if(!create(a,0,&p,PN_NODE_MUTEX,0))return 0;
 for(i=0;i<4;i++)p.seg[0][i]=rev[i];
 {unsigned n=create(a,0,&p,PN_NODE_NAME,0);if(!n)return 0;setint(&a->node[n].value,revision>=2?2:1);}
 for(i=0;i<4;i++)p.seg[0][i]=os[i];
 {unsigned n=create(a,0,&p,PN_NODE_NAME,0);if(!n)return 0;
  /* \_OS string lives in a static pseudo-table (index PN_AML_MAX_TABLES-1). */
  a->aml[PN_AML_MAX_TABLES-1]=(const unsigned char *)ostext;a->size[PN_AML_MAX_TABLES-1]=sizeof(ostext);
  zero(&a->node[n].value,sizeof(a->node[n].value));a->node[n].value.type=PN_OBJ_STRING;
  a->node[n].value.table=PN_AML_MAX_TABLES-1;a->node[n].value.value=0;a->node[n].value.length=sizeof(ostext)-1;}
 return 1;
}
int pn_aml_load(struct pn_aml *a,const unsigned char *body,pn_u32 length){
 struct exec x;struct frame f;unsigned t;
 if(!a||a->failed||!body||a->tables>=PN_AML_MAX_TABLES-1)return 0;
 t=a->tables++;a->aml[t]=body;a->size[t]=length;
 zero(&x,sizeof(x));x.a=a;x.readonly=1;x.loading=1;
 zero(&f,sizeof(f));f.scope=0;
 /* Top-level code runs read-only; any write or unsupported construct
    while loading makes the whole namespace unusable (fail closed). */
 if(!termlist(&x,&f,t,0,length)){a->failed=1;return 0;}
 return 1;
}
static unsigned sleepname(struct pn_aml *a,unsigned state){
 char nm[4];struct path p;unsigned i;
 nm[0]='_';nm[1]='S';nm[2]=(char)('0'+state);nm[3]='_';
 p.root=1;p.up=0;p.count=1;for(i=0;i<4;i++)p.seg[0][i]=nm[i];
 return lookup(a,0,&p);
}
int pn_aml_sleep_type(struct pn_aml *a,const struct pn_aml_env *env,unsigned state,unsigned *typa,unsigned *typb){
 struct exec x;struct pn_aml_obj o,e;unsigned n;pn_u32 v,w;
 if(!a||a->failed||state>5||!typa||!typb)return 0;
 n=sleepname(a,state);if(!n||n==0xffffu)return 0;
 zero(&x,sizeof(x));x.a=a;x.env=env;x.readonly=1;
 if(!readnode(&x,n,&o)||o.type!=PN_OBJ_PACKAGE||!o.count)return 0;
 if(!pkgelement(&x,&o,0,&e)||!toint(&x,&e,&v))return 0;
 if(o.count==1){w=(v>>8)&0xff;v&=0xff;}
 else if(!pkgelement(&x,&o,1,&e)||!toint(&x,&e,&w))return 0;
 if(v>7||w>7)return 0;
 *typa=(unsigned)v;*typb=(unsigned)w;return 1;
}
static unsigned prepname(struct pn_aml *a,unsigned which){
 static const char names[3][4]={{'_','T','T','S'},{'_','P','T','S'},{'_','G','T','S'}};
 struct path p;unsigned i;p.root=1;p.up=0;p.count=1;for(i=0;i<4;i++)p.seg[0][i]=names[which][i];
 i=lookup(a,0,&p);return i==0xffffu?0:i;
}
int pn_aml_has_prepare(struct pn_aml *a){
 unsigned i;if(!a)return 0;for(i=0;i<3;i++)if(prepname(a,i))return 1;return 0;
}
int pn_aml_verify_prepare(struct pn_aml *a,unsigned state){
 struct exec x;struct pn_aml_obj arg,out;unsigned i,n;int ok=1;
 if(!a||a->failed||state>5)return 0;
 zero(&x,sizeof(x));x.a=a;x.verify=1;a->last_op=0;
 for(i=0;i<3&&ok;i++){
  n=prepname(a,i);if(!n)continue;
  if(a->node[n].type!=PN_NODE_METHOD){ok=0;break;}
  setint(&arg,state);
  if(!call(&x,n,&arg,1,&out))ok=0;
 }
 /* Verification marks are scratch state. */
 for(i=0;i<a->nodes;i++)a->node[i].flags&=(unsigned char)~(F_VERIFIED|F_VERIFYING);
 return ok;
}
int pn_aml_prepare(struct pn_aml *a,const struct pn_aml_env *env,unsigned state){
 struct exec x;struct pn_aml_obj arg,out;unsigned i,n;int ok=1;
 if(!a||!env||state>5)return 0;
 for(i=0;i<3;i++){
  n=prepname(a,i);if(!n)continue;
  zero(&x,sizeof(x));x.a=a;x.env=env;
  setint(&arg,state);
  if(!call(&x,n,&arg,1,&out))ok=0;
 }
 return ok;
}
