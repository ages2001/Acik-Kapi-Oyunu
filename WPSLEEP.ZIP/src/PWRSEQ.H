#ifndef PN_PWRSEQ_H
#define PN_PWRSEQ_H
#include "S5.H"
struct pn_io {
 void *arg;
 unsigned (*get16)(void *,unsigned);
 void (*put16)(void *,unsigned,unsigned);
 void (*put8)(void *,unsigned,unsigned);
 void (*wait)(void *,unsigned);
 /* Optional: run firmware preparation methods after ACPI mode is active
    and before SLP_EN. NULL keeps the earlier static behavior. */
 int (*prepare)(void *);
 int (*write_mmio)(const struct pn_reg *,unsigned);
 int (*read_mmio16)(const struct pn_reg *,unsigned *);

};
/* Resolve only validated fixed FADT registers. A missing memory mapping makes
   that operation unavailable; System I/O requires no mapping. */
void pn_bindregs(struct pn_acpi *,int (*bind)(struct pn_reg *));
int pn_apm_permitted(const struct pn_acpi *,const struct pn_io *);
int pn_s5off(const struct pn_acpi *,const struct pn_io *);
int pn_reset(const struct pn_acpi *,const struct pn_io *);
#ifdef WP_2000
void pn_reset_fixed(const struct pn_acpi *,const struct pn_io *);
#endif
#endif
