#define WIN32_LEAN_AND_MEAN
#include "OSNAME.H"
#include <windows.h>
#include "FWAPI.H"
typedef UINT (WINAPI *FIRMWAREFN)(DWORD,DWORD,PVOID,DWORD);
int wp_fw_query(struct wp_fwtable *info){
 FIRMWAREFN query;HMODULE kernel;BYTE *buffer;UINT need,got;unsigned attempt;int ok;
 wp_fw_clear(info);if(!info)return 0;
 kernel=GetModuleHandleA("KERNEL32.DLL");if(!kernel)return 0;
 query=(FIRMWAREFN)GetProcAddress(kernel,"GetSystemFirmwareTable");
 if(!query)return 0;
 /* Provider 'ACPI'; table ID is the little-endian DWORD for "FACP".
    Explicit constants avoid implementation-defined multi-char literals. */
 need=query(0x41435049UL,0x50434146UL,0,0);
 for(attempt=0;attempt<2;attempt++){
  if(need<36||need>WP_FADT_MAX)return 0;
  buffer=(BYTE*)LocalAlloc(LMEM_FIXED,need);if(!buffer)return 0;
  got=query(0x41435049UL,0x50434146UL,buffer,need);
  ok=got&&got<=need?wp_fadt(buffer,got,info):0;
  LocalFree((HLOCAL)buffer);
  if(got<=need)return ok;
  need=got; /* One bounded retry if the required size changed. */
 }
 return 0;
}
void wp_fw_text(const struct wp_fwtable *info,char text[64]){
 if(!info||!info->revision){lstrcpyA(text,"N/A");return;}
 pn_acpitext(0xffff,info->revision,info->minor_valid?info->minor_revision:0xffff,text);
}
