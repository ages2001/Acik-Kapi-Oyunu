/* Compatibility helper name. Loading/querying only; no immediate power IOCTLs. */
#include "HNDLOAD.C"
