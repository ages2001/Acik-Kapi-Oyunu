#include "FWVER.H"
/* Unsupported NT3 final-shutdown research shim. Never installed automatically.
   Known kernel images only. No firmware writes in IRP_MJ_SHUTDOWN.
   The NoReboot path returns after its final IoShutdownSystem call; it never
   calls HAL. Redirect only that final call and wait for it to complete. */
#include <ntddk.h>
#include "LEGCTRL.H"
#include "ACPI.H"
#include "S5.H"
#include "PWRSEQ.H"
#ifdef PN_AML
#include "NTAML.H"
#include "NTAPM.H"
#endif
#include "MEMMAP.H"
#include "INTENT.H"
#include "SHUTFIND.H"
#undef IoCompleteRequest
#undef KeRaiseIrql
#undef KeLowerIrql
__declspec(dllimport) VOID NTAPI IoCompleteRequest(PIRP,CCHAR);
__declspec(dllimport) VOID NTAPI KeRaiseIrql(KIRQL,PKIRQL);
__declspec(dllimport) VOID NTAPI KeLowerIrql(KIRQL);
extern __declspec(dllimport) CCHAR KeNumberProcessors;
/* Imported through the loader: the export table may be discardable. */
typedef BOOLEAN (NTAPI *IOSTOP)(BOOLEAN,ULONG);
typedef PVOID (NTAPI *LOCKSECTION)(PVOID);
typedef VOID (NTAPI *UNLOCKSECTION)(PVOID);
static PUNICODE_STRING servicekey;
static IOSTOP original_io;
static UNLOCKSECTION unlock_section;
static PVOID section_lock;
static PUCHAR kernel,callsite;
static ULONG kernel_size,call_displacement;
static struct pn_acpi firmware;
static struct pn_memmap memory;
static volatile LONG shutdown_seen;
static ULONG status[12];
static PUCHAR sections;
static unsigned section_count;
static UNICODE_STRING linkname;
static int read_user(void *arg,unsigned long address,unsigned char *out,unsigned n) {
 ULONG p,last;(void)arg;
 if(!n||n>4096||address<0x10000||address>0x7ffeffffUL-n)return 0;
 p=address&~4095UL;last=(address+n-1)&~4095UL;
 for(;;p+=4096){if(!MmIsAddressValid((PVOID)p))return 0;if(p==last)break;}
 RtlCopyMemory(out,(void*)address,n);return 1;
}
static int trap_valid(ULONG p,ULONG low) {
 return p>=low&&p-low<8192&&!(p&3)&&MmIsAddressValid((PVOID)p)&&MmIsAddressValid((PVOID)(p+0x7f));
}
static unsigned shutdown_intent(ULONG frame) {
 KIRQL old;ULONG low=(ULONG)&old,outer;struct pn_userregs r;unsigned result=0;
 /* This lab accepts one active CPU. Raising IRQL prevents a concurrent
    page-out or user mapping change between the residency check and read.
    Do not fault in arbitrary user addresses or dereference unbounded data. */
 KeRaiseIrql(HIGH_LEVEL,&old);
 if(!trap_valid(frame,low)||(*(ULONG*)(frame+0x6c)&0xffff)!=8)goto done;
 outer=*(ULONG*)(frame+0x60);
 if(!trap_valid(outer,frame+0x7c)||(*(ULONG*)(outer+0x6c)&0xffff)!=0x1b||
    (*(ULONG*)(outer+0x70)&0x20000))goto done;
 r.eip=*(ULONG*)(outer+0x68);r.esp=*(ULONG*)(outer+0x74);
 r.ebx=*(ULONG*)(outer+0x5c);r.edi=*(ULONG*)(outer+0x54);
 result=pn_intent(status[7],&r,read_user,0);
 done:KeLowerIrql(old);return result;
}

static void mark(ULONG value) {
 OBJECT_ATTRIBUTES a;UNICODE_STRING n;HANDLE k;
 InitializeObjectAttributes(&a,servicekey,OBJ_CASE_INSENSITIVE,0,0);
 if(NT_SUCCESS(ZwOpenKey(&k,KEY_SET_VALUE,&a))) {
  RtlInitUnicodeString(&n,L"Stage");ZwSetValueKey(k,&n,0,REG_DWORD,&value,4);ZwClose(k);
 }
}
static unsigned get16(void *arg,unsigned port) {
 USHORT v;(void)arg;__asm__ volatile("inw %w1,%0":"=a"(v):"d"((USHORT)port));return v;
}
static void put16(void *arg,unsigned port,unsigned value) {
 (void)arg;__asm__ volatile("outw %0,%w1"::"a"((USHORT)value),"d"((USHORT)port));
}
static void put8(void *arg,unsigned port,unsigned value) {
 (void)arg;__asm__ volatile("outb %0,%w1"::"a"((UCHAR)value),"d"((USHORT)port));
}
static void waitio(void *arg,unsigned ticks) {
 unsigned i;(void)arg;for(i=0;i<ticks*55;i++)KeStallExecutionProcessor(1000);
}
#ifdef PN_AML
static const struct pn_io ports={0,get16,put16,put8,waitio,pn_ntaml_prepare,pn_ntreg_write,pn_ntreg_read16};
#else
static const struct pn_io ports={0,get16,put16,put8,waitio,0,0,0};
#endif
static void do_power(void) {
 /* ACPI S5 is the preferred power-off; the APM BIOS is the fallback when
    the machine has no ACPI. */
 if((firmware.off_ok||firmware.reduced)&&pn_s5off(&firmware,&ports)<0)return;
#ifdef PN_AML
 if(pn_apm_available()&&pn_apm_permitted(&firmware,&ports))pn_apm_off();
#endif
}
static BOOLEAN NTAPI __attribute__((optimize("no-omit-frame-pointer"))) completed_shutdown(BOOLEAN reboot,ULONG phase) {
 unsigned intent=0;BOOLEAN ok;
 /* The qualified NtShutdownSystem implementations preserve EBP: their
    caller frame is the nested kernel system-call trap. Its saved EBP is
    the outer user trap. Validate both before reading the Winlogon context. */
 if(leg_owner&&!reboot&&phase==1)intent=shutdown_intent(*(ULONG*)__builtin_frame_address(0));
 ok=original_io(reboot,phase);
 status[10]++;
 if(ok&&phase==1&&shutdown_seen&&leg_at_shutdown){
  if(intent==1)do_power();
  else if((intent==2||reboot)&&KeNumberProcessors==1)pn_reset(&firmware,&ports);
 }
 return ok;
}
static int readphys(void *arg,unsigned long address,unsigned char *out,unsigned size) {
 PHYSICAL_ADDRESS a;PUCHAR mapped;(void)arg;
 /* Map firmware physical memory on demand, wherever the ACPI pointers lead
    (Linux acpi_os_map_memory / VirtualBox DevACPI model). The RSDP scan reads
    the low 1 MiB; the RSDT/XSDT, FADT, DSDT and SSDTs can sit anywhere the
    ACPI structures reference - commonly a reserved region above RAM that is
    NOT part of the OS memory map - so the only bound here is a 4 GiB sanity
    limit. This does not assume a contiguous RAM profile, so hole-punched VM
    maps (VirtualBox, VMware) read the same as real hardware. Firmware WRITES
    stay policed separately by the NTAML firmware-area rules. */
 if(!size||address<0x400||address>=0xfffff000UL||size>0xfffff000UL-address)return 0;
 a.QuadPart=address;mapped=MmMapIoSpace(a,size,MmNonCached);if(!mapped)return 0;
 RtlCopyMemory(out,mapped,size);MmUnmapIoSpace(mapped,size);return 1;
}
static int memory_map(void) {
 UNICODE_STRING name,value;OBJECT_ATTRIBUTES a;HANDLE key;
 KEY_VALUE_PARTIAL_INFORMATION *info;NTSTATUS st;ULONG got;int ok=0;
 RtlInitUnicodeString(&name,L"\\Registry\\Machine\\HARDWARE\\RESOURCEMAP\\System Resources\\Physical Memory");
 InitializeObjectAttributes(&a,&name,OBJ_CASE_INSENSITIVE,0,0);
 mark(31);st=ZwOpenKey(&key,KEY_QUERY_VALUE,&a);
 if(!NT_SUCCESS(st)) {
  /* NT3.1 lacks this hardware-map registry key. The startup loader supplies a
     native SystemBasicInformation snapshot instead. Only the highest physical
     page is used, to bound firmware WRITES above RAM; the profile need NOT be
     contiguous. PageSize and AllocationGranularity confirm the record really
     is SYSTEM_BASIC_INFORMATION. Earlier builds also required
     NumberOfPhysicalPages to equal the page span, which rejected the
     hole-punched memory maps that VirtualBox and similar VMs report. */
  ULONG record[14];KEY_VALUE_PARTIAL_INFORMATION *v=(void*)record;ULONG *b;
  InitializeObjectAttributes(&a,servicekey,OBJ_CASE_INSENSITIVE,0,0);
  mark(311);if(!NT_SUCCESS(ZwOpenKey(&key,KEY_QUERY_VALUE,&a)))return 0;
  RtlInitUnicodeString(&value,L"BasicInfo");
  st=ZwQueryValueKey(key,&value,KeyValuePartialInformation,v,sizeof(record),&got);ZwClose(key);
  if(!NT_SUCCESS(st)||got!=sizeof(record)||v->Type!=REG_BINARY||v->DataLength!=44)return 0;
  mark(312);b=(ULONG*)v->Data;
  if(b[2]!=4096||b[6]!=65536||!b[5]||b[4]>b[5]||b[5]>=0xbff00)return 0;
  memory.count=1;memory.base[0]=0;memory.top=memory.length[0]=(b[5]+1)*4096;
  memory.limit=(memory.top+0xfffffUL)&~0xfffffUL;return memory.top>=0x100000;
 }
 info=ExAllocatePool(NonPagedPool,32768);if(!info){ZwClose(key);return 0;}
 RtlInitUnicodeString(&value,L".Translated");
 mark(32);st=ZwQueryValueKey(key,&value,KeyValuePartialInformation,info,32768,&got);ZwClose(key);
 if(NT_SUCCESS(st)&&got>=12&&got<=32768&&info->Type==REG_RESOURCE_LIST&&info->DataLength<=got-12) {
  mark(33);ok=pn_memmap(info->Data,info->DataLength,&memory);
 }
 ExFreePool(info);return ok;
}
static int discover(void) {
 ULONG ebda,p,found=0;UCHAR bytes[36],*work;int ok;
 /* RSDP scan first (Linux acpi_find_root_pointer): the EBDA, located from its
    segment word at BDA 0x40E, first 1 KiB; then the BIOS area 0xE0000-0xFFFFF,
    on 16-byte boundaries. This is independent of the physical-memory map, so a
    machine or VM whose RAM profile the loader could not model still finds the
    tables the same way real hardware does. */
 mark(34);if(!readphys(0,0x40e,bytes,2))return 0;
 ebda=((ULONG)bytes[0]|((ULONG)bytes[1]<<8))<<4;
 if(ebda>=0x400&&ebda<=0x9ffff)for(p=ebda;p+36<=ebda+1024&&p+36<=0x100000;p+=16)
  if(readphys(0,p,bytes,36)&&pn_rsdp(bytes,36)>=0){found=p;break;}
 if(!found)for(p=0xe0000;p<=0x100000-36;p+=16)
  if(readphys(0,p,bytes,36)&&pn_rsdp(bytes,36)>=0){found=p;break;}
 if(!found)return 0;
 mark(35);
 /* The physical-memory top is needed only to police firmware WRITES (NTAML
    allows them only above RAM, in the EBDA and 0xE0000-0xFFFFF). Best-effort:
    if the map is unavailable, set the top to the end of the address space so
    AML memory writes fail closed - ACPI S5 through the PM1 control port still
    powers the machine off. */
 if(!memory_map()){memory.count=0;memory.base[0]=0;memory.top=0xfffff000UL;memory.limit=0xfffff000UL;}
 /* Stage 36 = past the (best-effort) memory map with an RSDP already in hand.
    memory_map writes its own internal marks (31/311/312); re-stamping here
    means a terminal stage of 312 can ONLY come from an older build that still
    gated discovery on the memory map, which makes it easy to tell whether the
    generic driver is actually the one that ran. */
 mark(36);status[9]=memory.limit;
#ifdef PN_AML
 /* Bounded AML namespace; firmware memory writes only above NT RAM. */
 pn_ntaml_setup(memory.top,ebda);
 work=ExAllocatePool(NonPagedPool,262144);if(!work){pn_ntaml_release();return 0;}
 ok=pn_tables(readphys,0,found,&firmware,work,262144);ExFreePool(work);
 if(ok)pn_bindregs(&firmware,pn_ntreg_bind);
 pn_ntaml_done(ok&&firmware.off_ok);
#else
 work=ExAllocatePool(NonPagedPool,32768);if(!work)return 0;
 ok=pn_tables(readphys,0,found,&firmware,work,32768);ExFreePool(work);if(ok)pn_bindregs(&firmware,0);
#endif
 /* Stage 37xx = ACPI tables parsed; xx is pn_tables' diagnostic "where":
    0 RSDT/FADT not read, 2 FADT ok, 3 PM1 block, 4 PM1 ok, 5 DSDT read,
    6 AML load (DSDT/SSDT rejected by the bounded interpreter), 7 no usable
    \_S5, 8 _PTS verify. off_ok set (stage advances to 40/60) means a usable
    \_S5 + PM1 control was found. */
 mark(3700+firmware.where);
 return ok&&firmware.off_ok;
}
static int resident(PUCHAR base,ULONG size,ULONG rva,ULONG n) {
 ULONG p,last;
 if(!n||rva>=size||n>size-rva)return 0;
 p=((ULONG)base+rva)&~4095UL;last=((ULONG)base+rva+n-1)&~4095UL;
 for(;;p+=4096){if(!MmIsAddressValid((PVOID)p))return 0;if(p==last)break;}
 return 1;
}
static int name_is(PUCHAR base,ULONG size,ULONG rva,const char *name) {
 unsigned i;
 for(i=0;i<64;i++) {
  if(!resident(base,size,rva+i,1)||base[rva+i]!=(UCHAR)name[i])return 0;
  if(!name[i])return 1;
 }
 return 0;
}
static int find_kernel(void) {
 ULONG anchor=(ULONG)KeBugCheckEx,addr,tries,off=0,size=0,table;
 PUCHAR base=0,pe=0;
 /* Resolve the image base from a genuine imported kernel routine. Exact
    releases are recognised by build number; code locations are found by
    bounded unique patterns. No HAL import is changed. */
 mark(21);
 for(addr=anchor&~4095UL,tries=0;addr>=0x80000000UL&&tries<512;addr-=4096,tries++) {
  if(!MmIsAddressValid((PVOID)addr)||!MmIsAddressValid((PVOID)(addr+4095)))continue;
  base=(PUCHAR)addr;if(*(USHORT*)base!=0x5a4d)continue;
  off=*(ULONG*)(base+60);if(off>2048)continue;pe=base+off;
  if(*(ULONG*)pe!=0x4550||*(USHORT*)(pe+4)!=0x14c||*(USHORT*)(pe+20)!=224||*(USHORT*)(pe+24)!=0x10b)continue;
  size=*(ULONG*)(pe+80);if(anchor<addr||anchor-addr>=size)continue;
  /* The release family is identified later from which bounded shutdown
     pattern the resident code matches (prepare_io); no image identity
     table (timestamp, size, checksum or version field) is used. */
  kernel=base;kernel_size=size;
  break;
 }
 if(!kernel)return 0;
 section_count=*(USHORT*)(pe+6);table=off+24+224;
 if(!section_count||section_count>32||!resident(base,size,table,section_count*40))return 0;
 sections=base+table;kernel=base;kernel_size=size;mark(22);return 1;
}
static int executable(void *arg,unsigned long rva,unsigned long bytes) {
 unsigned i;(void)arg;
 if(!bytes||rva>=kernel_size||bytes>kernel_size-rva)return 0;
 for(i=0;i<section_count;i++) {
  PUCHAR s=sections+i*40;
  ULONG start=*(ULONG*)(s+12),n=*(ULONG*)(s+8),raw=*(ULONG*)(s+16),flags=*(ULONG*)(s+36);
  if(raw>n)n=raw;
  if(!(flags&0x20000000UL)||(flags&0x02000000UL)||start>=kernel_size||n>kernel_size-start)continue;
  if(rva>=start&&rva-start<n&&bytes<=n-(rva-start))return 1;
 }
 return 0;
}
static PVOID exported(const char *name) {
 ULONG pe=*(ULONG*)(kernel+60),rva=*(ULONG*)(kernel+pe+120),n=*(ULONG*)(kernel+pe+124);
 ULONG count,names,funcs,ords,i,functions;
 if(n<40||!resident(kernel,kernel_size,rva,n))return 0;
 functions=*(ULONG*)(kernel+rva+20);count=*(ULONG*)(kernel+rva+24);
 funcs=*(ULONG*)(kernel+rva+28);names=*(ULONG*)(kernel+rva+32);ords=*(ULONG*)(kernel+rva+36);
 if(!functions||functions>4096||!count||count>4096||
    !resident(kernel,kernel_size,funcs,functions*4)||
    !resident(kernel,kernel_size,names,count*4)||!resident(kernel,kernel_size,ords,count*2))return 0;
 for(i=0;i<count;i++)if(name_is(kernel,kernel_size,*(ULONG*)(kernel+names+i*4),name)) {
  ULONG index=*(USHORT*)(kernel+ords+i*2),target;
  if(index>=functions)return 0;
  target=*(ULONG*)(kernel+funcs+index*4);
  if(target>=kernel_size||(target>=rva&&target-rva<n))return 0;
  return kernel+target;
 }
 return 0;
}
static void release_section(void) {
 if(section_lock&&unlock_section){unlock_section(section_lock);section_lock=0;}
}
static int section_name(PUCHAR s,const char *name) {
 unsigned i;for(i=0;i<8;i++)if(s[i]!=(UCHAR)name[i])return 0;return 1;
}
static int prepare_variant(unsigned variant) {
 ULONG start=0,n=0;unsigned i,matches=0;LOCKSECTION lock_section;
 struct pn_shutmatch found;
 /* Select the executable section by its PE name, then scan a validated
    instruction pattern. Neither the callsite nor its target uses an RVA
    constant. Duplicate sections, duplicate matches and changed code fail. */
 for(i=0;i<section_count;i++) {
  PUCHAR s=sections+i*40;ULONG flags=*(ULONG*)(s+36);
  if(!(flags&0x20000000UL)||(flags&0x02000000UL))continue;
  if((variant==31&&!section_name(s,".text\0\0\0"))||
     (variant!=31&&!section_name(s,"PAGE\0\0\0\0")))continue;
  start=*(ULONG*)(s+12);n=*(ULONG*)(s+8);
  if(*(ULONG*)(s+16)>n)n=*(ULONG*)(s+16);
  matches++;
 }
 if(matches!=1||!executable(0,start,n))return 0;
 if(variant!=31) {
  /* Pin the selected PAGE section before scanning or changing its code. */
  lock_section=(LOCKSECTION)exported("MmLockPagableImageSection");
  unlock_section=(UNLOCKSECTION)exported("MmUnlockPagableImageSection");
  if(!lock_section||!unlock_section)return 0;
  section_lock=lock_section(kernel+start);if(!section_lock)return 0;
 }
 if(!resident(kernel,kernel_size,start,n)||
    !pn_shutfind(kernel+start,n,start,variant==31?31:351,executable,0,&found)||
    !resident(kernel,kernel_size,found.target_rva,1)) {
  release_section();return 0;
 }
 status[7]=variant;callsite=kernel+found.call_rva;original_io=(IOSTOP)(kernel+found.target_rva);
 call_displacement=found.displacement;return 1;
}
/* NT 3.1 keeps the shutdown path in .text; NT 3.5x in PAGE. Whichever
   bounded unique pattern matches identifies the family (31 or 35). */
static int prepare_io(void) {
 if(prepare_variant(31))return 1;
 return prepare_variant(35);
}
static int arm(void) {
 KIRQL old;ULONG cr0;int ok=0;
 KeRaiseIrql(HIGH_LEVEL,&old);
 __asm__ volatile("mov %%cr0,%0":"=r"(cr0)::"memory");
 /* UP + HIGH_LEVEL: recheck the discovered call before changing it. */
 if(callsite[0]==0xe8&&*(ULONG*)(callsite+1)==call_displacement) {
  ULONG writable=cr0&~0x10000UL;
  __asm__ volatile("mov %0,%%cr0"::"r"(writable):"memory");
  *(volatile ULONG*)(callsite+1)=(ULONG)completed_shutdown-(ULONG)(callsite+5);
  __asm__ volatile("mov %0,%%cr0"::"r"(cr0):"memory");
  ok=1;
 }
 KeLowerIrql(old);return ok;
}
static NTSTATUS NTAPI dispatch(PDEVICE_OBJECT dev,PIRP irp) {
 PIO_STACK_LOCATION s=IoGetCurrentIrpStackLocation(irp);NTSTATUS st=STATUS_INVALID_DEVICE_REQUEST;ULONG bytes=0;(void)dev;
 if(s->MajorFunction==IRP_MJ_CREATE||s->MajorFunction==IRP_MJ_CLOSE)st=STATUS_SUCCESS;
 else if(s->MajorFunction==IRP_MJ_SHUTDOWN){leg_latch();shutdown_seen=1;st=STATUS_SUCCESS;}
 else if(s->MajorFunction==IRP_MJ_DEVICE_CONTROL&&s->Parameters.DeviceIoControl.IoControlCode==0x00226000) {
  if(s->Parameters.DeviceIoControl.OutputBufferLength<sizeof(status))st=STATUS_BUFFER_TOO_SMALL;
  else{status[5]=shutdown_seen;RtlCopyMemory(irp->AssociatedIrp.SystemBuffer,status,sizeof(status));bytes=sizeof(status);st=STATUS_SUCCESS;}
 }
 else if(s->MajorFunction==IRP_MJ_DEVICE_CONTROL){
  st=leg_control(s->Parameters.DeviceIoControl.IoControlCode,irp->AssociatedIrp.SystemBuffer,
      s->Parameters.DeviceIoControl.InputBufferLength,s->Parameters.DeviceIoControl.OutputBufferLength,&bytes);
 }
 irp->IoStatus.Status=st;irp->IoStatus.Information=bytes;IoCompleteRequest(irp,IO_NO_INCREMENT);return st;
}
static NTSTATUS start_driver(PDRIVER_OBJECT driver,PUNICODE_STRING registry) {
 UNICODE_STRING name;PDEVICE_OBJECT dev;NTSTATUS st;
 KeInitializeSpinLock(&leg_lock);servicekey=registry;mark(10);status[8]=(ULONG)KeNumberProcessors;
#ifndef PN_AML
 if(KeNumberProcessors!=1)return STATUS_NOT_SUPPORTED;
#else
 /* Multiprocessor kernels: the patched call lies in the shutdown path,
    which no processor executes while the driver loads at system start. */
 if(KeNumberProcessors<1)return STATUS_NOT_SUPPORTED;
#endif
 if(!find_kernel())return STATUS_NOT_SUPPORTED;
 mark(36);if(!prepare_io())return STATUS_NOT_SUPPORTED;
#ifdef PN_AML
 /* discover() may fail when the machine has no ACPI; that is not fatal
    because an APM BIOS can still provide the power-off. ACPI is preferred. */
 mark(30);discover();if(!firmware.reduced)pn_apm_init();
 if(!firmware.off_ok&&!pn_apm_available()){release_section();return STATUS_NOT_SUPPORTED;}
#else
 mark(30);if(!discover()){release_section();return STATUS_NOT_SUPPORTED;}
#endif
 mark(40);RtlInitUnicodeString(&name,L"\\Device\\PN3LAB");RtlInitUnicodeString(&linkname,L"\\DosDevices\\PN3LAB");
 st=IoCreateDevice(driver,0,&name,FILE_DEVICE_UNKNOWN,0,FALSE,&dev);if(!NT_SUCCESS(st)){release_section();return st;}
 driver->MajorFunction[IRP_MJ_CREATE]=dispatch;driver->MajorFunction[IRP_MJ_CLOSE]=dispatch;
 driver->MajorFunction[IRP_MJ_DEVICE_CONTROL]=dispatch;driver->MajorFunction[IRP_MJ_SHUTDOWN]=dispatch;
 st=IoCreateSymbolicLink(&linkname,&name);if(!NT_SUCCESS(st)){IoDeleteDevice(dev);release_section();return st;}
 st=IoRegisterShutdownNotification(dev);
 if(!NT_SUCCESS(st)){IoDeleteSymbolicLink(&linkname);IoDeleteDevice(dev);release_section();return st;}
 status[0]=9;status[2]=firmware.rsdp_rev;status[3]=firmware.fadt_rev;status[4]=WP_FW_MINOR(firmware.fadt_rev,firmware.fadt_minor)|firmware.off_ok;
#ifdef PN_AML
 status[4]|=(pn_ntaml_tables()?4:0)|(pn_ntaml_prepared()?8:0)|(pn_apm_available()?16:0)|((ULONG)KeNumberProcessors<<8);
 status[6]=pn_apm_version();   /* APM BIOS version BCD (0 if unknown) */
#endif
 mark(50);if(!arm()){IoUnregisterShutdownNotification(dev);IoDeleteSymbolicLink(&linkname);IoDeleteDevice(dev);release_section();return STATUS_UNSUCCESSFUL;}
 status[1]=1;status[11]=1;driver->DriverUnload=0;dev->Flags&=~DO_DEVICE_INITIALIZING;mark(60);return STATUS_SUCCESS;
}

NTSTATUS NTAPI DriverEntry(PDRIVER_OBJECT driver,PUNICODE_STRING registry){
 NTSTATUS result=start_driver(driver,registry);
#ifdef PN_AML
 if(!NT_SUCCESS(result))pn_ntreg_release(&firmware);
#endif
 return result;
}
