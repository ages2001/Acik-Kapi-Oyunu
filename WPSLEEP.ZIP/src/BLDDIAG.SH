#!/bin/sh
# Read-only auxiliary drivers and diagnostics from the earlier GCC 13 build.
set -eu
cd "$(dirname "$0")"
sh BUILD3.SH
for arch in i686 x86_64; do
 cc="$arch-w64-mingw32-gcc"
 if [ "$arch" = i686 ]; then
  cpu="-march=i386 -mno-sse -mno-mmx"; out=X86; version=3.10
  app=_WinMainCRTStartup@0; driver=_DriverEntry@8
 else
  cpu=""; out=X64; version=5.2
  app=WinMainCRTStartup; driver=DriverEntry
 fi
 "$cc" $cpu -x c -Os -Wall -Wextra -Werror -nostdlib -ffreestanding -fno-stack-protector \
  -I"${DDK_ROOT:-/usr}/$arch-w64-mingw32/include/ddk" -D_WIN32_WINNT=0x0501 \
  -DNTDDI_VERSION=0x05010000 -DNTDDI_WINVISTA=0x06000000 -shared PNINFO.C ACPI.C \
  -Wl,--entry,"$driver",--subsystem,native,--image-base,0x10000 -o ../BIN/WINPWRNT/$out/PNINFO.SYS -lntoskrnl
 "$cc" $cpu -x c -Os -Wall -Wextra -fno-builtin -fno-stack-protector -nostdlib -mwindows \
  ../TEST/PNCHECK.C -Wl,--entry,"$app",--subsystem,windows:$version \
  -o ../BIN/WINPWRNT/$out/PNCHECK.EXE -lkernel32 -luser32 -ladvapi32
done
i686-w64-mingw32-gcc -x c -march=i386 -Os -Wall -Wextra -Werror \
 -fno-builtin -fno-stack-protector -nostdlib -mwindows -I. ../TEST/PNAUDIT.C PN9INI.C \
 -Wl,--entry,_WinMainCRTStartup@0,--subsystem,windows:4.0 -o ../BIN/WINPWR9X/LAB/PNAUDIT.EXE -luser32 -lkernel32 -ladvapi32
