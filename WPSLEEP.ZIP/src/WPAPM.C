/* Standalone DOS APM interface diagnostic. Never makes a power request. */
#include <stdio.h>
#include <string.h>
#include <dos.h>
#include <stddef.h>
#include "APMDATA.H"
unsigned __cdecl pn_cpu(void);
unsigned __cdecl wp_apmreal(void);
void __cdecl wp_apmregs(unsigned,struct wp_apm_raw *);
typedef char raw_flags_at_24[(offsetof(struct wp_apm_raw,flags)==24)?1:-1];
static int inwindows(void){
 union REGS in,out;memset(&in,0,sizeof(in));in.w.ax=0x1600;int86(0x2f,&in,&out);
 if(out.h.al&&out.h.al!=0x80)return 1;
 in.w.ax=0x4680;int86(0x2f,&in,&out);if(!out.w.ax)return 1;
 in.w.ax=0x160a;int86(0x2f,&in,&out);return !out.w.ax;
}
int main(int argc,char **argv){
 union REGS in,out;unsigned version,flags,mode=0,i;int valid;
 struct wp_apm_raw raw,disconnect;struct wp_apm_map map;
 if(argc>2||(argc==2&&stricmp(argv[1],"/16")&&stricmp(argv[1],"/32"))){puts("Usage: WPAPM [/16 | /32]");return 1;}
 if(argc==2)mode=!stricmp(argv[1],"/16")?16:32;
 puts("WINPOWER APM interface diagnostic 1.0");
 if(inwindows()){puts("Refused: leave Windows and run from standalone DOS.");return 2;}
 if(!pn_cpu()||!wp_apmreal()){puts("Requires a 386+ CPU in real mode; protected-mode DOS is refused.");return 2;}
 memset(&in,0,sizeof(in));in.w.ax=0x5300;int86(0x15,&in,&out);
 if(out.w.cflag||out.w.bx!=0x504d){puts("APM: N/A (installation check failed). No connection attempted.");return 3;}
 version=out.w.ax;flags=out.w.cx;
 printf("APM BIOS version: %X.%02X; flags: %04X\n",version>>8,version&255,flags);
 printf("16-bit interface: %s; 32-bit interface: %s\n",flags&1?"yes":"no",flags&2?"yes":"no");
 printf("BIOS power management: %s; disengaged flag: %s\n",flags&8?"disabled":"enabled",flags&16?"set":"clear");
 if(!mode){puts("Status only. No connection or power state was changed.");return 0;}
 if(!(flags&(mode==32?2:1))){puts("Requested interface is not advertised. No connection attempted.");return 3;}
 memset(&raw,0,sizeof(raw));memset(&disconnect,0,sizeof(disconnect));
 wp_apmregs(mode==32?0x5303:0x5302,&raw);
 if(raw.flags&1){printf("Connection refused; APM error %02lX. Existing connections were not disconnected.\n",(unsigned long)((raw.ax>>8)&255));return 4;}
 /* Disconnect before any DOS I/O, formatting, decoding or return path.
    Never disconnect after a failed connect: another owner may be active. */
 wp_apmregs(0x5304,&disconnect);
 printf("%u-bit connection entry: %04lX:%08lX\n",mode,(unsigned long)(raw.ax&0xffffUL),(unsigned long)(mode==32?raw.bx:raw.bx&0xffffUL));
 printf("Returned CX=%04lX DX=%04lX ESI=%08lX DI=%04lX\n",(unsigned long)(raw.cx&0xffffUL),(unsigned long)(raw.dx&0xffffUL),(unsigned long)raw.si,(unsigned long)(raw.di&0xffffUL));
 if(disconnect.flags&1){printf("Disconnect failed; APM error %02lX. Restart before using another power manager.\n",(unsigned long)((disconnect.ax>>8)&255));return 5;}
 puts("Temporary connection disconnected. No power request was made.");
 valid=wp_apm_decode(version,flags,mode,&raw,&map);
 if(!valid){puts("Descriptor layout is outside the validated mapping profile.");return 6;}
 for(i=0;i<map.count;i++)printf("Segment %u: physical base %08lX, bytes %lu\n",i,(unsigned long)map.base[i],(unsigned long)map.length[i]);
 puts("Descriptor layout accepted. No GDT, kernel mapping or far call was installed.");
 puts("These disconnected addresses are diagnostic data, not a kernel handoff.");return 0;
}
