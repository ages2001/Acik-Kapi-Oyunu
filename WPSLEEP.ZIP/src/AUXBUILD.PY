"""Complete a clean build with the auxiliary tools from the original release."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import struct
import subprocess
import sys
import tempfile


def read32(data, offset):
    return struct.unpack_from("<I", data, offset)[0]


def set_release_time(data, timestamp):
    """Restore link times and the associated PE checksum on a compiler output."""
    image = bytearray(data)
    pe = read32(image, 60)
    if image[pe:pe + 4] != b"PE\0\0":
        raise ValueError("A PE file was expected")
    original = read32(image, pe + 8)
    struct.pack_into("<I", image, pe + 8, timestamp)
    optional = pe + 24
    kind = struct.unpack_from("<H", image, optional)[0]
    data_directory = optional + {0x10B: 96, 0x20B: 112}[kind]
    export_rva = read32(image, data_directory)
    if export_rva:
        table = optional + struct.unpack_from("<H", image, pe + 20)[0]
        count = struct.unpack_from("<H", image, pe + 6)[0]
        for section in range(table, table + count * 40, 40):
            address, raw_size, raw_start = struct.unpack_from("<III", image, section + 12)
            if address <= export_rva < address + raw_size:
                stamp = raw_start + export_rva - address + 4
                if read32(image, stamp) == original:
                    struct.pack_into("<I", image, stamp, timestamp)
                break
        else:
            raise ValueError("The export directory is outside the image sections")
    checksum_field = optional + 64
    struct.pack_into("<I", image, checksum_field, 0)
    aligned = image + bytes(len(image) % 2)
    checksum = sum(word[0] for word in struct.iter_unpack("<H", aligned))
    while checksum >> 16:
        checksum = (checksum & 65535) + (checksum >> 16)
    struct.pack_into("<I", image, checksum_field, checksum + len(image))
    return image


def legacy_environment(stage):
    tools = Path(os.environ["MINGW13_BIN"]).resolve()
    aliases = stage / "cc13"
    aliases.mkdir()
    for arch in ("i686", "x86_64"):
        name = arch + "-w64-mingw32-gcc"
        compiler = tools / (name + "-win32")
        if not compiler.exists():
            compiler = tools / name
        version = subprocess.check_output([compiler, "-dumpversion"], text=True).strip()
        if version.split("-")[0].split(".")[0] != "13":
            raise ValueError("GCC 13 is required for the older diagnostics: " + str(compiler))
        (aliases / name).symlink_to(compiler)
    return dict(os.environ, PATH=os.pathsep.join((str(aliases), str(tools), os.environ["PATH"])),
                DDK_ROOT=os.environ.get("MINGW13_DDK", str(tools.parent)))


def main():
    stage, project, output = (Path(value).resolve() for value in sys.argv[1:])
    src = stage / "src"
    # These four installer builds used the preceding Program Manager helper.
    # The firmware GUIs and legacy NT/9x installers already exist in the stage.
    current = (src / "NTDDE.C").read_bytes()
    try:
        shutil.copyfile(src / "NTAUX" / "NTDDE.C", src / "NTDDE.C")
        for script in ("BLDSET5.SH", "BLDMOD.SH"):
            subprocess.run(["sh", str(src / script)], cwd=src, check=True)
    finally:
        (src / "NTDDE.C").write_bytes(current)
    for name in ("PNCHECK.C", "PNAUDIT.C"):
        shutil.copyfile(stage / "test" / name, stage / "TEST" / name)
    subprocess.run(["sh", str(src / "BLDDIAG.SH")], cwd=src, check=True, env=legacy_environment(stage))

    ready = stage / "out"
    for line in (src / "AUXFILES.TXT").read_text("ascii").splitlines():
        if not line or line.startswith("#"):
            continue
        group, epoch, destination, origin = line.split()
        data = (stage / origin).read_bytes()
        if group != "asset":
            data = set_release_time(data, int(epoch))
        (ready / destination).write_bytes(data)

    expected = json.loads((project / "test" / "SLPFILES.JSN").read_text())
    actual = {"bin/" + f.relative_to(ready).as_posix(): hashlib.sha256(f.read_bytes()).hexdigest()
              for f in ready.rglob("*") if f.is_file()}
    if actual != expected:
        changed = sorted(key for key in actual.keys() | expected.keys() if actual.get(key) != expected.get(key))
        raise ValueError("Clean build mismatch: " + ", ".join(changed))
    output.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(dir=output.parent) as directory:
        staged = Path(directory) / "bin"
        shutil.copytree(ready, staged)
        staged.rename(output)
    print("Clean build: regenerated and verified all %d ready files in %s" % (len(actual), output))


if __name__ == "__main__":
    main()
