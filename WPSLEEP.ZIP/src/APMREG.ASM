.model large,c
.386
.code
public wp_apmregs, wp_apmreal
; Caller must establish a 386+ CPU before either procedure is called.
wp_apmreal proc far
 smsw ax
 and ax,1
 xor ax,1
 ret
wp_apmreal endp
; void cdecl far wp_apmregs(unsigned function, struct wp_apm_raw far *out)
; Six DWORD outputs followed by the WORD flags, independent of C padding.
wp_apmregs proc far
 push bp
 mov bp,sp
 push ebx
 push ecx
 push edx
 push esi
 push edi
 push ds
 push es
 xor eax,eax
 mov ax,[bp+6]
 xor ebx,ebx
 xor ecx,ecx
 xor edx,edx
 xor esi,esi
 xor edi,edi
 push bp
 int 15h
 pop bp
 pushf
 push eax
 push ebx
 push ecx
 push edx
 push esi
 push edi
 les di,dword ptr [bp+8]
 pop eax
 mov es:[di+20],eax
 pop eax
 mov es:[di+16],eax
 pop eax
 mov es:[di+12],eax
 pop eax
 mov es:[di+8],eax
 pop eax
 mov es:[di+4],eax
 pop eax
 mov es:[di],eax
 pop ax
 mov es:[di+24],ax
 pop es
 pop ds
 pop edi
 pop esi
 pop edx
 pop ecx
 pop ebx
 pop bp
 ret
wp_apmregs endp
end
