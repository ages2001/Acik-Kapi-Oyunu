/* Windows coordinates device state, application notifications and the resume image. */
#include "SLPCAPS.H"
#include <powrprof.h>
#include "SLPVIDEO.H"
typedef BOOLEAN (WINAPI *wp_caps_fn)(SYSTEM_POWER_CAPABILITIES *);
typedef BOOLEAN (WINAPI *wp_allowed_fn)(void);
typedef BOOLEAN (WINAPI *wp_suspend_fn)(BOOLEAN,BOOLEAN,BOOLEAN);
typedef BOOL (WINAPI *wp_old_suspend_fn)(BOOL,BOOL);
typedef LONG (WINAPI *wp_min_sleep_fn)(ULONG,ULONG,ULONG,BOOLEAN);
static struct wp_sleep_caps wp_sleep;
static HMODULE wp_prof;
static wp_caps_fn wp_caps_query;
static wp_allowed_fn wp_can_suspend,wp_can_hibernate;
static wp_suspend_fn wp_set_sleep;
static wp_old_suspend_fn wp_set_old;
static wp_min_sleep_fn wp_set_min;
static BOOL wp_sleep_busy;

static void wp_sleep_open(void)
{
    char path[MAX_PATH];
    UINT length=GetSystemDirectoryA(path,sizeof(path));
    if(length && length+sizeof("\\POWRPROF.DLL")<=sizeof(path)){
        lstrcatA(path,"\\POWRPROF.DLL");
        wp_prof=LoadLibraryA(path);
    }
    if(wp_prof){
        wp_caps_query=(wp_caps_fn)GetProcAddress(wp_prof,"GetPwrCapabilities");
        wp_can_suspend=(wp_allowed_fn)GetProcAddress(wp_prof,"IsPwrSuspendAllowed");
        wp_can_hibernate=(wp_allowed_fn)GetProcAddress(wp_prof,"IsPwrHibernateAllowed");
        wp_set_sleep=(wp_suspend_fn)GetProcAddress(wp_prof,"SetSuspendState");
    }
    wp_set_old=(wp_old_suspend_fn)GetProcAddress(GetModuleHandleA("KERNEL32.DLL"),"SetSystemPowerState");
    if(os.dwPlatformId==VER_PLATFORM_WIN32_NT && os.dwMajorVersion>=5)
        wp_set_min=(wp_min_sleep_fn)GetProcAddress(GetModuleHandleA("NTDLL.DLL"),"NtInitiatePowerAction");
}
static void wp_sleep_refresh(void)
{
    SYSTEM_POWER_CAPABILITIES caps;
    BOOL known,pe=FALSE;
    int suspend_policy=WP_UNKNOWN,hibernate_policy=WP_UNKNOWN;
    ZeroMemory(&caps,sizeof(caps));
    known=wp_caps_query && wp_caps_query(&caps);
    if(wp_can_suspend)suspend_policy=wp_can_suspend()?WP_YES:WP_NO;
    else if(!known && os.dwPlatformId==VER_PLATFORM_WIN32_WINDOWS && wp_set_old)
        suspend_policy=WP_YES; /* Original Windows 95 can ask its APM driver. */
    if(wp_can_hibernate)hibernate_policy=wp_can_hibernate()?WP_YES:WP_NO;
#ifdef WP_MODERN
    pe=pe_mode;
#endif
    wp_sleep_decode(&wp_sleep,known?(const unsigned char *)&caps:NULL,
        os.dwMajorVersion,os.dwMinorVersion,wp_set_sleep||wp_set_old,suspend_policy,
        wp_set_sleep||wp_set_old,hibernate_policy,pe);
}
static const char *wp_state_word(unsigned v)
{
    if(v==WP_UNKNOWN)return "N/A";
    return v==WP_YES?"Available":"Unavailable";
}
static void wp_sleep_display(HWND dialog, BOOL init)
{
    HWND combo=GetDlgItem(dialog,152);
    const char *text;
    char states[420],item[48],video[240];
    unsigned i;LRESULT index;
    wp_sleep_refresh();
    wsprintfA(states,"S0   Working  (current session)\r\nS0   Low Power Idle  /  %s\r\n"
        "S1   Standby  /  %s\r\nS2   Standby  /  %s\r\nS3   Suspend to RAM  /  %s\r\n"
        "S4   Hibernate to disk  /  %s\r\nS5   Soft off  /  %s",
        wp_state_word(wp_sleep.low_idle),wp_state_word(wp_sleep.state[1]),
        wp_state_word(wp_sleep.state[2]),wp_state_word(wp_sleep.state[3]),
        wp_state_word(wp_sleep.state[4]),wp_state_word(wp_sleep.state[5]));
    SetDlgItemTextA(dialog,151,states);
    wp_sleep_video(video,sizeof(video));
    SetDlgItemTextA(dialog,156,video);
    if(init){
        SendMessageA(combo,CB_RESETCONTENT,0,0);
        index=SendMessageA(combo,CB_ADDSTRING,0,(LPARAM)"Windows policy");
        SendMessageA(combo,CB_SETITEMDATA,index,0);
        if(wp_set_min)for(i=1;i<=3;i++)if(wp_sleep.state[i]==WP_YES){
            wsprintfA(item,"S%u or deeper",i);
            index=SendMessageA(combo,CB_ADDSTRING,0,(LPARAM)item);
            SendMessageA(combo,CB_SETITEMDATA,index,i);
        }
        SendMessageA(combo,CB_SETCURSEL,0,0);
    }
    EnableWindow(combo,wp_sleep.suspend && SendMessageA(combo,CB_GETCOUNT,0,0)>1);
    EnableWindow(GetDlgItem(dialog,154),wp_sleep.suspend && !wp_sleep_busy);
    EnableWindow(GetDlgItem(dialog,155),wp_sleep.hibernate && !wp_sleep_busy);
    text="Windows chooses a supported suspend state and keeps wake events enabled.";
    if(wp_sleep.state[4]==WP_YES && wp_sleep.file_present==WP_NO)
        text="Windows reports S4. A hibernation file is required to restore this session.";
    else if(wp_sleep.reduced_file)
        text="The reduced hibernation file supports Fast Startup. Full hibernation needs a full file.";
    else if(!wp_sleep.suspend && !wp_sleep.hibernate)
        text="This Windows installation has no available session sleep operation.";
#ifdef WP_MODERN
    if(pe_mode)text="Windows PE does not provide session suspend or hibernation.";
#endif
    SetDlgItemTextA(dialog,153,text);
}
static void wp_sleep_request(HWND dialog,BOOL hibernate)
{
    DWORD bytes=0,err=0;HANDLE token=NULL;
    TOKEN_PRIVILEGES want,original;BOOL adjusted=FALSE,ok=FALSE;
    HWND combo=GetDlgItem(dialog,152);
    LRESULT index=SendMessageA(combo,CB_GETCURSEL,0,0);
    ULONG minimum=index==CB_ERR?0:(ULONG)SendMessageA(combo,CB_GETITEMDATA,index,0);
    LONG native_status=0;
    if(wp_sleep_busy)return;
    wp_sleep_refresh();
    if(hibernate?!wp_sleep.hibernate:!wp_sleep.suspend){wp_sleep_display(dialog,FALSE);return;}
    if(!hibernate && minimum && (minimum>3 || !wp_set_min || wp_sleep.state[minimum]!=WP_YES)){
        wp_sleep_display(dialog,TRUE);return;
    }
    if(MessageBoxA(dialog,hibernate?"Hibernate this session to disk?":"Suspend this session?",
                   "WINPOWER",MB_YESNO|MB_ICONQUESTION|MB_DEFBUTTON2)!=IDYES)return;
    if(os.dwPlatformId==VER_PLATFORM_WIN32_NT){
        if(!OpenProcessToken(GetCurrentProcess(),TOKEN_ADJUST_PRIVILEGES|TOKEN_QUERY,&token)){
            error(dialog,"Cannot open the process token.");return;
        }
        want.PrivilegeCount=1;want.Privileges[0].Attributes=SE_PRIVILEGE_ENABLED;
        if(!LookupPrivilegeValueA(NULL,"SeShutdownPrivilege",&want.Privileges[0].Luid)){err=GetLastError();goto done;}
        bytes=sizeof(original);SetLastError(ERROR_SUCCESS);
        if(!AdjustTokenPrivileges(token,FALSE,&want,sizeof(original),&original,&bytes)){err=GetLastError();goto done;}
        err=GetLastError();if(err)goto done;
        adjusted=TRUE;
    }
    wp_sleep_busy=TRUE;
    EnableWindow(GetDlgItem(dialog,154),FALSE);EnableWindow(GetDlgItem(dialog,155),FALSE);
    if(!hibernate && minimum){
        /* PowerActionSleep=2. PowerSystemSleeping1..3=2..4. These are minima.
           QUERY_ALLOWED and UI_ALLOWED preserve application and driver consent. */
        native_status=wp_set_min(2,minimum+1,3,FALSE);
        ok=native_status>=0;
    }
#ifdef WP_WIN9X_STATUS
    else if(os.dwPlatformId==VER_PLATFORM_WIN32_WINDOWS && wp_set_old)
        ok=wp_set_old(!hibernate,FALSE);
#endif
    else if(wp_set_sleep)ok=wp_set_sleep((BOOLEAN)hibernate,FALSE,FALSE);
    else if(wp_set_old)ok=wp_set_old(!hibernate,FALSE);
    if(!ok && native_status>=0){err=GetLastError();if(!err)err=ERROR_NOT_SUPPORTED;}
done:
    if(adjusted)AdjustTokenPrivileges(token,FALSE,&original,0,NULL,NULL);
    if(token)CloseHandle(token);
    wp_sleep_busy=FALSE;
    wp_sleep_display(dialog,FALSE);
    if(native_status<0){
        char msg[100];wsprintfA(msg,"Windows declined this minimum sleep level (NTSTATUS 0x%08lX).",native_status);
        MessageBoxA(dialog,msg,"WINPOWER",MB_OK|MB_ICONEXCLAMATION);
    }else if(err){SetLastError(err);error(dialog,"Windows could not complete the sleep request.");}
    else if(ok)SetDlgItemTextA(dialog,153,"Windows accepted the requested power transition.");
}
static INT_PTR CALLBACK wp_sleep_dialog(HWND h,UINT m,WPARAM w,LPARAM l)
{
    switch(m){
    case WM_INITDIALOG:wp_sleep_open();wp_sleep_display(h,TRUE);return TRUE;
    case WM_DRAWITEM:{
        LPDRAWITEMSTRUCT d=(LPDRAWITEMSTRUCT)l;
        if(d->CtlID==154||d->CtlID==155){pn_button(d,inst,d->CtlID==154?12:13,bodyfont,bodybrush);return TRUE;}
        break;
    }
    case WM_POWERBROADCAST:
        if(!wp_sleep_busy)wp_sleep_display(h,FALSE);
        return TRUE;
    case WM_COMMAND:
        if(LOWORD(w)==154||LOWORD(w)==155){wp_sleep_request(h,LOWORD(w)==155);return TRUE;}
        if(LOWORD(w)!=IDOK && LOWORD(w)!=IDCANCEL)break;
        /* fall through */
    case WM_CLOSE:
        if(!wp_sleep_busy)EndDialog(h,0);
        return TRUE;
    case WM_DESTROY:
        if(wp_prof)FreeLibrary(wp_prof);
        wp_prof=NULL;wp_caps_query=NULL;wp_can_suspend=NULL;wp_can_hibernate=NULL;wp_set_sleep=NULL;wp_set_old=NULL;wp_set_min=NULL;
        return TRUE;
    }
    return FALSE;
}
