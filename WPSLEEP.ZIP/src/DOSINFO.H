/* DOS family/version detection safe on DOS 2.0 and later. */
#ifndef DOSINFO_H
#define DOSINFO_H
struct pn_dos {
 unsigned char major,minor;      /* Reported version (AH=30h). */
 unsigned char true_major,true_minor; /* AX=3306h when available. */
 unsigned char oem;              /* OEM identifier from AH=30h. */
 unsigned char flags;            /* PN_DOS_* below. */
 unsigned char vendor;           /* PN_VENDOR_* below. */
 unsigned char reserved;
 unsigned drdos;                 /* DR-DOS internal version, or 0. */
};
#define PN_DOS_TRUEVER 1   /* AX=3306h returned a version. */
#define PN_DOS_HMA     2   /* DOS kernel resides in the HMA. */
#define PN_DOS_ROM     4   /* DOS kernel resides in ROM. */
#define PN_DOS_INT2F   8   /* INT 2Fh vector is installed. */
#define PN_DOS_WIN9X  16   /* Windows 9x/ME MS-DOS 7/8 kernel. */
#define PN_VENDOR_UNKNOWN 0
#define PN_VENDOR_MS      1
#define PN_VENDOR_IBM     2
#define PN_VENDOR_DR      3
#define PN_VENDOR_FREE    4
#define PN_VENDOR_OTHER   5
/* Fills info; never fails. */
void pn_dosinfo(struct pn_dos *info);
/* Writes a short name such as "MS-DOS 6.22" (at least 40 bytes). */
void pn_dosname(const struct pn_dos *info,char *out);
/* Nonzero when INT 2Fh can be called without jumping through a null vector. */
int pn_int2f_ok(void);
/* Nonzero when a Windows/DOS multitasker reports itself active. */
int pn_inwindows(void);
#endif
