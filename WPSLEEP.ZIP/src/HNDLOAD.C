/* Load/query the reviewed NT5 driver for this boot. No firmware IOCTLs. */
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
void *memset(void *p,int c,size_t n){unsigned char*q=p;while(n--)*q++=c;return p;}
static HANDLE device(void){return CreateFileA("\\\\.\\PN5LAB",GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,0,OPEN_EXISTING,0,0);}
void WINAPI WinMainCRTStartup(void){
 OSVERSIONINFOA os;SC_HANDLE manager=0,service=0;HANDLE d;DWORD v[8],n,error=0,mode=0;char path[MAX_PATH],message[512];int i,legacy=0;
 ZeroMemory(&os,sizeof(os));os.dwOSVersionInfoSize=sizeof(os);GetVersionExA(&os);
 if(os.dwPlatformId!=VER_PLATFORM_WIN32_NT||os.dwMajorVersion!=5||os.dwMinorVersion>2){
  MessageBoxA(0,"This loader requires Windows 2000, XP or Server 2003.","WINPOWER",MB_OK|MB_ICONEXCLAMATION);ExitProcess(1);
 }
 d=device();
 if(d==INVALID_HANDLE_VALUE){
  n=GetModuleFileNameA(0,path,sizeof(path));if(!n||n>=sizeof(path)){error=ERROR_INVALID_NAME;goto done;}
  for(i=(int)n-1;i>=0&&path[i]!='\\';i--){}if(i<0||i>MAX_PATH-14){error=ERROR_INVALID_NAME;goto done;}
  lstrcpyA(path+i+1,os.dwMinorVersion==0?"W2KHOOK.SYS":"PN5HOOK.SYS");
  if(MessageBoxA(0,"Load the WINPOWER final power driver for this boot?\r\nOS control remains the default. A restart unloads this driver.\r\nKeep this package folder available until then.\r\nSee HNDSTAT.TXT for the tested kernel profiles.","WINPOWER handoff loader",MB_YESNO|MB_DEFBUTTON2|MB_ICONQUESTION)!=IDYES)ExitProcess(0);
  manager=OpenSCManagerA(0,0,SC_MANAGER_CREATE_SERVICE);if(!manager){error=GetLastError();goto done;}
  service=CreateServiceA(manager,"WP5LOAD","WINPOWER handoff loader",SERVICE_START|DELETE,SERVICE_KERNEL_DRIVER,SERVICE_DEMAND_START,SERVICE_ERROR_NORMAL,path,0,0,0,0,0);
  if(!service){error=GetLastError();goto done;}
  if(!StartServiceA(service,0,0)){error=GetLastError();goto done;}
  d=device();if(d==INVALID_HANDLE_VALUE){error=GetLastError();goto done;}
 }
 if(!DeviceIoControl(d,0x226000,0,0,v,sizeof(v),&n,0)||n!=sizeof(v)){error=ERROR_INVALID_DATA;CloseHandle(d);goto done;}
 if(v[0]==5){
  if(!DeviceIoControl(d,0x22600c,&mode,sizeof(mode),0,0,&n,0)||
     !DeviceIoControl(d,0x226000,0,0,v,sizeof(v),&n,0)||n!=sizeof(v)||(v[5]&1)){
   error=GetLastError();if(!error)error=ERROR_INVALID_DATA;
  }
  CloseHandle(d);
  if(!error)legacy=1;
  goto done;
 }
 if(v[0]!=6||v[1]!=1||!(v[5]&0x100))error=ERROR_NOT_SUPPORTED;
 CloseHandle(d);
 done:
 if(service){if(!DeleteService(service)&&!error)error=GetLastError();CloseServiceHandle(service);}
 if(manager)CloseServiceHandle(manager);
 if(error)wsprintfA(message,"The final handoff is not available. Windows error: %lu.\r\nNo immediate power request was issued. See HNDSTAT.TXT.",error);
 else if(legacy)lstrcpyA(message,"The older NT5 driver has been returned to OS control. Restart Windows, then run this loader again to load the updated driver.");
 else lstrcpyA(message,"The updated driver is loaded for this boot. Open WINPWRNT.EXE to view or change OS/Driver control. All power requests use normal Windows shutdown.");
 MessageBoxA(0,message,"WINPOWER handoff loader",MB_OK|(error?MB_ICONEXCLAMATION:MB_ICONINFORMATION));ExitProcess(error?1:0);
}
