#define WIN32_LEAN_AND_MEAN
#include <windows.h>
void *memset(void *p,int c,size_t n){unsigned char*q=p;while(n--)*q++=(unsigned char)c;return p;}
static DWORD basic_info(void) {
 typedef LONG (WINAPI *QUERY)(ULONG,PVOID,ULONG,PULONG);
 QUERY query=(QUERY)GetProcAddress(GetModuleHandleA("NTDLL.DLL"),"NtQuerySystemInformation");
 DWORD basic[11],got=0;HKEY key;LONG error;
 if(!query||query(0,basic,sizeof(basic),&got)<0||got!=sizeof(basic))return ERROR_NOT_SUPPORTED;
 if(basic[2]!=4096||basic[6]!=65536)return ERROR_INVALID_DATA;
 error=RegOpenKeyExA(HKEY_LOCAL_MACHINE,"System\\CurrentControlSet\\Services\\PN3LAB",0,KEY_SET_VALUE,&key);
 if(error)return error;
 error=RegSetValueExA(key,"BasicInfo",0,REG_BINARY,(BYTE*)basic,sizeof(basic));RegCloseKey(key);return error;
}
static DWORD configure(int restore){
 const char *setting="Software\\Microsoft\\Windows NT\\CurrentVersion\\Winlogon";
 const char *backup="Software\\WINPOWER\\NT3LAB";
 struct {DWORD type,present,size;BYTE value[256];} record;
 HKEY key=0,saved=0;DWORD type,n,disp;LONG error;
 error=RegOpenKeyExA(HKEY_LOCAL_MACHINE,setting,0,KEY_QUERY_VALUE|KEY_SET_VALUE,&key);if(error)return error;
 if(restore)error=RegOpenKeyExA(HKEY_LOCAL_MACHINE,backup,0,KEY_QUERY_VALUE,&saved);
 else error=RegCreateKeyExA(HKEY_LOCAL_MACHINE,backup,0,0,0,KEY_QUERY_VALUE|KEY_SET_VALUE,0,&saved,&disp);
 if(error){RegCloseKey(key);return error;}
 n=sizeof(record);error=RegQueryValueExA(saved,"Saved",0,&type,(BYTE*)&record,&n);
 if(error==ERROR_FILE_NOT_FOUND&&!restore){
  ZeroMemory(&record,sizeof(record));record.size=sizeof(record.value);
  error=RegQueryValueExA(key,"PowerdownAfterShutdown",0,&record.type,record.value,&record.size);
  if(error==ERROR_FILE_NOT_FOUND){record.size=0;error=0;}else if(!error)record.present=1;
  if(!error){n=12+record.size;type=REG_BINARY;error=RegSetValueExA(saved,"Saved",0,type,(BYTE*)&record,n);}
 }
 if(!error&&(type!=REG_BINARY||n<12||record.size>256||n!=12+record.size||record.present>1))error=ERROR_INVALID_DATA;
 if(!error){
  if(!restore)error=RegSetValueExA(key,"PowerdownAfterShutdown",0,REG_SZ,(const BYTE*)"1",2);
  else if(record.present)error=RegSetValueExA(key,"PowerdownAfterShutdown",0,record.type,record.value,record.size);
  else {error=RegDeleteValueA(key,"PowerdownAfterShutdown");if(error==ERROR_FILE_NOT_FOUND)error=0;}
 }
 RegCloseKey(saved);RegCloseKey(key);
 if(!error&&restore)error=RegDeleteKeyA(HKEY_LOCAL_MACHINE,backup);
 return error;
}
void WINAPI WinMainCRTStartup(void){
 char path[MAX_PATH],result[768];SC_HANDLE manager=0,svc=0;HANDLE d;DWORD got,err=0,step=0,stage=0,v[12];int i,inspect=0,off=0,apm=0,deleted=0;
 {LPSTR cmd=GetCommandLineA();if(*cmd=='"'){cmd++;while(*cmd&&*cmd!='"')cmd++;if(*cmd)cmd++;}else while(*cmd&&*cmd!=' ')cmd++;
  while(*cmd==' ')cmd++;
  inspect=!lstrcmpiA(cmd,"/STATUS");off=!lstrcmpiA(cmd,"/OFF");apm=!lstrcmpiA(cmd,"/APM");if(!lstrcmpiA(cmd,"/RESTORE")){err=configure(1);wsprintfA(result,"Restore original Winlogon setting: error %lu",err);MessageBoxA(0,result,"WINPOWER NT3 Lab",MB_OK);ExitProcess(err?1:0);}}
 if(!inspect&&!off&&!apm&&MessageBoxA(0,"Known NT3 x86 uniprocessor kernel research test.\r\nThis redirects a dynamically located final I/O call.\r\nIt cannot unload while armed. Use a disposable VM copy.\r\n\r\nArm the experimental shim for this boot?","WINPOWER NT3 Lab",MB_YESNO|MB_DEFBUTTON2|MB_ICONEXCLAMATION)!=IDYES)ExitProcess(0);
 GetModuleFileNameA(0,path,sizeof(path));for(i=lstrlenA(path)-1;i>=0&&path[i]!='\\';--i){}path[i+1]=0;lstrcatA(path,"PN3HOOK.SYS");
 ZeroMemory(v,sizeof(v));if(inspect)goto query;manager=OpenSCManagerA(0,0,SC_MANAGER_CREATE_SERVICE);if(!manager){err=GetLastError();step=1;goto done;}
 svc=CreateServiceA(manager,"PN3LAB","WINPOWER NT3 research test",SERVICE_START|SERVICE_STOP|DELETE,SERVICE_KERNEL_DRIVER,SERVICE_DEMAND_START,SERVICE_ERROR_NORMAL,path,0,0,0,0,0);
 if(!svc){DWORD ce=GetLastError();
  if(ce==ERROR_SERVICE_EXISTS)svc=OpenServiceA(manager,"PN3LAB",SERVICE_START|SERVICE_STOP|DELETE|SERVICE_QUERY_STATUS);
  if(!svc){err=ce;step=2;goto done;}}
 err=basic_info();if(err){step=8;goto done;}
 if(!StartServiceA(svc,0,0)){DWORD se=GetLastError();if(se!=ERROR_SERVICE_ALREADY_RUNNING){err=se;step=3;goto done;}}
 query:
 d=CreateFileA("\\\\.\\PN3LAB",GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,0,OPEN_EXISTING,0,0);
 if(d==INVALID_HANDLE_VALUE){err=GetLastError();step=4;goto done;}
 if(!DeviceIoControl(d,0x00226000,0,0,v,sizeof(v),&got,0)){err=GetLastError();step=5;}
 else if(got!=sizeof(v)||v[0]!=9||v[1]!=1||v[11]!=1||(v[4]&~0xff1fUL)||!(v[4]&0x11)){err=ERROR_INVALID_DATA;step=5;}
 else if(off){DeviceIoControl(d,0x00226004,0,0,0,0,&got,0);/* production power-off path */}
 else if(apm){DeviceIoControl(d,0x00226008,0,0,0,0,&got,0);/* APM-only path */}
 CloseHandle(d);
 done:
 {HKEY k;DWORD size=4;if(!RegOpenKeyExA(HKEY_LOCAL_MACHINE,"System\\CurrentControlSet\\Services\\PN3LAB",0,KEY_QUERY_VALUE,&k)){RegQueryValueExA(k,"Stage",0,0,(BYTE*)&stage,&size);RegCloseKey(k);}}
 if(svc){deleted=DeleteService(svc);if(!deleted&&!err){err=GetLastError();step=7;}CloseServiceHandle(svc);}if(manager)CloseServiceHandle(manager);
 wsprintfA(result,"NT3 final-power research test\r\nStep: %lu  Error: %lu  Kernel stage: %lu\r\nArmed: %lu  RSDP: %lu  FADT: %lu\r\nCapabilities: %lu  Shutdown seen: %lu\r\nKernel: %lu  CPUs: %lu  Memory limit: %lu MiB\r\nFinal I/O hook: %lu  Completed calls: %lu\r\n\r\n%s\r\n%s\r\n%s",step,err,stage,v[1],v[2],v[3],v[4],v[5],v[7],v[8],v[9]>>20,v[11],v[10],
  v[1]?"The armed shim stays resident until reboot.":"No active shim was reported.",
  inspect?"Status query only; no settings changed.":(deleted?"Temporary service marked for deletion.":"See the reported step/error before continuing."),
  "No Winlogon setting is changed by this version.");
 MessageBoxA(0,result,"WINPOWER NT3 Lab result",MB_OK|(err?MB_ICONEXCLAMATION:MB_ICONINFORMATION));ExitProcess(err?1:0);
}
