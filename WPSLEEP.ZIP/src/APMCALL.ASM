; Open Watcom large-model DOS interface. Firmware sees only the APM requests
; in APMSEQ.S. Preserve the C caller's nonvolatile and segment registers.
.286
.model large,c
.code
public wp_apmoff
wp_apmoff proc far
 push bx
 push si
 push di
 push ds
 push es
 call apm_sequence
 pop es
 pop ds
 pop di
 pop si
 pop bx
 ret
wp_apmoff endp
apm_sequence proc near
 include APMSEQ.INC
apm_sequence endp
end
