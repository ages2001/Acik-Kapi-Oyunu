#!/bin/sh
# GUI-only alias; retain tested drivers and installers.
set -eu
exec sh "$(dirname "$0")/BUILDUI.SH" gui "$@"
