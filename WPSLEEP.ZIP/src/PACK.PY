"""Verify every extracted file and make the WINPOWER v1.0 sleep distribution."""
import argparse
import hashlib
from pathlib import Path
import re
import tempfile
import zipfile


def digest(data):
    return hashlib.sha256(data).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('output', nargs='?', type=Path, help='optional ZIP path outside the extracted project')
    args = parser.parse_args()
    root = Path(__file__).resolve().parent.parent
    lines = (root / 'SHA256.TXT').read_text('ascii').splitlines()
    expected = {}
    for line in lines:
        checksum, name = line.split('  ', 1)
        if not re.fullmatch(r'[a-f0-9]{64}', checksum):
            raise ValueError('Invalid SHA-256 entry')
        expected[name] = checksum
    if len(lines) != len(expected):
        raise ValueError('Duplicate checksum entry')
    files = {f.relative_to(root).as_posix(): f for f in root.rglob('*') if f.is_file()}
    if set(files) != set(expected) | {'SHA256.TXT'}:
        raise ValueError('The extracted file set differs from the manifest')
    seen = set()
    for name, source in files.items():
        if name.upper() in seen or not all(re.fullmatch(r'[A-Z0-9_]{1,8}(?:\.[A-Z0-9_]{1,3})?', p.upper()) for p in Path(name).parts):
            raise ValueError('Invalid or duplicate DOS path ' + name)
        seen.add(name.upper())
        if name in expected and digest(source.read_bytes()) != expected[name]:
            raise ValueError('Checksum mismatch in ' + name)
    if args.output:
        target = args.output.resolve()
        if root in target.parents or target == root:
            parser.error('Write the ZIP outside the extracted project.')
        target.parent.mkdir(parents=True, exist_ok=True)
        with tempfile.TemporaryDirectory(dir=target.parent) as tmp:
            generated = Path(tmp) / 'ARCHIVE.ZIP'
            with zipfile.ZipFile(generated, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
                for name in sorted(files):
                    member = zipfile.ZipInfo(name, date_time=(2026, 11, 19, 0, 0, 0))
                    member.create_system = 0
                    member.external_attr = 0x20
                    archive.writestr(member, files[name].read_bytes(), compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
            with zipfile.ZipFile(generated) as archive:
                if archive.testzip() is not None or set(archive.namelist()) != set(files):
                    raise ValueError('ZIP readback failed')
            generated.replace(target)
        print('SHA-256', digest(target.read_bytes()), target.name)
    print('Verified', len(files), 'files and DOS 8.3 names.')


if __name__ == '__main__':
    main()
