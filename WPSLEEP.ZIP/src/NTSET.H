#ifndef WINPOWER_NTSET_H
#define WINPOWER_NTSET_H
#include <windows.h>
BOOL nt_preflight(void);
BOOL nt_installed(const char *folder);
void nt_setprogress(void (*cb)(int));
DWORD nt_backendwarning(void);
DWORD nt_backendstage(void);
BOOL nt_stage(const char *self,const char *folder);
BOOL nt_install(const char *folder);
BOOL nt_abort(const char *folder);
BOOL nt_abortfinish(void);
BOOL nt_linkmark(const char *path);
BOOL nt_linkundo(void);
BOOL nt_linkremove(const char *folder);
unsigned nt_linknotice(void);
BOOL nt_newfile(const char *path);
BOOL nt_remove(const char *folder,BOOL external);
BOOL nt_finish(const char *folder);
BOOL nt_target(char *folder);
const char *nt_reason(void);
void nt_error(const char *step,DWORD error);
#endif
