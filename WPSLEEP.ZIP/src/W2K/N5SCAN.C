#include "N5SCAN.H"
static unsigned long u32(const unsigned char *p){
 return (unsigned long)p[0]|((unsigned long)p[1]<<8)|
        ((unsigned long)p[2]<<16)|((unsigned long)p[3]<<24);
}
static int same(const unsigned char *p,const unsigned char *s,unsigned n){
 unsigned i;for(i=0;i<n;i++)if(p[i]!=s[i])return 0;return 1;
}
unsigned long wp_n5_candidate(const unsigned char *p,unsigned n,int x64){
 unsigned long a;
 static const unsigned char x86a[]={0x8b,0xc3,0xc1,0xe0,4,0x8d,0xb8};
 static const unsigned char x86b[]={0xa5,0xa5,0xa5,0xa5,0x80,0xa0};
 if(!x64){
  if(n<36||!same(p,x86a,7)||!same(p+11,x86b,6))return 0;
  a=u32(p+7);if(a>0xfffffff0UL)return 0;
  if(u32(p+17)!=a+5||p[21]||p[22]!=0x80||p[23]!=0xa0||
     u32(p+24)!=a+6||p[28]||p[29]!=0x80||p[30]!=0xa0||
     u32(p+31)!=a+7||p[35])return 0;
  return a;
 }
 return 0;
}
