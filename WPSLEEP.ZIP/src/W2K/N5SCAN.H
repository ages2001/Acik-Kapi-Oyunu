#ifndef WP_N5SCAN_H
#define WP_N5SCAN_H
/* Read-only recognition of NT5 power-handler registration code. A match
 * supplies a table address, never a fixed kernel or service-pack offset.
 * Unknown instruction layouts must fail closed. */
unsigned long wp_n5_candidate(const unsigned char *p,unsigned n,int x64);
#endif
