#ifdef _WIN64
#error The Windows 2000 module requires x86.
#endif
/* Windows 2000 x86 final power handoff. No power write in shutdown IRPs.
 * Registration layouts are recognized dynamically and validated against
 * the loaded kernel/HAL images. Only two final-state handler pointers are
 * interposed; sleep/hibernate entries and OS handlers remain intact.
 * This is an undocumented interface, not a universal support guarantee. */
#include <ntddk.h>
#include "N5HAND.H"
#include "N5SCAN.H"
NTSYSAPI NTSTATUS NTAPI ZwQuerySystemInformation(ULONG,PVOID,ULONG,PULONG);
typedef struct {PVOID section,mapped,base;ULONG size,flags;USHORT load,init,count,name;UCHAR path[256];} MOD;
typedef struct {ULONG count;MOD item[1];} MODS;
typedef NTSTATUS (NTAPI *SYSFN)(PVOID);
typedef NTSTATUS (NTAPI *ENTERFN)(PVOID,SYSFN,PVOID,LONG,volatile LONG*);
typedef struct {ULONG type;UCHAR rtc,spare[3];ENTERFN handler;PVOID context;} ENTRY;
static ENTERFN oldoff,oldreset;
static KSPIN_LOCK mode_lock;
static ULONG mode,latched,closing,ready;
static volatile LONG arrived,phase;
/* 0: collecting processors; 1: all arrived; 2: delegated to Windows. */
void wp_n5_initialize(void){KeInitializeSpinLock(&mode_lock);}
static UCHAR *kernel,*hal;
static ULONG kernelsize,halsize;
static void trace(const char *s){while(*s){__asm__ volatile("outb %0,%w1"::"a"((UCHAR)*s++),"d"((USHORT)0xe9));}}
static int range(ULONG_PTR a,ULONG_PTR b,ULONG n,ULONG size){return a>=b&&a-b<size&&n<=size-(a-b);}
static int equal(const UCHAR *a,const char *b){unsigned i;
 for(i=0;i<256;i++){unsigned c=a[i],d=(UCHAR)b[i];if(c>='a'&&c<='z')c-=32;if(d>='a'&&d<='z')d-=32;if(c!=d)return 0;if(!c)return 1;}return 0;
}
static int images(void){
 ULONG got=0,i;MODS *m=ExAllocatePool(NonPagedPool,262144);int ok=0;
 if(!m)return 0;
 if(NT_SUCCESS(ZwQuerySystemInformation(11,m,262144,&got))&&got<=262144&&
    m->count&&m->count<=(262144-FIELD_OFFSET(MODS,item))/sizeof(MOD)){
  kernel=m->item[0].base;kernelsize=m->item[0].size;
  for(i=0;i<m->count;i++){m->item[i].path[255]=0;
   if(m->item[i].name<256&&equal(m->item[i].path+m->item[i].name,"HAL.DLL")){
    hal=m->item[i].base;halsize=m->item[i].size;
   }
  }
  ok=kernel&&hal&&kernelsize>=4096&&kernelsize<=0x1000000&&halsize>=4096&&halsize<=0x400000;
 }
 ExFreePool(m);return ok;
}
static int section(UCHAR *base,ULONG size,ULONG_PTR address,ULONG length,ULONG flags){
 ULONG pe,i,n,head,va,span;UCHAR *s;
 if(!range(address,(ULONG_PTR)base,length,size)||*(USHORT*)base!=0x5a4d)return 0;
 pe=*(ULONG*)(base+60);if(pe>2048||*(ULONG*)(base+pe)!=0x4550)return 0;
 n=*(USHORT*)(base+pe+6);head=pe+24+*(USHORT*)(base+pe+20);
 if(!n||n>96||head>4096-n*40)return 0;
 for(i=0;i<n;i++){s=base+head+40*i;va=*(ULONG*)(s+12);span=*(ULONG*)(s+8);
  if(va<size&&span<=size-va&&range(address,(ULONG_PTR)base+va,length,span))
   return (*(ULONG*)(s+36)&flags)==flags&&!( *(ULONG*)(s+36)&0x02000000UL);
 }return 0;
}
static int valid_table(ENTRY *p){unsigned i;
 if((ULONG_PTR)p&(sizeof(PVOID)-1))return 0;
 if(!section(kernel,kernelsize,(ULONG_PTR)p,7*sizeof(*p),0x80000000UL))return 0;
 for(i=0;i<7;i++){
  if(!MmIsAddressValid(p+i)||!MmIsAddressValid((UCHAR*)(p+i+1)-1))return 0;
  if(p[i].handler&&(p[i].type!=i||
     (!section(hal,halsize,(ULONG_PTR)p[i].handler,1,0x20000000UL)&&
      !section(kernel,kernelsize,(ULONG_PTR)p[i].handler,1,0x20000000UL))))return 0;
 }
 return 1;
}
static ENTRY *find_table(void){
 ULONG pe,n,head,i,j,va,span,hits=0;UCHAR *s,*q;ENTRY *found=0;ULONG_PTR a;
 if(!images()||*(USHORT*)kernel!=0x5a4d){trace("N5 images rejected\n");return 0;}
 pe=*(ULONG*)(kernel+60);if(pe>2048||*(ULONG*)(kernel+pe)!=0x4550)return 0;
 if(*(USHORT*)(kernel+pe+4)!=0x14c)return 0;
 n=*(USHORT*)(kernel+pe+6);head=pe+24+*(USHORT*)(kernel+pe+20);
 if(!n||n>96||head>4096-n*40)return 0;
 for(i=0;i<n;i++){
  s=kernel+head+40*i;va=*(ULONG*)(s+12);span=*(ULONG*)(s+8);
  if(!( *(ULONG*)(s+36)&0x20000000UL)||( *(ULONG*)(s+36)&0x02000000UL)||
     va>=kernelsize||span>kernelsize-va||span<68)continue;
  for(j=0;j<=span-68;j++){
   q=kernel+va+j;
   /* Skip nonresident pages, never probe discarded initialization code. */
   /* At PASSIVE_LEVEL, a normal pageable executable section can fault in.
      Discardable sections have already been excluded above. */
   a=wp_n5_candidate(q,68,0);
   if(a){trace("N5 registration layout found\n");
    if(valid_table((ENTRY*)a)){found=(ENTRY*)a;hits++;trace("N5 table validated\n");}
   }
  }
 }
 return hits==1?found:0;
}
/* The kernel calls final-state handlers after shutdown work and dispatches
 * participating processors. The OS implementation is used for OS mode.
 * Driver mode drains caches and waits for every participant before the
 * single boot processor writes the hardware power/reset registers. */
static NTSTATUS transition(ULONG action,PVOID context,SYSFN sys,PVOID sysctx,
                          LONG cpus,volatile LONG *number,ENTERFN original){
 ULONG_PTR flags;NTSTATUS st=STATUS_UNSUCCESSFUL;unsigned cpu,waits=0;
 if(!closing||!latched||sys||cpus<1||cpus>64||InterlockedCompareExchange(&phase,0,0)==2)
  return original?original(context,sys,sysctx,cpus,number):STATUS_NOT_SUPPORTED;
 /* A classic FADT can omit RESET_REG. Windows must complete its normal
    multiprocessor restart sequence before entering the platform HAL. */
 if(action==2&&!wp_n5_has_reset_register()){
  trace("WINPOWER PLATFORM RESET\n");
  return original?original(context,sys,sysctx,cpus,number):STATUS_NOT_SUPPORTED;
 }
 {UCHAR number8;__asm__ volatile("movb %%fs:0x51,%0":"=q"(number8));cpu=number8;}
 __asm__ volatile("pushfl; popl %0; cli; wbinvd":"=r"(flags)::"memory");
 InterlockedIncrement(&arrived);
 /* A late or missing participant must not strand the machine with
    interrupts disabled. Once aborted, later callbacks delegate as well. */
 while (InterlockedCompareExchange(&phase, 0, 0) == 0) {
  if (cpu == 0 && InterlockedCompareExchange(&arrived, 0, 0) == cpus) {
   if (InterlockedCompareExchange(&phase, 1, 0) == 0) {
    wp_n5_power(action);
    InterlockedExchange(&phase, 2);
   }
  } else if (++waits >= 20000) {
   InterlockedCompareExchange(&phase, 2, 0);
  } else KeStallExecutionProcessor(50);
 }
 while (InterlockedCompareExchange(&phase, 0, 0) == 1)
  KeStallExecutionProcessor(1);
 __asm__ volatile("pushl %0; popfl"::"r"(flags):"memory");
 /* If hardware did not transition, retain the OS's own final fallback. */
 if(original)st=original(context,sys,sysctx,cpus,number);
 return st;
}
static NTSTATUS NTAPI off(PVOID c,SYSFN s,PVOID x,LONG n,volatile LONG *p){return transition(1,c,s,x,n,p,oldoff);}
static NTSTATUS NTAPI reset(PVOID c,SYSFN s,PVOID x,LONG n,volatile LONG *p){return transition(2,c,s,x,n,p,oldreset);}
int wp_n5_arm(ULONG minor){
 /* NT5 uses slot 6 for ShutdownOff and slot 5 for ShutdownReset.
    Do not substitute the later Windows private enum (Off == 4). */
 ENTRY *t;ULONG offindex=6;PVOID prev;(void)minor;
 if(minor!=0)return 0;
 t=find_table();if(!t||!t[offindex].handler){trace("N5 final table rejected\n");return 0;}
 oldoff=t[offindex].handler;oldreset=t[5].handler;
 /* A missing Windows reset handler or firmware RESET_REG leaves reset
    entirely with Windows. Registering an empty replacement changes the
    normal multiprocessor path even when the selected owner is the OS. */
 if(oldreset&&wp_n5_has_reset_register()){
  prev=InterlockedCompareExchangePointer((PVOID volatile*)&t[5].handler,(PVOID)reset,(PVOID)oldreset);
  if(prev!=(PVOID)oldreset)return 0;
 }
 prev=InterlockedCompareExchangePointer((PVOID volatile*)&t[offindex].handler,(PVOID)off,(PVOID)oldoff);
 if(prev!=(PVOID)oldoff)return 0;
 ready=1;trace("N5 final handoff armed\n");return 1;
}
void wp_n5_latch(void){KIRQL irql;
 KeAcquireSpinLock(&mode_lock,&irql);latched=mode;closing=1;KeReleaseSpinLock(&mode_lock,irql);
}
NTSTATUS wp_n5_set(ULONG value){KIRQL irql;NTSTATUS st=STATUS_SUCCESS;
 if(value>1)return STATUS_INVALID_PARAMETER;
 KeAcquireSpinLock(&mode_lock,&irql);
 if(closing)st=STATUS_SHUTDOWN_IN_PROGRESS;
 else if(!ready&&value)st=STATUS_NOT_SUPPORTED;
 else mode=value;
 KeReleaseSpinLock(&mode_lock,irql);return st;
}
ULONG wp_n5_state(void){return (ready?0x100:0)|mode;}
