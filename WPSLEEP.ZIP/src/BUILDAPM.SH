#!/bin/sh
# Build only the isolated APM diagnostic; retain existing qualified binaries.
set -eu
: "${WATCOM:?Set WATCOM to the Open Watcom 1.9 directory}"
cd "$(dirname "$0")"
export INCLUDE="$WATCOM/h"
export PATH="$WATCOM/binl:$PATH"
run() { if [ -n "${WIN16_RUN:-}" ]; then "$WIN16_RUN" "$@"; else "$@"; fi; }
mkdir -p ../BIN/WPWRDOS ../TEST/TMPAPM
for name in BIOREAD APMREG; do
 run "$WATCOM/binl/wasm" -fo=../TEST/TMPAPM/$name.OBJ $name.ASM
done
for name in WPAPM APMDATA WPSLEEP; do
 run "$WATCOM/binl/wcc" -bt=dos -ml -0 -os -w4 -we -fo=../TEST/TMPAPM/$name.OBJ $name.C
done
run "$WATCOM/binl/wlink" system dos option stack=8192 name ../BIN/WPWRDOS/WPAPM.EXE file ../TEST/TMPAPM/WPAPM.OBJ,../TEST/TMPAPM/APMDATA.OBJ,../TEST/TMPAPM/APMREG.OBJ,../TEST/TMPAPM/BIOREAD.OBJ
run "$WATCOM/binl/wlink" system dos option stack=8192 name ../BIN/WPWRDOS/WPSLEEP.EXE file ../TEST/TMPAPM/WPSLEEP.OBJ,../TEST/TMPAPM/APMREG.OBJ,../TEST/TMPAPM/BIOREAD.OBJ
rm ../TEST/TMPAPM/*.OBJ
rmdir ../TEST/TMPAPM
