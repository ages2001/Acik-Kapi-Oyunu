#include "PWRSEQ.H"
static int resolve(struct pn_reg *r,int (*bind)(struct pn_reg *)){
 return r->space==1||(bind&&bind(r));
}
void pn_bindregs(struct pn_acpi *p,int (*bind)(struct pn_reg *)){
 if(p->reduced&&p->off_ok&&(!resolve(&p->control_reg,bind)||!resolve(&p->status_reg,bind)))p->off_ok=0;
 if(!p->reduced&&p->off_ok&&
    ((p->pm1a_reg.bytes&&!resolve(&p->pm1a_reg,bind))||
     (p->pm1b_reg.bytes&&!resolve(&p->pm1b_reg,bind))))p->off_ok=0;
 if(p->reset_ok&&!resolve(&p->reset_reg,bind))p->reset_ok=0;
}
static int write_byte(const struct pn_io *io,const struct pn_reg *r,unsigned value){
 if(r->space==1){io->put8(io->arg,(unsigned)r->low,value);return 1;}
 return io->write_mmio&&io->write_mmio(r,value);
}
#ifdef WP_2000
/* Windows still has its platform fallback if the firmware write returns. */
void pn_reset_fixed(const struct pn_acpi *p,const struct pn_io *io){
 if(p->reset_ok&&write_byte(io,&p->reset_reg,p->reset_value))io->wait(io->arg,4);
}
#endif
static int has_b(const struct pn_acpi *p){return p->pm1b||p->pm1b_reg.bytes;}
static int get_control(const struct pn_io *io,const struct pn_reg *r,unsigned port,unsigned *v){
 if(r->bytes&&r->space==0)return io->read_mmio16&&io->read_mmio16(r,v);
 if(!port||!io->get16)return 0;
 *v=io->get16(io->arg,port);return 1;
}
static int put_control(const struct pn_io *io,const struct pn_reg *r,unsigned port,unsigned value){
 if(r->bytes&&r->space==0)return io->write_mmio&&io->write_mmio(r,value);
 if(!port||!io->put16)return 0;
 io->put16(io->arg,port,value);return 1;
}
static int get_pair(const struct pn_acpi *p,const struct pn_io *io,unsigned *a,unsigned *b){
 *b=0;return get_control(io,&p->pm1a_reg,p->pm1a,a)&&
        (!has_b(p)||get_control(io,&p->pm1b_reg,p->pm1b,b));
}
/* A missing or unexecutable S5 method does not release firmware ownership.
   Only an inactive, readable classic control block permits the BIOS path. */
int pn_apm_permitted(const struct pn_acpi *p,const struct pn_io *io){
 unsigned a,b;
 if(p->reduced||p->fadt_rev>6)return 0;
 if(!p->fadt_rev)return 1;
 return get_pair(p,io,&a,&b)&&!((a|b)&0x2001);
}
static int put_pair(const struct pn_acpi *p,const struct pn_io *io,unsigned a,unsigned b){
 return put_control(io,&p->pm1a_reg,p->pm1a,a)&&
        (!has_b(p)||put_control(io,&p->pm1b_reg,p->pm1b,b));
}
static int sci(const struct pn_acpi *p,const struct pn_io *io,int enabled){
 unsigned i,a,b;
 for(i=0;i<54;i++){
  if(!get_pair(p,io,&a,&b))return 0;
  if(((a&1)!=0)==enabled&&(!has_b(p)||((b&1)!=0)==enabled))return 1;
  io->wait(io->arg,1);
 }
 return 0;
}
int pn_s5off(const struct pn_acpi *p,const struct pn_io *io){
 unsigned a,b,atype,btype;int changed=0,failed=0;
 if(p->reduced){
  if(!p->off_ok||p->sleepa>7)return -1;
  if(io->prepare&&!io->prepare(io->arg))return -1;
  if(!write_byte(io,&p->status_reg,0x80))return -1;
  if(!write_byte(io,&p->control_reg,0x20|(p->sleepa<<2)))return -1;
  io->wait(io->arg,54);return -1;
 }
 if(!p->off_ok)return 0;
 if(!get_pair(p,io,&a,&b)||(a&0x2000)||(b&0x2000)||(has_b(p)&&((a^b)&1)))return -1;
 if(!(a&1)){
  if(!p->smi||!p->enable||!p->disable)return 0;
  io->put8(io->arg,(unsigned)p->smi,p->enable);changed=1;
  if(!sci(p,io,1))goto restore_mode;
 }
 if((io->prepare&&!io->prepare(io->arg))||!get_pair(p,io,&a,&b)){
  failed=1;goto restore_mode;
 }
 /* Program both SLP_TYP fields before asserting SLP_EN, as required for
    platforms with independent PM1a and PM1b control registers. */
 atype=(a&~0x3c00U)|(p->sleepa<<10);btype=(b&~0x3c00U)|(p->sleepb<<10);
 if(!put_pair(p,io,atype,btype)||!put_pair(p,io,atype|0x2000,btype|0x2000))failed=1;
 else io->wait(io->arg,54);
 if(!put_pair(p,io,a&~0x2000U,b&~0x2000U))failed=1;
restore_mode:
 if(changed){io->put8(io->arg,(unsigned)p->smi,p->disable);if(!sci(p,io,0))return -1;}
 if(failed||!get_pair(p,io,&a,&b))return -1;
 return ((a|b)&1)?-1:0;
}
int pn_reset(const struct pn_acpi *p,const struct pn_io *io){
 unsigned pass;
 /* Reset like the Linux kernel: try each known mechanism in turn so a
    machine without an ACPI reset register still restarts. Whichever works
    resets the system before the next is reached; two passes let a keyboard
    controller drain its input buffer first. All three writes target fixed,
    PC-compatible reset hardware, so an unsupported one is simply ignored. */
 for(pass=0;pass<2;pass++){
  /* 1. ACPI RESET_REG from the FADT, when the firmware provides one. */
  if(p->reset_ok)write_byte(io,&p->reset_reg,p->reset_value);
  if(p->reduced){io->wait(io->arg,4);return 0;}
  io->wait(io->arg,2);
  /* 2. PCI reset control register at 0CF9h: 0Eh requests a full cold reset. */
  io->put8(io->arg,0x0cf9,0x02);io->wait(io->arg,1);
  io->put8(io->arg,0x0cf9,0x0e);io->wait(io->arg,2);
  /* 3. Keyboard controller command FEh pulses the CPU reset line. */
  io->put8(io->arg,0x64,0xfe);io->wait(io->arg,4);
 }
 return 0;
}
