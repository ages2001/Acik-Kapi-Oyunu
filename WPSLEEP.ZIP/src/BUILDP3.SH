#!/bin/sh
set -eu
cd "$(dirname "$0")"
mkdir -p ../BIN/WINPWRNT/NT3LAB
cc=i686-w64-mingw32-gcc
case "${1:-all}" in all|helper) ;; *) echo 'Usage: BUILDP3.SH [all|helper]' >&2; exit 2;; esac
if [ "${1:-all}" = all ]; then
 "$cc" -x c -march=i486 -Os -Wall -Wextra -Werror -Wno-misleading-indentation -nostdlib -ffreestanding -fno-stack-protector -I"${DDK_ROOT:-/usr}/i686-w64-mingw32/include/ddk" -D_WIN32_WINNT=0x0501 -DNTDDI_VERSION=0x05010000 -DNTDDI_WINVISTA=0x06000000 -DPN_AML -DPN_NO_APM_PROBE -DPN_NT3ABI -shared PN3HOOK.C PNMIN.C MEMMAP.C INTENT.C SHUTFIND.C S5.C ACPI.C PWRSEQ.C AML.C NTAML.C NTAPM.C -Wl,--entry,_DriverEntry@8,--subsystem,native:3.10,--image-base,0x10000 -o ../BIN/WINPWRNT/NT3LAB/PN3HOOK.SYS -lntoskrnl -lhal
fi
"$cc" -x c -march=i386 -Os -Wall -Wextra -Werror -fno-builtin -fno-stack-protector -nostdlib -mwindows PN3TEST.C -Wl,--entry,_WinMainCRTStartup@0,--subsystem,windows:3.10 -o ../BIN/WINPWRNT/NT3LAB/PN3TEST.EXE -lkernel32 -luser32 -ladvapi32
"$cc" -x c -march=i386 -Os -Wall -Wextra -Werror -fno-builtin -fno-stack-protector -nostdlib -mwindows ../TEST/PNREG.C -Wl,--entry,_WinMainCRTStartup@0,--subsystem,windows:3.10 -o ../BIN/WINPWRNT/NT3LAB/PNREG.EXE -lkernel32 -luser32 -ladvapi32

cc -x c -std=c89 -Wall -Wextra -Werror -pedantic -fsanitize=address,undefined -I. MEMMAP.C ../TEST/MEMTEST.C -o ../TEST/MEMTEST
../TEST/MEMTEST
rm ../TEST/MEMTEST
cc -x c -std=c89 -Wall -Wextra -Werror -pedantic -fsanitize=address,undefined -I. INTENT.C ../TEST/INTTEST.C -o ../TEST/INTTEST
../TEST/INTTEST
rm ../TEST/INTTEST
