#ifndef WP_REGMEM_H
#define WP_REGMEM_H
#include <stdint.h>
/* Validate an entire fixed-register access against one OS-owned RAM span.
   A malformed span or address must never authorize a device mapping. */
static int wp_ram_disjoint(uint64_t address,unsigned bytes,
                           uint64_t ram,uint64_t length)
{
 uint64_t last=~(uint64_t)0;
 if(!length||(bytes!=1&&bytes!=2)||ram>last-(length-1)||
    address>last-(bytes-1))return 0;
 return address+bytes-1<ram||ram+length-1<address;
}
#endif
