#include <dos.h>
#include <i86.h>
#include <conio.h>
#include <string.h>
#include <stdlib.h>
#include "ACPIDOS.H"
#include "ACPI.H"
#include "PWRSEQ.H"
unsigned __cdecl pn_cpu(void);
unsigned __cdecl pn_e820(unsigned long *,unsigned char *);
#ifdef PN_BIGREAD
unsigned __cdecl pn_v86(void);
unsigned __cdecl pn_a20(void);
unsigned __cdecl pn_bigread(unsigned long,void __far *,unsigned);
/* Set by pn_probe: 1 = real mode with A20 enabled, use a 4 GiB FS read. */
static unsigned bigmode;
#endif
struct range {unsigned long base,end;};
static struct range ranges[64],reserved[32];
static unsigned count;
#ifdef PN_AML
/* Firmware-owned ranges (E820 types 2, 3 and 4) where AML may write. */
static struct range owned[32];
static unsigned owned_count;
#endif
static unsigned char transfer[258],gdt[48];
static unsigned long dword(const unsigned char *p){return (unsigned long)p[0]|((unsigned long)p[1]<<8)|((unsigned long)p[2]<<16)|((unsigned long)p[3]<<24);}
static unsigned long linear(void __far *p){return ((unsigned long)FP_SEG(p)<<4)+FP_OFF(p);}
static void descriptor(unsigned char *p,unsigned long address,unsigned bytes){
 p[0]=(bytes-1)&255;p[1]=(bytes-1)>>8;p[2]=(unsigned char)address;p[3]=(unsigned char)(address>>8);
 p[4]=(unsigned char)(address>>16);p[5]=0x93;p[6]=0;p[7]=(unsigned char)(address>>24);
}
static int allowed(unsigned long p,unsigned n){
 unsigned i;if(!n||p>0xffffffffUL-n)return 0;
 if(p>=0xe0000UL&&p+n<=0x100000UL)return 1;
 if(p>=0x400UL&&p+n<=0xa0000UL)return 1;
 for(i=0;i<count;i++)if(p>=ranges[i].base&&p+n<=ranges[i].end)return 1;
 return 0;
}
static int readmem(void *unused,unsigned long p,unsigned char *out,unsigned n){
 union REGS in,res;struct SREGS seg;unsigned chunk,even,i;unsigned char __far *low;
 (void)unused;if(!allowed(p,n))return 0;
 while(n){
  chunk=n>256?256:n;
  if(p<0x100000UL){low=MK_FP((unsigned)(p>>4),(unsigned)(p&15));for(i=0;i<chunk;i++)out[i]=low[i];}
#ifdef PN_BIGREAD
  else if(bigmode){if(!pn_bigread(p,out,chunk))return 0;}
#endif
  else{
   even=(chunk+1)&~1;if(!allowed(p,even))return 0;
   memset(gdt,0,sizeof(gdt));descriptor(gdt+16,p,even);descriptor(gdt+24,linear(transfer),even);
   memset(&in,0,sizeof(in));segread(&seg);in.w.ax=0x8700;in.w.cx=even/2;
   seg.es=FP_SEG(gdt);in.w.si=FP_OFF(gdt);int86x(0x15,&in,&res,&seg);
   if(res.w.cflag||res.h.ah)return 0;memcpy(out,transfer,chunk);
  }
  p+=chunk;out+=chunk;n-=chunk;
 }
 return 1;
}
#ifdef PN_AML
unsigned __cdecl pn_bigwrite(unsigned long,void __far *,unsigned);
unsigned long __cdecl pn_in32(unsigned);
void __cdecl pn_out32(unsigned,unsigned long);
#define PN_WORK 60000U
#define PN_NODES 1150U
#define PN_ARENA 60000U
static struct pn_amlctx amlctx;
static int inowned(unsigned long p,unsigned n){
 unsigned i;if(!n||p>0xffffffffUL-n)return 0;
 for(i=0;i<owned_count;i++)if(p>=owned[i].base&&p+n<=owned[i].end)return 1;
 /* The extended BIOS data area is firmware memory below 640 KiB. */
 {unsigned long e=(unsigned long)*(unsigned __far *)MK_FP(0x40,0x0e)<<4;
  if(e>=0x80000UL&&e<0xa0000UL&&p>=e&&p+n<=0xa0000UL)return 1;}
 return p>=0xe0000UL&&p+n<=0x100000UL;
}
static int physio(unsigned long p,unsigned char *b,unsigned n,int write){
 union REGS in,res;struct SREGS seg;unsigned char __far *low;unsigned i;
 if(p<0x100000UL){
  low=MK_FP((unsigned)(p>>4),(unsigned)(p&15));
  for(i=0;i<n;i++){if(write)low[i]=b[i];else b[i]=low[i];}
  return 1;
 }
 if(!pn_v86()&&pn_a20())return write?pn_bigwrite(p,b,n):pn_bigread(p,b,n);
 /* V86: the BIOS block move is emulated by the V86 monitor. Even count. */
 if(n&1)return 0;
 memset(gdt,0,sizeof(gdt));
 if(write){descriptor(gdt+16,linear(b),n);descriptor(gdt+24,p,n);}
 else{descriptor(gdt+16,p,n);descriptor(gdt+24,linear(b),n);}
 memset(&in,0,sizeof(in));segread(&seg);in.w.ax=0x8700;in.w.cx=n/2;
 seg.es=FP_SEG(gdt);in.w.si=FP_OFF(gdt);int86x(0x15,&in,&res,&seg);
 return !res.w.cflag&&!res.h.ah;
}
static int amlmemr(void *g,pn_u32 a,unsigned w,pn_u32 *v){
 unsigned char b[4];unsigned i,n=w/8;(void)g;
 if(!allowed(a,n)&&!inowned(a,n))return 0;
 if(n==1&&a>=0x100000UL){unsigned char t[2];if(!physio(a&~1UL,t,2,0))return 0;*v=t[a&1];return 1;}
 if(!physio(a,b,n,0))return 0;*v=0;for(i=0;i<n;i++)*v|=(pn_u32)b[i]<<(8*i);return 1;
}
static int amlmemw(void *g,pn_u32 a,unsigned w,pn_u32 v){
 unsigned char b[4];unsigned i,n=w/8;(void)g;
 if(!inowned(a,n))return 0;
 if(n==1&&a>=0x100000UL){unsigned char t[2];if(!physio(a&~1UL,t,2,0))return 0;t[a&1]=(unsigned char)v;return physio(a&~1UL,t,2,1);}
 for(i=0;i<n;i++)b[i]=(unsigned char)(v>>(8*i));return physio(a,b,n,1);
}
static int amlior(void *g,pn_u32 p,unsigned w,pn_u32 *v){
 (void)g;if(p>0xffffUL)return 0;
 if(w==8)*v=inp((unsigned)p);else if(w==16)*v=inpw((unsigned)p);else if(w==32)*v=pn_in32((unsigned)p);else return 0;
 return 1;
}
static int amliow(void *g,pn_u32 p,unsigned w,pn_u32 v){
 (void)g;if(p>0xffffUL)return 0;
 /* PCI configuration ports are reached only through the PCI hooks. */
 if(p>=0xcf8&&p<0xd00)return 0;
 if(w==8)outp((unsigned)p,(unsigned)v);else if(w==16)outpw((unsigned)p,(unsigned)v);else if(w==32)pn_out32((unsigned)p,v);else return 0;
 return 1;
}
static int pciaddr(unsigned b,unsigned d,unsigned f,unsigned r,unsigned long *a){
 if(b>255||d>31||f>7||r>255)return 0;
 *a=0x80000000UL|((unsigned long)b<<16)|((unsigned long)d<<11)|((unsigned long)f<<8)|(r&0xfc);return 1;
}
static int amlpcir(void *g,unsigned b,unsigned d,unsigned f,unsigned r,unsigned w,pn_u32 *v){
 unsigned long a,x;(void)g;if(!pciaddr(b,d,f,r,&a)||(r&3)+w/8>4)return 0;
 _disable();pn_out32(0xcf8,a);x=pn_in32(0xcfc);_enable();
 *v=(x>>(8*(r&3)))&(w==32?0xffffffffUL:((1UL<<w)-1));return 1;
}
static int amlpciw(void *g,unsigned b,unsigned d,unsigned f,unsigned r,unsigned w,pn_u32 v){
 unsigned long a;(void)g;if(!pciaddr(b,d,f,r,&a)||(r&3)+w/8>4)return 0;
 _disable();pn_out32(0xcf8,a);
 if(w==8)outp(0xcfc+(r&3),(unsigned)v);else if(w==16)outpw(0xcfc+(r&2),(unsigned)v);else pn_out32(0xcfc,v);
 _enable();return 1;
}
static void amlstall(void *g,pn_u32 us){
 union REGS in,out;(void)g;memset(&in,0,sizeof(in));in.h.ah=0x86;
 in.w.cx=(unsigned)(us>>16);in.w.dx=(unsigned)(us&0xffff);int86(0x15,&in,&out);
}
static const struct pn_aml_env amlenv={0,amlior,amliow,amlmemr,amlmemw,amlpcir,amlpciw,amlstall};
void pn_release(void){
 if(amlctx.nodes)free(amlctx.nodes);if(amlctx.arena)free(amlctx.arena);
 memset(&amlctx,0,sizeof(amlctx));pn_amlctx=0;
}
static int aml_setup(void){
 pn_release();
 amlctx.nodes=malloc(PN_NODES*sizeof(struct pn_aml_node));amlctx.arena=malloc(PN_ARENA);
 if(!amlctx.nodes||!amlctx.arena){pn_release();return 1;} /* Static fallback */
 amlctx.capacity=PN_NODES;amlctx.arena_size=PN_ARENA;amlctx.env=&amlenv;pn_amlctx=&amlctx;
 return 1;
}
static int bind_byte(struct pn_reg *r){
 unsigned i;
 /* Byte writes must remain byte writes. BIOS block moves in a V86 session
    are word-wide and may acknowledge the adjacent status register. */
 if(!bigmode||!count||r->high||r->low<0x100000UL)return 0;
 for(i=0;i<count;i++)if(r->low<ranges[i].end&&(r->low>=ranges[i].base||ranges[i].base-r->low<r->bytes))return 0;
 return 1;
}
static int write_mmio(const struct pn_reg *r,unsigned value){
 unsigned short word=(unsigned short)value;
 if(r->bytes!=1&&r->bytes!=2)return 0;
 return pn_bigwrite(r->low,&word,r->bytes);
}
static int read_mmio16(const struct pn_reg *r,unsigned *v){
 unsigned short word;
 if(r->bytes!=2||!pn_bigread(r->low,&word,2))return 0;
 *v=word;return 1;
}
static int prepare(void *arg){
 (void)arg;
 return !amlctx.loaded||!amlctx.prepare||pn_aml_prepare(&amlctx.aml,&amlenv,5);
}
int pn_aml_prepared(void){return amlctx.loaded&&amlctx.prepare;}
#endif
int pn_probe(struct pn_acpi *out){
 unsigned char map[20],head[36],*work;unsigned i,j,reserved_count=0;unsigned long key=0,base,len,ebda,p,found=0;int ok=0;
 memset(out,0,sizeof(*out));out->rsdp_rev=0xffff;count=0;
#ifdef PN_AML
 owned_count=0;
#endif
 if(!pn_cpu())return 0;
#ifdef PN_BIGREAD
 /* Real mode: avoid INT 15h AH=87h, which some DOS XMS managers do not
    pass to the BIOS. V86 mode (EMM386 and similar) keeps the BIOS move,
    which the V86 monitor emulates. A20 must already be enabled; the probe
    does not change the A20 gate. */
 bigmode=!pn_v86()&&pn_a20();
#endif
 for(i=0;i<128;i++){
  if(!pn_e820(&key,map))break;
  base=dword(map);len=dword(map+8);
  if(!dword(map+4)&&!dword(map+12)&&len&&base<=0xffffffffUL-len&&
     (dword(map+16)==1||dword(map+16)==3||dword(map+16)==4)){
   if(count==64)return 0;ranges[count].base=base;ranges[count++].end=base+len;
  }
#ifdef PN_AML
  if(!dword(map+4)&&!dword(map+12)&&len&&base<=0xffffffffUL-len&&owned_count<32&&
     (dword(map+16)==2||dword(map+16)==3||dword(map+16)==4)){
   owned[owned_count].base=base;owned[owned_count++].end=base+len;
  }
#endif
  if(!dword(map+4)&&!dword(map+12)&&dword(map+16)==2&&base>=0x100000UL&&
     base<0xc0000000UL&&len&&len<=0x100000UL&&reserved_count<32){
   reserved[reserved_count].base=base;reserved[reserved_count++].end=base+len;
  }
  if(!key)break;
 }
 if(i==128)return 0;
 /* Some BIOSes place tables in a small reserved tail directly adjoining RAM.
    Do not admit PCI/MMIO windows or arbitrary reserved regions. */
 for(i=0;i<reserved_count;i++)for(j=0;j<count;j++){
  if(ranges[j].base>=0x100000UL&&ranges[j].end==reserved[i].base){
   ranges[j].end=reserved[i].end;break;
  }
 }
 ebda=(unsigned long)*(unsigned __far *)MK_FP(0x40,0x0e)<<4;
 if(ebda>=0x400UL&&ebda<=0x9ffffUL)for(p=ebda;p+36<=ebda+1024&&p+36<=0x100000UL;p+=16){
  if(readmem(0,p,head,36)&&!memcmp(head,"RSD PTR ",8)&&pn_rsdp(head,36)>=0){found=p;break;}
 }
 if(!found)for(p=0xe0000UL;p<=0x100000UL-36;p+=16){
  if(readmem(0,p,head,36)&&!memcmp(head,"RSD PTR ",8)&&pn_rsdp(head,36)>=0){found=p;break;}
 }
 if(!found)return 0;
#ifdef PN_AML
 if(!aml_setup())return 0;
 work=malloc(PN_WORK);if(!work){pn_release();return 0;}
 ok=pn_tables(readmem,0,found,out,work,PN_WORK);free(work);
 if(ok)pn_bindregs(out,bind_byte);
 if(!ok||!out->off_ok||!amlctx.loaded)pn_release();
 pn_amlctx=0;return ok;
#else
 work=malloc(32768U);if(!work)return 0;
 ok=pn_tables(readmem,0,found,out,work,32768U);free(work);if(ok)pn_bindregs(out,0);return ok;
#endif
}
static void delay_ticks(unsigned n){
 unsigned long start=*(unsigned long __far *)MK_FP(0x40,0x6c),now;
 do{now=*(volatile unsigned long __far *)MK_FP(0x40,0x6c);if(now<start)start=0;}while(now-start<n);
}
static unsigned get16(void *arg,unsigned port){(void)arg;return inpw(port);}
static void put16(void *arg,unsigned port,unsigned value){(void)arg;outpw(port,value);}
static void put8(void *arg,unsigned port,unsigned value){(void)arg;outp(port,value);}
static void pauseio(void *arg,unsigned ticks){(void)arg;delay_ticks(ticks);}
#ifdef PN_AML
static const struct pn_io io={0,get16,put16,put8,pauseio,prepare,write_mmio,read_mmio16};
#else
static const struct pn_io io={0,get16,put16,put8,pauseio,0,0,0};
#endif
int pn_acoff(const struct pn_acpi *p){return pn_s5off(p,&io);}
int pn_acapm(const struct pn_acpi *p){return pn_apm_permitted(p,&io);}
int pn_acreset(const struct pn_acpi *p){return pn_reset(p,&io);}
