#!/bin/sh
# Rebuild generic NT/Win9x installers only, retaining GUI/core/audit bytes.
set -eu
cd "$(dirname "$0")"
sh BUILDUI.SH setup
sh BUILD9S.SH setup
