/* Desktop link ownership for GUI and Win9x installers. No INI delete paths. */
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include "LINKOWN.H"
#include "SHA256.H"
static struct lo_record staged;
static BOOL have_staged;
static unsigned notice;
static char reason[300];
static BOOL fail(const char *step,DWORD error){wsprintfA(reason,"%s\r\nWindows error: %lu",step,error);return FALSE;}
const char *lo_reason(void){return reason[0]?reason:0;}
unsigned lo_notice(void){return notice;}
BOOL lo_newfile(const char *path){
 /* The caller must have just copied exclusively to this new destination. */
 return SetFileAttributesA(path,FILE_ATTRIBUTE_NORMAL)?TRUE:fail("Cannot set attributes on the newly installed file.",GetLastError());
}
static BOOL valid(const struct lo_record *record,const char *name){
 unsigned n,m;
 if(record->magic!=LO_LINK_MAGIC||record->path[MAX_PATH-1])return FALSE;
 n=(unsigned)lstrlenA(record->path);m=(unsigned)lstrlenA(name);
 if(m!=12||n<m+3||record->path[n-m-1]!='\\'||lstrcmpiA(record->path+n-m,name))return FALSE;
 if(((record->path[0]>='A'&&record->path[0]<='Z')||(record->path[0]>='a'&&record->path[0]<='z'))&&record->path[1]==':'&&record->path[2]=='\\')return TRUE;
 return record->path[0]=='\\'&&record->path[1]=='\\'&&record->path[2]&&record->path[2]!='.'&&record->path[2]!='?';
}
static DWORD hash(const char *path,BYTE digest[32]){
 struct wp_sha256 state;BYTE bytes[1024];HANDLE file;DWORD got,error=0;
 file=CreateFileA(path,GENERIC_READ,FILE_SHARE_READ,0,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,0);
 if(file==INVALID_HANDLE_VALUE)return GetLastError();
 wp_sha_init(&state);
 for(;;){
  if(!ReadFile(file,bytes,sizeof(bytes),&got,0)){error=GetLastError();break;}
  if(!got)break;
  wp_sha_add(&state,bytes,got);
 }
 CloseHandle(file);if(!error)wp_sha_end(&state,digest);return error;
}
static BOOL remove_record(const struct lo_record *record){
 BYTE digest[32];DWORD error,attr;unsigned i;
 error=hash(record->path,digest);
 if(error==ERROR_FILE_NOT_FOUND||error==ERROR_PATH_NOT_FOUND)return TRUE;
 if(error){notice=2;return TRUE;}
 for(i=0;i<32;i++)if(digest[i]!=record->hash[i]){notice=1;return TRUE;}
 attr=GetFileAttributesA(record->path);
 if(attr==INVALID_FILE_ATTRIBUTES){error=GetLastError();if(error==ERROR_FILE_NOT_FOUND||error==ERROR_PATH_NOT_FOUND)return TRUE;return fail("Cannot inspect the verified desktop shortcut. Retry removal.",error);}
 if(attr&FILE_ATTRIBUTE_DIRECTORY){notice=2;return TRUE;}
 if(attr&FILE_ATTRIBUTE_READONLY){
  attr&=~FILE_ATTRIBUTE_READONLY;
  if(!SetFileAttributesA(record->path,attr?attr:FILE_ATTRIBUTE_NORMAL))return fail("Cannot prepare the verified desktop shortcut for removal. Retry removal.",GetLastError());
 }
 if(!DeleteFileA(record->path)){
  error=GetLastError();if(error!=ERROR_FILE_NOT_FOUND&&error!=ERROR_PATH_NOT_FOUND)return fail("Cannot remove the verified desktop shortcut. Retry removal.",error);
 }return TRUE;
}
BOOL lo_save(const char *key,const char *path,const char *name){
 HKEY arp;DWORD error;unsigned i;
 have_staged=FALSE;for(i=0;i<sizeof(staged);i++)((BYTE*)&staged)[i]=0;
 if(lstrlenA(path)>=MAX_PATH)return fail("The desktop shortcut path is too long.",ERROR_FILENAME_EXCED_RANGE);
 staged.magic=LO_LINK_MAGIC;lstrcpyA(staged.path,path);
 if(!valid(&staged,name))return fail("The desktop shortcut path is invalid.",ERROR_INVALID_NAME);
 error=hash(path,staged.hash);if(error)return fail("Cannot identify the created desktop shortcut.",error);
 have_staged=TRUE;
 error=RegOpenKeyExA(HKEY_LOCAL_MACHINE,key,0,KEY_SET_VALUE,&arp);
 if(error)return fail("Cannot open the shortcut ownership record.",error);
 /* A single value prevents a path and digest from different writes from
    being paired. Keep the staged identity if persistence fails. */
 error=RegSetValueExA(arp,"Shortcut",0,REG_BINARY,(BYTE*)&staged,sizeof(staged));
 if(!error)error=RegFlushKey(arp);
 RegCloseKey(arp);
 return error?fail("Cannot save desktop shortcut ownership.",error):TRUE;
}
BOOL lo_remove(const char *key,const char *name){
 HKEY arp;struct lo_record record;DWORD error,type,size=sizeof(record);
 error=RegOpenKeyExA(HKEY_LOCAL_MACHINE,key,0,KEY_QUERY_VALUE,&arp);
 if(error==ERROR_FILE_NOT_FOUND||error==ERROR_PATH_NOT_FOUND){notice=2;return TRUE;}
 if(error)return fail("Cannot inspect desktop shortcut ownership.",error);
 error=RegQueryValueExA(arp,"Shortcut",0,&type,(BYTE*)&record,&size);RegCloseKey(arp);
 if(error==ERROR_FILE_NOT_FOUND||error==ERROR_MORE_DATA){notice=2;return TRUE;}
 if(error)return fail("Cannot read desktop shortcut ownership.",error);
 if(type!=REG_BINARY||size!=sizeof(record)||!valid(&record,name)){notice=2;return TRUE;}
 return remove_record(&record);
}
BOOL lo_undo(void){
 if(!have_staged){notice=2;return TRUE;}
 return remove_record(&staged);
}
static BOOL short_path(const char *path){
 unsigned i;
 if(!((path[0]>='A'&&path[0]<='Z')||(path[0]>='a'&&path[0]<='z'))||path[1]!=':'||path[2]!='\\'||!path[3])return FALSE;
 for(i=3;path[i];i++){
  unsigned c=(unsigned char)path[i];
  if(!((c>='A'&&c<='Z')||(c>='a'&&c<='z')||(c>='0'&&c<='9')||c=='_'||c=='~'||c=='.'||c=='-'||c=='\\'))return FALSE;
 }
 return TRUE;
}
BOOL lo_finish9(const char *folder){
 typedef DWORD (WINAPI *SHORTFN)(const char *,char *,DWORD);
 SHORTFN shortfn;HKEY key;HANDLE file;DWORD error,disp,size,got=0,type;BOOL ok;
 char windows[MAX_PATH],shortdir[MAX_PATH],batch[MAX_PATH],command[MAX_PATH+48],script[1024];
 /* These paths become batch commands: accept only the fixed installed
    directory and a shell-safe short Windows path. Never recurse on RD. */
 if(lstrlenA(folder)!=11||!short_path(folder)||lstrcmpiA(folder+2,"\\WINPWR9X"))return fail("Invalid Win9x GUI cleanup directory.",ERROR_INVALID_NAME);
 size=GetWindowsDirectoryA(windows,sizeof(windows));
 if(!size||size>=sizeof(windows))return fail("Cannot locate Windows for removal cleanup.",ERROR_INVALID_NAME);
 shortfn=(SHORTFN)GetProcAddress(GetModuleHandleA("KERNEL32.DLL"),"GetShortPathNameA");
 if(!shortfn)return fail("Short Windows paths are unavailable for removal cleanup.",ERROR_INVALID_NAME);
 size=shortfn(windows,shortdir,sizeof(shortdir));
 if(!size||size>=sizeof(shortdir)||size>MAX_PATH-14||!short_path(shortdir))return fail("The short Windows directory is unsuitable for removal cleanup.",ERROR_INVALID_NAME);
 wsprintfA(batch,"%s\\WPGCLN.BAT",shortdir);
 error=RegCreateKeyExA(HKEY_LOCAL_MACHINE,"Software\\Microsoft\\Windows\\CurrentVersion\\RunOnce",0,0,0,KEY_QUERY_VALUE|KEY_SET_VALUE,0,&key,&disp);
 if(error)return fail("Cannot schedule Win9x GUI removal cleanup.",error);
 size=0;error=RegQueryValueExA(key,"WINPWR9XGUI",0,&type,0,&size);
 if(error!=ERROR_FILE_NOT_FOUND){RegCloseKey(key);return fail("A WINPWR9XGUI RunOnce entry already exists or cannot be inspected. Finish that cleanup before retrying.",error?error:ERROR_ALREADY_EXISTS);}
 file=CreateFileA(batch,GENERIC_WRITE,0,0,CREATE_NEW,FILE_ATTRIBUTE_NORMAL,0);
 if(file==INVALID_HANDLE_VALUE){error=GetLastError();RegCloseKey(key);return fail("WPGCLN.BAT already exists or cannot be created. Preserve it and finish the earlier cleanup before retrying.",error);}
 wsprintfA(script,"@ECHO OFF\r\nIF EXIST %s\\UNINST.EXE DEL %s\\UNINST.EXE\r\nRD %s\r\nDEL %s\r\n",folder,folder,folder,batch);
 size=(DWORD)lstrlenA(script);ok=WriteFile(file,script,size,&got,0)&&got==size&&FlushFileBuffers(file);
 error=ok?0:GetLastError();if(!ok&&!error)error=ERROR_WRITE_FAULT;CloseHandle(file);
 wsprintfA(command,"%s\\COMMAND.COM /C %s",shortdir,batch);
 if(!error)error=RegSetValueExA(key,"WINPWR9XGUI",0,REG_SZ,(const BYTE*)command,lstrlenA(command)+1);
 RegCloseKey(key);
 if(error){DeleteFileA(batch);return fail("Win9x GUI removal cleanup could not be saved. Retry the uninstaller.",error);}
 return TRUE;
}
