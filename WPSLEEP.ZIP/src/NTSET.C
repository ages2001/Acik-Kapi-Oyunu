/* Persistent legacy NT installation, with owned-state rollback and removal. */
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include "NTSET.H"
#include "NTPWR.H"
static char reason[300];
static DWORD kind;
static BOOL copied_service,copied_driver,created_meta,created_service,created_kernel,saved_value;
struct nt_linkrecord { DWORD magic;char path[MAX_PATH];BYTE hash[32]; };
#define NT_LINK_MAGIC 0x57504c31UL
static struct nt_linkrecord staged_link;
static BOOL have_link;
/* 0: absent/deleted, 1: changed and preserved, 2: identity unavailable. */
static unsigned link_notice;
static BOOL fail(const char *step,DWORD error){wsprintfA(reason,"%s\r\nWindows error: %lu",step,error);return FALSE;}
const char *nt_reason(void){return reason[0]?reason:"Installation did not complete.";}
void nt_error(const char *step,DWORD error){fail(step,error);}
unsigned nt_linknotice(void){return link_notice;}
BOOL nt_newfile(const char *path){
 /* Called only immediately after an exclusive CopyFile to a new path. */
 return SetFileAttributesA(path,FILE_ATTRIBUTE_NORMAL)?TRUE:fail("Cannot set attributes on the newly installed file.",GetLastError());
}
static DWORD writable_owned(const char *path){
 DWORD attr=GetFileAttributesA(path);
 if(attr==INVALID_FILE_ATTRIBUTES)return GetLastError();
 if(attr&FILE_ATTRIBUTE_DIRECTORY)return ERROR_INVALID_DATA;
 if(attr&FILE_ATTRIBUTE_READONLY){attr&=~FILE_ATTRIBUTE_READONLY;if(!SetFileAttributesA(path,attr?attr:FILE_ATTRIBUTE_NORMAL))return GetLastError();}
 return 0;
}
static BOOL valid_link(const struct nt_linkrecord *link){
 int n;
 if(link->magic!=NT_LINK_MAGIC||link->path[MAX_PATH-1])return FALSE;
 n=lstrlenA(link->path);
 if(n<15||lstrcmpiA(link->path+n-13,"\\WINPWRNT.LNK"))return FALSE;
 if(((link->path[0]>='A'&&link->path[0]<='Z')||(link->path[0]>='a'&&link->path[0]<='z'))&&link->path[1]==':'&&link->path[2]=='\\')return TRUE;
 return link->path[0]=='\\'&&link->path[1]=='\\'&&link->path[2]&&link->path[2]!='.'&&link->path[2]!='?';
}
BOOL nt_linkmark(const char *path){
 DWORD error;have_link=FALSE;ZeroMemory(&staged_link,sizeof(staged_link));
 if(lstrlenA(path)>=MAX_PATH)return fail("The desktop shortcut path is too long.",ERROR_FILENAME_EXCED_RANGE);
 staged_link.magic=NT_LINK_MAGIC;lstrcpyA(staged_link.path,path);
 if(!valid_link(&staged_link))return fail("The desktop shortcut path is invalid.",ERROR_INVALID_NAME);
 error=wp_hash(path,staged_link.hash,0);
 if(error)return fail("Cannot record the created desktop shortcut.",error);
 have_link=TRUE;return TRUE;
}
static BOOL remove_link(const struct nt_linkrecord *link){
 BYTE digest[32];DWORD error;
 if(!valid_link(link)){link_notice=2;return TRUE;}
 error=wp_hash(link->path,digest,0);
 if(error==ERROR_FILE_NOT_FOUND||error==ERROR_PATH_NOT_FOUND)return TRUE;
 if(error){link_notice=2;return TRUE;}
 if(memcmp(digest,link->hash,32)){link_notice=1;return TRUE;}
 error=writable_owned(link->path);if(error)return fail("Cannot prepare the verified desktop shortcut for removal. Retry removal.",error);
 if(!DeleteFileA(link->path)){
  error=GetLastError();if(error!=ERROR_FILE_NOT_FOUND&&error!=ERROR_PATH_NOT_FOUND)return fail("Cannot remove the verified desktop shortcut. Retry removal.",error);
 }
 return TRUE;
}
BOOL nt_linkundo(void){
 if(!have_link){link_notice=2;return TRUE;}
 return remove_link(&staged_link);
}
BOOL nt_linkremove(const char *folder){
 HKEY meta;struct wp_config cfg;struct nt_linkrecord link;DWORD error,type,size=sizeof(link);
 error=RegOpenKeyExA(HKEY_LOCAL_MACHINE,WP_META,0,KEY_QUERY_VALUE,&meta);
 if(error)return fail("Cannot inspect desktop shortcut ownership.",error);
 error=wp_config(meta,&cfg);
 if(!error&&(cfg.kind!=4||lstrcmpiA(cfg.folder,folder)))error=ERROR_INVALID_DATA;
 if(error){RegCloseKey(meta);return fail("Invalid desktop shortcut installation record.",error);}
 error=RegQueryValueExA(meta,"Shortcut",0,&type,(BYTE*)&link,&size);RegCloseKey(meta);
 /* Older packages did not record link identity. Never use their editable
    INI path as a deletion target. Preserve any unverified shortcut. */
 if(error==ERROR_FILE_NOT_FOUND||error==ERROR_MORE_DATA){link_notice=2;return TRUE;}
 if(error)return fail("Cannot read desktop shortcut ownership.",error);
 if(type!=REG_BINARY||size!=sizeof(link)){link_notice=2;return TRUE;}
 return remove_link(&link);
}
BOOL nt_preflight(void){
 kind=wp_kind();if(!kind)return fail("This power package requires Windows NT 3.x or NT 4 x86.",ERROR_NOT_SUPPORTED);
 return TRUE;
}
BOOL nt_installed(const char *folder){
 /* TRUE if any WINPOWER startup-install marker is present: the recovery
    registry key, the installation directory, or either owned service. */
 HKEY key;SC_HANDLE manager,svc;DWORD k;BOOL found=FALSE;
 if(RegOpenKeyExA(HKEY_LOCAL_MACHINE,WP_META,0,KEY_QUERY_VALUE,&key)==ERROR_SUCCESS){RegCloseKey(key);return TRUE;}
 if(GetFileAttributesA(folder)!=INVALID_FILE_ATTRIBUTES)return TRUE;
 k=wp_kind();
 manager=OpenSCManagerA(0,0,SC_MANAGER_CONNECT);
 if(manager){
  svc=OpenServiceA(manager,WP_SERVICE,SERVICE_QUERY_STATUS);if(svc){CloseServiceHandle(svc);found=TRUE;}
  if(!found&&k){svc=OpenServiceA(manager,wp_kernel(k),SERVICE_QUERY_STATUS);if(svc){CloseServiceHandle(svc);found=TRUE;}}
  CloseServiceHandle(manager);
 }
 return found;
}
static void (*nt_progress_cb)(int);
void nt_setprogress(void (*cb)(int)){nt_progress_cb=cb;}
/* When the structural install succeeds but the kernel backend does not arm
   (no usable ACPI S5 / APM power method on this firmware), the install still
   completes and these report the driver's error and the stage it reached, so
   the failure can be diagnosed. 0 = the backend armed normally. */
static DWORD backend_warning,backend_stage;
DWORD nt_backendwarning(void){return backend_warning;}
DWORD nt_backendstage(void){return backend_stage;}
static DWORD read_driver_stage(void){
 HKEY k;DWORD v=0,sz=sizeof(v);char p[160];
 lstrcpyA(p,"System\\CurrentControlSet\\Services\\");lstrcatA(p,wp_kernel(kind));
 if(RegOpenKeyExA(HKEY_LOCAL_MACHINE,p,0,KEY_QUERY_VALUE,&k)==ERROR_SUCCESS){
  RegQueryValueExA(k,"Stage",0,0,(BYTE*)&v,&sz);RegCloseKey(k);
 }
 return v;
}
BOOL nt_stage(const char *self,const char *folder){
 char source[MAX_PATH],target[MAX_PATH];int i;DWORD error;
 if(!wp_folder(folder))return fail("Invalid destination directory.",ERROR_INVALID_NAME);
 if(lstrlenA(self)>=MAX_PATH)return fail("Source directory is too long.",ERROR_FILENAME_EXCED_RANGE);
 lstrcpyA(source,self);for(i=lstrlenA(source)-1;i>=0&&source[i]!='\\';i--){}
 if(i<0||i>MAX_PATH-18)return fail("Source directory is too long.",ERROR_FILENAME_EXCED_RANGE);
 lstrcpyA(source+i+1,"WINPSVC.EXE");wp_path(target,folder,"WINPSVC.EXE");
 if(!CopyFileA(source,target,TRUE))return fail("Cannot copy the startup service.",GetLastError());copied_service=TRUE;
 if(!nt_newfile(target))return FALSE;
 lstrcpyA(source+i+1,wp_driver(kind));wp_path(target,folder,wp_driver(kind));
 if(!CopyFileA(source,target,TRUE)){error=GetLastError();return fail("Cannot copy the selected kernel backend.",error);}copied_driver=TRUE;return nt_newfile(target);
}
static DWORD stop_service(SC_HANDLE service){
 SERVICE_STATUS state;DWORD start=GetTickCount(),error;BOOL requested=FALSE;
 for(;;){
  if(!QueryServiceStatus(service,&state))return GetLastError();
  if(state.dwCurrentState==SERVICE_STOPPED)return 0;
  if(!requested&&state.dwCurrentState==SERVICE_RUNNING){
   if(!ControlService(service,SERVICE_CONTROL_STOP,&state)){error=GetLastError();if(error!=ERROR_SERVICE_NOT_ACTIVE)return error;}
   requested=TRUE;
  }
  if(GetTickCount()-start>=20000)return ERROR_TIMEOUT;Sleep(100);
 }
}
static DWORD disable(SC_HANDLE service){
 if(!ChangeServiceConfigA(service,SERVICE_NO_CHANGE,SERVICE_DISABLED,SERVICE_NO_CHANGE,0,0,0,0,0,0,0)){
  DWORD error=GetLastError();return error==ERROR_SERVICE_MARKED_FOR_DELETE?0:error;
 }return 0;
}
static DWORD delete_service(SC_HANDLE service){
 if(!DeleteService(service)){DWORD error=GetLastError();return error==ERROR_SERVICE_MARKED_FOR_DELETE?0:error;}return 0;
}
BOOL nt_install(const char *folder){
 struct wp_config cfg;struct wp_regvalue value;HKEY meta=0,winlogon=0;SC_HANDLE manager=0,kernel=0,loader=0;
 DWORD error=0,disp,size,stage=0,last=0;unsigned i;char path[MAX_PATH],command[MAX_PATH+2];SERVICE_STATUS state;BOOL started=FALSE;
 backend_warning=0;backend_stage=0;
 ZeroMemory(&cfg,sizeof(cfg));cfg.magic=WP_CONFIG_MAGIC;cfg.kind=kind;lstrcpyA(cfg.folder,folder);
 for(i=0;i<4;i++){wp_path(path,folder,wp_file(kind,i));error=wp_hash(path,cfg.hashes[i],0);if(error)goto done;}
 error=RegCreateKeyExA(HKEY_LOCAL_MACHINE,WP_META,0,0,0,KEY_QUERY_VALUE|KEY_SET_VALUE,0,&meta,&disp);if(error)goto done;
 if(disp!=REG_CREATED_NEW_KEY){error=ERROR_ALREADY_EXISTS;goto done;}created_meta=TRUE;
 error=RegSetValueExA(meta,"Config",0,REG_BINARY,(BYTE*)&cfg,sizeof(cfg));if(error)goto done;
 if(kind==4){
  if(!have_link){error=ERROR_INVALID_DATA;goto done;}
  error=RegSetValueExA(meta,"Shortcut",0,REG_BINARY,(BYTE*)&staged_link,sizeof(staged_link));if(error)goto done;
 }
 if(kind==4){
  error=RegOpenKeyExA(HKEY_LOCAL_MACHINE,"Software\\Microsoft\\Windows NT\\CurrentVersion\\Winlogon",0,KEY_QUERY_VALUE,&winlogon);if(error)goto done;
  error=wp_regread(winlogon,&value);RegCloseKey(winlogon);winlogon=0;if(error)goto done;
  error=RegSetValueExA(meta,"PowerBefore",0,REG_BINARY,(BYTE*)&value,sizeof(value));if(error)goto done;saved_value=TRUE;
 }
 if((error=wp_setnum(meta,"Owner",0))||(error=wp_setnum(meta,"Removing",0))||(error=wp_setnum(meta,"Starts",0))||
    (error=wp_setnum(meta,"LastError",0))||(error=wp_setnum(meta,"Stage",0))||
    (error=wp_setnum(meta,"Ready",1))||(error=RegFlushKey(meta)))goto done;
 manager=OpenSCManagerA(0,0,SC_MANAGER_CREATE_SERVICE);if(!manager){error=GetLastError();goto done;}
 wp_path(path,folder,wp_driver(kind));
 /* Demand-start the kernel backend. The auto-start WINPSVC loader owns the
    boot-time arming: at every boot it captures a user-mode
    SystemBasicInformation snapshot, writes it as the driver's "BasicInfo"
    value (NT 3.1 has no hardware memory-map registry key for the driver to
    read), and only then starts the driver. An auto-started driver would run
    before the loader has written BasicInfo, so DriverEntry would fail to find
    the ACPI tables and return STATUS_NOT_SUPPORTED ("service failed to start",
    SCM error 50). The loader also validates this service as demand-start, so
    an auto-start type makes the loader refuse it with ERROR_INVALID_DATA. */
 kernel=CreateServiceA(manager,wp_kernel(kind),kind==3?"WINPOWER NT3 final power":"WINPOWER NT4 final power",SERVICE_ALL_ACCESS,SERVICE_KERNEL_DRIVER,SERVICE_DEMAND_START,SERVICE_ERROR_NORMAL,path,0,0,0,0,0);
 if(!kernel){error=GetLastError();goto done;}created_kernel=TRUE;
 /* The fixed 8.3 path has no spaces. NT 3.1/3.50 SCM does not reliably
    accept a quoted executable path here. */
 wp_path(path,folder,"WINPSVC.EXE");lstrcpyA(command,path);
 loader=CreateServiceA(manager,WP_SERVICE,"WINPOWER startup",SERVICE_ALL_ACCESS,SERVICE_WIN32_OWN_PROCESS,SERVICE_AUTO_START,SERVICE_ERROR_NORMAL,command,0,0,0,0,0);
 if(!loader){error=GetLastError();goto done;}created_service=TRUE;
 if(!StartServiceA(loader,0,0)){error=GetLastError();goto done;}
 started=TRUE;
 size=GetTickCount();
 for(;;){
  if(!QueryServiceStatus(loader,&state)){error=GetLastError();break;}
  if(state.dwCurrentState==SERVICE_RUNNING){
   error=wp_getnum(meta,"Stage",&stage);if(error)break;
   if(stage==6)break;
  }
  if(state.dwCurrentState==SERVICE_STOPPED){error=state.dwWin32ExitCode?state.dwWin32ExitCode:ERROR_SERVICE_NOT_ACTIVE;break;}
  if(GetTickCount()-size>=20000){error=ERROR_TIMEOUT;break;}
  if(nt_progress_cb){DWORD e=GetTickCount()-size;nt_progress_cb(e>=20000?98:(int)(80+e*18/20000));}
  Sleep(100);
 }
 if(!error){error=wp_getnum(meta,"Stage",&stage);if(!error)error=wp_getnum(meta,"LastError",&last);if(!error&&(last||stage!=6))error=last?last:ERROR_INVALID_DATA;}
 done:
 if(loader)CloseServiceHandle(loader);if(kernel)CloseServiceHandle(kernel);if(manager)CloseServiceHandle(manager);
 if(winlogon)RegCloseKey(winlogon);if(meta)RegCloseKey(meta);
 /* Structural install failed (files/registry/services) -> real failure, roll
    back. The loader started but the kernel backend did not arm (no usable
    ACPI/APM on this firmware) -> the install is complete; keep it and report
    the backend's error and the stage it reached so it can be diagnosed and so
    a later boot can arm it if the firmware allows. */
 if(error&&!started)return fail("The startup service could not activate this power backend.",error);
 if(error){backend_warning=error;backend_stage=read_driver_stage();}
 return TRUE;
}
BOOL nt_abort(const char *folder){
 SC_HANDLE manager=0,loader=0,kernel=0;HKEY meta=0;SERVICE_STATUS state;DWORD error=0,result;BOOL resident=FALSE;char path[MAX_PATH];
 if(created_meta){
  result=RegOpenKeyExA(HKEY_LOCAL_MACHINE,WP_META,0,KEY_QUERY_VALUE|KEY_SET_VALUE,&meta);
  if(result)error=result;else {result=wp_setnum(meta,"Removing",1);if(result)error=result;}
 }
 if(created_service||created_kernel){
  manager=OpenSCManagerA(0,0,SC_MANAGER_CONNECT);if(!manager)error=GetLastError();
  if(manager&&created_service){
   wp_path(path,folder,"WINPSVC.EXE");result=wp_owned(manager,WP_SERVICE,path,SERVICE_WIN32_OWN_PROCESS,&loader);
   if(result)error=result;else {result=disable(loader);if(!result)result=stop_service(loader);if(result)error=result;}
  }
  if(manager&&created_kernel){
   wp_path(path,folder,wp_driver(kind));result=wp_owned(manager,wp_kernel(kind),path,SERVICE_KERNEL_DRIVER,&kernel);
   if(result)error=result;else {result=disable(kernel);if(result)error=result;
    if(QueryServiceStatus(kernel,&state))resident=state.dwCurrentState!=SERVICE_STOPPED;else error=GetLastError();
   }
  }
 }
 if(saved_value&&meta){result=wp_winlogon(meta,TRUE);if(result)error=result;}
 if(!error&&!resident){
  if(loader){result=delete_service(loader);if(result)error=result;}
  if(kernel){result=delete_service(kernel);if(result)error=result;}
 }
 if(loader)CloseServiceHandle(loader);if(kernel)CloseServiceHandle(kernel);if(manager)CloseServiceHandle(manager);if(meta)RegCloseKey(meta);
 if(error||resident)return fail("Cleanup requires a restart. Installation files were retained. Restart, then run the installed UNINST.EXE to finish removal.",error?error:ERROR_BUSY);
 if(copied_driver){wp_path(path,folder,wp_driver(kind));result=writable_owned(path);if(result)return fail("Cannot prepare the staged driver for removal. Recovery state was retained.",result);if(!DeleteFileA(path))return fail("Cannot remove the staged driver. Installation files were retained.",GetLastError());}
 if(copied_service){wp_path(path,folder,"WINPSVC.EXE");result=writable_owned(path);if(result)return fail("Cannot prepare the staged service for removal. Recovery state was retained.",result);if(!DeleteFileA(path))return fail("Cannot remove the staged service. Installation files were retained.",GetLastError());}
 return TRUE;
}
BOOL nt_abortfinish(void){
 DWORD error;
 /* Keep Config and Removing=1 until staged files and shell registration
    have actually been removed. SETUP /REMOVE can retry a failed cleanup. */
 if(!created_meta)return TRUE;
 error=RegDeleteKeyA(HKEY_LOCAL_MACHINE,WP_META);
 if(error&&error!=ERROR_FILE_NOT_FOUND)return fail("Rollback files were removed, but its recovery record remains. Retry SETUP.EXE /REMOVE.",error);
 RegDeleteKeyA(HKEY_LOCAL_MACHINE,"Software\\WINPOWER");return TRUE;
}
BOOL nt_remove(const char *folder,BOOL external){
 struct wp_config cfg;HKEY meta=0;SC_HANDLE manager=0,loader=0,kernel=0;HANDLE locks[4]={0,0,0,0},probe;
 DWORD error,removing;char path[MAX_PATH];BYTE digest[32];unsigned i;BOOL changed=FALSE;
 HANDLE owner_mutex=NULL;DWORD wait;BOOL locked=FALSE;
 error=RegOpenKeyExA(HKEY_LOCAL_MACHINE,WP_META,0,KEY_QUERY_VALUE|KEY_SET_VALUE,&meta);if(error)goto done;
 error=wp_config(meta,&cfg);if(error)goto done;
 if(lstrcmpiA(cfg.folder,folder)){error=ERROR_INVALID_NAME;goto done;}
 error=wp_getnum(meta,"Removing",&removing);if(error||removing>1){if(!error)error=ERROR_INVALID_DATA;goto done;}
 /* A retry may follow partial delayed deletion. Validate all remaining
    owned files; accept missing files only after removal was recorded. */
 for(i=0;i<4;i++){
  wp_path(path,folder,wp_file(cfg.kind,i));error=wp_hash(path,digest,0);
  if(removing&&(error==ERROR_FILE_NOT_FOUND||error==ERROR_PATH_NOT_FOUND))error=0;
  else if(!error){
   if(memcmp(digest,cfg.hashes[i],32))error=ERROR_CRC;
   else error=writable_owned(path);
  }
  if(error)goto done;
 }
 /* SETUP /REMOVE may recover an older compatible installation. All
    remaining installed files still have to match that installation's
    saved hashes; only the external recovery executable may be newer. */
 if(!external){
  if(!GetModuleFileNameA(0,path,MAX_PATH)){error=GetLastError();goto done;}
  error=wp_hash(path,digest,0);if(!error&&memcmp(digest,cfg.hashes[1],32))error=ERROR_CRC;if(error)goto done;
 }
 wp_path(path,folder,"WINPWRNT.EXE");
 probe=CreateFileA(path,GENERIC_READ|GENERIC_WRITE,0,0,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,0);
 if(probe==INVALID_HANDLE_VALUE){error=GetLastError();if(!removing||(error!=ERROR_FILE_NOT_FOUND&&error!=ERROR_PATH_NOT_FOUND))goto done;error=0;}
 else CloseHandle(probe);
 manager=OpenSCManagerA(0,0,SC_MANAGER_CONNECT);if(!manager){error=GetLastError();goto done;}
 wp_path(path,folder,"WINPSVC.EXE");error=wp_owned(manager,WP_SERVICE,path,SERVICE_WIN32_OWN_PROCESS,&loader);
 if(error==ERROR_SERVICE_DOES_NOT_EXIST||error==ERROR_SERVICE_MARKED_FOR_DELETE)error=0;if(error)goto done;
 wp_path(path,folder,wp_driver(cfg.kind));error=wp_owned(manager,wp_kernel(cfg.kind),path,SERVICE_KERNEL_DRIVER,&kernel);
 if(error==ERROR_SERVICE_DOES_NOT_EXIST||error==ERROR_SERVICE_MARKED_FOR_DELETE)error=0;if(error)goto done;
 /* Serialize disarming and the removal marker with a startup/GUI change.
    Release the mutex before waiting for the startup service to stop. */
 owner_mutex=CreateMutexA(NULL,FALSE,WP_OWNER_MUTEX);
 if(!owner_mutex){error=GetLastError();goto done;}
 wait=WaitForSingleObject(owner_mutex,30000);
 if(wait!=WAIT_OBJECT_0&&wait!=WAIT_ABANDONED){error=wait==WAIT_TIMEOUT?ERROR_TIMEOUT:GetLastError();goto done;}
 locked=TRUE;
 error=wp_getnum(meta,"Removing",&removing);if(error||removing>1){if(!error)error=ERROR_INVALID_DATA;goto done;}
 if(!removing){
  error=wp_legacy_owner(cfg.kind,0);
  if(error==ERROR_FILE_NOT_FOUND||error==ERROR_PATH_NOT_FOUND||error==ERROR_INVALID_FUNCTION||error==ERROR_NOT_SUPPORTED)error=0;
  if(error)goto done;
  error=wp_setnum(meta,"Removing",1);if(error)goto done;
 }
 changed=TRUE;ReleaseMutex(owner_mutex);locked=FALSE;
 if(loader){error=disable(loader);if(!error)error=stop_service(loader);if(error)goto done;}
 if(kernel){error=disable(kernel);if(error)goto done;}
 if(cfg.kind==4){error=wp_winlogon(meta,TRUE);if(error)goto done;}
 if(loader){error=delete_service(loader);if(error)goto done;}
 if(kernel){error=delete_service(kernel);if(error)goto done;}
 done:
 if(locked)ReleaseMutex(owner_mutex);if(owner_mutex)CloseHandle(owner_mutex);
 wp_unlock(locks);if(loader)CloseServiceHandle(loader);if(kernel)CloseServiceHandle(kernel);if(manager)CloseServiceHandle(manager);if(meta)RegCloseKey(meta);
 if(error)return fail(changed?"Startup removal is incomplete. Files were retained; retry UNINST.EXE before restarting.":"Cannot remove the owned power installation. Close WINPOWER and check that its installed files are unchanged.",error);
 return TRUE;
}
BOOL nt_finish(const char *folder){
 struct wp_config cfg;HKEY meta=0;DWORD error,removing;unsigned i;char path[MAX_PATH];BYTE digest[32];
 error=RegOpenKeyExA(HKEY_LOCAL_MACHINE,WP_META,0,KEY_QUERY_VALUE,&meta);if(error)goto done;
 error=wp_config(meta,&cfg);if(error)goto done;
 error=wp_getnum(meta,"Removing",&removing);if(error||removing!=1||lstrcmpiA(cfg.folder,folder)){if(!error)error=ERROR_INVALID_DATA;goto done;}
 /* Only after startup is disabled and shell items are removed, queue the
    remaining files. A retained registry record permits SETUP /REMOVE to
    retry after an interrupted cleanup, including after a restart. */
 for(i=0;i<4;i++){
  wp_path(path,folder,wp_file(cfg.kind,i));error=wp_hash(path,digest,0);
  if(error==ERROR_FILE_NOT_FOUND||error==ERROR_PATH_NOT_FOUND){error=0;continue;}
  if(!error&&memcmp(digest,cfg.hashes[i],32))error=ERROR_CRC;if(error)goto done;
  error=writable_owned(path);if(error)goto done;
  if(!MoveFileExA(path,0,MOVEFILE_DELAY_UNTIL_REBOOT)){error=GetLastError();goto done;}
 }
 wp_path(path,folder,"WINPOWER.INI");
 if(GetFileAttributesA(path)!=INVALID_FILE_ATTRIBUTES){
  if(!MoveFileExA(path,0,MOVEFILE_DELAY_UNTIL_REBOOT)){error=GetLastError();goto done;}
 }else {error=GetLastError();if(error!=ERROR_FILE_NOT_FOUND&&error!=ERROR_PATH_NOT_FOUND)goto done;error=0;}
 if(GetFileAttributesA(folder)!=INVALID_FILE_ATTRIBUTES){
  if(!MoveFileExA(folder,0,MOVEFILE_DELAY_UNTIL_REBOOT)){error=GetLastError();goto done;}
 }else {error=GetLastError();if(error!=ERROR_FILE_NOT_FOUND&&error!=ERROR_PATH_NOT_FOUND)goto done;error=0;}
 RegCloseKey(meta);meta=0;error=RegDeleteKeyA(HKEY_LOCAL_MACHINE,WP_META);
 if(error==ERROR_FILE_NOT_FOUND)error=0;
 if(!error)RegDeleteKeyA(HKEY_LOCAL_MACHINE,"Software\\WINPOWER");
 done:if(meta)RegCloseKey(meta);
 return error?fail("Startup is disabled, but file cleanup is incomplete. Retry the original SETUP.EXE /REMOVE to finish.",error):TRUE;
}
BOOL nt_target(char *folder){
 struct wp_config cfg;HKEY meta;DWORD error;
 error=RegOpenKeyExA(HKEY_LOCAL_MACHINE,WP_META,0,KEY_QUERY_VALUE,&meta);
 if(error)return fail("No valid startup installation was found.",error);
 error=wp_config(meta,&cfg);RegCloseKey(meta);
 if(error)return fail("The installation record is invalid.",error);
 lstrcpyA(folder,cfg.folder);return TRUE;
}
