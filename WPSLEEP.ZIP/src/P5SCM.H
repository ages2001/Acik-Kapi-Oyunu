#ifndef WINPOWER_P5SCM_H
#define WINPOWER_P5SCM_H
/* Standard SCM registration for installed NT5 packages. */
#define WP5_NAME "WINPWR5"
#define WP5_TITLE "WINPOWER final power driver"
#define WP5_IMAGE "\\SystemRoot\\System32\\drivers\\WINPWR5.SYS"
DWORD wp5_start(void);
DWORD wp5_remember(DWORD owner);
DWORD wp5_disarm_legacy(BOOL *found);
DWORD wp5_install(const char *source);
DWORD wp5_remove(void);
#endif
