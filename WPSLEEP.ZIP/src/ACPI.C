#include "ACPI.H"
static int sumok(const unsigned char *p, unsigned long n) {
    unsigned char s = 0; unsigned long i;
    for (i = 0; i < n; ++i) s = (unsigned char)(s + p[i]);
    return s == 0;
}
int pn_rsdp(const unsigned char *p, unsigned long n) {
    unsigned long len; unsigned i;
    static const char sig[] = "RSD PTR ";
    if (!p || n < 20) return -1;
    for (i = 0; i < 8; ++i) if (p[i] != (unsigned char)sig[i]) return -1;
    if (!sumok(p, 20)) return -1;
    if (p[15] == 0) return 0;
    if (p[15] < 2 || n < 36) return -1;
    len = (unsigned long)p[20] | ((unsigned long)p[21] << 8) |
          ((unsigned long)p[22] << 16) | ((unsigned long)p[23] << 24);
    if (len < 36 || len > n || !sumok(p, len)) return -1;
    return p[15];
}
