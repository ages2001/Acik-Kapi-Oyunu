#ifndef WP_SLPVIDEO_H
#define WP_SLPVIDEO_H
/* Read the primary adapter name reported by USER and its active display
   driver list. The adapter name never limits the available power actions. */
static void wp_sleep_video(char *label, unsigned capacity)
{
    typedef BOOL (WINAPI *enum_adapters)(LPCSTR,DWORD,PDISPLAY_DEVICEA,DWORD);
    enum_adapters list=(enum_adapters)GetProcAddress(GetModuleHandleA("USER32.DLL"),"EnumDisplayDevicesA");
    DISPLAY_DEVICEA dev;
    HKEY key;
    char modules[160];
    DWORD n,i,type=0;
    static const char machine[]="\\Registry\\Machine\\";
    if(capacity<4)return;
    lstrcpyA(label,"N/A");
    if(!list)return;
    for(i=0;i<64;i++){
        ZeroMemory(&dev,sizeof(dev));dev.cb=sizeof(dev);
        if(!list(NULL,i,&dev,0))return;
        if(!(dev.StateFlags&DISPLAY_DEVICE_PRIMARY_DEVICE))continue;
        dev.DeviceString[sizeof(dev.DeviceString)-1]=0;
        if(dev.DeviceString[0]){
            unsigned k=0;
            while(k+1<capacity && dev.DeviceString[k]){label[k]=dev.DeviceString[k];++k;}
            label[k]=0;
        }
        dev.DeviceKey[sizeof(dev.DeviceKey)-1]=0;
        if(lstrlenA(dev.DeviceKey)<(int)sizeof(machine) || dev.DeviceKey[0]!='\\')return;
        for(n=0;n<sizeof(machine)-1;n++)
            if((dev.DeviceKey[n]|32)!=(machine[n]|32))return;
        if(RegOpenKeyExA(HKEY_LOCAL_MACHINE,dev.DeviceKey+sizeof(machine)-1,0,KEY_QUERY_VALUE,&key)!=ERROR_SUCCESS)return;
        n=sizeof(modules)-1;
        if(RegQueryValueExA(key,"InstalledDisplayDrivers",NULL,&type,(BYTE*)modules,&n)==ERROR_SUCCESS &&
           n>0 && (type==REG_SZ||type==REG_MULTI_SZ)){
            modules[n]=0;
            if(modules[0] && (unsigned)(lstrlenA(label)+lstrlenA(modules)+4)<=capacity){
                lstrcatA(label," (");lstrcatA(label,modules);lstrcatA(label,")");
            }
        }
        RegCloseKey(key);return;
    }
}
#endif
