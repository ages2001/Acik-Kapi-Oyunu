#ifndef WINPOWER_FWTABLE_H
#define WINPOWER_FWTABLE_H
/* OS-provided FADT metadata, never a claim of complete ACPI support. */
#define WP_FADT_MAX 65536UL
struct wp_fwtable {
 unsigned long table_length,flags;
 unsigned revision,minor_revision,minor_valid,flags_valid;
 unsigned capabilities_valid,reset_register,hardware_reduced,low_power_s0;
};
void wp_fw_clear(struct wp_fwtable *info);
int wp_fadt(const unsigned char *data,unsigned long size,struct wp_fwtable *info);
#endif
