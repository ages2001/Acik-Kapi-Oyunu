/* Windows/386 has a separate protected-mode entry point. */
#ifndef WP_ENTRY16_H
#define WP_ENTRY16_H
#ifdef PN_386_ENTRY
#define WP_ENTRY_FILE "WIN386.EXE"
#define WP_ENTRY_CMD "WIN386"
#else
#define WP_ENTRY_FILE "WIN.COM"
#define WP_ENTRY_CMD "WIN"
#endif
#endif
