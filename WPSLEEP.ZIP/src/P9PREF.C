/* Win9x loads the VxD from SYSTEM.INI, then applies the owner's saved choice
   using RunServices. The bootstrap never requests shutdown or loads a VxD. */
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include "P9PREF.H"
static const char product[] = "Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\WINPWR9X";
static const char startup[] = "Software\\Microsoft\\Windows\\CurrentVersion\\RunServices";
static const char value_name[] = "WINPWR9X";
static DWORD run_entry(const char *folder, BOOL add)
{
    char command[MAX_PATH + 24], actual[MAX_PATH + 24];
    DWORD type, bytes = sizeof(actual);
    LONG error;
    HKEY key;
    if (lstrlenA(folder) >= MAX_PATH-16) return ERROR_BAD_PATHNAME;
    wsprintfA(command, "\"%s\\WINPWR9X.EXE\" /RESTORE", folder);
    error = add ? RegCreateKeyA(HKEY_LOCAL_MACHINE, startup, &key) :
                  RegOpenKeyA(HKEY_LOCAL_MACHINE, startup, &key);
    if (error) return !add && error == ERROR_FILE_NOT_FOUND ? 0 : error;
    error = RegQueryValueExA(key, value_name, 0, &type, (BYTE*)actual, &bytes);
    if (add && error == ERROR_FILE_NOT_FOUND)
        error = RegSetValueExA(key, value_name, 0, REG_SZ, (BYTE*)command, lstrlenA(command)+1);
    else if (!add && error == ERROR_FILE_NOT_FOUND) error = 0;
    else if (!error) {
        if (type != REG_SZ || bytes != (DWORD)lstrlenA(command)+1 ||
            actual[bytes-1] || lstrcmpiA(command, actual))
            error = ERROR_ALREADY_EXISTS;
        else if (!add) error = RegDeleteValueA(key, value_name);
        else error = ERROR_ALREADY_EXISTS;
    }
    RegCloseKey(key);
    return error;
}
DWORD wp9_add_pref(const char *folder)
{
    HKEY key;
    DWORD owner = 0, error = RegOpenKeyA(HKEY_LOCAL_MACHINE, product, &key);
    if (error) return error;
    error = run_entry(folder, TRUE);
    if (!error) {
        error = RegSetValueExA(key, "Owner", 0, REG_DWORD, (BYTE*)&owner, sizeof(owner));
        if (error) run_entry(folder, FALSE);
    }
    RegCloseKey(key);
    return error;
}
DWORD wp9_del_pref(const char *folder) { return run_entry(folder, FALSE); }

static DWORD saved_owner(DWORD *owner, BOOL set)
{
    HKEY key;
    DWORD type, bytes = sizeof(DWORD), old;
    LONG error = RegOpenKeyA(HKEY_LOCAL_MACHINE, product, &key);
    if (error == ERROR_FILE_NOT_FOUND) return 0; /* Portable current-boot mode. */
    if (error) return error;
    error = RegQueryValueExA(key, "Owner", 0, &type, (BYTE*)&old, &bytes);
    if (error == ERROR_FILE_NOT_FOUND) error = 0;
    else if (!error) {
        if (type != REG_DWORD || bytes != sizeof(old) || old > 1) error = ERROR_INVALID_DATA;
        else if (set) error = RegSetValueExA(key, "Owner", 0, REG_DWORD, (BYTE*)owner, sizeof(*owner));
        else *owner = old;
    }
    RegCloseKey(key);
    return error;
}
DWORD wp9_remember(DWORD owner) { return saved_owner(&owner, TRUE); }
DWORD wp9_restore(void)
{
    DWORD owner=0, actual=2, bytes, error=saved_owner(&owner, FALSE);
    HANDLE dev;
    if (error || !owner) return error;
    dev = CreateFileA("\\\\.\\PN9HOOK",0,0,NULL,OPEN_EXISTING,0,NULL);
    if (dev == INVALID_HANDLE_VALUE) return GetLastError();
    if (!DeviceIoControl(dev,5,NULL,0,&actual,sizeof(actual),&bytes,NULL) ||
        !DeviceIoControl(dev,4,&owner,sizeof(owner),NULL,0,&bytes,NULL) ||
        !DeviceIoControl(dev,5,NULL,0,&actual,sizeof(actual),&bytes,NULL))
        error=GetLastError();
    else if (bytes!=sizeof(actual) || actual!=owner) error=ERROR_INVALID_DATA;
    CloseHandle(dev);
    return error;
}
