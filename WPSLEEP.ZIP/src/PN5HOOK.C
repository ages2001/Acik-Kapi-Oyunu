#include "FWVER.H"
/* NT5 final power handoff candidate. See N5HAND.C for qualification limits. */
#include <ntddk.h>
#include "S5.H"
#include "PWRSEQ.H"
#include "ACPI.H"
#include "N5HAND.H"
#ifdef PN_AML
#include "NTAML.H"
#include "NTAPM.H"
#endif
NTSYSAPI NTSTATUS NTAPI ZwQuerySystemInformation(ULONG,PVOID,ULONG,PULONG);
extern __declspec(dllimport) CCHAR KeNumberProcessors;
static PUNICODE_STRING servicekey;
static void mark(ULONG value){OBJECT_ATTRIBUTES a;UNICODE_STRING n;HANDLE k;
 InitializeObjectAttributes(&a,servicekey,OBJ_CASE_INSENSITIVE,0,0);
 if(NT_SUCCESS(ZwOpenKey(&k,KEY_SET_VALUE,&a))){RtlInitUnicodeString(&n,L"Stage");ZwSetValueKey(k,&n,0,REG_DWORD,&value,sizeof(value));ZwClose(k);}}
/* Only our installed service uses its SCM start type as the saved owner.
   A portable or third-party loader always starts with OS control. */
static BOOLEAN auto_owner(PUNICODE_STRING path)
{
 UNICODE_STRING suffix, tail, value;
 KEY_VALUE_PARTIAL_INFORMATION *info;
 union { ULONG align; UCHAR data[64]; } buffer;
 OBJECT_ATTRIBUTES attributes;
 HANDLE key;
 ULONG bytes, start;
 NTSTATUS result;
 RtlInitUnicodeString(&suffix, L"\\WINPWR5");
 if (path->Length < suffix.Length) return FALSE;
 tail.Length = tail.MaximumLength = suffix.Length;
 tail.Buffer = path->Buffer + (path->Length - suffix.Length) / sizeof(WCHAR);
 if (!RtlEqualUnicodeString(&suffix, &tail, TRUE)) return FALSE;
 InitializeObjectAttributes(&attributes, path, OBJ_CASE_INSENSITIVE, NULL, NULL);
 if (!NT_SUCCESS(ZwOpenKey(&key, KEY_QUERY_VALUE, &attributes))) return FALSE;
 RtlInitUnicodeString(&value, L"Start");
 result = ZwQueryValueKey(key, &value, KeyValuePartialInformation,
                          buffer.data, sizeof(buffer.data), &bytes);
 ZwClose(key);
 info = (KEY_VALUE_PARTIAL_INFORMATION *)buffer.data;
 if (!NT_SUCCESS(result) || info->Type != REG_DWORD ||
     info->DataLength != sizeof(start)) return FALSE;
 RtlCopyMemory(&start, info->Data, sizeof(start));
 return start == 2;  /* SERVICE_AUTO_START */
}
static struct pn_acpi firmware;
#ifdef WP_2000
int wp_n5_has_reset_register(void) { return firmware.reset_ok != 0; }
#endif
static ULONG status[8];
static UNICODE_STRING linkname;
static unsigned get16(void *arg,unsigned port){USHORT value;(void)arg;__asm__ volatile("inw %w1,%0":"=a"(value):"d"((USHORT)port));return value;}
static void put16(void *arg,unsigned port,unsigned value){(void)arg;__asm__ volatile("outw %0,%w1"::"a"((USHORT)value),"d"((USHORT)port));}
static void put8(void *arg,unsigned port,unsigned value){(void)arg;__asm__ volatile("outb %0,%w1"::"a"((UCHAR)value),"d"((USHORT)port));}
static void waitio(void *arg,unsigned ticks){unsigned i;(void)arg;for(i=0;i<ticks*55;i++)KeStallExecutionProcessor(1000);}
#ifdef PN_AML
static const struct pn_io ports={0,get16,put16,put8,waitio,0,pn_ntreg_write,pn_ntreg_read16};
#else
static const struct pn_io ports={0,get16,put16,put8,waitio,0,0,0};
#endif
void wp_n5_power(ULONG action){
 const char *trace=action==1?"WINPOWER FINAL OFF\n":"WINPOWER FINAL RESET\n";
 while(*trace)put8(0,0xe9,(unsigned char)*trace++);
 status[6]=action;
 /* action 0/1 -> power off (ACPI S5 preferred, APM fallback);
    2/3 -> hardware reset. */
 if(action==0||action==1){
  if((firmware.off_ok||firmware.reduced)&&pn_s5off(&firmware,&ports)<0)return;
#ifdef PN_AML
  if(pn_apm_available()&&pn_apm_permitted(&firmware,&ports))pn_apm_off();
#endif
 }
 else if(action==2||action==3){
#ifdef WP_2000
  pn_reset_fixed(&firmware,&ports);
#else
  pn_reset(&firmware,&ports);
#endif
 }
}
static int readphys(void *arg,pn_address address,unsigned char *out,unsigned size){
 PHYSICAL_ADDRESS a;PUCHAR mapped;(void)arg;
 /* Map firmware/ACPI physical memory on demand wherever the ACPI pointers
    lead (Linux acpi_os_map_memory model): RSDP in the low 1 MiB, tables
    wherever the structures reference - commonly a reserved region outside the
    OS RAM map. The reader checks the native address width, so
    VirtualBox/VMware hole-punched maps read like real hardware. Firmware
    writes stay policed by the NTAML firmware-area rules. */
#ifdef PN_WIDE_TABLES
 const pn_address max_physical=((pn_address)0xfffffUL<<32)|0xffffffffUL;
 if(!size||address<0x400||address>max_physical-(size-1U))return 0;
#else
 if(!size||address<0x400||address>=0xfffff000UL||size>0xfffff000UL-address)return 0;
#endif
 a.QuadPart=address;mapped=MmMapIoSpace(a,size,MmNonCached);if(!mapped)return 0;
 RtlCopyMemory(out,mapped,size);MmUnmapIoSpace(mapped,size);return 1;
}
/* SYSTEM_BASIC_INFORMATION. The user-mode-address and affinity fields are
   pointer-width, so this structure is 44 bytes on x86 and 64 on x64;
   SystemBasicInformation rejects any other length with STATUS_INFO_LENGTH_
   MISMATCH, so a fixed ULONG[] array (x86 size) fails the query on x64. */
struct pn_sbi{ULONG reserved,timer,pagesize,numphys,lowphys,highphys,allocgran;
 ULONG_PTR minuser,maxuser,affinity;CCHAR nproc;};
static int discover(void){
 struct pn_sbi basic;ULONG got=0,ebda,p,found=0;UCHAR bytes[36],*work;int ok;
 if(!NT_SUCCESS(ZwQuerySystemInformation(0,&basic,sizeof(basic),&got)))return 0;
 if(basic.pagesize!=4096)return 0;
 if(!readphys(0,0x40e,bytes,2))return 0;ebda=((ULONG)bytes[0]|((ULONG)bytes[1]<<8))<<4;
 if(ebda>=0x400&&ebda<=0x9ffff)for(p=ebda;p+36<=ebda+1024&&p+36<=0x100000;p+=16){
  if(readphys(0,p,bytes,36)&&pn_rsdp(bytes,36)>=0){found=p;break;}
 }
 if(!found)for(p=0xe0000;p<=0x100000-36;p+=16){if(readphys(0,p,bytes,36)&&pn_rsdp(bytes,36)>=0){found=p;break;}}
 if(!found)return 0;
#ifdef PN_AML
 pn_ntaml_pages(basic.highphys,ebda);
 work=ExAllocatePool(NonPagedPool,262144);if(!work){pn_ntaml_release();return 0;}
 ok=pn_tables(readphys,0,found,&firmware,work,262144);ExFreePool(work);
 if(ok)pn_bindregs(&firmware,pn_ntreg_bind);
 pn_ntaml_done(ok&&firmware.off_ok);
 /* This NT5 callback may be at elevated IRQL. A firmware preparation
    method can require pageable services and must not run here. */
 if(pn_ntaml_prepared())firmware.off_ok=0;
 return ok&&firmware.off_ok;
#else
 work=ExAllocatePool(NonPagedPool,32768);if(!work)return 0;
 ok=pn_tables(readphys,0,found,&firmware,work,32768);ExFreePool(work);if(ok)pn_bindregs(&firmware,0);return ok&&firmware.off_ok;
#endif
}
static NTSTATUS NTAPI dispatch(PDEVICE_OBJECT dev,PIRP irp){
 PIO_STACK_LOCATION s=IoGetCurrentIrpStackLocation(irp);NTSTATUS st=STATUS_INVALID_DEVICE_REQUEST;ULONG bytes=0;(void)dev;
 if(s->MajorFunction==IRP_MJ_CREATE||s->MajorFunction==IRP_MJ_CLOSE)st=STATUS_SUCCESS;
 else if(s->MajorFunction==IRP_MJ_DEVICE_CONTROL&&s->Parameters.DeviceIoControl.IoControlCode==0x00226000){
  if(s->Parameters.DeviceIoControl.OutputBufferLength<sizeof(status))st=STATUS_BUFFER_TOO_SMALL;
  else{status[5]=wp_n5_state();RtlCopyMemory(irp->AssociatedIrp.SystemBuffer,status,sizeof(status));bytes=sizeof(status);st=STATUS_SUCCESS;}
 }
 else if(s->MajorFunction==IRP_MJ_DEVICE_CONTROL&&s->Parameters.DeviceIoControl.IoControlCode==0x0022600C){
  if(s->Parameters.DeviceIoControl.InputBufferLength!=sizeof(ULONG))st=STATUS_INVALID_PARAMETER;
  else st=wp_n5_set(*(ULONG*)irp->AssociatedIrp.SystemBuffer);
 }
 else if(s->MajorFunction==IRP_MJ_SHUTDOWN){
  /* Notification only. It carries no restart/off distinction and is not
     the final storage barrier. Actual hardware writes happen in N5HAND. */
  wp_n5_latch();st=STATUS_SUCCESS;
 }
 irp->IoStatus.Status=st;irp->IoStatus.Information=bytes;IoCompleteRequest(irp,IO_NO_INCREMENT);return st;
}
static NTSTATUS start_driver(PDRIVER_OBJECT driver,PUNICODE_STRING registry){
 ULONG major,minor,build,i;UNICODE_STRING name;PDEVICE_OBJECT dev;NTSTATUS st;(void)registry;
 servicekey=registry;mark(10);PsGetVersion(&major,&minor,&build,0);
 /* Windows 2000 (5.0) and Windows XP / Server 2003 (5.1/5.2), x86. */
 if(major!=5||minor>2||KeNumberProcessors<1)return STATUS_NOT_SUPPORTED;
#ifdef WP_2000
 if(minor!=0||build!=2195)return STATUS_NOT_SUPPORTED;
#endif
 mark(30);
#ifdef PN_AML
 /* ACPI is expected on NT5; the APM path is only a safety fallback. */
#ifdef WP_2000
 /* Eager low-memory APM setup competes with the RTM memory manager at
    service startup. An active ACPI platform cannot use that fallback.
    Only allocate BIOS resources when the current firmware permits APM. */
 {const char *msg="WINPOWER DISCOVERY START\n";while(*msg)put8(0,0xe9,(unsigned char)*msg++);}
 discover();
 if(pn_apm_permitted(&firmware,&ports))pn_apm_init();
 {const char *msg="WINPOWER DISCOVERY DONE\n";while(*msg)put8(0,0xe9,(unsigned char)*msg++);}
#else
 discover();
 if(!firmware.reduced)pn_apm_init();
#endif
 if(!firmware.off_ok&&!pn_apm_available())return STATUS_NOT_SUPPORTED;
#else
 if(!discover())return STATUS_NOT_SUPPORTED;
 if(!firmware.off_ok)return STATUS_NOT_SUPPORTED;
#endif
 mark(40);RtlInitUnicodeString(&name,L"\\Device\\PN5LAB");RtlInitUnicodeString(&linkname,L"\\DosDevices\\PN5LAB");
 st=IoCreateDevice(driver,0,&name,FILE_DEVICE_UNKNOWN,FILE_DEVICE_SECURE_OPEN,FALSE,&dev);if(!NT_SUCCESS(st))return st;
 for(i=0;i<=IRP_MJ_MAXIMUM_FUNCTION;i++)driver->MajorFunction[i]=dispatch;
 st=IoCreateSymbolicLink(&linkname,&name);if(!NT_SUCCESS(st)){IoDeleteDevice(dev);return st;}
 status[0]=6;status[1]=1;status[2]=firmware.rsdp_rev;status[3]=firmware.fadt_rev;status[4]=WP_FW_MINOR(firmware.fadt_rev,firmware.fadt_minor)|firmware.off_ok|(firmware.reset_ok<<1);
#ifdef PN_AML
 status[4]|=(pn_ntaml_tables()?4:0)|(pn_ntaml_prepared()?8:0)|(pn_apm_available()?16:0)|((ULONG)KeNumberProcessors<<8);
 status[7]=pn_apm_version();   /* APM BIOS version BCD (0 if unknown) */
#endif
 /* Keep the module resident even if registration is unavailable: an
    installed final callback must never point at an unloaded image. */
 wp_n5_initialize();
#ifdef WP_2000
 st=IoRegisterShutdownNotification(dev);
#else
 st=IoRegisterLastChanceShutdownNotification(dev);
#endif
 if(NT_SUCCESS(st) && wp_n5_arm(minor) && auto_owner(registry))
  wp_n5_set(1);
 status[5]=wp_n5_state();
 mark(60);driver->DriverUnload=0;dev->Flags&=~DO_DEVICE_INITIALIZING;return STATUS_SUCCESS;
}

NTSTATUS NTAPI DriverEntry(PDRIVER_OBJECT driver,PUNICODE_STRING registry){
 NTSTATUS result=start_driver(driver,registry);
#ifdef PN_AML
 if(!NT_SUCCESS(result))pn_ntreg_release(&firmware);
#endif
 return result;
}
