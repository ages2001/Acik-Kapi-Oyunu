#ifndef WINPOWER_LINKOWN_H
#define WINPOWER_LINKOWN_H
#include <windows.h>
/* One REG_BINARY value stores the exact created path and its byte identity. */
#define LO_LINK_MAGIC 0x57504c32UL
struct lo_record { DWORD magic;char path[MAX_PATH];BYTE hash[32]; };
BOOL lo_save(const char *key,const char *path,const char *name);
BOOL lo_remove(const char *key,const char *name);
BOOL lo_undo(void);
BOOL lo_newfile(const char *path);
BOOL lo_finish9(const char *folder);
unsigned lo_notice(void);
const char *lo_reason(void);
#endif
