#ifndef WINPOWER_FWVER_H
#define WINPOWER_FWVER_H
/* The old fixed-size driver replies reserve the high bits of capabilities.
   Previous clients read their original low-bit flags unchanged. */
#define WP_FW_MINOR(rev,minor) (((rev)==5||(rev)==6)&&(minor)<=255 ? \
 (0x80000000UL|((unsigned long)(minor)<<16)) : 0UL)
#define wp_minor(flags) (((flags)&0x80000000UL)?(unsigned)(((flags)>>16)&255U):0xffffU)
#endif
