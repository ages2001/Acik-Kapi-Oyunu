/* x64 APM stub. Long mode cannot call the 16-bit real-mode APM BIOS, so the
   AMD64 build has no APM fallback - it requires usable ACPI power-off
   registers and sleep-state information on the running platform. These replace NTAPM.C in the x64 build. */
#include "NTAPM.H"
int pn_apm_init(void){return 0;}
int pn_apm_available(void){return 0;}
unsigned pn_apm_version(void){return 0;}
void pn_apm_off(void){}
void pn_apm_cleanup(void){}
