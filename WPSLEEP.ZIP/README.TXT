WINPOWER v1.0
Power off, restart, suspend and hibernate

Choose the bin directory for the installed operating system.

  DOS                      DOS power utilities
  WIN1, WIN2, WIN3         Windows 1.x, 2.x and 3.x
  WIN386                   Windows/386 2.11
  WIN9X                    Windows 95, 98 and Me x86
  NT3, NT4                 Windows NT 3.x and 4.0 x86
  2KXP, XPAMD64            Windows 2000 and XP x86, or XP x64
  NT6X86, NT6AMD64         Vista and newer x86, or x64

Extract the complete matching directory. Run SETUP.EXE on Win9x and NT.
On Win16, use PNINST.EXE. Read INSTALL.TXT for the OS-specific steps.

The Win32 and Win64 Power Center opens its Sleep states panel with the
Sleep button or Alt+S. The panel lists the current S0 session, Low Power
Idle, S1, S2, S3, S4 and S5 and displays the primary graphics adapter.
Suspend uses a supported OS state. On supported NT versions the list also
allows a minimum standby state. Windows can choose a deeper state. S4
requires working session hibernation, a full hibernation file on systems
with file types, sufficient disk space and OS policy permission.

The Windows power manager saves device and application state. The panel
keeps wake sources enabled and uses the installed display driver. The
shutdown ownership preference applies to power off and restart. A BIOS
revision alone does not establish whether sleep or hibernation works.

DOS users can run WPSLEEP /STANDBY or WPSLEEP /SUSPEND. The utility
requests a firmware-managed transition and returns control to DOS. It
checks APM 1.2 capability bits and respects an existing APM connection.
On APM 1.0 and 1.1, firmware decides whether to accept the request.

TESTS.TXT gives the actual results with Standard VGA. BUILD.TXT describes
the clean build and the checksum verifier. The separate first-phase ZIP
WINPWR10.ZIP contains the full shutdown/restart qualification and the
three early Windows installation disks. Its SHA-256 is
495ac093d0545ce417cf932f2064adba6822d4bab2eba1368a7c05d36a95ec45.
